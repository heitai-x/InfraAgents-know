import dataclasses
import datetime
import functools
import os
import threading
import time
import traceback
from contextlib import contextmanager
from enum import IntEnum
from queue import Queue
from typing import Callable, Dict, Iterable, List, Optional, Tuple, Union

import torch

from tensorrt_llm.llmapi import DisaggScheduleStyle
from tensorrt_llm.serve.responses_utils import get_steady_clock_now_in_seconds

try:
    from cuda.bindings import runtime as cudart
except ImportError:
    from cuda import cudart

from tensorrt_llm._utils import (customized_gc_thresholds, is_trace_enabled,
                                 mpi_comm, mpi_disabled, nvtx_range,
                                 set_thread_local_mpi_comm, trace_func)
from tensorrt_llm.bindings.executor import (DisServingRequestStats,
                                            FinishReason, InflightBatchingStats,
                                            IterationStats, KvCacheStats,
                                            RequestStage, RequestStats,
                                            RequestType, SpecDecodingStats,
                                            StaticBatchingStats)
from tensorrt_llm.bindings.internal.batch_manager import (LlmRequestType,
                                                          ReqIdsSet)
from tensorrt_llm.inputs.multimodal import strip_mm_data_for_generation
from tensorrt_llm.llmapi.llm_args import PeftCacheConfig, WaitingQueuePolicy
from tensorrt_llm.logger import logger
from tensorrt_llm.mapping import CpType
from tensorrt_llm.runtime.generation import CUASSERT
from tensorrt_llm.tools.layer_wise_benchmarks import get_calibrator
from tensorrt_llm.tools.profiler.host_profile_tools.host_profiler import \
    host_profiler_context

from ..distributed import Distributed
from ..expert_statistic import ExpertStatistic
from ..models.modeling_llama import Llama4ForConditionalGeneration
from ..models.modeling_utils import DecoderModelForCausalLM
from ..modules.decoder_layer import DecoderLayer
from ..speculative.drafter import Drafter
from ..speculative.spec_sampler_base import SampleStateTensorsSpec
from ..speculative.speculation_gate import SpeculationGate
from .connectors.kv_cache_connector import KvCacheConnectorManager
from .dwdp import DwdpManager
from .error_classification import ErrorBudget
from .executor_request_queue import ExecutorRequestQueue, RequestQueueItem
from .guided_decoder import GuidedDecoder
from .handle_additional_outputs import HandleAdditionalOutputs
from .handle_logits import HandleLogits
from .hang_detector import HangDetector
from .kv_cache_transceiver import KvCacheTransceiver
from .llm_request import (ExecutorRequest, LlmRequest, LlmRequestState,
                          LlmResponse, get_draft_token_length)
from .model_engine import ModelEngine
from .perf_metrics_manager import PerfMetricsManager
from .request_utils import (RequestBroadcaster, attach_py_objects_to_requests,
                            get_from_waiting_queue, merge_requests)
from .resource_manager import (KVCacheManagerV2, ResourceManager,
                               ResourceManagerType, request_context)
from .sampler import (AsyncWorkerMixin, Sampler, SamplerEvent, SampleState,
                      SampleStateTensors, TRTLLMSampler)
from .scheduler import (RequestScheduler, ScheduledRequests,
                        SerializableSchedulerOutput, WaitingQueue,
                        create_waiting_queue)
from .scheduler.adp_router import ADPRouter

# Environment variable to specify iteration ranges for profiling start/stop.
# Format: "start1-stop1,start2-stop2,..." or single iterations "iter1,iter2,..."
PROFILE_START_STOP_ENV_VAR_NAME = "TLLM_PROFILE_START_STOP"

# Environment variable to enable PyTorch profiler tracing.
# Set to a path to save detailed tracing of PyTorch operations.
PROFILE_TRACE_ENV_VAR_NAME = "TLLM_TORCH_PROFILE_TRACE"

# Environment variable to control which ranks print step logging.
# Format: comma-separated rank IDs, e.g. "0,1,3", or "all" for all ranks.
# Default: "0" (only rank 0 prints, matching existing behavior).
PROFILE_LOG_RANKS_ENV_VAR_NAME = "TLLM_PROFILE_LOG_RANKS"


class PPCommTag(IntEnum):
    """
    Unique tags for pipeline parallelism communication.
    """
    TERMINATION = 20000
    SCHEDULE_RESULT = 20001
    EXECUTED_BATCH_NUM = 20002
    SAMPLE_STATE = 20003


@functools.cache
def _load_iteration_indexes(env_var: str):
    spans = os.environ.get(env_var, None)
    starts, stops = [], []

    if spans:
        spans = spans.split(',')

        for span in spans:
            try:
                if '-' in span:
                    start, stop = span.strip().split('-')
                    starts.append(int(start))
                    stops.append(int(stop))
                else:
                    it = int(span.strip())
                    starts.append(it)
                    stops.append(it)
            except ValueError as e:
                raise ValueError(
                    f"Cannot parse span in environment variable `{env_var}`: {e}"
                ) from None

    return frozenset(starts), frozenset(stops)


def _strip_py_multimodal_data_post_prefill(request: LlmRequest) -> None:
    """Drop pinned encoder cache and raw pre-encoder tensors after prefill completes.

    Wraps `strip_mm_data_for_generation` and mutates the shared `request.py_multimodal_data`
    in-place so the `LlmRequest`'s multimodal tensors actually get freed (unlike
    `MultimodalParams.strip_for_generation`, which rebinds a per-forward-call wrapper's attribute
    and leaves the request's dict untouched).
    """
    mm_data = getattr(request, "py_multimodal_data", None)
    if not mm_data:
        return
    strip_mm_data_for_generation(mm_data)


@dataclasses.dataclass
class BatchState:
    scheduled_requests: ScheduledRequests
    sample_state: SampleState

    iter_start_time: float = 0
    iter_stats: IterationStats = None


@dataclasses.dataclass
class BatchStatePP(BatchState):
    microbatch_id: int = -1


class AsyncTransferManager:
    """
    Handle asynchronous transfer of KV cache after a request has completed.
    When running with both the KV cache transceiver and the KV cache connector, we must ensure that BOTH transfers (if any) are completed before we can release the KV cache blocks.
    The AsyncTransferManager has a few key responsibilities:
    1. Track requests in transfer.
    2. Pin blocks for reuse while blocks are in transfer.
    3. Unpin blocks after all transfers are complete.

    TODO(jthomson04): This only handles async send/saving, not loading. Loading kv cache is handled through a separate codepath. Eventually, we'll want to merge these two paths.
    """

    class RequestTransferMetadata:

        def __init__(self, block_id: Optional[int]):
            self.block_id = block_id
            self.counter = 0

        def start_transfer(self):
            self.counter += 1

        def end_transfer(self) -> bool:
            """
            Returns:
                bool: True if there are no more transfers for this request
            """
            self.counter -= 1
            return self.counter == 0

    def __init__(self,
                 resource_manager: "ResourceManager",
                 should_store_blocks: bool = True):
        self.resource_manager = resource_manager
        self.kv_cache_manager = resource_manager.resource_managers.get(
            ResourceManagerType.KV_CACHE_MANAGER)

        self.should_store_blocks = should_store_blocks

        # Mapping of request id to the LlmRequest
        self._requests_in_transfer: Dict[int, LlmRequest] = dict()

        # Mapping of request id to the request metadata
        self._request_transfer_metadata: Dict[
            int, self.RequestTransferMetadata] = dict()

    def requests_in_transfer(self) -> Dict[int, LlmRequest]:
        return self._requests_in_transfer

    def start_transfer(self, request: LlmRequest):
        """
        Called when a Cache transceiver or connector transfer is started.
        1. Increment the counter for the request.
        2. Releases all resources except for the KV cache, if not already released.
        3. Store KV cache blocks for reuse.
        """

        req_id = request.py_request_id

        if req_id not in self._requests_in_transfer:
            for resource_mgr_type in (
                    ResourceManagerType.SEQ_SLOT_MANAGER,
                    ResourceManagerType.SPEC_RESOURCE_MANAGER):
                if resource_mgr_type in self.resource_manager.resource_managers and self.resource_manager.resource_managers[
                        resource_mgr_type] is not None:
                    self.resource_manager.resource_managers[
                        resource_mgr_type].free_resources(request)

            request.state = LlmRequestState.DISAGG_CONTEXT_TRANS_IN_PROGRESS

            if self.should_store_blocks:
                block_id = self.kv_cache_manager.store_blocks_for_reuse(
                    request, True)
            else:
                block_id = None

            self._requests_in_transfer[req_id] = request
            self._request_transfer_metadata[
                req_id] = self.RequestTransferMetadata(block_id)

        self._request_transfer_metadata[req_id].start_transfer()

    def end_transfer(self, request: LlmRequest) -> bool:
        """
        Called after a send of KV cache is complete.
        1. Decrements counter for request.
        2. If there are no more inflight transfers for this request, unpin the blocks and mark the request as complete.

        Returns:
            bool: True if the request should be terminated after call to end_transfer
        """
        try:
            transfer_metadata = self._request_transfer_metadata[
                request.py_request_id]
        except KeyError:
            logger.warning(
                f"Request {request.py_request_id} not found in transfer manager"
            )
            return False

        if transfer_metadata.end_transfer():
            self._requests_in_transfer.pop(request.py_request_id)
            self._request_transfer_metadata.pop(request.py_request_id)

            if self.should_store_blocks:
                self.kv_cache_manager.unpin_blocks_by_id(
                    transfer_metadata.block_id)

            # We don't want to overwrite any error state.
            if request.state != LlmRequestState.DISAGG_TRANS_ERROR:
                request.state = LlmRequestState.DISAGG_CONTEXT_COMPLETE

            return True

        return False

    def has_any_inflight_requests(self) -> bool:
        return len(self._requests_in_transfer) > 0


class PyExecutor:
    # Minimum number of async micro batches for async PP execution.
    # This is a trade-off between memory usage and performance.
    # If the number of micro batches is too small, the executor will spend too much time in synchronization.
    # If the number of micro batches is too large, the executor will spend too much host memory (No additional GPU memory is required).
    # 1024 in-flight micro batches can avoid synchronization in most cases and keep host memory usage low.
    MIN_ASYNC_MICRO_BATCH_NUM = 1024

    def __init__(
            self,
            resource_manager,
            scheduler: RequestScheduler,
            model_engine: ModelEngine,
            sampler: Sampler,
            dist: Distributed,
            max_num_sequences: int,
            drafter: Optional[Drafter] = None,
            disable_overlap_scheduler: bool = False,
            max_input_len: int = 0x7fffffff,
            max_batch_size: int = 8,
            max_beam_width: int = 1,
            max_draft_len: int = 0,
            max_total_draft_tokens: int = 0,
            kv_cache_transceiver: Optional[KvCacheTransceiver] = None,
            guided_decoder: Optional[GuidedDecoder] = None,
            garbage_collection_gen0_threshold: Optional[int] = None,
            start_worker: bool = True,
            kv_connector_manager: Optional[KvCacheConnectorManager] = None,
            max_seq_len: Optional[int] = None,
            peft_cache_config: Optional[PeftCacheConfig] = None,
            virtual_memory_pools: Optional[dict] = None,
            hang_detection_timeout: Optional[int] = None,
            execution_stream: Optional[torch.cuda.Stream] = None,
            waiting_queue_policy: WaitingQueuePolicy = WaitingQueuePolicy.FCFS,
            adp_router: Optional[ADPRouter] = None,
            dwdp_manager: Optional[DwdpManager] = None):
        super(PyExecutor, self).__init__()
        self.device_id = torch.cuda.current_device()
        self.global_rank = dist.rank
        # Store the execution stream for model forward operations.
        # This stream is used for proper synchronization with KVCacheTransferManager.
        # execution_stream can be provided by create_py_executor
        # Create a new stream if none provided
        self.execution_stream = execution_stream if execution_stream is not None else torch.cuda.Stream(
        )
        logger.info(
            f"[PyExecutor] execution_stream initialized: {self.execution_stream}. "
        )

        self.peft_cache_config = peft_cache_config

        self.iter_counter = 0
        # profile config
        self.profile_start_iters, self.profile_stop_iters = _load_iteration_indexes(
            PROFILE_START_STOP_ENV_VAR_NAME)

        # related modules
        self.resource_manager = resource_manager
        self.scheduler = scheduler
        self.model_engine = model_engine
        self.enable_attention_dp = model_engine.enable_attention_dp
        self.dist = dist
        self.sampler = sampler
        self.drafter = drafter
        self.draft_model_engine = getattr(self.drafter, "draft_model_engine",
                                          None)
        self.guided_decoder = guided_decoder
        self.disable_overlap_scheduler = disable_overlap_scheduler
        self.virtual_memory_pools = virtual_memory_pools

        # enqueue and _fetch_new_requests used data
        self.active = True
        self.max_beam_width = max_beam_width
        self.max_draft_len = max_draft_len
        self.max_total_draft_tokens = max_total_draft_tokens
        self.llm_args = self.model_engine.llm_args
        self.max_stats_len = max(self.llm_args.max_stats_len, 1)
        self.max_num_tokens = self.llm_args.max_num_tokens
        self.print_log = self.llm_args.print_iter_log
        self.enable_iter_perf_stats = self.llm_args.enable_iter_perf_stats
        self.enable_iter_req_stats = self.llm_args.enable_iter_req_stats
        self.stream_interval = self.llm_args.stream_interval
        self.perf_manager = PerfMetricsManager(
            enabled=getattr(self.llm_args, 'return_perf_metrics', False))
        self.attention_dp_enable_balance = (
            self.llm_args.attention_dp_config is not None
            and self.llm_args.attention_dp_config.enable_balance)
        if self.attention_dp_enable_balance:
            self.attention_dp_time_out_iters = self.llm_args.attention_dp_config.timeout_iters
            self.attention_dp_batching_wait_iters = self.llm_args.attention_dp_config.batching_wait_iters
        self.batch_wait_timeout_ms = self.llm_args.batch_wait_timeout_ms
        self.batch_wait_timeout_iters = self.llm_args.batch_wait_timeout_iters
        self.batch_wait_max_tokens_ratio = self.llm_args.batch_wait_max_tokens_ratio
        self.enable_batch_waiting = self.batch_wait_timeout_iters > 0 or self.batch_wait_max_tokens_ratio > 0

        self.num_fetch_requests_cur_rank = 0
        self.num_fetch_requests = 0
        self.shutdown_event = threading.Event()

        # Rolling acceptance tracking for spec decode (disable speculation if rolling acceptance is below threshold)
        spec_config = getattr(self.model_engine, 'spec_config', None)
        self.acceptance_window = getattr(
            spec_config, 'acceptance_window',
            None) if spec_config is not None else None
        self.acceptance_length_threshold = getattr(
            spec_config, 'acceptance_length_threshold',
            None) if spec_config is not None else None
        self.speculation_permanently_disabled = False
        self.speculation_gate = None
        if self.acceptance_window and self.acceptance_length_threshold is not None:
            self.speculation_gate = SpeculationGate(
                self.acceptance_window, self.acceptance_length_threshold)

        # response used data
        self.response_lock = threading.Lock()
        self.response_cv = threading.Condition(self.response_lock)
        self.responses = {}
        self.result_wait_queues = {}

        # kv cache events
        self.kv_cache_manager = self.resource_manager.resource_managers.get(
            ResourceManagerType.KV_CACHE_MANAGER)
        # V2 scheduler calls suspend_request() during scheduling, which
        # offloads GPU pages while preserving the radix tree.  The executor
        # does not need to call _terminate_requests (GPU resources are already
        # freed by suspend) or _pause_requests (V2's prepare_context handles
        # resume internally, so resetting to CONTEXT_INIT is unnecessary).
        self._scheduler_manages_kv_suspend = isinstance(self.kv_cache_manager,
                                                        KVCacheManagerV2)
        self.enable_kv_cache_events = self.kv_cache_manager is not None and self.kv_cache_manager.event_buffer_max_size > 0
        self.enable_kv_cache_reuse = self.kv_cache_manager is not None and self.kv_cache_manager.enable_block_reuse
        self.enable_partial_reuse_for_disagg = (
            self.enable_kv_cache_reuse
            and self.kv_cache_manager.enable_partial_reuse)

        self.max_input_len = max_input_len
        # _executor_loop private data
        self.max_num_active_requests = model_engine.get_max_num_sequences()
        self.active_requests: List[LlmRequest] = []
        self.expected_num_active_requests = 0
        # TODO: Remove the condition on the PP size once disagg support from KVCache reuse
        # path is fixed.
        # Buffer for responses generated inside _end_transfer_and_maybe_terminate.
        # With ADP, _enqueue_responses does a tp_gather collective.  When called
        # from _send_kv_async the owning DP rank has a response but the other
        # rank does not, causing a collective mismatch deadlock.  Buffering the
        # responses and flushing them at a synchronised point in the executor
        # loop avoids the mismatch.
        self._pending_transfer_responses: List[Tuple[int, LlmResponse]] = []

        self.async_transfer_manager = AsyncTransferManager(
            self.resource_manager,
            should_store_blocks=self.enable_partial_reuse_for_disagg
            and not self.kv_cache_manager.is_vswa and self.dist.pp_size == 1)

        # Router is built after async_transfer_manager so KVCacheAwareADPRouter
        # can receive the transfer-manager reference at construction time.
        self.adp_router: ADPRouter = ADPRouter.create(
            dist=self.dist,
            kv_cache_manager=self.kv_cache_manager,
            attention_dp_config=self.llm_args.attention_dp_config,
            async_transfer_manager=self.async_transfer_manager,
        )

        self.previous_batch: Optional[BatchState] = None
        self.has_previous_draft_tokens = False
        self.num_scheduled_requests: int = 0
        self.benchmark_req_queues_size = int(
            os.environ.get("TLLM_BENCHMARK_REQ_QUEUES_SIZE", 0))

        # list of requests in each PP micro batch
        self.num_micro_batches = max(self.dist.pp_size,
                                     self.MIN_ASYNC_MICRO_BATCH_NUM)
        self.micro_batches: List[BatchStatePP
                                 | None] = [None] * self.num_micro_batches
        self.send_handles = [None] * self.num_micro_batches
        # schedule handle for PP to propagate the first PP rank's schedule result
        self.send_schedule_handles = [None] * self.num_micro_batches
        self.send_expected_batch_num_handles = [None] * self.num_micro_batches
        self.unhandled_batch_counter = 0
        self.pp_scheduler_max_retry_count = int(
            os.environ.get("TLLM_PP_SCHEDULER_MAX_RETRY_COUNT", 10))
        self.pp_multi_stream_sample = os.environ.get(
            "TRTLLM_PP_MULTI_STREAM_SAMPLE", "1") == "1"
        self.sample_stream = torch.cuda.Stream()
        self.finish_sample_event = torch.cuda.Event()
        if (self.dist.pp_size > 1 and self.pp_multi_stream_sample
                and isinstance(self.sampler, TRTLLMSampler)):
            # TRTLLM sampler uses default stream for store and algorithms.
            # To enable multi-stream sampling, we need to re-initialize
            # the sampler store and algorithms on the sample stream.
            with torch.cuda.stream(self.sample_stream):
                self.sampler._initialize_store()
                self.sampler._instantiate_algorithms()

        # Set of request IDs that are currently in flight across all micro batches.
        # The scheduler will avoid scheduling requests that are already in flight.
        self.inflight_req_ids = ReqIdsSet()

        # During warmup, we don't enable the profiler
        # Run warmup on the execution_stream for proper synchronization with
        # KVCacheTransferManager's onboard/offload operations.
        self.is_warmup = True

        self.execution_stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(self.execution_stream):
            self.model_engine.warmup(self.resource_manager)
            if self.draft_model_engine is not None:
                self.draft_model_engine.warmup(self.resource_manager)

        # Ensure the default stream waits for execution_stream to complete
        # before subsequent operations.
        torch.cuda.current_stream().wait_stream(self.execution_stream)
        self.is_warmup = False

        # Snapshot some cumulative KV cache counters so that stats reported to
        # users exclude blocks reused and missed during warmup dummy requests.
        if hasattr(self.kv_cache_manager, 'snapshot_warmup_baseline'):
            self.kv_cache_manager.snapshot_warmup_baseline()

        self.is_shutdown = False
        self._fatal_error: Optional[BaseException] = None
        self._error_budget = ErrorBudget()
        self.max_batch_size = max_batch_size
        self.adp_ctx_waiting_iters_count = 0
        self.adp_ctx_batching_wait_iters_count = 0
        self.batch_wait_iters_count = 0

        def on_detected():
            self._handle_errors(
                f"Hang detected on rank {self.global_rank} in PyExecutor.")
            self.shutdown_event.set()
            self.is_shutdown = True

        self.hang_detector = HangDetector(timeout=hang_detection_timeout,
                                          on_detected=on_detected)

        # request fetcher initialization
        self._set_global_steady_clock_offset()
        self.executor_request_queue = ExecutorRequestQueue(
            dist=self.dist,
            max_batch_size=max_batch_size,
            enable_iter_perf_stats=self.enable_iter_perf_stats,
            batch_wait_timeout_ms=self.batch_wait_timeout_ms,
        )
        # When overlap scheduler is enabled then when starting to handle a new prompt,
        # _sample_async is called twice before the first call to update_requests:
        # - 1st time as a context request that operates on the 1st generated token
        # - 2nd time as a generation request that operates on the 2nd generated token.
        # and only after these two calls the sampler's update_request method is called.
        # So in a sampler that works by the expected flow of handling the logits in
        # _sample_async, every update_request doesn't handle the newest token, but one
        # before it. Since all these calls work on the same request object, then its
        # logits storage contains the logits of both the token update_requests should work
        # on, and also its next token. Thus, excluding the last generation logits from any
        # getter is required.
        self.should_exclude_last_generation_logits = (
            not self.disable_overlap_scheduler and self.dist.pp_size == 1)

        # Request processing state (managed by executor)
        self.canceled_req_ids: List[int] = []
        self.control_requests: List[RequestQueueItem] = []
        self.request_accumulated: List[RequestQueueItem] = []
        self.new_active_requests_queue_latency_ms = 0.0
        self._disable_mpi = mpi_disabled()
        self.request_broadcaster = RequestBroadcaster(self.dist,
                                                      self.hang_detector)

        # Waiting queue for requests that have been fetched but not yet scheduled
        self.waiting_queue: WaitingQueue = create_waiting_queue(
            waiting_queue_policy)

        self.control_request_barrier = threading.Event()
        self.control_action_done = threading.Event()

        self.stats_lock = threading.Lock()
        self.stats = []
        self._latest_kv_iter_stats = None
        self._last_kv_iter_stats_fetch_iter = None
        self._kv_iter_stats_interval = getattr(
            getattr(self.llm_args, 'kv_cache_config', None),
            'iteration_stats_interval', 1)
        self.gather_all_responses = False

        self.kv_cache_transceiver = kv_cache_transceiver
        self.is_benchmark_disagg = (self.benchmark_req_queues_size > 0
                                    and self.kv_cache_transceiver is not None)
        # True while the benchmark disagg fill phase is in progress (waiting
        # for all benchmark requests to complete KV transfer before the first
        # forward pass).  Cleared by _check_benchmark_disagg_gate when the
        # can_forward gate opens.  Used by _should_skip_dummy_for_benchmark_disagg
        # to prevent permanent dummy insertion during fill; once False, the
        # normal dummy add-forward-terminate lifecycle handles taper-down.
        # Only relevant in benchmark disagg mode; False otherwise.
        self._benchmark_fill_phase_active = self.is_benchmark_disagg

        # Initialize disagg PP termination handler if needed
        self._disagg_pp_termination_handler = None
        if self.dist.pp_size > 1 and self.enable_kv_cache_reuse and self.kv_cache_transceiver:
            self._disagg_pp_termination_handler = DisaggPPTerminationHandler(
                self.dist, self._do_terminate_request)

        if self.dist.pp_size > 1:
            self.event_loop = self._executor_loop_pp
            # `TLLM_PP_ASYNC_BROADCAST_SAMPLE_STATE` controls whether to broadcast the sample state asynchronously.
            # If true, the executor loop can broadcast and handle sample states asynchronously to achieve best perf.
            # If false, the executor loop can only broadcast and handle each sample state in a pre-defined iteration.
            # It is only for debugging purposes.
            # Some tests can disable it to get a deterministic behavior.
            self.pp_async_broadcast_sample_state = os.environ.get(
                "TLLM_PP_ASYNC_BROADCAST_SAMPLE_STATE", "1") == "1"
        else:
            self.event_loop = self._executor_loop if self.disable_overlap_scheduler else self._executor_loop_overlap
        if is_trace_enabled("TLLM_TRACE_EXECUTOR_LOOP"):
            self.event_loop = trace_func(self.event_loop)

        if dwdp_manager is not None and not self.disable_overlap_scheduler:
            raise ValueError(
                "DWDP requires disable_overlap_scheduler=True. "
                "Overlap scheduler is not yet supported with DWDP.")

        if self.drafter is not None:
            if self.event_loop.__name__ == self._executor_loop_pp.__name__:
                raise NotImplementedError(
                    "Drafting is not supported for selected executor loop. "
                    "Please disable disagg/pipeline parallelism scheduler.")
        self.garbage_collection_gen0_threshold = garbage_collection_gen0_threshold
        self.max_seq_len = max_seq_len

        self.worker_started = False
        self.worker_lock = threading.Lock()

        self.kv_connector_manager = kv_connector_manager

        self._maybe_init_kv_connector_manager()

        self.dwdp_manager = dwdp_manager

        if start_worker:
            self.start_worker()

    def _maybe_init_kv_connector_manager(self):
        if self.kv_connector_manager is not None:
            if self.kv_cache_transceiver is not None:
                logger.warning(
                    "Both KV Cache Connector and KV Cache Transceiver are enabled. Are you sure you want to do this?"
                )

            if self.dist.pp_size > 1:
                raise NotImplementedError(
                    "KV Cache Connector is not supported with pipeline parallelism."
                )

            if self.kv_cache_manager is None:
                raise ValueError(
                    "KV Cache Connector requires a KV Cache Manager.")

            kv_tensor = self.kv_cache_manager.get_unique_primary_pool()
            self.kv_connector_manager.worker.register_kv_caches(kv_tensor)

            # For each of our layers, we need to register the pre/post hooks.
            # These are used for methods like `wait_for_layer_load` and `save_kv_layer`.
            for _name, module in self.model_engine.model.named_modules():
                if isinstance(module, DecoderLayer):
                    module.register_forward_pre_hook(
                        self.kv_connector_manager.layer_pre_hook)
                    module.register_forward_hook(
                        self.kv_connector_manager.layer_post_hook)

            self.kv_connector_manager.wait_for_initialization()

    def _end_transfer_and_maybe_terminate(self, request: LlmRequest):
        if self.kv_cache_transceiver and request in self.active_requests:
            # Fast-transfer: KV transfer completed in the same iteration
            # before _handle_responses could run. Create the response now
            # while state is still TRANS_IN_PROGRESS (required by C++
            # createResult). Then proceed with end_transfer + termination.
            response = request.create_response(False, self.dist.rank)
            if response:
                response.result.cached_tokens = request.cached_tokens
                # Buffer the response instead of enqueueing immediately.
                # With ADP, _enqueue_responses does a tp_gather collective.
                # Calling it here would deadlock because only the owning DP
                # rank reaches this point; the other DP rank never enters
                # the matching collective.  The buffer is flushed later at
                # _flush_pending_transfer_responses where all ranks
                # participate.
                self._pending_transfer_responses.append(
                    (request.py_request_id, response))
            if self.async_transfer_manager.end_transfer(request):
                self.active_requests.remove(request)
                self._terminate_request(request)
            return
        if self.async_transfer_manager.end_transfer(request):
            # When should_store_blocks is True, _handle_responses already
            # terminated this request via the early-termination path
            # (enable_partial_reuse_for_disagg branch). Skip the redundant
            # termination to avoid double free_resources calls.
            if not self.async_transfer_manager.should_store_blocks:
                self._terminate_request(request)

    def _flush_pending_transfer_responses(self):
        """Enqueue buffered transfer-completion responses.

        Must be called at a point where ALL DP ranks execute in lockstep so
        that the tp_gather inside _enqueue_responses does not deadlock.
        """
        responses = self._pending_transfer_responses
        self._pending_transfer_responses = []
        if responses or self.enable_attention_dp:
            # Even when this rank has no responses we must participate in the
            # collective when ADP is enabled so that the other rank's gather
            # can complete.
            self._enqueue_responses(responses)

    # Performance metrics methods are in PerfMetricsManager (self.perf_manager)

    def _event_loop_wrapper(self):
        try:
            # Skip line profiler during warmup/memory estimation phase to avoid
            # saving incomplete results that would be overwritten anyway
            enable_profiler = bool(os.environ.get(
                "TLLM_LINE_PROFILER_PATH")) and not self.is_warmup
            with host_profiler_context(enable=enable_profiler), \
                 customized_gc_thresholds(self.garbage_collection_gen0_threshold):
                self.event_loop()
        except Exception as e:
            logger.error(f"Error in event loop: {e}")
            logger.error(traceback.format_exc())
            raise e
        finally:
            self._executor_loop_cleanup()

    @property
    def is_warmup(self) -> bool:
        return getattr(self, "_is_warmup", False)

    @is_warmup.setter
    def is_warmup(self, value: bool):
        self._is_warmup = value
        # Set warmup flag in model engine to trigger torch compile and avoid moe load balancer statistics update
        self.model_engine.is_warmup = value
        if self.draft_model_engine is not None:
            self.draft_model_engine.is_warmup = value

    def start_worker(self):
        with self.worker_lock:
            if not self.worker_started:
                if self.dist.pp_size > 1:
                    self.executed_batch_queue: Queue[BatchStatePP] = Queue(
                        maxsize=self.num_micro_batches)
                    self.executed_batch_response_queue: Queue[
                        BatchStatePP] = Queue(maxsize=-1)
                    broadcast_sample_state_loop = self._broadcast_sample_state_loop
                    if is_trace_enabled("TLLM_TRACE_EXECUTOR_LOOP"):
                        broadcast_sample_state_loop = trace_func(
                            broadcast_sample_state_loop)
                    self.broadcast_sample_state_handler = threading.Thread(
                        target=broadcast_sample_state_loop,
                        daemon=True,
                        name="broadcast_sample_state_handler",
                    )
                    self.broadcast_sample_state_handler.start()
                self.worker_thread = threading.Thread(
                    target=self._event_loop_wrapper, daemon=True)
                self.worker_thread.start()
                self.worker_started = True
            # Start the sampler's async worker, if it is enabled
            if (isinstance(self.sampler, AsyncWorkerMixin)
                    and self.sampler.async_worker_enabled()):
                logger.info("Starting the async worker for sampler D2H copies")
                self.sampler.async_worker_start()

    def _set_global_steady_clock_offset(self):
        assert self.global_rank >= 0, "rank should be >= 0"

        # Sync all ranks
        self.dist.barrier()
        # Immediately take the local steady clock timestamp
        local_timestamp = get_steady_clock_now_in_seconds()
        all_rank_timestamps = self.dist.allgather(local_timestamp)
        if self.global_rank == 0:
            logger.info(
                f"global_steady_clock_offset at each rank: {[local_timestamp - ts for ts in all_rank_timestamps]}"
            )
        # Compute the steady clock offset between rank 0 and current rank
        global_steady_clock_offset = all_rank_timestamps[0] - local_timestamp
        LlmRequest.global_steady_clock_offset = global_steady_clock_offset
        logger.info(
            f"Setting global_steady_clock_offset: {global_steady_clock_offset} seconds for rank {self.global_rank}"
        )

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.shutdown()

    def enqueue_requests(
        self,
        requests: List[ExecutorRequest],
        result_wait_queue: "Optional[ray.actor.ActorHandle]" = None
    ) -> List[int]:
        """
        Enqueue new requests
        """
        req_ids = self.executor_request_queue.enqueue_requests(requests)
        if result_wait_queue is not None:
            with self.response_cv:
                for req_id in req_ids:
                    self.result_wait_queues[req_id] = result_wait_queue
        return req_ids

    def await_responses(
        self,
        id: Optional[Union[List[int], int]] = None,
        timeout: Optional[datetime.timedelta] = None,
    ) -> Union[List[List[LlmResponse]], List[LlmResponse]]:
        """
        Await ready responses
        Args:
            id (Optional[Union[List[int], int]]): Request id
            timeout (Optional[datetime.timedelta]): The maximum time to wait for new responses
        Returns:
            Union[List[LlmResponse], List[List[LlmResponse]]]: Responses
        """
        timeout = timeout.total_seconds() if timeout is not None else None
        if id is None:
            return self._await_any_response(timeout=timeout)
        if isinstance(id, int):
            return self._await_single_response(id=id, timeout=timeout)
        responses = []
        for req_id in id:
            responses.append(
                self._await_single_response(id=req_id, timeout=timeout))

        return responses

    def cancel_request(self, id: int):
        """
        Cancel the request with provided request id
        Args:
            id (int): The request id for which to cancel the response
        """
        self.executor_request_queue.enqueue_cancel_request(id)

    def shutdown(self):
        """
        Signals the server to shutdown.
        """
        self.executor_request_queue.enqueue_shutdown_request()
        self.shutdown_event.wait()
        if self.hang_detector.detected():
            # Early return here to avoid waiting for hanging threads.
            # Since `on_detected` has sent the error message as response,
            # this worker will be asked to shutdown immediately.
            # Since the whole process will shutdown after this `shutdown` call,
            # All threads and memory pools will be freed properly.
            logger.error("Hang detected, shutting down immediately.")
            return
        self.worker_thread.join()
        if self.dist.pp_size > 1:
            self.executed_batch_queue.put(None)
            self.broadcast_sample_state_handler.join()
        self.worker_started = False
        # Release CUDA graphs before resource managers free their GPU memory.
        # Resource managers (e.g. SuffixAutomatonManager) allocate GPU workspace
        # that is referenced by raw pointers inside captured CUDA graphs.  If
        # the workspace is freed first (and returned to the driver via
        # empty_cache), the subsequent CUDA graph teardown can trigger a
        # device-wide cudaErrorIllegalAddress when the driver touches metadata
        # for the now-freed memory regions.
        for engine in (self.model_engine, self.draft_model_engine):
            if engine is not None and hasattr(engine, '_release_cuda_graphs'):
                engine._release_cuda_graphs()
        # Ensure graph destruction has fully completed on device before
        # resource managers start freeing GPU-backed workspaces.
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        for manager in self.resource_manager.resource_managers.values():
            if manager:
                manager.shutdown()
        del self.model_engine
        if self.draft_model_engine is not None:
            del self.draft_model_engine
        if self.virtual_memory_pools is not None:
            keys = list(self.virtual_memory_pools.keys())
            for key in keys:
                del self.virtual_memory_pools[key]
        # Stop the sampler's async worker, if it was used
        if (isinstance(self.sampler, AsyncWorkerMixin)
                and self.sampler.async_worker_enabled()):
            self.sampler.async_worker_stop()
        if self.dwdp_manager is not None:
            self.dwdp_manager.__exit__(None, None, None)
            self.dwdp_manager = None

    def can_enqueue_requests(self) -> bool:
        """
        Indicates if the current process is allowed to enqueue requests
        """
        return self.executor_request_queue.can_enqueue_request()

    def get_latest_iteration_stats(self):
        """
        Returns the per-iterations statistics computed since last call to this method.
        Contains at most iter_stats_max_iterations iterations.
        """
        if self.enable_iter_perf_stats == False:
            return []

        latest_stats = (IterationStats(), None)
        with self.stats_lock:
            latest_stats = self.stats
            self.stats = []
        return latest_stats

    def get_latest_kv_cache_events(self):
        kv_cache_manager = self.resource_manager.resource_managers.get(
            ResourceManagerType.KV_CACHE_MANAGER)
        if not kv_cache_manager or not self.enable_kv_cache_events:
            return []

        events = kv_cache_manager.get_latest_events(0)
        return events

    def wait_shutdown(self):
        self.shutdown_event.wait()

    def enqueue_request(
            self,
            request: ExecutorRequest,
            query: Optional[List] = None,
            result_wait_queue: "Optional[ray.actor.ActorHandle]" = None) -> int:
        """
        Enqueue a new request, query is only used in `StarAttention`.
        """
        req_id = self.executor_request_queue.enqueue_request(request, query)
        if result_wait_queue is not None:
            with self.response_cv:
                self.result_wait_queues[req_id] = result_wait_queue
        return req_id

    def set_gather_responses(self, gather_all_responses):
        self.gather_all_responses = gather_all_responses

    @property
    def should_stop_processing(self):
        return self.is_shutdown and len(self.active_requests) == 0 and \
            len(self.waiting_queue) == 0

    @contextmanager
    def _profiler(self):
        it = -1
        enabled = False
        start_time = None

        # These events are used to record the time of the previous batch.
        # We need two set of the start-end events to record the time through
        # a ping-pong way so that it works with overlap scheduler.
        start_event_1 = None
        end_event_1 = torch.cuda.Event(enable_timing=True)
        start_event_2 = None
        end_event_2 = torch.cuda.Event(enable_timing=True)
        prev_device_step_time = None

        torch_trace_path = os.environ.get(PROFILE_TRACE_ENV_VAR_NAME, None)
        profile_start_stop = os.environ.get(PROFILE_START_STOP_ENV_VAR_NAME,
                                            None)
        enable_torch_trace = bool(torch_trace_path and profile_start_stop)
        if torch_trace_path and profile_start_stop is None:
            logger.warning(
                f"{PROFILE_START_STOP_ENV_VAR_NAME} environment variable "
                "needs to be set to enable the torch trace. Example to profile "
                f"iteration 10-20: export {PROFILE_START_STOP_ENV_VAR_NAME}=10-20"
            )

        if enable_torch_trace:
            activities = [
                torch.profiler.ProfilerActivity.CPU,
                torch.profiler.ProfilerActivity.CUDA,
                torch.profiler.ProfilerActivity.XPU,
            ]
            torch_profiler = torch.profiler.profile(activities=activities,
                                                    record_shapes=True,
                                                    with_modules=True)

        log_ranks_str = os.environ.get(PROFILE_LOG_RANKS_ENV_VAR_NAME, "0")
        if log_ranks_str.strip().lower() == "all":
            log_all_ranks = True
            log_ranks = set()
        else:
            log_all_ranks = False
            log_ranks = {int(r) for r in log_ranks_str.split(",")}

        calibrator = get_calibrator()

        def profile_step():
            nonlocal it, enabled, start_time, start_event_1, end_event_1, start_event_2, end_event_2, prev_device_step_time
            calibrator.post_step(it)
            if it in self.profile_stop_iters and not self.is_warmup:
                assert enabled, "Inconsistent CUDA profiling state"
                if enable_torch_trace:
                    torch_profiler.stop()
                    torch_profiler.export_chrome_trace(torch_trace_path)
                    logger.info(f"Profiling stopped at iteration {it}, "
                                f"trace saved to {torch_trace_path}")
                torch.cuda.cudart().cudaProfilerStop()
                calibrator.stop()
                enabled = False

            if start_time is not None and self.print_log and (
                    log_all_ranks or self.dist.rank in log_ranks):
                end_time = time.time()
                if it % 2 == 0:
                    end_event_1.record()
                    if start_event_2 is not None:
                        end_event_2.synchronize()
                        prev_device_step_time = start_event_2.elapsed_time(
                            end_event_2)
                else:
                    end_event_2.record()
                    if start_event_1 is not None:
                        end_event_1.synchronize()
                        prev_device_step_time = start_event_1.elapsed_time(
                            end_event_1)

                if prev_device_step_time is None:
                    prev_device_step_time = "N/A"  # Handle first iteration
                else:
                    prev_device_step_time = f"{prev_device_step_time}ms"
                host_step_time = (end_time - start_time) * 1000  # milliseconds
                formatted_timestamp = datetime.datetime.now().strftime(
                    "%Y-%m-%d %H:%M:%S")
                logger.info(
                    f"iter = {self.iter_counter}, "
                    f"global_rank = {self.global_rank}, "
                    f"rank = {self.dist.rank}, "
                    f"currank_total_requests = {self.num_fetch_requests_cur_rank}/"
                    f"{self.num_fetch_requests}, "
                    f"host_step_time = {host_step_time}ms, "
                    f"prev_device_step_time = {prev_device_step_time}, "
                    f"timestamp = {formatted_timestamp}, "
                    f"num_scheduled_requests: {self.num_scheduled_requests}, "
                    f"states = {self.model_engine.iter_states}")

            it += 1

            if it in self.profile_start_iters and not self.is_warmup:
                assert not enabled, "Inconsistent CUDA profiling state"
                calibrator.start()
                torch.cuda.cudart().cudaProfilerStart()
                if enable_torch_trace:
                    torch_profiler.start()
                logger.info(f"Profiling started at iteration {it}.")
                enabled = True
            calibrator.pre_step(it)
            start_time = time.time()
            if it % 2 == 0:
                if start_event_1 is None:
                    start_event_1 = torch.cuda.Event(enable_timing=True)
                start_event_1.record()
            else:
                if start_event_2 is None:
                    start_event_2 = torch.cuda.Event(enable_timing=True)
                start_event_2.record()

        try:
            yield profile_step
        finally:
            if enabled:
                # Stop on early exit / exception
                if enable_torch_trace:
                    torch_profiler.stop()
                    torch_profiler.export_chrome_trace(torch_trace_path)
                    logger.info(f"Profiling stopped at iteration {it}, "
                                f"trace saved to {torch_trace_path}")
                torch.cuda.cudart().cudaProfilerStop()
                calibrator.stop()

    def _get_init_iter_stats(self, num_new_active_requests,
                             new_active_requests_queue_latency_ms):
        stats = IterationStats()
        stats.timestamp = datetime.datetime.now().strftime(
            "%m-%d-%Y %H:%M:%S.%f")

        stats.num_new_active_requests = num_new_active_requests
        stats.num_active_requests = len(self.active_requests)
        stats.new_active_requests_queue_latency_ms = new_active_requests_queue_latency_ms
        stats.inflight_batching_stats = InflightBatchingStats()
        # staticBatchingStats is not used in pytorch path
        stats.static_batching_stats = StaticBatchingStats()

        # Create specdec_stats if speculative decoding is enabled
        # Either via spec_resource_manager (two-model mode) or spec_config (one-model mode)
        spec_resource_manager = self.resource_manager.resource_managers.get(
            ResourceManagerType.SPEC_RESOURCE_MANAGER)
        has_spec_config = self.model_engine.spec_config is not None

        if spec_resource_manager is not None or has_spec_config:
            stats.specdec_stats = SpecDecodingStats()
            # Reset draft latency at the start of each iteration to prevent stale values
            # from previous iterations when speculation is disabled
            if self.drafter is not None and hasattr(self.drafter,
                                                    'last_draft_latency_ms'):
                self.drafter.last_draft_latency_ms = 0.0

        return stats

    def _populate_req_stats(
            self, finished_requests: List[LlmRequest],
            active_requests: List[LlmRequest],
            scheduled_requests: ScheduledRequests
    ) -> Optional[List[RequestStats]]:

        def get_req_stats(req: LlmRequest) -> RequestStats:
            req_stat = RequestStats()
            req_stat.id = req.request_id
            req_stat.context_prefill_position = req.context_current_position
            req_stat.num_generated_tokens = req.max_beam_num_tokens - req.orig_prompt_len
            req_stat.avg_num_decoded_tokens_per_iter = req.avg_decoded_tokens_per_iter
            req_stat.alloc_total_blocks_per_request = req.alloc_total_blocks
            req_stat.alloc_new_blocks_per_request = req.alloc_new_blocks
            req_stat.reused_blocks_per_request = req.reused_blocks
            req_stat.missed_blocks_per_request = req.missed_blocks
            req_stat.kv_cache_hit_rate_per_request = req.kv_cache_hit_rate
            req_stat.scheduled = req in scheduled_requests.context_requests or req in scheduled_requests.generation_requests
            if req.llm_request_type == LlmRequestType.LLMREQUEST_TYPE_CONTEXT_ONLY or req.llm_request_type == LlmRequestType.LLMREQUEST_TYPE_GENERATION_ONLY:
                req_stat.dis_serving_stats = DisServingRequestStats()
                req_stat.dis_serving_stats.kv_cache_transfer_ms = req.kv_cache_transfer_time_ms
                req_stat.dis_serving_stats.kv_cache_size = req.kv_cache_size
            return req_stat

        def get_queued_req_stats(request_id: int) -> RequestStats:
            req_stat = RequestStats()
            req_stat.id = request_id
            req_stat.context_prefill_position = 0
            req_stat.num_generated_tokens = 0
            req_stat.avg_num_decoded_tokens_per_iter = 0
            req_stat.alloc_total_blocks_per_request = 0
            req_stat.alloc_new_blocks_per_request = 0
            req_stat.reused_blocks_per_request = 0
            req_stat.missed_blocks_per_request = 0
            req_stat.kv_cache_hit_rate_per_request = 0
            return req_stat

        req_stats = []
        for req in active_requests:
            req_stat = get_req_stats(req)
            req_stat.stage = req.stage
            req_stats.append(req_stat)

        for req in list(self.executor_request_queue.get_request_queue().queue):
            if isinstance(req, RequestQueueItem):
                req_stat = get_queued_req_stats(req.id)
                req_stat.stage = RequestStage.QUEUED
                req_stats.append(req_stat)

        for req in finished_requests:
            req_stat = get_req_stats(req)
            req_stat.stage = RequestStage.GENERATION_COMPLETE
            req_stats.append(req_stat)

        return req_stats

    def _update_iter_stats(self, stats, iter_latency_ms, num_completed_requests,
                           scheduled_batch, micro_batch_id) -> IterationStats:
        stats.iter_latency_ms = iter_latency_ms

        stats.num_queued_requests = self.executor_request_queue.get_request_queue_size(
        )
        stats.num_completed_requests = num_completed_requests
        stats.max_num_active_requests = self.max_num_active_requests

        end, total_gpu_memory = torch.cuda.mem_get_info()
        stats.gpu_mem_usage = total_gpu_memory - end
        stats.cpu_mem_usage = 0
        stats.pinned_mem_usage = 0

        stats.iter = self.iter_counter

        kv_cache_manager = self.resource_manager.resource_managers.get(
            ResourceManagerType.KV_CACHE_MANAGER)
        if kv_cache_manager is not None:
            kv_stats = kv_cache_manager.get_kv_cache_stats()
            kv_stats_to_save = KvCacheStats()
            kv_stats_to_save.max_num_blocks = kv_stats.max_num_blocks
            kv_stats_to_save.free_num_blocks = kv_stats.free_num_blocks
            kv_stats_to_save.used_num_blocks = kv_stats.used_num_blocks
            kv_stats_to_save.tokens_per_block = kv_stats.tokens_per_block
            kv_stats_to_save.alloc_total_blocks = kv_stats.alloc_total_blocks
            kv_stats_to_save.alloc_new_blocks = kv_stats.alloc_new_blocks
            kv_stats_to_save.reused_blocks = kv_stats.reused_blocks
            kv_stats_to_save.missed_blocks = kv_stats.missed_blocks
            kv_stats_to_save.cache_hit_rate = kv_stats.cache_hit_rate
            stats.kv_cache_stats = kv_stats_to_save

            # Collect per-iteration stats (with deltas) at configured interval.
            # Between calls, C++ deltas accumulate so the reported values cover multiple iterations.
            # Guard: only fetch once per iter_counter to avoid draining deltas in PP multi-batch.
            if (self.iter_counter % self._kv_iter_stats_interval == 0 and
                    self._last_kv_iter_stats_fetch_iter != self.iter_counter):
                self._latest_kv_iter_stats = kv_cache_manager.get_iteration_stats(
                )
                self._last_kv_iter_stats_fetch_iter = self.iter_counter
            else:
                self._latest_kv_iter_stats = None

        stats.inflight_batching_stats.num_context_requests = scheduled_batch.num_context_requests
        stats.inflight_batching_stats.num_gen_requests = scheduled_batch.num_generation_requests
        stats.inflight_batching_stats.num_scheduled_requests = stats.inflight_batching_stats.num_context_requests + stats.inflight_batching_stats.num_gen_requests
        stats.inflight_batching_stats.num_paused_requests = len(
            scheduled_batch.paused_requests)
        stats.inflight_batching_stats.avg_num_decoded_tokens_per_iter = 0
        stats.inflight_batching_stats.micro_batch_id = micro_batch_id

        if stats.specdec_stats is not None:
            total_draft_tokens = 0
            total_accepted_tokens = 0
            num_requests_with_draft = 0

            # Aggregate stats from all generation requests
            for req in scheduled_batch.generation_requests:
                draft_len = getattr(req, 'num_draft_tokens', 0)
                py_draft_tokens = getattr(req, 'py_draft_tokens', None)
                py_num_accepted = getattr(req, 'py_num_accepted_draft_tokens',
                                          None)

                # Use py_draft_tokens length if num_draft_tokens is 0
                if draft_len == 0 and py_draft_tokens is not None:
                    # Count non-zero draft tokens
                    draft_len = sum(1 for t in py_draft_tokens if t != 0)

                if draft_len > 0:
                    total_draft_tokens += draft_len
                    accepted_tokens = py_num_accepted if py_num_accepted is not None else 0
                    total_accepted_tokens += accepted_tokens
                    num_requests_with_draft += 1

            stats.specdec_stats.num_draft_tokens = total_draft_tokens
            stats.specdec_stats.num_accepted_tokens = total_accepted_tokens
            stats.specdec_stats.num_requests_with_draft_tokens = num_requests_with_draft

            # Calculate acceptance length: average tokens produced per step for requests with draft tokens
            if num_requests_with_draft > 0:
                # acceptance_length = (total_accepted_tokens + num_requests_with_draft) / num_requests_with_draft
                # Each request produces 1 target token + accepted draft tokens per iteration
                stats.specdec_stats.acceptance_length = float(
                    total_accepted_tokens +
                    num_requests_with_draft) / float(num_requests_with_draft)
            else:
                stats.specdec_stats.acceptance_length = 0.0

            # Get draft latency from drafter if available (only for two-model mode)
            # Only use draft latency if there were actually draft tokens in this iteration
            draft_latency_ms = 0.0
            if total_draft_tokens > 0 and self.drafter is not None and hasattr(
                    self.drafter, 'last_draft_latency_ms'):
                draft_latency_ms = getattr(self.drafter,
                                           'last_draft_latency_ms', 0.0)

            stats.specdec_stats.iter_latency_ms = draft_latency_ms

            # Calculate draft overhead
            stats.specdec_stats.draft_overhead = 0.0 if iter_latency_ms <= 0.0 else float(
                draft_latency_ms) / float(iter_latency_ms)

        # Extra per-iteration request-aggregate counters attached to
        # inflight_batching_stats. These complement the existing
        # num_context_requests / num_gen_requests / num_ctx_tokens /
        # num_paused_requests members with token-weighted counts and
        # queue/paused KV accounting.

        # Tokens read from prior state (prefix-cache hits and
        # previously-chunked tokens) summed across scheduled context
        # requests; complements num_ctx_tokens (tokens computed this
        # iteration). Read from py_last_context_chunk, a Python-side
        # cache set by _update_request_states before state mutation — it
        # stays valid after the request transitions to
        # GENERATION_IN_PROGRESS, unlike the C++ getContextChunkSize() /
        # getContextCurrentPosition() accessors that would raise
        # RuntimeError on a mutated request.
        num_ctx_kv_tokens = 0
        for req in scheduled_batch.context_requests:
            if getattr(req, "is_attention_dp_dummy", False):
                continue
            last_chunk = getattr(req, "py_last_context_chunk", None)
            if last_chunk is not None and last_chunk[0] is not None:
                start, _end = last_chunk
                num_ctx_kv_tokens += start
            else:
                try:
                    num_ctx_kv_tokens += \
                        req.context_current_position
                except RuntimeError:
                    pass

        # Total KV context length (prompt + tokens generated so far)
        # summed across scheduled generation requests.
        num_gen_kv_tokens = 0
        for req in scheduled_batch.generation_requests:
            if getattr(req, "is_attention_dp_dummy", False):
                continue
            try:
                num_gen_kv_tokens += req.get_num_tokens(0)
            except RuntimeError:
                pass

        # Normal requests waiting in the executor_request_queue that have
        # never been scheduled. Excludes non-normal control items
        # (shutdown/cancel) and items with a missing payload. Each queued
        # item is a RequestQueueItem wrapping an ExecutorRequest
        # (tle::Request). Requests are routed by request_type:
        #   - CONTEXT_AND_GENERATION (default) and CONTEXT_ONLY
        #     (disagg-prefill side) -> queued-context counters.
        #   - GENERATION_ONLY (disagg-decode side, awaiting KV transfer
        #     before they can start decoding) -> queued-gen counters.
        # On a non-disagg engine all items land in the context counters;
        # on a disagg-decode engine all items land in the gen counters.
        num_queued_context_requests = 0
        num_queued_ctx_tokens = 0
        num_queued_gen_requests = 0
        num_queued_gen_kv_tokens = 0
        for item in list(self.executor_request_queue.get_request_queue().queue):
            if not item.is_normal_request:
                continue
            if item.request is None:
                continue
            try:
                token_count = len(item.request.input_token_ids)
            except (AttributeError, TypeError) as e:
                # Unusual request shape with no usable token payload;
                # exclude from all queued counters so downstream consumers
                # see consistent per-request averages. Not expected on the
                # current API (ExecutorRequest construction requires a
                # non-empty input_token_ids), logged so future API drift
                # surfaces instead of being silently dropped.
                logger.warning(f"Excluding queued item {item.id} from queued "
                               f"counters: input_token_ids not readable "
                               f"({type(e).__name__})")
                continue
            if item.request.request_type == RequestType.REQUEST_TYPE_GENERATION_ONLY:
                num_queued_gen_requests += 1
                num_queued_gen_kv_tokens += token_count
            else:
                num_queued_context_requests += 1
                num_queued_ctx_tokens += token_count

        # Total KV context length summed across paused (preempted-decode)
        # requests — were decoding but got evicted back to the waiting
        # pool for this iteration.
        num_paused_kv_tokens = 0
        for req in scheduled_batch.paused_requests:
            if getattr(req, "is_attention_dp_dummy", False):
                continue
            try:
                num_paused_kv_tokens += req.get_num_tokens(0)
            except RuntimeError:
                pass

        stats.inflight_batching_stats.num_ctx_kv_tokens = num_ctx_kv_tokens
        stats.inflight_batching_stats.num_gen_kv_tokens = num_gen_kv_tokens
        stats.inflight_batching_stats.num_queued_context_requests = num_queued_context_requests
        stats.inflight_batching_stats.num_queued_ctx_tokens = num_queued_ctx_tokens
        stats.inflight_batching_stats.num_queued_gen_requests = num_queued_gen_requests
        stats.inflight_batching_stats.num_queued_gen_kv_tokens = num_queued_gen_kv_tokens
        stats.inflight_batching_stats.num_paused_kv_tokens = num_paused_kv_tokens

        return stats

    def _append_iter_stats(self,
                           stats: IterationStats,
                           req_stats: Optional[List[RequestStats]] = None):

        with self.stats_lock:
            if len(self.stats) > self.max_stats_len:
                self.stats.pop(0)
            self.stats.append((stats, req_stats, self._latest_kv_iter_stats))

    def _process_iter_stats(
        self,
        finished_requests: list[LlmRequest],
        active_requests: List[LlmRequest],
        batch_state: BatchState,
        micro_batch_id: int = 0,
    ):
        iter_end_time = time.time()
        iter_latency_ms = (iter_end_time - batch_state.iter_start_time) * 1e3
        if batch_state.iter_stats is None:
            return

        req_stats = self._populate_req_stats(
            finished_requests, active_requests,
            batch_state.scheduled_requests) if (
                self.enable_iter_req_stats
                and self.enable_iter_perf_stats) else None

        self._append_iter_stats(
            self._update_iter_stats(batch_state.iter_stats, iter_latency_ms,
                                    len(finished_requests),
                                    batch_state.scheduled_requests,
                                    micro_batch_id), req_stats)

    def _executor_loop_cleanup(self):

        for i in range(self.num_micro_batches):
            self.wait_on_pp_send_handles(self.send_handles, i)
            self.wait_on_pp_send_handles(self.send_schedule_handles, i)
            self.wait_on_pp_send_handles(self.send_expected_batch_num_handles,
                                         i)

        with self.response_cv:
            self.is_shutdown = True
            self.response_cv.notify_all()
        self.shutdown_event.set()

    def _pp_schedule_and_propagate(self, microbatch_id: int):
        """The first PP rank schedules the requests and propagates the result to all other PP ranks."""

        # For TP/CP cases, the first rank schedules the requests.
        # For DP cases, the first PP rank schedules the requests.
        scheduled_batch = None
        serializable_schedule = None
        is_dp_broadcast = self.dist.tp_size > 1 and self.enable_attention_dp
        if self.dist.rank == 0 or (self.dist.is_first_pp_rank
                                   and is_dp_broadcast):
            scheduled_batch, fitting_disagg_gen_init_requests, num_fitting_reqs = self._schedule(
            )
            serializable_schedule = SerializableSchedulerOutput.from_scheduler_result(
                scheduled_batch, fitting_disagg_gen_init_requests,
                num_fitting_reqs)

        # Broadcast within first tp+cp group before send/recv chain to other tp+cp groups
        if self.dist.is_first_pp_rank:
            if self.dist.tp_size > 1 and not self.enable_attention_dp:
                with nvtx_range("tp_broadcast_schedule"):
                    serializable_schedule = self.dist.tp_broadcast(
                        serializable_schedule, root=0)
            if self.dist.cp_size > 1:
                with nvtx_range("cp_broadcast_schedule"):
                    serializable_schedule = self.dist.cp_broadcast(
                        serializable_schedule, root=0)

        # Other ranks receive the schedule result from the previous PP rank.
        if not self.dist.is_first_pp_rank:
            with nvtx_range("recv_schedule_from_prev_pp"):
                serializable_schedule = self.dist.recv_object(
                    self.dist.prev_pp_rank, PPCommTag.SCHEDULE_RESULT)

        # Propagate the schedule result to the next PP rank except the last PP rank.
        if not self.dist.is_last_pp_rank:
            self.wait_on_pp_send_handles(self.send_schedule_handles,
                                         microbatch_id)
            with nvtx_range("send_schedule_to_next_pp"):
                self.send_schedule_handles[
                    microbatch_id] = self.dist.isend_object(
                        serializable_schedule, self.dist.next_pp_rank,
                        PPCommTag.SCHEDULE_RESULT)

        if scheduled_batch is None:
            scheduled_batch, fitting_disagg_gen_init_requests, num_fitting_reqs = serializable_schedule.to_scheduler_result(
                self.active_requests)
        return scheduled_batch, fitting_disagg_gen_init_requests, num_fitting_reqs

    def _pp_retry_until_can_schedule(self, scheduled_batch):
        """
        If current rank cannot run the scheduled batch, it will retry following steps until it has enough KV cache resources or reach maximum retry count:
        1. Wait for cache transceiver to finish at least one cache transmission.
        2. Terminate requests that have finished context cache transmission.
        3. Check if current rank has enough KV cache resources to run the scheduled batch.
        """
        scheduled_batch_requests = scheduled_batch.all_requests()
        if self.scheduler.can_schedule(scheduled_batch_requests):
            return

        logger.warning(
            "Cannot run first PP's schedule result due to limited KV cache resources. This may cause bubbles in the PP pipeline. Please consider increasing the KV cache size by setting `free_gpu_memory_fraction` to a larger value."
        )
        if self.kv_cache_transceiver is None:
            raise RuntimeError(
                "KV cache transceiver is not enabled, but current rank cannot run first PP's schedule result due to limited KV cache resources. This is not expected."
            )
        if not self.async_transfer_manager.has_any_inflight_requests():
            raise RuntimeError(
                "No context cache transmission is in progress, but current rank cannot run first PP's schedule result due to limited KV cache resources. This is not expected."
            )
        if self.enable_kv_cache_reuse and self._disagg_pp_termination_handler is not None:
            raise RuntimeError(
                "Cannot terminate requests in cache transmission and release their KV cache resources when block reuse is enabled. Please consider increasing the KV cache size."
            )

        for retry_count in range(self.pp_scheduler_max_retry_count):
            if self.scheduler.can_schedule(scheduled_batch_requests):
                break
            logger.debug(
                f"Retrying to run first PP's schedule result ({retry_count + 1}/{self.pp_scheduler_max_retry_count})"
            )

            # Let cache transceiver finish at least one cache transmission and release requests' KV cache resources
            self._check_disagg_ctx_cache_transfer_status(1)
            self._check_kv_transfer_timeout()
        else:
            raise RuntimeError(
                f"Reach maximum PP retry count ({self.pp_scheduler_max_retry_count}) but still cannot run first PP's schedule result. Please consider increasing the KV cache size by setting `free_gpu_memory_fraction` to a larger value. Or you can set `TLLM_PP_SCHEDULER_MAX_RETRY_COUNT` to a larger value to allow more retries."
            )

    def _executor_loop_pp(self):
        logger.debug(f"Starting executor loop for pp_rank {self.dist.pp_rank}")
        torch.cuda.set_device(self.device_id)
        # ensure the context is created, otherwise, some MPI calls will fail.
        CUASSERT(cudart.cudaSetDevice(self.device_id))
        microbatch_id = 0
        with self._profiler() as profile_step, self.hang_detector:
            iter_start_time = time.time()
            iter_stats = None
            while True:
                self.hang_detector.checkpoint()
                profile_step()
                if self.enable_iter_perf_stats:
                    iter_start_time = time.time()

                # Fetch new requests from request queue
                new_requests = self._fetch_and_activate_new_requests()
                if self.should_stop_processing:
                    break

                self._handle_control_request()

                if self.kv_cache_transceiver:
                    self._check_disagg_ctx_schedulable_status(new_requests)
                    self._check_disagg_gen_transfer_status()

                if self.enable_iter_perf_stats:
                    iter_stats = self._get_init_iter_stats(
                        len(new_requests),
                        self._get_new_active_requests_queue_latency())

                self._pad_attention_dp_dummy_request()

                # Stage 0: first PP rank schedules requests and propagates the result to all other PP ranks.
                scheduled_batch, fitting_disagg_gen_init_requests, num_fitting_reqs = self._pp_schedule_and_propagate(
                    microbatch_id)
                if self.dist.rank != 0:
                    # Retry until current rank can run first PP's schedule result.
                    self._pp_retry_until_can_schedule(scheduled_batch)
                    # Run scheduler locally because scheduler may change llm requests' state.
                    self.scheduler.schedule_request(self.active_requests,
                                                    self.inflight_req_ids)

                # For requests that are fitting disagg gen init, also prepare resources for KV cache manager
                if self.kv_cache_transceiver:
                    self._prepare_disagg_gen_init(
                        fitting_disagg_gen_init_requests)

                    all_gen_first = self.active_requests and all(
                        req.py_disaggregated_params
                        and req.py_disaggregated_params.schedule_style ==
                        DisaggScheduleStyle.GENERATION_FIRST
                        for req in self.active_requests)
                    if num_fitting_reqs == 0 and not fitting_disagg_gen_init_requests:
                        if not all_gen_first:
                            logger.warning(
                                "num_fitting_reqs=0 and fitting_disagg_gen_init_requests is empty, may not have enough kvCache"
                            )
                            self._check_disagg_ctx_cache_transfer_status(1)
                        elif self.async_transfer_manager.has_any_inflight_requests(
                        ):
                            # Non-blocking cleanup of completed/timed-out
                            # transfers to free KV blocks (see _executor_loop).
                            self._check_disagg_ctx_cache_transfer_status(0)

                self.num_scheduled_requests = scheduled_batch.batch_size

                logger.debug(
                    f'iteration {self.iter_counter}, microbatch {microbatch_id}, '
                    f'has {len(self.active_requests)} active_requests, '
                    f'scheduled {scheduled_batch.num_context_requests} context requests and '
                    f'{scheduled_batch.num_generation_requests} generation requests'
                )

                can_queue, _ = self._can_queue(scheduled_batch)
                if not can_queue:
                    self._revert_gen_alloc(scheduled_batch)
                    logger.debug(
                        f"microbatch {microbatch_id} cannot be queued, skipping"
                    )
                    self.micro_batches[microbatch_id] = None
                else:
                    logger.debug(f"microbatch {microbatch_id} can be queued")

                    self._add_inflight_ids(scheduled_batch)

                    if self.kv_cache_transceiver:
                        # For generation requests which have completed KV cache transfer
                        self._prepare_disagg_gen_transmission_complete(
                            scheduled_batch)

                    self._handle_dynamic_draft_len(scheduled_batch)

                    self.resource_manager.prepare_resources(scheduled_batch)

                    # The generation requests that do not have batch_idx
                    # need to be in front of the batch due to the assumptions
                    # made in model_engine.py::_forward_step. This is only important
                    # for disaggregated serving. For non-disaggregated serving,
                    # the generation requests always have batch_idx.
                    scheduled_batch.generation_requests = sorted(  # stable sort
                        scheduled_batch.generation_requests,
                        key=lambda req: int(req.py_batch_idx is not None),
                    )

                    if self.kv_cache_transceiver:
                        # Return the first token to the client
                        self._handle_first_token_response(scheduled_batch)

                    # Stage 1.1: Async forward (all ranks) and decoding pass (last rank only)
                    if not self.dist.is_last_pp_rank:
                        with torch.cuda.nvtx.range(
                                f"_forward_step_inter_pp pp_rank {self.dist.pp_rank}"
                        ):
                            sample_state = self._forward_step_inter_pp(
                                scheduled_batch)
                    else:
                        with torch.cuda.nvtx.range(
                                f"_forward_step_last_pp pp_rank {self.dist.pp_rank}"
                        ):
                            # init_disagg_gen_requests must be before engine forward, where the prev_seq_slot is updated.
                            if self.guided_decoder is not None and self.kv_cache_transceiver:
                                self.guided_decoder.add_batch(scheduled_batch)
                                self.guided_decoder.init_disagg_gen_requests()

                            batch_outputs = self._forward_step(scheduled_batch)

                            guided_decoder_failed_requests = None
                            if self.guided_decoder is not None:
                                self.guided_decoder.add_batch(scheduled_batch)
                                guided_decoder_failed_requests = self.guided_decoder.execute(
                                    batch_outputs['logits'])

                            if self.pp_multi_stream_sample:
                                # Wait for the previous sample to finish.
                                self.finish_sample_event.wait()
                                # Copy the batch outputs as sampler inputs
                                # to avoid next forward step overwriting them.
                                batch_outputs_copy = {
                                    name: tensor.clone()
                                    for name, tensor in batch_outputs.items()
                                }
                                self.sample_stream.wait_stream(
                                    torch.cuda.current_stream())
                                with torch.cuda.stream(self.sample_stream):
                                    sample_state = self._sample_async(
                                        scheduled_batch, batch_outputs_copy)
                                    self.finish_sample_event.record()
                            else:
                                sample_state = self._sample_async(
                                    scheduled_batch, batch_outputs)

                            assert sample_state is not None, "Sampling failed"

                            # Handle guided decoder errors after _sample_async to avoid state conflicts.
                            # If called before, failed requests would be marked as GENERATION_COMPLETE,
                            # causing _sample_async to fail when accessing context_chunk_size property.
                            self._handle_guided_decoder_errors(
                                scheduled_batch, guided_decoder_failed_requests)

                            self._update_request_states(scheduled_batch)
                            if not self.disable_overlap_scheduler:
                                self._update_generation_requests_that_will_complete_next_iteration(
                                    scheduled_batch.generation_requests)

                    if self.enable_iter_perf_stats:
                        iter_stats.inflight_batching_stats.num_ctx_tokens = self.model_engine.iter_states[
                            'num_ctx_tokens']
                    batch_state = BatchStatePP(
                        scheduled_requests=scheduled_batch,
                        sample_state=sample_state,
                        iter_start_time=iter_start_time,
                        iter_stats=iter_stats,
                        microbatch_id=microbatch_id,
                    )

                    self.micro_batches[microbatch_id] = batch_state

                # Stage 1.2: Sync sampler for previous microbatch to start new sample state comm chain.
                # For last PP rank, we must synchronize the previous batch
                # since we need to broadcast its sample state soon afterwards in the same iteration.
                # For other PP ranks, we can delay the synchronization if the current batch cannot be queued.
                previous_batch = self.previous_batch
                if can_queue:
                    self.previous_batch = batch_state
                if (self.dist.is_last_pp_rank
                        or can_queue) and previous_batch is not None:
                    with nvtx_range("sync_previous_sampler_event"):
                        previous_batch.sample_state.sampler_event.synchronize()

                # Stage 2: Enqueue sample state for executed batch to ring broadcast it in background thread asynchronously.
                # send/recv chain: (pp_size - 1) -> 0 -> 1 -> ... -> (pp_size - 2)
                # intermediate ranks: send/recv sample state for next microbatch to allow overlap
                offset = -1 if self.dist.is_last_pp_rank else (
                    1 - self.dist.pp_size)
                executed_microbatch_id = (microbatch_id +
                                          offset) % self.num_micro_batches
                executed_batch = self.micro_batches[executed_microbatch_id]
                if executed_batch is not None:
                    self.executed_batch_queue.put(executed_batch)
                    self.unhandled_batch_counter += 1
                self.micro_batches[executed_microbatch_id] = None

                def fetch_executed_batches() -> list[BatchStatePP]:
                    executed_batches = []
                    if self.pp_async_broadcast_sample_state:
                        # Wait for at least one batch to finish if no new request is available.
                        must_get = not can_queue
                    else:
                        must_get = True
                    while not self.executed_batch_response_queue.empty() or (
                            must_get and self.unhandled_batch_counter > 0):
                        with nvtx_range("get_executed_batch"):
                            executed_batches.append(
                                self.executed_batch_response_queue.get())
                        must_get = False
                    return executed_batches

                def ring_broadcast_executed_batch_num(
                        executed_batch_num: int) -> int:
                    if self.dist.is_first_pp_rank and self.dist.tp_size * self.dist.cp_size > 1:
                        with nvtx_range("tp_cp_broadcast_executed_batch_num"):
                            executed_batch_num = self.dist.tp_cp_broadcast(
                                executed_batch_num,
                                root=0,
                            )
                    if not self.dist.is_first_pp_rank:
                        with nvtx_range("recv_expected_batch_num"):
                            executed_batch_num = self.dist.recv_object(
                                src=self.dist.prev_pp_rank,
                                tag=PPCommTag.EXECUTED_BATCH_NUM,
                            )
                    if not self.dist.is_last_pp_rank:
                        self.wait_on_pp_send_handles(
                            self.send_expected_batch_num_handles, microbatch_id)
                        with nvtx_range("send_expected_batch_num"):
                            self.send_expected_batch_num_handles[
                                microbatch_id] = self.dist.isend_object(
                                    executed_batch_num,
                                    dest=self.dist.next_pp_rank,
                                    tag=PPCommTag.EXECUTED_BATCH_NUM,
                                )
                    return executed_batch_num

                def handle_executed_batches(executed_batch_num: int):
                    if self.dist.rank != 0:
                        dequeue_counter = 0
                        while dequeue_counter < executed_batch_num:
                            with nvtx_range("get_executed_batch"):
                                executed_batch = self.executed_batch_response_queue.get(
                                )
                            self._handle_executed_batch(executed_batch)
                            dequeue_counter += 1
                    else:
                        for executed_batch in executed_batches:
                            self._handle_executed_batch(executed_batch)
                    self.unhandled_batch_counter -= executed_batch_num

                executed_batch_num = 0

                # Stage 3.1: The first rank determines the number of executed batches.
                if self.dist.rank == 0:
                    executed_batches = fetch_executed_batches()
                    executed_batch_num = len(executed_batches)

                # Stage 3.2: Broadcast the number of executed batches to other ranks.
                executed_batch_num = ring_broadcast_executed_batch_num(
                    executed_batch_num)

                # Stage 3.3: Handle executed batches.
                handle_executed_batches(executed_batch_num)

                # Stage 4: March forward in microbatch slots
                microbatch_id = (microbatch_id + 1) % self.num_micro_batches
                self.iter_counter += 1

            # Stage 5: Handle remaining executed batches in the queue.
            while self.unhandled_batch_counter > 0:
                with nvtx_range("get_executed_batch"):
                    executed_batch = self.executed_batch_response_queue.get()
                self._handle_executed_batch(executed_batch)
                self.unhandled_batch_counter -= 1

    def _broadcast_sample_state_loop(self):
        logger.debug(
            f"Starting broadcast sample state loop for pp_rank {self.dist.pp_rank}"
        )
        torch.cuda.set_device(self.device_id)
        # ensure the context is created, otherwise, some MPI calls will fail.
        CUASSERT(cudart.cudaSetDevice(self.device_id))
        # Acquiring pkl5.Intracomm's send/recv locks from both executor loop thread
        # and this thread will cause perf drop and even deadlock.
        # We create new MPI comm to avoid these issues.
        logger.info(
            "Create new MPI comm for broadcast sample state thread to avoid deadlock."
        )
        new_mpi_comm = mpi_comm().Dup()
        set_thread_local_mpi_comm(new_mpi_comm)
        while True:
            executed_batch = self.executed_batch_queue.get()
            if executed_batch is None:
                break
            self._ring_broadcast_sample_state(executed_batch)
        set_thread_local_mpi_comm(None)
        new_mpi_comm.Free()

    def _ring_broadcast_sample_state(
        self,
        executed_batch: Optional[BatchStatePP],
    ) -> None:
        if executed_batch is None:
            return

        tag = PPCommTag.SAMPLE_STATE
        microbatch_id = executed_batch.microbatch_id
        sample_state = executed_batch.sample_state
        requests = sample_state.requests

        if not self.dist.is_last_pp_rank:
            # Receive tokens from previous pp rank (w.r.t model forward direction)
            with nvtx_range("recv_sample_state"):
                sample_state.host, py_result_diffs = self.dist.recv_object(
                    src=self.dist.prev_pp_rank,
                    tag=tag,
                )

            for request, py_result_diff in zip(requests, py_result_diffs):
                request.py_result.apply_diff(py_result_diff)

        self.executed_batch_response_queue.put(executed_batch)

        # Send tokens to next pp rank (w.r.t model forward direction)
        # Second last rank does not need to since last rank has original decoded tokens
        if not self.dist.is_second_last_pp_rank:
            py_result_diffs = []
            for request in requests:
                diff = request.py_result.get_diff()
                py_result_diffs.append(diff)
                request.py_result.reset_diff()
            self.wait_on_pp_send_handles(self.send_handles, microbatch_id)
            with nvtx_range("send_sample_state"):
                self.send_handles[microbatch_id] = self.dist.isend_object(
                    (sample_state.host, py_result_diffs),
                    dest=self.dist.next_pp_rank,
                    tag=tag,
                )

    def _handle_executed_batch(self, executed_batch: Optional[BatchStatePP]):
        finished_requests = []
        if executed_batch is not None:
            with torch.cuda.nvtx.range("_handle_executed_batch_pp"):
                self._update_requests(executed_batch.sample_state)

                scheduled_requests = executed_batch.scheduled_requests
                if self.kv_cache_transceiver:
                    finished_ctx_reqs = scheduled_requests.context_requests_last_chunk
                    self._send_kv_async(finished_ctx_reqs)
                self._flush_pending_transfer_responses()
                self._handle_canceled_requests()

                finished_requests = self._handle_responses()
                # Complete ctx send sessions AFTER responses are created so
                # _handle_responses sees the request before it is terminated.
                if self.kv_cache_transceiver:
                    self._check_disagg_ctx_cache_transfer_status(0)
                sample_state_scheduled_requests = executed_batch.scheduled_requests
                attn_metadata = getattr(self.model_engine, 'attn_metadata',
                                        None)
                kv_cache_dtype_byte_size = getattr(self.model_engine,
                                                   'kv_cache_dtype_byte_size',
                                                   None)
                self.resource_manager.update_resources(
                    sample_state_scheduled_requests, attn_metadata,
                    kv_cache_dtype_byte_size)

                self._remove_inflight_ids(scheduled_requests)

        if self.kv_cache_transceiver and self.async_transfer_manager.has_any_inflight_requests(
        ):
            self._check_kv_transfer_timeout()

        if self._disagg_pp_termination_handler is not None:
            self._disagg_pp_termination_handler.terminate_pending_requests()

        if self.enable_iter_perf_stats and executed_batch is not None:
            self._process_iter_stats(
                finished_requests,
                self.active_requests,
                executed_batch,
                executed_batch.microbatch_id % self.dist.pp_size,
            )

    @nvtx_range("wait_on_pp_send_handles")
    def wait_on_pp_send_handles(self, send_handles, microbatch_id):
        if send_handles[microbatch_id] is not None:
            send_handles[microbatch_id].wait()
            send_handles[microbatch_id] = None

    def _handle_dynamic_draft_len(self,
                                  scheduled_batch: ScheduledRequests) -> None:
        """Handle dynamic draft length for the current batch.

        Must be called BEFORE prepare_resources so that KV cache allocation
        uses the correct draft length.

        Two things happen here:
        1. Determine the runtime draft length from the draft_len_schedule
           based on the current batch size, and store it on model_engine so
           that the rest of the forward path can read it.
        2. Pad / truncate each request's py_draft_tokens to exactly match
           the determined draft length, ensuring uniform draft token counts across the
           batch (required by CUDA graph replay and the attention kernel).

        When dynamic draft length is not enabled, runtime_draft_len is simply
        set to max_draft_len (the static maximum).
        """
        if not hasattr(self.model_engine, 'max_draft_len'):
            return

        if (self.model_engine.spec_config is not None
                and self.model_engine.spec_config.draft_len_schedule is not None
                and self.model_engine.spec_config.spec_dec_mode.
                support_dynamic_draft_len()):
            from tensorrt_llm._torch.speculative.utils import \
                get_draft_len_for_batch_size

            # 1. Resolve runtime draft length from schedule
            runtime_draft_len = get_draft_len_for_batch_size(
                self.model_engine.spec_config.draft_len_schedule,
                scheduled_batch.batch_size, self.model_engine.max_draft_len)

            # 2. Pad or truncate draft tokens to the resolved length
            PADDING_TOKEN = 0
            for request in scheduled_batch.generation_requests:
                current_draft_len = len(request.py_draft_tokens)
                if current_draft_len < runtime_draft_len:
                    padding_needed = runtime_draft_len - current_draft_len
                    request.py_draft_tokens.extend([PADDING_TOKEN] *
                                                   padding_needed)
                elif current_draft_len > runtime_draft_len:
                    request.py_draft_tokens = request.py_draft_tokens[:
                                                                      runtime_draft_len]

            self.model_engine.runtime_draft_len = runtime_draft_len
        else:
            self.model_engine.runtime_draft_len = self.model_engine.max_total_draft_tokens

    def _can_queue(self, scheduled_batch):

        # can_queue_this_rank is for case that the batch is not empty on this rank, but empty on other ranks
        # For bs == 1, we cannot pad dummy request to make the batch non-empty since it will cause the batch size to be 2.
        # 1 for dummy request, 1 for the yet-to-complete but not-yet-updated request.
        if self.enable_attention_dp:
            tp_batch_sizes = self.dist.tp_allgather(scheduled_batch.batch_size)
            can_queue = 0 not in tp_batch_sizes
            can_queue_this_rank = scheduled_batch.batch_size > 0
        else:
            can_queue = can_queue_this_rank = scheduled_batch.batch_size > 0

        return can_queue, can_queue_this_rank

    def _revert_gen_alloc(self, scheduled_batch):
        """Revert KV cache capacity growth when the batch is skipped.

        With attention DP, can_queue=False means another rank has an empty
        batch so no forward pass will run.  The V2 scheduler already grew
        each generation request's KV cache capacity during scheduling;
        revert that growth so it does not accumulate across skipped
        iterations and overflow the host page-index buffer.

        Only applies to KV cache manager V2 + scheduler V2, because the V2
        scheduler allocates KV cache capacity during scheduling, before the
        can_queue check.  V1 allocates in prepare_resources() after the
        can_queue check, so no revert is needed.
        """
        if self._scheduler_manages_kv_suspend:
            for req in scheduled_batch.generation_requests:
                self.kv_cache_manager.revert_allocate_generation(req)

    def _prepare_and_schedule_batch(self):
        new_requests = self._fetch_and_activate_new_requests()
        if self.should_stop_processing:
            return None, None

        if self.kv_cache_transceiver:
            self._check_disagg_ctx_schedulable_status(new_requests)
            self._check_disagg_gen_transfer_status()
            self._check_kv_transfer_timeout()

        iter_stats = None
        if self.enable_iter_perf_stats:
            iter_stats = self._get_init_iter_stats(
                len(new_requests),
                self._get_new_active_requests_queue_latency())

        self._pad_attention_dp_dummy_request()

        if self.drafter is not None:
            # Honor permanent disable flag based on rolling acceptance first
            if self.drafter.draft_len_schedule is not None:
                batch_size_input = len(self.active_requests)

                self.max_total_draft_tokens = self.drafter.get_draft_len_for_batch_size(
                    batch_size_input)

                self.drafter.update_max_total_draft_tokens(
                    self.max_total_draft_tokens)

            # Check if draft_len=0 → immediately disable
            # self.max_total_draft_tokens==0 is only possible when draft_len_schedule is provided
            # for example, draft_len_schedule = {1:4, 4:2, 8:0}, batch_size >= 8 will set self.max_draft_len = 0
            if self.drafter.draft_len_schedule is not None and self.max_total_draft_tokens == 0:
                self.use_spec_decode = False
            elif getattr(self, 'speculation_permanently_disabled', False):
                self.use_spec_decode = False
            else:
                self.use_spec_decode = self.drafter.should_use_spec_decode(
                    self.active_requests, self.max_batch_size,
                    self.model_engine.llm_args.max_num_tokens,
                    self.max_total_draft_tokens)
            logger.debug(f"Use spec decode: {self.use_spec_decode}")
            self.model_engine.enable_spec_decode = self.use_spec_decode

            # Set up draft_tokens in active_requests, because they could be used in the scheduling stage.
            for request in self.active_requests:
                if request.state not in (
                        LlmRequestState.GENERATION_IN_PROGRESS,
                        LlmRequestState.DISAGG_GENERATION_INIT):
                    continue
                request.draft_tokens = [
                    0
                ] * self.max_total_draft_tokens if self.max_total_draft_tokens > 0 else []

            # If speculation is off, this function sets py_draft_tokens to []
            # for all active requests. If it's on, we initialize py_draft_tokens
            # with dummy draft tokens to make the scheduler aware of the fact
            # that speculation is about to happen.
            self._prepare_draft_requests()

        scheduled_batch, fitting_disagg_gen_init_requests, num_fitting_reqs = self._schedule(
        )

        if self.drafter is not None and not self.use_spec_decode:
            for request in scheduled_batch.all_requests():
                request.py_disable_speculative_decoding = True

        if self.kv_cache_transceiver:
            # For requests that are fitting disagg gen init, also prepare resources for KV cache manager
            self._prepare_disagg_gen_init(fitting_disagg_gen_init_requests)

            all_gen_first = self.active_requests and all(
                req.py_disaggregated_params and req.py_disaggregated_params.
                schedule_style == DisaggScheduleStyle.GENERATION_FIRST
                for req in self.active_requests)
            if num_fitting_reqs == 0 and not fitting_disagg_gen_init_requests:
                if not all_gen_first:
                    logger.warning(
                        "num_fitting_reqs=0 and fitting_disagg_gen_init_requests is empty, may not have enough kvCache"
                    )
                    self._check_disagg_ctx_cache_transfer_status(1)
                elif self.async_transfer_manager.has_any_inflight_requests():
                    # Non-blocking cleanup of completed/timed-out transfers
                    # to free KV blocks. We avoid the blocking check because
                    # gen-first requests may be waiting for peer info (which
                    # would block indefinitely), but completed transfers must
                    # still be reaped so that KV cache can be reclaimed.
                    self._check_disagg_ctx_cache_transfer_status(0)

            # In gen-only benchmark mode, all requests must fit in KV cache
            # simultaneously. If some requests are stuck in INIT state and the
            # scheduler could not allocate KV for any of them, the benchmark
            # will hang forever because in-progress generation requests won't
            # release their KV cache.
            if (self.benchmark_req_queues_size > 0 and not self.is_warmup
                    and not fitting_disagg_gen_init_requests):
                stuck_init_requests = [
                    req for req in self.active_requests
                    if req.is_disagg_generation_init_state
                ]
                # Only fail once all benchmark requests have been fetched
                # so that _handle_errors covers every request and every
                # client receives an error response.
                if (stuck_init_requests and self.num_fetch_requests
                        >= self.benchmark_req_queues_size):
                    error_msg = (
                        f"Insufficient KV cache for gen-only benchmark mode: "
                        f"{len(stuck_init_requests)} request(s) are waiting for "
                        f"KV cache allocation but the scheduler could not fit "
                        f"any of them. Increase free_gpu_memory_fraction or "
                        f"reduce TLLM_BENCHMARK_REQ_QUEUES_SIZE (currently "
                        f"{self.benchmark_req_queues_size}).")
                    logger.error(error_msg)
                    # Fail all active and waiting requests so every
                    # client receives an error instead of hanging.
                    self._handle_errors(error_msg,
                                        requests=self.active_requests)
                    return None, None

        self.num_scheduled_requests = scheduled_batch.batch_size
        logger.debug(
            f'has {len(self.active_requests)} active_requests, '
            f'scheduled {scheduled_batch.num_context_requests} context requests and '
            f'{scheduled_batch.num_generation_requests} generation requests')
        return scheduled_batch, iter_stats

    def _kv_connector_start_batch(self, scheduled_batch):
        if self.kv_connector_manager:
            self.kv_connector_manager.take_scheduled_requests_pending_load(
                scheduled_batch)
            self.kv_connector_manager.handle_metadata()
            self.kv_connector_manager.worker.start_load_kv(
                torch.cuda.current_stream())

    def _kv_connector_terminate_requests(self):
        if self.kv_connector_manager:
            reqs_to_terminate = self.kv_connector_manager.get_finished()
            for req in reqs_to_terminate:
                self._end_transfer_and_maybe_terminate(req)

    def _kv_connector_wait_for_save(self):
        if self.kv_connector_manager is not None:
            self.kv_connector_manager.worker.wait_for_save(
                torch.cuda.current_stream())

    def _is_benchmark_disagg_fill_complete(
            self, scheduled_batch: ScheduledRequests) -> bool:
        """Check whether all benchmark disagg requests have completed KV transfer.

        With ADP, generation requests are distributed across TP ranks, so an
        allgather is needed to obtain the global count.  Without ADP every
        request is local, and we can compare directly.

        This method must only be called when ``is_benchmark_disagg`` is True.

        Args:
            scheduled_batch: The current iteration's scheduled requests,
                used to count generation requests that have completed
                KV transfer.

        Returns:
            True when the total number of generation-ready requests
            reaches ``benchmark_req_queues_size``.
        """
        if not self.is_benchmark_disagg:
            raise RuntimeError(
                "_is_benchmark_disagg_fill_complete() should not be called outside benchmark "
                "disagg mode.  This is an unexpected error.")
        local_gen_count = sum(1 for req in scheduled_batch.generation_requests
                              if not req.is_attention_dp_dummy)
        if self.enable_attention_dp:
            total_gen_count = sum(self.dist.tp_allgather(local_gen_count))
        else:
            total_gen_count = local_gen_count

        if total_gen_count >= self.benchmark_req_queues_size:
            return True
        if self.dist.rank == 0:
            logger.debug(
                f"Benchmark disagg fill in progress: "
                f"num_fetched={self.num_fetch_requests}, "
                f"total_gen_count={total_gen_count} (local={local_gen_count})")
        return False

    def _check_benchmark_disagg_gate(self, scheduled_batch: ScheduledRequests,
                                     can_forward: bool) -> tuple[bool, bool]:
        """Gate the forward pass until all benchmark disagg requests are ready.

        In benchmark disagg mode the GEN executor must defer the forward
        pass until every request has completed KV transfer.  This helper
        consolidates the check used by both ``_executor_loop`` and
        ``_executor_loop_overlap``.

        A short sleep (0.1s) yields the CPU between retries while
        keeping the polling interval short enough to avoid KV transfer
        backpressure on the CTX server.

        Args:
            scheduled_batch: The current scheduled batch.
            can_forward: Current gate state.

        Returns:
            ``(can_forward, should_retry)`` — when *should_retry* is True
            the caller should ``continue`` to the next loop iteration.
        """
        if not self.is_warmup and not can_forward:
            can_forward = self._is_benchmark_disagg_fill_complete(
                scheduled_batch)
            if can_forward:
                self._benchmark_fill_phase_active = False
            else:
                time.sleep(0.1)
                return can_forward, True
        return can_forward, False

    def _executor_loop(self):
        torch.cuda.set_device(self.device_id)
        # ensure the context is created, otherwise, some MPI calls will fail.
        CUASSERT(cudart.cudaSetDevice(self.device_id))
        with self._profiler() as profile_step, self.hang_detector:
            sample_state = None
            iter_start_time = time.time()
            iter_stats = None
            can_forward = not self.is_benchmark_disagg
            while True:
                self.hang_detector.checkpoint()
                profile_step()
                if self.enable_iter_perf_stats:
                    iter_start_time = time.time()

                scheduled_batch, iter_stats = self._prepare_and_schedule_batch()
                self._handle_control_request()

                if scheduled_batch is None:
                    break

                can_forward, should_retry = self._check_benchmark_disagg_gate(
                    scheduled_batch, can_forward)
                if should_retry:
                    continue

                if not self._scheduler_manages_kv_suspend:
                    self._terminate_requests(scheduled_batch.paused_requests)
                    self._pause_requests(scheduled_batch.paused_requests)

                finished_requests = []

                can_queue, _ = self._can_queue(scheduled_batch)

                if can_queue:
                    if self.kv_cache_transceiver:
                        # For generation requests which have completed KV cache transfer
                        self._prepare_disagg_gen_transmission_complete(
                            scheduled_batch)

                        # Return the first token to the client
                        self._handle_first_token_response(scheduled_batch)

                    self._handle_dynamic_draft_len(scheduled_batch)

                    self.resource_manager.prepare_resources(scheduled_batch)

                if self.kv_connector_manager:
                    self.kv_connector_manager.handle_metadata()

                if can_queue:
                    self._kv_connector_start_batch(scheduled_batch)

                # if using a kv connector, we need to call can_queue again since scheduled_batch might have changed
                if self.kv_connector_manager:
                    can_queue, _ = self._can_queue(scheduled_batch)

                if not can_queue:
                    self._revert_gen_alloc(scheduled_batch)

                if can_queue:
                    # init_disagg_gen_requests must be before drafter loop, otherwise draft requests do not have initialized matchers.
                    # init_disagg_gen_requests must be before engine forward, where the prev_seq_slot is updated.
                    if self.guided_decoder is not None:
                        self.guided_decoder.add_batch(scheduled_batch)
                        if self.kv_cache_transceiver:
                            self.guided_decoder.init_disagg_gen_requests()

                    if self.drafter is not None and self.use_spec_decode:
                        if self.guided_decoder is not None:
                            self.guided_decoder.rollback_rejected_tokens()
                        with request_context(
                                is_draft=self.draft_model_engine is not None,
                                scheduled_requests=scheduled_batch):
                            self.execution_stream.wait_stream(
                                torch.cuda.current_stream())
                            with torch.cuda.stream(self.execution_stream):
                                self.drafter.prepare_draft_tokens(
                                    scheduled_batch, self.resource_manager)
                                # Pad draft tokens to the max draft length and extend KV cache
                                # capacity to match. This is for CUDA graph compatibility.
                                self.drafter.pad_draft_tokens_for_cuda_graph(
                                    scheduled_batch, self.resource_manager)
                            torch.cuda.current_stream().wait_stream(
                                self.execution_stream)
                        # add_batch must be called again to restore to target requests with updated draft tokens.
                        if self.guided_decoder is not None:
                            self.guided_decoder.add_batch(scheduled_batch)
                            if hasattr(self.drafter, "guided_decoder"):
                                self.guided_decoder.rollback_draft_tokens()

                    # GPU and CPU timing for perf metrics
                    gpu_forward_start, gpu_forward_end, gpu_sample_end = self.perf_manager.create_timing_events(
                    )

                    with self.perf_manager.record_perf_events(
                            gpu_forward_start, gpu_forward_end) as fwd_timing:
                        if self.dwdp_manager is not None:
                            self.dwdp_manager.prefetch_first_layers()
                        batch_outputs = self._forward_step(scheduled_batch)

                    guided_decoder_failed_requests = None
                    if self.guided_decoder is not None:
                        guided_decoder_failed_requests = self.guided_decoder.execute(
                            batch_outputs['logits'])

                    with self.perf_manager.record_perf_events(
                            None, gpu_sample_end) as sample_timing:
                        sample_state = self._sample_async(
                            scheduled_batch, batch_outputs)

                    self.perf_manager.save_timing_to_requests(
                        scheduled_batch.all_requests(), gpu_forward_start,
                        gpu_forward_end, gpu_sample_end, fwd_timing.start_time,
                        fwd_timing.end_time, sample_timing.start_time,
                        sample_timing.end_time)

                    # Handle guided decoder errors after _sample_async to avoid state conflicts.
                    # If called before, failed requests would be marked as GENERATION_COMPLETE,
                    # causing _sample_async to fail when accessing context_chunk_size property.
                    self._handle_guided_decoder_errors(
                        scheduled_batch, guided_decoder_failed_requests)

                    # Handle SaveHiddenStates mode - save hidden states after forward
                    if not self.is_warmup:
                        spec_resource_mgr = self.resource_manager.resource_managers.get(
                            ResourceManagerType.SPEC_RESOURCE_MANAGER)
                        if spec_resource_mgr is not None and hasattr(
                                spec_resource_mgr, 'process_and_save'):
                            spec_metadata = getattr(self.model_engine,
                                                    'spec_metadata', None)
                            spec_resource_mgr.process_and_save(
                                scheduled_batch, spec_metadata)

                    self._update_request_states(scheduled_batch)
                    self._update_requests(sample_state, self.resource_manager)

                    self._send_kv_async(scheduled_batch.all_requests())
                    self._flush_pending_transfer_responses()

                    self._handle_canceled_requests()
                    finished_requests = self._handle_responses()
                    # Complete ctx send sessions AFTER responses are created so
                    # _handle_responses sees the request before it is terminated.
                    if self.kv_cache_transceiver:
                        self._check_disagg_ctx_cache_transfer_status(0)
                    # Compute GPU times after _handle_responses creates metric entries
                    # (safe in non-overlap mode: no next iteration to overwrite events)
                    self.perf_manager.compute_batch_gpu_times(
                        scheduled_batch.all_requests())
                    attn_metadata = getattr(self.model_engine, 'attn_metadata',
                                            None)
                    kv_cache_dtype_byte_size = getattr(
                        self.model_engine, 'kv_cache_dtype_byte_size', None)
                    self.resource_manager.update_resources(
                        scheduled_batch, attn_metadata,
                        kv_cache_dtype_byte_size)
                    if self.enable_kv_cache_events:
                        self._add_kv_cache_events()

                if self.kv_cache_transceiver and self.async_transfer_manager.has_any_inflight_requests(
                ):
                    self._check_kv_transfer_timeout()

                self._kv_connector_terminate_requests()

                if self.enable_iter_perf_stats and sample_state is not None:
                    iter_stats.inflight_batching_stats.num_ctx_tokens = self.model_engine.iter_states[
                        'num_ctx_tokens']
                    self._process_iter_stats(
                        finished_requests, self.active_requests,
                        BatchState(scheduled_requests=scheduled_batch,
                                   sample_state=sample_state,
                                   iter_stats=iter_stats,
                                   iter_start_time=iter_start_time))

                self.iter_counter += 1

    def _prepare_draft_requests(self):
        try:
            # Set draft tokens here to make the KV cache manager
            # and scheduler aware of them.
            for req in self.active_requests:
                if req.state not in (LlmRequestState.GENERATION_IN_PROGRESS,
                                     LlmRequestState.DISAGG_GENERATION_INIT):
                    continue

                req.py_last_draft_tokens = req.py_draft_tokens

                if self.max_total_draft_tokens > 0 and self.use_spec_decode and not req.py_disable_speculative_decoding:
                    req.py_draft_tokens = [0] * self.max_total_draft_tokens
                    req.py_draft_pages_allocated = self.max_total_draft_tokens
                else:
                    req.py_draft_tokens = []
                    req.py_draft_pages_allocated = 0

        except Exception as e:
            traceback.print_exc()
            error_msg = str(e)
            logger.error(f"Encountered an error in decode: {error_msg}")
            self._handle_errors(error_msg)

    def _handle_control_request(self):
        if len(self.active_requests) == 0 and \
            len(self.waiting_queue) == 0 and \
            len(self.control_requests) > 0:
            assert len(self.control_requests) == 1, (
                f"Expected exactly one control request to be processed at a time, "
                f"but found {len(self.control_requests)} control requests. "
                f"This may indicate a race condition or improper control request handling."
            )
            self.control_requests.pop(0)
            self.control_request_barrier.set()
            self.control_action_done.wait()
            self.control_action_done.clear()

    @contextmanager
    def control_action(self):
        """
        Context manager for synchronized control actions.

        Usage:
            with control_action():
                # Eventloop thread has finished all previous requests and paused
                do some actions here
            # Eventloop thread resumes automatically after exiting
        """

        if self.dist.rank == 0:
            self.executor_request_queue.enqueue_control_request()

        # Wait for worker to finish all previous requests
        self.control_request_barrier.wait()

        try:
            # Yield control to the with block
            # Worker is now paused, safe to execute actions
            yield self
        finally:
            # Cleanup: signal worker to resume
            self.control_action_done.set()
            self.control_request_barrier.clear()

    def _executor_loop_overlap(self):
        torch.cuda.set_device(self.device_id)
        # ensure the context is created, otherwise, some MPI calls will fail.
        CUASSERT(cudart.cudaSetDevice(self.device_id))
        with self._profiler() as profile_step, self.hang_detector:
            iter_start_time = time.time()
            iter_stats = None
            target_inputs = None
            previous_tensors_device = None
            can_forward = not self.is_benchmark_disagg
            while True:
                self.hang_detector.checkpoint()
                profile_step()
                if self.enable_iter_perf_stats:
                    iter_start_time = time.time()

                scheduled_batch, iter_stats = self._prepare_and_schedule_batch()
                self._handle_control_request()

                if scheduled_batch is None:
                    break

                can_forward, should_retry = self._check_benchmark_disagg_gate(
                    scheduled_batch, can_forward)
                if should_retry:
                    continue

                if not self._scheduler_manages_kv_suspend:
                    self._terminate_requests(scheduled_batch.paused_requests)

                can_queue, can_queue_this_rank = self._can_queue(
                    scheduled_batch)

                if can_queue:
                    if self.kv_cache_transceiver:
                        # For generation requests which have completed KV cache transfer
                        self._prepare_disagg_gen_transmission_complete(
                            scheduled_batch)

                    has_draft_batch = self.drafter is not None and self.previous_batch is not None and self.use_spec_decode and self.drafter.should_forward_draft_model(
                        scheduled_batch)
                    # Reset the draft tokens to avoid preparing resources for the draft model.
                    if self.drafter is not None and self.use_spec_decode and not has_draft_batch:
                        self.use_spec_decode = False
                        # We are not running the draft model. Remove the draft tokens and turn off spec
                        # decode so that the requests get handled correctly.
                        # One corner case: when we have at least one context request, we have to keep spec
                        # dec on. This ensures that we capture hidden states for requests that haven't done
                        # prefill yet.
                        self.use_spec_decode = False
                        self.model_engine.enable_spec_decode = scheduled_batch.num_context_requests > 0
                        if not self.model_engine.enable_spec_decode:
                            for request in scheduled_batch.all_requests():
                                request.py_draft_tokens = []

                    self._handle_dynamic_draft_len(scheduled_batch)

                    self.resource_manager.prepare_resources(scheduled_batch)

                if self.kv_connector_manager:
                    self.kv_connector_manager.handle_metadata()

                if can_queue:
                    self._kv_connector_start_batch(scheduled_batch)

                # if using a kv connector, we need to call can_queue again since scheduled_batch might have changed
                if self.kv_connector_manager:
                    can_queue, can_queue_this_rank = self._can_queue(
                        scheduled_batch)

                if not can_queue:
                    self._revert_gen_alloc(scheduled_batch)

                # If the batch is not empty on this rank, but empty on other ranks,
                # we need to delay the update of the previous batch's sample state,
                # and let the later iteration to update it.
                should_process_previous_batch = can_queue or not can_queue_this_rank
                if can_queue:

                    # The generation requests that do not have batch_idx
                    # need to be in front of the batch due to the assumptions
                    # made in model_engine.py::_forward_step. This is only important
                    # for disaggregated serving. For non-disaggregated serving,
                    # the generation requests always have batch_idx.
                    scheduled_batch.generation_requests = sorted(  # stable sort
                        scheduled_batch.generation_requests,
                        key=lambda req: int(req.py_batch_idx is not None),
                    )

                    if self.kv_cache_transceiver:
                        # Return the first token to the client
                        self._handle_first_token_response(scheduled_batch)

                    # init_disagg_gen_requests must be before engine forward, where the prev_seq_slot is updated.
                    if self.guided_decoder is not None and self.kv_cache_transceiver:
                        self.guided_decoder.add_batch(scheduled_batch)
                        self.guided_decoder.init_disagg_gen_requests()

                    previous_tensors = self.previous_batch and self.previous_batch.sample_state
                    # If there are previous draft tokens, we need to update the target requests to accept some draft tokens.
                    # When there's any accepted tokens, we can't directly use the previous batch's outputs in this iteration for the target model,
                    # so we'll set the target model's input to None and skip updating the target requests after target model forward.
                    use_previous_draft_tokens = self.has_previous_draft_tokens
                    num_accepted_tokens_device = None

                    target_inputs = None
                    num_accepted_tokens_device = None

                    if has_draft_batch:
                        self.execution_stream.wait_stream(
                            torch.cuda.current_stream())
                        with torch.cuda.stream(self.execution_stream):
                            target_inputs, num_accepted_tokens_device = self._handle_speculative_decoding(
                                scheduled_batch, previous_tensors,
                                previous_tensors_device)
                        torch.cuda.current_stream().wait_stream(
                            self.execution_stream)

                    # Use the draft_model's outputs if we've launched the draft model.
                    # Otherwise, use the previous batch's outputs.
                    if (target_inputs is not None
                            and target_inputs.next_draft_tokens
                            is not None) or use_previous_draft_tokens:
                        previous_tensors_device = target_inputs
                    else:
                        previous_tensors_device = self.previous_batch and self.previous_batch.sample_state and self.previous_batch.sample_state.device

                    # GPU timing for perf metrics
                    gpu_forward_start, gpu_forward_end, gpu_sample_end = self.perf_manager.create_timing_events(
                    )

                    with self.perf_manager.record_perf_events(
                            gpu_forward_start, gpu_forward_end) as fwd_timing:
                        batch_outputs = self._forward_step(
                            scheduled_batch, previous_tensors_device,
                            num_accepted_tokens_device)

                if self.previous_batch is not None and should_process_previous_batch:
                    self._update_requests(self.previous_batch.sample_state)

                    self._send_kv_async(
                        self.previous_batch.scheduled_requests.all_requests())

                # Flush outside the conditional so that all DP ranks
                # participate in the tp_gather collective even when
                # should_process_previous_batch differs between ranks.
                self._flush_pending_transfer_responses()

                if self.drafter is not None and self.use_spec_decode and should_process_previous_batch:
                    # Cleanup previous draft resources used in the draft model
                    self.drafter.cleanup_previous_draft_resources()

                if not self._scheduler_manages_kv_suspend:
                    self._pause_requests(scheduled_batch.paused_requests)

                if can_queue:
                    guided_decoder_failed_requests = None
                    with self.perf_manager.record_perf_events(
                            None, gpu_sample_end) as sample_timing:
                        if self.guided_decoder is not None:
                            # add_batch must be called again to have updated new tokens.
                            self.guided_decoder.add_batch(scheduled_batch)
                            guided_decoder_failed_requests = self.guided_decoder.execute(
                                batch_outputs['logits'])

                        sample_state = self._sample_async(
                            scheduled_batch, batch_outputs)

                    assert sample_state is not None, "Sampling failed"

                    # Handle guided decoder errors after _sample_async to avoid state conflicts.
                    # If called before, failed requests would be marked as GENERATION_COMPLETE,
                    # causing _sample_async to fail when accessing context_chunk_size property.
                    self._handle_guided_decoder_errors(
                        scheduled_batch, guided_decoder_failed_requests)
                    self._update_request_states(scheduled_batch)

                if self.previous_batch is not None and should_process_previous_batch:
                    self._process_previous_batch()
                    self.perf_manager.compute_batch_gpu_times(
                        self.previous_batch.scheduled_requests.all_requests())
                else:
                    self._enqueue_responses([])

                # Call set_exclude_last_generation_logits after _process_previous_batch.
                # If set before, the response of a request may be incorrect, as it will
                # use the wrong indices for generation logits when streaming is enabled.
                if can_queue:
                    self._update_generation_requests_that_will_complete_next_iteration(
                        scheduled_batch.generation_requests)

                if can_queue:
                    self.perf_manager.save_timing_to_requests(
                        scheduled_batch.all_requests(), gpu_forward_start,
                        gpu_forward_end, gpu_sample_end, fwd_timing.start_time,
                        fwd_timing.end_time, sample_timing.start_time,
                        sample_timing.end_time)
                    if self.enable_iter_perf_stats:
                        iter_stats.inflight_batching_stats.num_ctx_tokens = self.model_engine.iter_states[
                            'num_ctx_tokens']

                    self.previous_batch = BatchState(
                        scheduled_requests=scheduled_batch,
                        sample_state=sample_state,
                        iter_start_time=iter_start_time,
                        iter_stats=iter_stats)
                elif not can_queue_this_rank:
                    # If the batch is empty on this rank, we need to clear the previous batch.
                    self.previous_batch = None

                if self.kv_cache_transceiver and self.async_transfer_manager.has_any_inflight_requests(
                ):
                    self._check_kv_transfer_timeout()

                self._kv_connector_terminate_requests()

                self.iter_counter += 1

    @nvtx_range("_accept_draft_tokens")
    def _accept_draft_tokens(
        self, scheduled_batch: ScheduledRequests,
        target_outputs: SampleStateTensors,
        target_inputs: Optional[SampleStateTensors]
    ) -> Tuple[SampleStateTensorsSpec, Optional[torch.Tensor]]:
        """
        Prepare target device inputs after computing draft token acceptance.

        This function:
        1. If draft tokens exist: compares sampled tokens with draft tokens to compute acceptance
        2. If no draft tokens: directly uses the first sampled token
        3. Creates new_tokens by extracting accepted tokens per request

        Args:
            scheduled_batch: The scheduled requests
            target_outputs: Contains new_tokens [max_draft_len + 1, batch_size, beam_width]
                                or [1, batch_size, beam_width] if no draft tokens
            target_inputs: Contains next_draft_tokens [batch_size, max_draft_len]
        Returns:
            Tuple of:
            - SampleStateTensorsSpec with new_tokens set to accepted tokens,
              new_tokens_lens and next_draft_tokens set to None
            - num_accepted_tokens: [batch_size] tensor with acceptance counts per request,
              or None if no draft tokens
        """
        has_draft_tokens = target_inputs is not None and isinstance(
            target_inputs, SampleStateTensorsSpec
        ) and target_inputs.next_draft_tokens is not None
        target_tokens = target_outputs.new_tokens  # [max_draft_len + 1, batch_size, beam_width] or [1, batch_size, beam_width]
        new_tokens = torch.zeros_like(target_tokens)

        # Squeeze the beam dimension (beam_width=1 for greedy or single beam)
        target_tokens = target_tokens.squeeze(
            -1)  # [max_draft_len + 1, batch_size] or [1, batch_size]

        batch_size = target_tokens.shape[1]
        device = target_tokens.device
        # Compute number of accepted tokens per request
        num_accepted_tokens = torch.zeros(batch_size,
                                          dtype=torch.int32,
                                          device=device)

        if has_draft_tokens:
            # Draft tokens exist, compute acceptance
            draft_tokens = target_inputs.next_draft_tokens  # [batch_size, max_draft_len]
            max_draft_len = draft_tokens.shape[1]

            # Compute number of accepted tokens per request
            # Generation requests: compare with draft tokens to find acceptance
            num_contexts = scheduled_batch.num_context_requests
            if batch_size > num_contexts:
                # Use .T to transpose: [max_draft_len + 1, num_gens] -> [num_gens, max_draft_len + 1]
                gen_target_tokens = target_tokens[:,
                                                  num_contexts:].T  # [num_gens, max_draft_len + 1]

                # Compare draft tokens with target tokens to find acceptance
                # Use cumprod to find the first rejection point
                draft_tokens_gen = draft_tokens[
                    num_contexts:, :].int()  # [num_gens, max_draft_len]
                num_accepted_tokens[num_contexts:] += torch.cumprod(
                    (draft_tokens_gen == gen_target_tokens[:, :max_draft_len]
                     ).int(),
                    dim=-1).sum(dim=1)

            # Vectorized extraction using advanced indexing (no GPU-CPU sync)
            # Use num_accepted_tokens as indices to gather the right tokens
            batch_indices = torch.arange(batch_size, device=device)
            new_tokens[0, :, 0] = target_tokens[num_accepted_tokens,
                                                batch_indices]
        else:
            # No draft tokens to accept, just use the first (and only) sampled token
            batch_indices = torch.arange(batch_size, device=device)
            new_tokens[0, :, 0] = target_tokens[0, batch_indices]

        # Create the updated SampleStateTensorsSpec
        # new_tokens_lens and next_draft_tokens are left as None
        result_tensors = SampleStateTensorsSpec(
            new_tokens=new_tokens,
            log_probs=target_outputs.log_probs,
            new_tokens_lens=None,
            next_draft_tokens=None)

        # Copy logits if available
        if hasattr(target_outputs, 'logits'):
            result_tensors.logits = target_outputs.logits

        return result_tensors, num_accepted_tokens

    def _process_previous_batch(self):
        self._handle_canceled_requests()
        finished_requests = self._handle_responses()
        scheduled_requests = self.previous_batch.scheduled_requests
        attn_metadata = getattr(self.model_engine, 'attn_metadata', None)
        kv_cache_dtype_byte_size = getattr(self.model_engine,
                                           'kv_cache_dtype_byte_size', None)
        self.resource_manager.update_resources(scheduled_requests,
                                               attn_metadata,
                                               kv_cache_dtype_byte_size)
        if self.enable_kv_cache_events:
            self._add_kv_cache_events()

        if self.enable_iter_perf_stats:
            self._process_iter_stats(finished_requests, self.active_requests,
                                     self.previous_batch)

    def _forward_step_inter_pp(self, scheduled_batch) -> SampleState:
        self._forward_step(scheduled_batch)
        sampler_event = torch.cuda.Event()
        sampler_event.record()
        self._update_request_states(scheduled_batch)
        sampling_requests = scheduled_batch.context_requests_last_chunk + scheduled_batch.generation_requests
        return self.sampler.SampleState(
            requests=sampling_requests,
            sampler_event=SamplerEvent(cuda_event=sampler_event),
            runtime_draft_len=self.model_engine.runtime_draft_len,
        )

    def _validate_token_id_range(self, request: LlmRequest) -> None:
        if isinstance(self.model_engine.model, DecoderModelForCausalLM):
            # Only skip token‐range checks for Llama4 when the request has multimodal data
            if isinstance(self.model_engine.model,
                          Llama4ForConditionalGeneration):
                has_mm = bool(request.py_multimodal_data)
                if has_mm:
                    logger.debug(
                        f"Skipping token-range validation for {type(self.model_engine.model).__name__} "
                        "(multimodal request)")
                    return

            # FIXME: This check is necessary because of how Qwen2ForProcessRewardModel
            #        subclasses DecoderModelForCausalLM. Perhaps the functionality
            #        of DecoderModelForCausalLM reused by Qwen2ForProcessRewardModel
            #        should be factored out into a separate class instead.
            if not hasattr(self.model_engine.model, "lm_head"):
                return

            if not request.check_token_id_range(
                    self.model_engine.model.lm_head.num_embeddings):
                raise ValueError("Token ID out of range")

    def _validate_request(self, request: LlmRequest):
        # Validate beam width
        sampling_config = request.sampling_config
        if sampling_config is not None:
            if sampling_config.beam_width != self.max_beam_width:
                raise ValueError(
                    f"Request beam width {sampling_config.beam_width} "
                    f"is not equal to max_beam_width {self.max_beam_width}. This is not supported!"
                )

        # Check token ID ranges
        self._validate_token_id_range(request)

        # Perform sampler-specific validation
        self.sampler.validate_request(request)

    def _fetch_and_enqueue_requests(self, waiting_queue: WaitingQueue,
                                    total_num_active_requests: int) -> None:
        """Fetch requests from request_queue and enqueue to waiting_queue."""
        # Block new requests while control requests are pending
        if len(self.control_requests) != 0:
            return

        # Calculate timeout
        idle = (total_num_active_requests == 0) and len(waiting_queue) == 0
        if idle:
            # In Ray path (TLLM_DISABLE_MPI=1), use a periodic heartbeat timeout so rank 0
            # reaches the broadcast path regularly to prevent trtllm-serve timeout when idle.
            timeout = datetime.timedelta(
                seconds=1200) if self._disable_mpi else None
        else:
            timeout = datetime.timedelta(0)

        # Fetch requests from rank 0
        new_requests = []
        if self.dist.rank == 0:
            # Process accumulated requests that were queued during control request handling.
            if len(self.request_accumulated) != 0:
                new_requests.extend(self.request_accumulated)
                self.request_accumulated.clear()
                # Reset timeout to 0 to avoid hanging when no new requests are available
                timeout = datetime.timedelta(0)
            with self.hang_detector.pause():
                new_requests.extend(
                    self.executor_request_queue.get_from_request_queue(timeout))

        # Broadcast requests and handle Python objects
        new_requests, py_request_objects = self.request_broadcaster.broadcast(
            new_requests)

        # Validate and filter requests
        new_requests = self._handle_special_queue_items(new_requests)

        # Attach Python objects to requests
        if py_request_objects and (self.dist.tp_size > 1 or self.dist.has_pp
                                   or self.dist.cp_size
                                   > 1) and self.dist.rank > 0:
            attach_py_objects_to_requests(new_requests, py_request_objects)

        waiting_queue.add_requests(new_requests)

    def _pop_from_waiting_queue(
        self,
        waiting_queue: WaitingQueue,
        total_num_active_requests: int,
        all_ranks_num_active_requests: Optional[List[int]] = None
    ) -> List[RequestQueueItem]:
        """Pop requests from waiting_queue based on available capacity."""
        if self.enable_attention_dp:
            total_max = self.dist.tp_size * self.max_num_active_requests
        else:
            total_max = self.max_num_active_requests

        max_new_requests = total_max - total_num_active_requests

        return get_from_waiting_queue(
            waiting_queue,
            max_new_requests,
            enable_attention_dp=self.enable_attention_dp,
            max_num_active_requests=self.max_num_active_requests,
            all_ranks_num_active_requests=all_ranks_num_active_requests)

    @nvtx_range("_fetch_new_requests")
    def _fetch_new_requests(
            self, waiting_queue: WaitingQueue,
            active_requests: List[LlmRequest]) -> List[LlmRequest]:
        """Fetch new requests and return LlmRequests ready for execution."""
        # 1. Gather rank states and calculate total_num_active_requests
        if self.enable_attention_dp:
            # NOTE: gather_all_rank_states is called here (before step 3)
            # because _pop_from_waiting_queue needs all_ranks_num_active_requests
            # from the allgather result. Moving it to step 5 would require an
            # extra allgather. When introducing new router implementations
            # (e.g. KV-cache-aware) that need new_requests to gather additional
            # info, the allgather position may need to be revisited.

            all_rank_states = self.adp_router.gather_all_rank_states(
                active_requests)
            all_ranks_num_active_requests = [
                s.num_active_requests for s in all_rank_states
            ]
            total_num_active_requests = sum(all_ranks_num_active_requests)
        else:
            total_num_active_requests = len(active_requests)
            all_ranks_num_active_requests = None
            all_rank_states = None

        # 2. Fetch and enqueue to waiting queue
        self._fetch_and_enqueue_requests(waiting_queue,
                                         total_num_active_requests)

        # 3. Pop requests from waiting queue
        new_requests = self._pop_from_waiting_queue(
            waiting_queue, total_num_active_requests,
            all_ranks_num_active_requests)

        # 4. Update performance metrics (before DP scheduling to clear all start_times)
        if self.enable_iter_perf_stats and self.dist.rank == 0:
            self._update_new_active_requests_queue_latency(new_requests)

        # 5. Update total fetch counter (used by benchmark disagg gating)
        self.num_fetch_requests += len(new_requests)

        # 6. Schedule requests across ranks (DP only)
        if self.enable_attention_dp:
            if self.adp_router.needs_prefix_matches:
                self.adp_router.gather_prefix_matches(new_requests)

            all_ranks_new_requests, self.expected_num_active_requests = \
                self.adp_router.route_requests(
                    all_rank_states, new_requests,
                    self.max_num_active_requests)
            new_requests_cur_rank = all_ranks_new_requests[self.dist.tp_rank]

            # Update per-rank counter for DP
            self.num_fetch_requests_cur_rank += len(new_requests_cur_rank)

            new_requests = new_requests_cur_rank

        # 7. Merge requests
        return merge_requests(new_requests,
                              cp_config=self.dist.cp_config,
                              cp_rank=self.dist.cp_rank,
                              cp_size=self.dist.cp_size,
                              exclude_last_generation_logits=self.
                              _should_exclude_last_generation_logits())

    def _handle_special_queue_items(
            self,
            new_requests: List[RequestQueueItem]) -> List[RequestQueueItem]:
        """Handle special signals."""
        accepted_new_requests = []
        for idx, req_item in enumerate(new_requests):
            if req_item.is_shutdown_request:
                self.is_shutdown = True
                break
            elif req_item.is_canceled_request:
                self.canceled_req_ids.append(req_item.id)
            elif req_item.is_control_request:
                self.control_requests.append(req_item)
                if self.dist.rank == 0:
                    self.request_accumulated.extend(new_requests[idx + 1:])
                break
            else:
                accepted_new_requests.append(req_item)

        return accepted_new_requests

    def _update_new_active_requests_queue_latency(
            self, new_requests: List[RequestQueueItem]):
        """Update queue latency metrics for new requests."""
        now = time.time()
        latency = self.executor_request_queue.calculate_queue_latency(
            new_requests, now)
        self.new_active_requests_queue_latency_ms += latency

    def _get_new_active_requests_queue_latency(self) -> float:
        return self.new_active_requests_queue_latency_ms

    def _should_exclude_last_generation_logits(self) -> bool:
        return self.should_exclude_last_generation_logits

    def _fetch_and_activate_new_requests(self) -> List[LlmRequest]:

        def _respond_if_invalid(request: LlmRequest) -> bool:
            """Immediately fail invalid request.

            Return True if invalid request was encountered and
            handled.
            """
            try:
                self._validate_request(request)
                return False
            except Exception as e:
                self._handle_errors(str(e),
                                    requests=[request],
                                    charge_budget=False)
                return True

        new_requests_cur_rank = self._fetch_new_requests(
            self.waiting_queue, self.active_requests)

        validated_requests = [
            request for request in new_requests_cur_rank
            if not _respond_if_invalid(request)
        ]

        self.active_requests.extend(validated_requests)
        return validated_requests

    def _add_kv_cache_events(self):
        kv_cache_manager = self.resource_manager.resource_managers.get(
            ResourceManagerType.KV_CACHE_MANAGER)
        if not kv_cache_manager:
            return
        # Flush iteration events at each iteration to ensure that events have enough time
        # to be transferred to main thread when user needs them.
        kv_cache_manager.flush_iteration_events()

    def _balance_adp_requests(self, context_requests: list[LlmRequest],
                              generation_requests: list[LlmRequest]):
        balanced_context_requests = context_requests
        num_scheduled_context_requests = len(context_requests)
        num_scheduled_generation_requests = len(generation_requests)
        num_scheduled_tokens = sum(
            [len(req.get_tokens(0))
             for req in context_requests]) + num_scheduled_generation_requests
        # Note: We use tp_allgather instead of tp_cp_allgather because we want to
        # balance the requests across DP ranks; not CP ranks within those DP ranks.
        responses_list = self.dist.tp_allgather([
            num_scheduled_context_requests, num_scheduled_generation_requests,
            num_scheduled_tokens
        ])
        all_ranks_num_scheduled_context_requests = [
            response[0] for response in responses_list
        ]
        all_ranks_num_scheduled_generation_requests = [
            response[1] for response in responses_list
        ]
        all_ranks_have_free_ctx_slots = all([
            num_gen < self.max_batch_size
            for num_gen in all_ranks_num_scheduled_generation_requests
        ])
        all_ranks_have_ctx_requests = all([
            num_ctx > 0 for num_ctx in all_ranks_num_scheduled_context_requests
        ])
        all_ranks_have_gen_requests = all([
            num_gen > 0
            for num_gen in all_ranks_num_scheduled_generation_requests
        ])

        if self.attention_dp_enable_balance:
            # wait for all ranks have context requests
            if all_ranks_have_free_ctx_slots and all_ranks_have_ctx_requests:
                self.adp_ctx_waiting_iters_count = 0
                # balance number of context requests across ranks
                if all_ranks_have_gen_requests:
                    if self.adp_ctx_batching_wait_iters_count < self.attention_dp_batching_wait_iters:
                        self.adp_ctx_batching_wait_iters_count += 1
                        balanced_context_requests = []
                    else:
                        self.adp_ctx_batching_wait_iters_count = 0
            else:
                self.adp_ctx_waiting_iters_count += 1
                balanced_context_requests = []
                timeout_reached = self.adp_ctx_waiting_iters_count >= self.attention_dp_time_out_iters
                if timeout_reached or not all_ranks_have_gen_requests:
                    self.adp_ctx_waiting_iters_count = 0
                    balanced_context_requests = context_requests
        return balanced_context_requests

    @staticmethod
    def _compute_scheduled_tokens(context_requests, generation_requests):
        """Compute the total number of scheduled tokens for batch waiting decisions.

        For context requests, we estimate the actual compute tokens for this
        iteration (excluding tokens served from KV cache).

        For generation requests, each contributes 1 + num_draft_tokens.

        Note on reusable token handling:
        estimated_reusable_tokens is an absolute count from position 0.
        Depending on the scheduler, context_current_position may or may not
        have been advanced past the reusable prefix by the time this method
        is called:
        - V1 scheduler: prepare_context runs after scheduling, so
          context_current_position is still 0.
        - V2 scheduler: prepare_context runs during scheduling, so
          context_current_position is already advanced to the reused offset.
        To handle both correctly, the reusable credit applied to the current
        chunk is max(0, reusable - context_current_position), i.e. only the
        portion of the reusable range that falls within this chunk's span.
        """
        num_scheduled_ctx_tokens = 0
        for ctx_req in context_requests:
            reusable = (ctx_req.estimated_reusable_tokens
                        if ctx_req.is_first_context_chunk else 0)
            # Credit only the reusable tokens that overlap with the current
            # chunk: if context_current_position has already been advanced past
            # the reusable prefix (V2), the credit is 0; if not (V1), the full
            # reusable count is subtracted.
            reusable_in_chunk = max(0,
                                    reusable - ctx_req.context_current_position)
            remaining = ctx_req.context_remaining_length
            if reusable_in_chunk <= 0:
                compute = ctx_req.context_chunk_size
            elif reusable_in_chunk + ctx_req.context_chunk_size < remaining:
                compute = ctx_req.context_chunk_size
            else:
                compute = max(1, remaining - reusable_in_chunk)
            num_scheduled_ctx_tokens += compute
        num_scheduled_gen_tokens = sum(1 + gen_req.num_draft_tokens
                                       for gen_req in generation_requests)
        return num_scheduled_ctx_tokens + num_scheduled_gen_tokens

    def _waiting_requests(self, context_requests: list[LlmRequest],
                          generation_requests: list[LlmRequest]):
        """
        Return an empty list if scheduled requests fulfill the waiting conditions, otherwise return the original context requests.
        Waiting conditions:
        - The number of scheduled tokens (both context and generation) is smaller than `self.batch_wait_max_tokens_ratio * self.max_num_tokens`
        - The number of waiting iterations is smaller than `self.batch_wait_timeout_iters`.
        """

        num_scheduled_tokens = self._compute_scheduled_tokens(
            context_requests, generation_requests)

        should_waiting = self.batch_wait_iters_count < self.batch_wait_timeout_iters and num_scheduled_tokens < self.batch_wait_max_tokens_ratio * self.max_num_tokens
        if should_waiting:
            self.batch_wait_iters_count += 1
            return []

        self.batch_wait_iters_count = 0
        return context_requests

    @nvtx_range("_schedule")
    def _schedule(self):
        scheduler_output = self.scheduler.schedule_request(
            self.active_requests, self.inflight_req_ids)

        scheduled_context_requests = scheduler_output.context_requests
        if self.enable_attention_dp and self.attention_dp_enable_balance:
            scheduled_context_requests = self._balance_adp_requests(
                scheduler_output.context_requests,
                scheduler_output.generation_requests)

        # If no generation requests, no need to wait, to avoid dead waiting
        should_check_waiting = not self.enable_attention_dp and self.enable_batch_waiting and len(
            scheduler_output.context_requests) > 0 and len(
                scheduler_output.generation_requests) > 0
        if should_check_waiting:
            scheduled_context_requests = self._waiting_requests(
                scheduler_output.context_requests,
                scheduler_output.generation_requests)

        scheduled_requests = ScheduledRequests()
        scheduled_requests.reset_context_requests(scheduled_context_requests)
        scheduled_requests.generation_requests = scheduler_output.generation_requests
        scheduled_requests.paused_requests = scheduler_output.paused_requests

        return scheduled_requests, scheduler_output.fitting_disagg_gen_init_requests, scheduler_output.num_fitting_requests

    @nvtx_range("_check_disagg_gen_transfer_status")
    def _check_disagg_gen_transfer_status(self):

        need_check = any([
            req.is_disagg_generation_transmission_in_progress
            for req in self.active_requests
        ])
        non_gen_first_reqs = [
            req for req in self.active_requests
            if req.py_disaggregated_params and req.py_disaggregated_params.
            schedule_style != DisaggScheduleStyle.GENERATION_FIRST
        ]
        need_check_one = bool(non_gen_first_reqs) and all(
            req.is_disagg_generation_transmission_in_progress
            for req in non_gen_first_reqs)

        if need_check:
            at_least_num = 1 if need_check_one else 0
            self._check_disagg_gen_cache_transfer_status(at_least_num)

        return

    @nvtx_range("_check_kv_transfer_timeout")
    def _check_kv_transfer_timeout(self):
        if not self.kv_cache_transceiver:
            return
        timeout_ms = self.kv_cache_transceiver.kv_transfer_timeout_ms
        if timeout_ms is None:
            return

        def flag_if_kv_transfer_timed_out(req: LlmRequest, type: str) -> None:
            current_time = time.time()
            if req.py_kv_transfer_start_time is None:
                return
            elapsed_time = (current_time - req.py_kv_transfer_start_time) * 1000
            if elapsed_time > timeout_ms and not req.py_kv_transfer_timed_out:
                logger.warning(
                    f"Terminating {type} request {req.py_request_id} due to KV cache transfer timeout"
                )
                req.py_kv_transfer_timed_out = True

        for req in self.async_transfer_manager.requests_in_transfer().values():
            flag_if_kv_transfer_timed_out(req, "context")

        for req in self.active_requests:
            if req.is_disagg_generation_transmission_in_progress:
                flag_if_kv_transfer_timed_out(req, "generation")

        return

    @nvtx_range("_check_disagg_ctx_schedulable_status")
    def _check_disagg_ctx_schedulable_status(self,
                                             new_requests: List[LlmRequest]):
        """
        In context-first mode, context requests are schedulable immediately,
        otherwise, we need to check if context requests are ready to be scheduled by querying kv cache transceiver
        """
        if not self.kv_cache_transceiver:
            return
        gen_first_ctx_requests = [
            req for req in new_requests
            if req.is_context_only_request and req.py_disaggregated_params.
            schedule_style == DisaggScheduleStyle.GENERATION_FIRST
        ]
        # Always call prepare_context_requests when there are new requests
        # or previously-waiting requests, so the tp_allgather consensus
        # can promote requests whose peer info has arrived on all ranks.
        self.kv_cache_transceiver.prepare_context_requests(
            gen_first_ctx_requests)

    def _count_schedulable_active_requests(self) -> int:
        """Count active requests that are ready for scheduling.

        In non-disaggregated mode, all active requests are schedulable.
        In disaggregated mode, requests still waiting for KV cache
        transfer (in INIT or transmission-in-progress state) are
        excluded because they cannot participate in the forward pass
        until transfer completes.

        Returns:
            The number of active requests eligible for scheduling.
        """
        if self.kv_cache_transceiver is None:
            return len(self.active_requests)

        def _is_awaiting_kv_transfer(req) -> bool:
            return (req.is_disagg_generation_init_state
                    or req.is_disagg_generation_transmission_in_progress)

        return sum(1 for req in self.active_requests
                   if not _is_awaiting_kv_transfer(req))

    def _should_skip_dummy_for_benchmark_disagg(
            self, num_schedulable_requests: int) -> bool:
        """Decide whether to skip ADP dummy insertion during benchmark disagg fill.

        During the fill phase (``_benchmark_fill_phase_active`` is True),
        the ``can_forward`` gate prevents forward-pass collectives, so
        temporarily-empty ranks don't need dummies.  Dummies added during
        the fill phase would never be cleaned up (termination only runs
        after a forward pass), permanently wasting KV cache slots.

        Once the fill phase completes and the gate opens, the flag is
        cleared and this method stops skipping — the normal dummy
        add-forward-terminate lifecycle handles taper-down correctly
        (e.g., when ranks empty out at different rates due to varied
        speculative decoding acceptance rates).

        Args:
            num_schedulable_requests: Number of active requests that have
                completed KV transfer and are ready for the forward pass.

        Returns:
            True if dummy insertion should be skipped for this iteration.
        """
        if not self._benchmark_fill_phase_active or self.is_warmup:
            return False

        logger.info(f"Skipped adding dummy requests: "
                    f"num_fetch_requests={self.num_fetch_requests}, "
                    f"num_schedulable_requests={num_schedulable_requests}")
        return True

    @nvtx_range("_pad_attention_dp_dummy_request")
    def _pad_attention_dp_dummy_request(self):
        """
        Pad with a generation dummy request, if required, to ensure every attention_dp rank has at least one active request.
        """
        if not self.enable_attention_dp:
            return

        assert self.expected_num_active_requests >= len(self.active_requests)
        num_active_request = self._count_schedulable_active_requests()

        if self._should_skip_dummy_for_benchmark_disagg(num_active_request):
            return

        # Other ranks have work but this rank is idle — insert a dummy so
        # it can participate in collective operations during the forward pass.
        if num_active_request == 0 and self.expected_num_active_requests > 0:
            llm_request = self.kv_cache_manager.add_dummy_requests(
                request_ids=[0],
                is_gen=True,
                prepare_resource=True,
                max_num_draft_tokens=self.max_total_draft_tokens,
            )[0]
            llm_request.is_attention_dp_dummy = True
            spec_resource_manager = self.resource_manager.get_resource_manager(
                ResourceManagerType.SPEC_RESOURCE_MANAGER)
            if spec_resource_manager is not None:
                spec_resource_manager.add_dummy_requests([0])
            self.active_requests.append(llm_request)

    @nvtx_range("_prepare_disagg_gen_init")
    def _prepare_disagg_gen_init(self, fitting_disagg_gen_init_requests):
        if fitting_disagg_gen_init_requests:
            disagg_gen_init_to_prepare = ScheduledRequests()
            disagg_gen_init_to_prepare.context_requests_last_chunk = fitting_disagg_gen_init_requests

            for resource_mgr_type in (
                    ResourceManagerType.KV_CACHE_MANAGER,
                    ResourceManagerType.SPEC_RESOURCE_MANAGER,
                    ResourceManagerType.DRAFT_KV_CACHE_MANAGER):
                if (resource_mgr_type in self.resource_manager.resource_managers
                        and self.resource_manager.
                        resource_managers[resource_mgr_type] is not None):
                    self.resource_manager.resource_managers[
                        resource_mgr_type].prepare_resources(
                            disagg_gen_init_to_prepare)

            # Trigger KV cache exchange for new disagg_gen_init_requests
            self._recv_disagg_gen_cache(fitting_disagg_gen_init_requests)

    @nvtx_range("_prepare_disagg_gen_transmission_complete")
    def _prepare_disagg_gen_transmission_complete(self, scheduled_batch):
        cache_trans_complete_requests = []
        for req in scheduled_batch.generation_requests:
            if req.is_disagg_generation_transmission_complete:
                cache_trans_complete_requests.append(req)
        if len(cache_trans_complete_requests) > 0:
            requests = ScheduledRequests()
            requests.context_requests_last_chunk = cache_trans_complete_requests
            self.resource_manager.resource_managers[
                ResourceManagerType.SEQ_SLOT_MANAGER].prepare_resources(
                    requests)
            self._setup_sampler_step(requests)

        for req in scheduled_batch.generation_requests:
            if req.is_disagg_generation_transmission_complete:
                req.state = LlmRequestState.GENERATION_IN_PROGRESS
                req.context_current_position = req.prompt_len
                req.decoding_iter = 1
                req.py_decoding_iter = 1
                req.py_kv_transfer_start_time = None
                first_gen_tokens = req.context_phase_params.first_gen_tokens
                ctx_draft_tokens = req.context_phase_params.draft_tokens
                req.py_draft_tokens = [] if ctx_draft_tokens is None else ctx_draft_tokens
                beam_width = req.sampling_config.beam_width
                for beam in range(0, beam_width):
                    req.add_new_token(first_gen_tokens[beam], beam)

                self._maybe_prepend_logprobs_and_logits(req, beam_width)

    def _maybe_prepend_logprobs_and_logits(self, req, beam_width):
        """Prepend logprobs and generation logits for first_gen_tokens
        if transferred from prefill."""
        disagg_params = getattr(req, 'py_disaggregated_params', None)
        if disagg_params is None:
            return

        if getattr(disagg_params, 'first_gen_log_probs', None) is not None:
            if beam_width != 1:
                logger.warning(
                    "Skipping first_gen_log_probs prepend for "
                    "request %s: beam_width=%s is not supported.",
                    req.py_request_id, beam_width)
            else:
                req.py_result.append_log_probs(
                    [disagg_params.first_gen_log_probs])

        if getattr(disagg_params, 'first_gen_logits', None) is not None:
            if beam_width != 1:
                logger.warning(
                    "Skipping first_gen_logits prepend for "
                    "request %s: beam_width=%s is not supported.",
                    req.py_request_id, beam_width)
            else:
                device = torch.device('cuda', self.device_id)
                for logits_tensor in disagg_params.first_gen_logits:
                    req.py_result.append_generation_logits(
                        logits_tensor.to(device))

    def _has_prepended_logits(self, req) -> bool:
        """Check whether the request has first-gen logits prepended from
        prefill that need a snapshot before response creation."""
        if not self.should_exclude_last_generation_logits:
            return False
        disagg_params = getattr(req, 'py_disaggregated_params', None)
        if disagg_params is None:
            return False
        return getattr(disagg_params, 'first_gen_logits', None) is not None

    @nvtx_range("_recv_disagg_gen_cache")
    def _recv_disagg_gen_cache(self, new_gen_reqs):

        # For gen-only benchmarking, mark new gen request as transmission complete right away
        if os.getenv("TRTLLM_DISAGG_BENCHMARK_GEN_ONLY") == "1":
            for req in new_gen_reqs:
                req.state = LlmRequestState.DISAGG_GENERATION_TRANS_COMPLETE
            return

        if os.getenv("TRTLLM_DISABLE_KV_CACHE_TRANSFER_OVERLAP") == "1":
            for req in new_gen_reqs:
                self.kv_cache_transceiver.request_and_receive_sync(req)
        else:
            for req in new_gen_reqs:
                self.kv_cache_transceiver.request_and_receive_async(req)

        if self.kv_cache_transceiver.kv_transfer_timeout_ms is not None:
            for req in new_gen_reqs:
                if req.state == LlmRequestState.DISAGG_GENERATION_TRANS_IN_PROGRESS:
                    req.py_kv_transfer_start_time = time.time()

        non_gen_first_active = [
            req for req in self.active_requests
            if req.py_disaggregated_params and req.py_disaggregated_params.
            schedule_style != DisaggScheduleStyle.GENERATION_FIRST
        ]
        block_transfer = bool(non_gen_first_active) and all(
            req.is_disagg_generation_transmission_in_progress
            for req in non_gen_first_active)
        self._check_disagg_gen_cache_transfer_status(1 if block_transfer else 0)

        return

    @nvtx_range("_send_kv_async")
    def _send_kv_async(self, scheduled_requests: List[LlmRequest]):

        def kv_connector_request_finished(req: LlmRequest):
            try:
                cache_block_ids = self.kv_cache_manager.get_cache_indices(req)
            except Exception as e:
                logger.warning(
                    f"Unable to get cache blocks for request {req.py_request_id}. Skipping asynchronous saving: {e}"
                )
            else:
                if self.kv_connector_manager.request_finished(
                        req, cache_block_ids):
                    self.async_transfer_manager.start_transfer(req)

        if self.kv_cache_transceiver:
            for req in scheduled_requests:
                if req.is_context_only_request and (
                        req.is_context_finished or req.is_finished_due_to_length
                ) and not req.is_finished_due_to_cancellation:
                    # Order is important here: we need to start the transfer before responding
                    # to make sure the blocks are stored for reuse before they are sent.
                    self.async_transfer_manager.start_transfer(req)
                    self.kv_cache_transceiver.respond_and_send_async(req)

                    if self.kv_cache_transceiver.kv_transfer_timeout_ms is not None:
                        req.py_kv_transfer_start_time = time.time()

        if self.kv_connector_manager:
            if not self.disable_overlap_scheduler:
                requests = self.previous_batch.scheduled_requests.all_requests(
                ) if self.previous_batch is not None else []
            else:
                requests = scheduled_requests
            for req in requests:
                if req.is_finished:
                    kv_connector_request_finished(req)

        if self.kv_cache_transceiver:
            self._check_disagg_ctx_cache_transfer_status(0)

    def _get_disagg_reqs_in_error_state(self):
        return [
            req for req in self.active_requests
            if req.state == LlmRequestState.DISAGG_TRANS_ERROR
        ]

    def _check_cache_transfer_errors(self, error_msg_prefix: str):
        """Common helper to check for and handle cache transfer errors."""
        error_requests = self._get_disagg_reqs_in_error_state()
        if error_requests:
            self._handle_errors(
                f"Error in kv cache transfer for {error_msg_prefix}",
                requests=error_requests,
                charge_budget=False)

    @nvtx_range("_check_disagg_ctx_cache_transfer_status")
    def _check_disagg_ctx_cache_transfer_status(self, atLeastNum: int = 0):
        finished_requests, error_requests = self.kv_cache_transceiver.check_context_transfer_status(
            atLeastNum)

        completed_req_ids = set(finished_requests + error_requests)

        requests_in_transfer = self.async_transfer_manager.requests_in_transfer(
        )

        for request_id in completed_req_ids:

            if request_id not in requests_in_transfer:
                logger.warning(
                    f"Request {request_id} not found in transfer manager")
                continue

            request = requests_in_transfer[request_id]

            self._end_transfer_and_maybe_terminate(request)

        # The set of requests in transfer may have changed since we terminated some requests.
        requests_in_transfer = self.async_transfer_manager.requests_in_transfer(
        )

        for request_id in list(requests_in_transfer.keys()):
            request = requests_in_transfer[request_id]
            if request.py_kv_transfer_timed_out and request_id not in completed_req_ids:
                is_cancelled = self.kv_cache_transceiver.cancel_request(request)
                # If cancel is successful, mark as complete so it can be cleaned up
                # Otherwise, try at next iteration
                if is_cancelled:
                    request.py_kv_transfer_start_time = None
                    request.state = LlmRequestState.DISAGG_CONTEXT_COMPLETE

                    self._end_transfer_and_maybe_terminate(request)

        self._check_cache_transfer_errors("context requests")

    @nvtx_range("_check_disagg_gen_cache_transfer_status")
    def _check_disagg_gen_cache_transfer_status(self, atLeastNum: int = 0):
        self.kv_cache_transceiver.check_gen_transfer_status(atLeastNum)
        self._check_cache_transfer_errors("generation requests")

    def _forward_step(
            self,
            scheduled_requests: ScheduledRequests,
            new_tensors_device: Optional[SampleStateTensors] = None,
            num_accepted_tokens_device: Optional[torch.Tensor] = None):
        ExpertStatistic.set_iter(self.iter_counter)

        @nvtx_range(
            f"[Executor] _forward_step {self.iter_counter}: {scheduled_requests.num_context_requests} ctx reqs, {scheduled_requests.num_generation_requests} gen reqs"
        )
        def forward(scheduled_requests, resource_manager, new_tensors_device,
                    gather_context_logits, cache_indirection_buffer,
                    num_accepted_tokens_device):
            return self.model_engine.forward(
                scheduled_requests,
                resource_manager,
                new_tensors_device,
                gather_context_logits=gather_context_logits,
                cache_indirection_buffer=cache_indirection_buffer,
                num_accepted_tokens_device=num_accepted_tokens_device)

        try:
            gather_context_logits = any(
                a.py_return_context_logits
                for a in scheduled_requests.context_requests)
            cache_indirection_buffer = self.sampler.get_cache_indirection()

            # Run model forward on the execution stream for proper synchronization
            # with KVCacheTransferManager's onboard/offload operations.
            self.execution_stream.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(self.execution_stream):
                outputs = forward(scheduled_requests, self.resource_manager,
                                  new_tensors_device, gather_context_logits,
                                  cache_indirection_buffer,
                                  num_accepted_tokens_device)

            # Ensure the default stream waits for execution_stream to complete
            # before downstream operations use the outputs.
            torch.cuda.current_stream().wait_stream(self.execution_stream)

            self._kv_connector_wait_for_save()

            return outputs
        except Exception as e:
            traceback.print_exc()
            error_msg = str(e)
            logger.error(
                f"Encountered an error in forward function: {error_msg}")
            self._handle_errors(error_msg)
            return None

    def _update_generation_requests_that_will_complete_next_iteration(
            self, generation_requests: list[LlmRequest]):
        """ Update the generation requests that will complete next iteration.

        If overlap scheduling is enabled, we need update the state of generation requests that will complete next iteration
        and adjust the exclude_last_generation_logits flag accordingly.
        """
        for request in generation_requests:
            if request.state != LlmRequestState.GENERATION_COMPLETE and request.will_complete_next_iteration(
            ):
                request.set_exclude_last_generation_logits(False)
                request.state = LlmRequestState.GENERATION_TO_COMPLETE

    def _update_request_states_tp(self, scheduled_requests: ScheduledRequests):
        # handle potential attention dp dummy request
        if self.active_requests and self.active_requests[
                -1].is_attention_dp_dummy:
            request = self.active_requests[-1]
            request.state = LlmRequestState.GENERATION_COMPLETE
            self.inflight_req_ids.erase(request.py_request_id)
            self._terminate_request(request)
            self.active_requests.remove(request)

        for request in scheduled_requests.context_requests:
            if request.state != LlmRequestState.GENERATION_COMPLETE:  # skip failed requests
                request.py_last_context_chunk = (
                    request.context_current_position,
                    request.context_current_position +
                    request.context_chunk_size)
                request.move_to_next_context_chunk()
            if request.context_remaining_length == 0:
                # Prefill is done for this request; drop pinned encoder outputs
                # (multimodal_embedding) and raw pre-encoder tensors that multimodal models stashed
                # on `py_multimodal_data`. Without this, encoder inputs and outputs for multi-modal
                # requests stay pinned on GPU through the full decode lifetime and can lead to OOMs
                # at high concurrency.
                _strip_py_multimodal_data_post_prefill(request)
                if not self.disable_overlap_scheduler and request.will_complete_next_iteration(
                ):
                    request.set_exclude_last_generation_logits(False)
                    request.state = LlmRequestState.GENERATION_TO_COMPLETE
                else:
                    request.state = LlmRequestState.GENERATION_IN_PROGRESS

    def _update_request_states_star_attention(
            self, scheduled_requests: ScheduledRequests):
        for request in scheduled_requests.context_requests:
            if request.ctx_iters >= len(request.ctx_blocks) - 2:
                request.state = LlmRequestState.GENERATION_IN_PROGRESS
            request.ctx_iters += 1

        for request in scheduled_requests.generation_requests:
            request.gen_iters += 1

    @nvtx_range("_update_request_states")
    def _update_request_states(self, scheduled_requests: ScheduledRequests):
        cp_config = self.dist.cp_config
        if 'cp_type' in cp_config:
            cp_type = cp_config['cp_type']
            if cp_type == CpType.STAR:
                self._update_request_states_star_attention(scheduled_requests)
            elif cp_type == CpType.HELIX:
                # Take the usual route with _update_request_states_tp().
                pass
            else:
                raise NotImplementedError(
                    f'Unsupported cp type {cp_type.name}.')
        self._update_request_states_tp(scheduled_requests)

    @nvtx_range("_sample_async")
    def _sample_async(self, scheduled_batch,
                      batch_outputs) -> SampleState | None:
        try:
            if batch_outputs is not None:
                num_context_logits_prefix_sum = [0]
                prefix_sum = 0
                num_context_tokens = 0
                for request in scheduled_batch.context_requests:
                    context_chunk_size = request.context_chunk_size
                    prefix_sum += context_chunk_size if request.py_return_context_logits else 1
                    num_context_logits_prefix_sum.append(prefix_sum)
                    num_context_tokens += context_chunk_size

                beam_width = self.sampler.beam_width(
                    scheduled_batch.all_requests())

                HandleLogits()(scheduled_batch.context_requests,
                               scheduled_batch.generation_requests,
                               batch_outputs["logits"], beam_width,
                               num_context_logits_prefix_sum,
                               self.sampler.is_generation_model())

                HandleAdditionalOutputs()(scheduled_batch.context_requests,
                                          scheduled_batch.generation_requests,
                                          batch_outputs, beam_width,
                                          num_context_tokens)

                return self.sampler.sample_async(scheduled_batch, batch_outputs,
                                                 num_context_logits_prefix_sum)
        except Exception as e:
            traceback.print_exc()
            error_msg = str(e)
            logger.error(f"Encountered an error in sampling: {error_msg}")
            self._handle_errors(error_msg)

    @nvtx_range("_setup_sampler_step")
    def _setup_sampler_step(self, requests: ScheduledRequests):
        try:
            return self.sampler.setup_sampler_step(requests)
        except Exception as e:
            traceback.print_exc()
            error_msg = str(e)
            logger.error(f"Encountered an error in sampling: {error_msg}")
            self._handle_errors(error_msg)

    @nvtx_range("_update_requests")
    def _update_requests(self,
                         sample_state: SampleState,
                         resource_manager: Optional[ResourceManager] = None):
        try:
            self.sampler.update_requests(sample_state, resource_manager)
        except Exception as e:
            traceback.print_exc()
            error_msg = str(e)
            logger.error(f"Encountered an error in sampling: {error_msg}")
            self._handle_errors(error_msg)

    def _handle_errors(self,
                       error_msg: Optional[str] = None,
                       *,
                       requests: Optional[List[LlmRequest]] = None,
                       charge_budget: bool = True) -> None:
        """Fail requests and optionally initiate shutdown on fatal errors.

        When ``charge_budget`` is True (the default), classifies the error
        via the error budget.  If deemed fatal (immediate-fatal pattern or
        budget exhausted), **all** active requests are failed and a shutdown
        is enqueued.  Otherwise only the requests in *requests* are failed.

        When ``charge_budget`` is False, the error is treated as a
        per-request failure: only the specified requests are failed, the
        error budget is not consumed, and shutdown is never triggered.
        Use this for request-scoped errors (validation, KV-transfer
        timeout, guided-decoder) that should not affect server health.

        .. note::
            The ``charge_budget=False`` path reuses the full
            ``_handle_errors`` machinery (queue drain, response
            enqueue, terminate) even though it only needs to fail a
            single request.  A future improvement would be to extract
            a lightweight ``_fail_request(request, error_msg)`` helper
            for request-scoped failures, keeping ``_handle_errors``
            focused on system-level errors that may crash the engine.

        Args:
            error_msg: Human-readable error description.  Defaults to
                ``"error"`` when ``None``.
            requests: Subset of active requests to fail.  When ``None``
                (or when the error is fatal), all ``active_requests`` are
                failed.
            charge_budget: Whether to consume the error budget.  Set to
                False for request-scoped errors that should not affect
                server health.
        """
        error_responses: Dict[int, LlmResponse] = {}
        error_msg = error_msg or "error"

        is_fatal = (self._error_budget.consume(error_msg)
                    if charge_budget else False)
        if is_fatal and self._error_budget.budget < 1e-9:
            logger.error(f"Error budget exhausted "
                         f"(budget={self._error_budget.budget:.3f}), "
                         "treating as fatal")

        if is_fatal:
            self._fatal_error = RuntimeError(f"Fatal error: {error_msg}")
            self.is_shutdown = True
            logger.error(
                f"Fatal error detected, initiating shutdown: {error_msg}")
            requests = None

            # Drain waiting_queue so that queued-but-not-yet-activated
            # requests don't get picked up on the next iteration.
            # These are RequestQueueItems (not yet LlmRequests), so we
            # fail them via error responses.  Buffer all responses and
            # call _enqueue_responses once after the loop so every rank
            # enters the same number of collectives (attention-DP /
            # gather-all modes use collective gathers internally).
            waiting_responses: List[Tuple[int, LlmResponse]] = []
            while self.waiting_queue:
                item = self.waiting_queue.pop_request()
                if (self.gather_all_responses
                        or self.dist.rank == 0) and item.request is not None:
                    waiting_responses.append(
                        (item.id,
                         LlmResponse(request_id=item.id,
                                     error_msg=error_msg,
                                     client_id=getattr(item.request,
                                                       'client_id', None))))
            # Also drain executor_request_queue so items already queued
            # but not yet fetched by the main loop are not scheduled
            # after the CUDA context is corrupted.  Safe to use empty()
            # here because is_shutdown is True and the queue's active
            # flag is about to be set False, so no new items arrive.
            raw_queue = self.executor_request_queue.get_request_queue()
            while not raw_queue.empty():
                item = raw_queue.get_nowait()
                if item.is_shutdown_request:
                    continue
                if ((self.gather_all_responses or self.dist.rank == 0)
                        and item.request is not None):
                    waiting_responses.append(
                        (item.id,
                         LlmResponse(request_id=item.id,
                                     error_msg=error_msg,
                                     client_id=getattr(item.request,
                                                       'client_id', None))))

            if waiting_responses:
                self._enqueue_responses(waiting_responses)
                logger.info(f"Drained {len(waiting_responses)} queued requests "
                            "on fatal error")

        failed_requests = (list(self.active_requests)
                           if requests is None else requests)
        for request in failed_requests:
            req_id = request.py_request_id
            request.state = LlmRequestState.GENERATION_COMPLETE
            error_responses[req_id] = LlmResponse(
                request_id=req_id,
                error_msg=error_msg,
                client_id=request.py_client_id)
        if requests is None:
            self.active_requests.clear()
        else:
            self.active_requests = [
                request for request in self.active_requests
                if request not in requests
            ]
        self._enqueue_responses(list(error_responses.items()))
        for request in failed_requests:
            self._terminate_request(request)

        if self._fatal_error is not None:
            self.executor_request_queue.enqueue_shutdown_request()

    def _terminate_request(self, request: LlmRequest):
        # Dummy requests don't participate in disagg KV cache transfers,
        # so they must bypass the PP termination handler to avoid stale
        # sequences in the KV cache manager (the handler delays removal,
        # but the dummy ID is reused every iteration).
        if (self._disagg_pp_termination_handler is not None
                and not request.is_dummy_request):
            self._disagg_pp_termination_handler.terminate(request)
        else:
            self._do_terminate_request(request)

    def _do_terminate_request(self, request: LlmRequest):
        self.resource_manager.free_resources(request)

        if self.gather_all_responses or self.dist.rank == 0:
            self.result_wait_queues.pop(request.py_request_id, None)

    def _is_request_in_transmission(self, request) -> bool:
        """Check if a request is currently in transmission state."""
        return (request.state
                == LlmRequestState.DISAGG_CONTEXT_TRANS_IN_PROGRESS
                or request.state
                == LlmRequestState.DISAGG_GENERATION_TRANS_IN_PROGRESS)

    def _try_cancel_request(self, request) -> bool:
        """Check if a request can be canceled and attempt cancellation if needed.

        Returns:
            bool: True if the request can be canceled (either successfully cancelled or doesn't need cancellation).
        """
        if self.kv_cache_transceiver is None:
            return True

        if not self._is_request_in_transmission(request):
            return True

        return self.kv_cache_transceiver.cancel_request(request)

    @nvtx_range("_handle_canceled_requests")
    def _handle_canceled_requests(self):
        if len(self.canceled_req_ids) == 0:
            return

        # Create set from list of canceled request ids to speed up canceled test
        canceled_req_ids_set = set(self.canceled_req_ids)

        # Remove canceled requests from the waiting queue
        self.waiting_queue.remove_by_ids(canceled_req_ids_set)

        still_pending_canceled_ids = []
        for request in self.active_requests:
            req_id = request.py_request_id if not request.is_child else request.parent_request_id
            if req_id not in canceled_req_ids_set:
                continue

            is_cancelled = self._try_cancel_request(request)
            if is_cancelled:
                # Mark requests as finished, then, we reuse all existing code
                # to clean up the KV cache resources.
                request.finish_by_reason(FinishReason.CANCELLED)
                request.decoding_iter = request.py_decoding_iter
            else:
                still_pending_canceled_ids.append(req_id)

        # Clear list of requests marked for cancellation and add back those that failed to cancel.
        self.canceled_req_ids.clear()
        self.canceled_req_ids.extend(still_pending_canceled_ids)

    @nvtx_range("_enqueue_responses")
    def _enqueue_responses(self, responses: Iterable[Tuple[int, LlmResponse]]):
        if 0 not in self.dist.mapping.tp_group and not self.gather_all_responses:
            return

        if self.enable_attention_dp and self.dist.world_size != 1:
            if not self.gather_all_responses:
                responses_list = self.dist.tp_gather(responses)
            else:
                responses_list = self.dist.allgather(responses)
            if self.dist.rank == 0 or self.gather_all_responses:
                gather_responses = []
                if responses_list is not None:
                    for resp in responses_list:
                        if resp is not None:
                            gather_responses.extend(resp)
                    responses = gather_responses
        logger.debug(
            f'after gather, rank = {self.dist.rank}, responses = {responses}')

        if self.dist.rank == 0 or self.gather_all_responses:
            with self.response_cv:
                for req_id, resp in responses:
                    if req_id in self.responses.keys():
                        self.responses[req_id].append(resp)
                    else:
                        self.responses.update({req_id: [resp]})
                    # (TODO: joyang) There are other types of responses, we need to sort out.
                    if type(
                            resp
                    ) == LlmResponse and req_id in self.result_wait_queues and self.result_wait_queues[
                            req_id] is not None:
                        self.result_wait_queues[req_id].put_response.remote(
                            resp.client_id, resp)
                self.response_cv.notify_all()

    @nvtx_range("_handle_first_token_response")
    def _handle_first_token_response(self, scheduled_batch):
        new_responses = []
        for req in scheduled_batch.generation_requests:
            if req.py_decoding_iter == 1:
                logger.debug(
                    f'Send first token response for request {req.py_request_id}'
                )
                # Snapshot prepended first_gen_logits for the response:
                #
                # 1. generation_logits is not stored on LlmResult; every
                #    access goes through __getattr__ -> PyResult property
                #    -> LogitsStorage, re-reading shared mutable state.
                # 2. All streaming responses reference the same PyResult,
                #    so later tokens mutate what earlier responses would
                #    read.
                # 3. With the overlap scheduler, exclude_last_generation_logits
                #    is True, which would hide the prepended logits since
                #    they are the only entry at this point.
                #
                # WAR: read the logits now (bypassing exclusion), then set
                # the tensor directly on LlmResult as an instance attribute.
                # This shadows __getattr__ so the consumer always gets the
                # correct, frozen logits.
                has_prepended_logits = self._has_prepended_logits(req)
                logits_snapshot = (req.py_result.get_latest_logits_unexcluded()
                                   if has_prepended_logits else None)
                response = req.create_response(False, self.dist.rank)
                if logits_snapshot is not None and response is not None:
                    response.result.generation_logits = logits_snapshot
                new_responses.append((req.py_request_id, response))

        self._enqueue_responses(new_responses)

    @nvtx_range("_handle_responses")
    def _handle_responses(self):
        new_responses = []
        requests_to_terminate = []
        # Requests terminated by _check_disagg_ctx_cache_transfer_status (DISAGG_CONTEXT_COMPLETE);
        # included in the return value for stats but not re-terminated here.
        requests_finished_by_transfer = []
        new_active_requests = []
        logger.debug(
            f'------before _handle_responses, rank = {self.dist.rank}, output = {self.active_requests}'
        )

        batch_token_time = self.perf_manager.get_timestamp()

        for request in self.active_requests:
            req_id = request.py_request_id
            # no responses for dummy request, and finish it
            if request.is_attention_dp_dummy:
                requests_to_terminate.append(request)
                continue

            # Check if generation request needs cleanup due to KV cache transfer timeout
            if request.py_kv_transfer_timed_out:
                is_cancelled = self.kv_cache_transceiver.cancel_request(request)
                if is_cancelled:
                    self._handle_errors(
                        error_msg=f"Request {request.py_request_id} timed out",
                        requests=[request],
                        charge_budget=False)
                continue

            if request.is_generation_only_request() and not request.is_finished:
                # If request is in transmission, so we don't need to emit a response
                # Also, for the first iteration with overlap, we should skip since first
                # token has already been emitted previously
                if request.is_disagg_generation_transmission_in_progress or (
                        not self.disable_overlap_scheduler
                        and request.py_decoding_iter <= 1):
                    self.perf_manager.append_step_metrics(
                        request,
                        self.iter_counter,
                        batch_token_time=batch_token_time)
                    new_active_requests.append(request)
                    continue

            request.draft_tokens = request.py_draft_tokens if get_draft_token_length(
                request) > 0 else []
            request.decoding_iter = request.py_decoding_iter

            self.perf_manager.append_step_metrics(
                request, self.iter_counter, batch_token_time=batch_token_time)

            # Ensure C++ perf metrics (lastTokenTime, etc.) are always updated
            # independently of whether append_step_metrics early-returned.
            # This is critical for E2E latency computation in tracing/Prometheus.
            if request.return_perf_metrics and request.py_decoding_iter >= 1:
                request.update_perf_metrics(self.iter_counter)

            request_done = False
            if request.py_decoding_iter == 1 or request.is_finished or \
                    request.py_decoding_iter % self.stream_interval == 0:
                response = request.create_response(False, self.dist.rank)
                if response:
                    request_done = request.is_finished
                    response.result.cached_tokens = request.cached_tokens
                    new_responses.append((req_id, response))

            if request_done:
                if (self.drafter is not None and getattr(
                        self.model_engine, 'enable_spec_decode', False)
                        and not self.speculation_permanently_disabled
                        and not request.is_dummy and not self.is_warmup):
                    if self.speculation_gate is not None:
                        # Response handling runs on multiple PP ranks. Only the last PP rank performs
                        # sampling; restrict rolling stat updates to it to avoid overcounting.
                        if (not getattr(self.dist, 'has_pp',
                                        False)) or self.dist.is_last_pp_rank:
                            avg_decoded = getattr(
                                request, 'avg_decoded_tokens_per_iter', None)
                            if avg_decoded is not None:
                                disabled_now, _ = self.speculation_gate.record_avg_decoded(
                                    avg_decoded,
                                    request_id=getattr(request, 'py_request_id',
                                                       None))
                                if disabled_now:
                                    # disable speculation permanently
                                    # starting from next iteration, _prepare_and_schedule_batch will set self.use_spec_decode to False
                                    self.speculation_permanently_disabled = True
                            else:
                                logger.debug(
                                    f"Request {request.py_request_id} has no avg_decoded_tokens_per_iter"
                                )

                # If partial reuse is enabled, and the KV cache manager is not VSWA, and the PP size is 1,
                # then we need to terminate the request. TODO: Remove this once disagg support from KVCache reuse
                # path is fixed.
                force_terminate_for_partial_reuse = (
                    self.enable_partial_reuse_for_disagg
                    and not self.kv_cache_manager.is_vswa
                    and self.dist.pp_size == 1)
                if request.is_disagg_context_complete_state:
                    # Already terminated by _check_disagg_ctx_cache_transfer_status;
                    # track for stats only to avoid double-free (nvbug/5961736).
                    requests_finished_by_transfer.append(request)
                elif force_terminate_for_partial_reuse:
                    requests_to_terminate.append(request)
                elif not request.is_disagg_context_transmission_state:
                    requests_to_terminate.append(request)
            else:
                new_active_requests.append(request)

        self.active_requests.clear()
        self.active_requests.extend(new_active_requests)
        # Request should be terminated after enqueueing response to ensure we can enqueue response successfully.
        self._enqueue_responses(new_responses)
        for request in requests_to_terminate:
            self._terminate_request(request)
        return requests_to_terminate + requests_finished_by_transfer

    def _await_any_response(self,
                            timeout: Optional[float] = None
                            ) -> List[LlmResponse]:

        def any_responses_ready():
            return len(self.responses) > 0 or self.is_shutdown

        responses = []
        with self.response_cv:
            self.response_cv.wait_for(any_responses_ready, timeout=timeout)
            for req_id, response in self.responses.items():
                responses += response
            self.responses = {}

        return responses

    def _await_single_response(
            self,
            id: int,
            timeout: Optional[float] = None) -> List[LlmResponse]:
        with self.response_cv:

            def key_has_response():
                return id in self.responses.keys()

            self.response_cv.wait_for(key_has_response, timeout=timeout)
            response = self.responses[id]
            self.responses.pop(id)
            return response

    def _terminate_requests(self, requests_to_terminate):
        # todo: support work with self.inflight_req_ids.
        #       Currently, self.inflight_req_ids is not updated.
        for req in requests_to_terminate:
            self._terminate_request(req)

    def _pause_requests(self, requests_to_pause):
        for req in requests_to_pause:
            req.pause(self.max_input_len)

    def _add_inflight_ids(self, scheduled_requests: ScheduledRequests):
        """Add request IDs of current sampling requests to self.inflight_req_ids.

        Non-final context chunks should not be added to the inflight set, so the scheduler can keep scheduling
        further context chunks while earlier ones are in the PP pipeline.
        Only requests that sample new tokens should be added to the inflight set since their next iteration depends
        on these new tokens, so they should be skipped in the scheduler until the new tokens are generated.
        This includes context requests that finish context phase and generation requests.
        """
        for req in scheduled_requests.context_requests_last_chunk:
            logger.debug(
                f"Context request with ID {req.request_id} added to DECODER model inflight set"
            )
            self.inflight_req_ids.insert(req.request_id)
        for req in scheduled_requests.generation_requests:
            logger.debug(
                f"Generation request with ID {req.request_id} added to DECODER model inflight set"
            )
            self.inflight_req_ids.insert(req.request_id)

    def _remove_inflight_ids(self, scheduled_requests: ScheduledRequests):
        """Remove request IDs of current sampling requests from self.inflight_req_ids."""
        for req in scheduled_requests.context_requests_last_chunk:
            logger.debug(
                f"Context request with ID {req.request_id} removed from DECODER model inflight set"
            )
            self.inflight_req_ids.erase(req.request_id)
        for req in scheduled_requests.generation_requests:
            logger.debug(
                f"Generation request with ID {req.request_id} removed from DECODER model inflight set"
            )
            self.inflight_req_ids.erase(req.request_id)

    def _handle_speculative_decoding(
        self, scheduled_batch, previous_tensors, target_inputs
    ) -> Tuple[Optional[SampleStateTensorsSpec], Optional[torch.Tensor]]:
        with request_context(is_draft=self.draft_model_engine is not None,
                             scheduled_requests=scheduled_batch):
            target_outputs = self.previous_batch.sample_state and self.previous_batch.sample_state.device
            assert target_outputs is not None, "target_outputs should not be None"
            new_target_inputs, num_accepted_tokens_device = self._accept_draft_tokens(
                scheduled_batch=scheduled_batch,
                target_inputs=target_inputs,
                target_outputs=target_outputs)

            self.drafter.generate_draft_tokens_with_overlap(
                scheduled_batch, self.resource_manager,
                previous_tensors.device if previous_tensors else None,
                new_target_inputs, num_accepted_tokens_device)

            # Pad draft tokens to the max draft length for CUDA graph compatibility
            self.has_previous_draft_tokens = new_target_inputs is not None and new_target_inputs.next_draft_tokens is not None

        return new_target_inputs, num_accepted_tokens_device

    def reset_prefix_cache(self):
        self.kv_cache_manager.reset_reuse_state()

    def _handle_guided_decoder_errors(
            self, scheduled_batch: ScheduledRequests,
            failed_requests: Optional[List[Tuple[int, str]]]):
        """Handle errors that occurred during guided decoding.

        Args:
            scheduled_batch: The current batch of scheduled requests
            failed_requests: List of (request_id, error_message) tuples for failed requests,
                           or None if no failures occurred
        """
        if not failed_requests:
            return

        failed_req_id_to_err = {req_id: err for req_id, err in failed_requests}

        for request in scheduled_batch.all_requests():
            if request.py_request_id not in failed_req_id_to_err:
                continue
            error_msg = failed_req_id_to_err[request.py_request_id]
            self._handle_errors(error_msg,
                                requests=[request],
                                charge_budget=False)


class DisaggPPTerminationHandler:
    """Handles termination synchronization across pipeline parallel ranks under disaggregated serving.

    We require synchronization when terminating requests in disaggregated PP when
    KV cache reuse is enabled. All PP ranks need to reach consensus before freeing
    resources to avoid a NCCL hang.
    """

    def __init__(self, dist, terminator_func: Callable[[LlmRequest], None]):
        self._dist = dist
        self._terminator_func = terminator_func
        self._pending_termination = {}
        self._terminating_iteration = 0
        self._send_handle = None
        self._comm_tag = PPCommTag.TERMINATION

    def terminate(self, request: LlmRequest):
        self._pending_termination[request.py_request_id] = request

    @nvtx_range("_disagg_pp_termination_handler_sync")
    def terminate_pending_requests(self):
        """
        Ring-style communicating to decide which requests to be terminated and avoid bubbles.
        This ensures that one request is terminated from rank_0 to rank_(pp_size-1) in order.
        """
        terminate_req_ids = []
        term_state = None
        if self._send_handle:
            self._send_handle.wait()

        if not (self._dist.is_first_pp_rank
                and self._terminating_iteration == 0):
            term_state = self._dist.recv_object(src=self._dist.prev_pp_rank,
                                                tag=self._comm_tag)

        ready_req_map = term_state["ready"] if term_state else {
        }  # {req_id: num_ranks} ranks vote in the ready dict
        terminate_req_ids = term_state["term"] if term_state else [
        ]  # request ids to be terminated in the current iteration

        reqs_to_terminate = {
            req_id: self._pending_termination.pop(req_id, None)
            for req_id in terminate_req_ids
            if req_id in self._pending_termination
        }

        if self._dist.is_first_pp_rank:
            # rank0 proposes the requests to be terminated
            ready_req_map = {req_id: 1 for req_id in self._pending_termination}
        else:
            # if a rank agrees to terminate a request, increase the vote count for the request id
            for req_id in ready_req_map.keys():
                if req_id in self._pending_termination:
                    ready_req_map[req_id] += 1

        if self._dist.is_last_pp_rank:
            new_terminate_req_ids = [
                req_id for req_id, num_ranks in ready_req_map.items()
                if num_ranks == self._dist.pp_size
            ]
            # by determining the terminate ids in the last rank, we can save the overhead of sending the ready dict back to rank0
            new_term_state = {"ready": {}, "term": new_terminate_req_ids}
        else:
            # other pp ranks pass the updated ready dict and terminate request ids to the next rank, and the
            # terminate_req_ids will not change in a given iteration, so we can terminate the requests synchronously
            new_term_state = {"ready": ready_req_map, "term": terminate_req_ids}

        self._send_handle = self._dist.isend_object(
            new_term_state, dest=self._dist.next_pp_rank, tag=self._comm_tag)

        if reqs_to_terminate:
            logger.debug(
                f'rank {self._dist.pp_rank} terminates {list(reqs_to_terminate.keys())} in iter {self._terminating_iteration}'
            )
        for req_id, req in reqs_to_terminate.items():
            if req:
                self._terminator_func(req)
        self._terminating_iteration += 1
