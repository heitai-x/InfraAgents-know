# SPDX-FileCopyrightText: Copyright (c) 2022-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import functools
from contextlib import contextmanager
from typing import Callable

try:
    import ray
except ImportError:
    import tensorrt_llm.ray_stub as ray


@contextmanager
def unwrap_ray_errors():
    try:
        yield
    except ray.exceptions.RayTaskError as e:
        raise e.as_instanceof_cause() from e


def control_action_decorator(func: Callable) -> Callable:
    """
    Decorator that wraps a method to use control_action context manager.
    """

    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        with self.engine.control_action():
            return func(self, *args, **kwargs)

    return wrapper
