import os
from typing import Dict, List, Optional, Union

import torch

import tensorrt_llm
import tensorrt_llm.bindings.executor as trtllm
from tensorrt_llm._torch.model_config import ModelConfig
from tensorrt_llm._torch.models.modeling_utils import \
    MODEL_CLASS_VISION_ENCODER_MAPPING
from tensorrt_llm._utils import (confidential_compute_enabled,
                                 str_dtype_to_binding, torch_dtype_to_str)
from tensorrt_llm.bindings.executor import DecodingMode

# isort: off
from tensorrt_llm.llmapi.llm_args import (
    CacheTransceiverConfig, CapacitySchedulerPolicy, EagleDecodingConfig,
    KvCacheConfig, MTPDecodingConfig, PeftCacheConfig, SamplerType,
    SchedulerConfig, SparseAttentionConfig, SpeculativeConfig, TorchLlmArgs,
    WaitingQueuePolicy)
# isort: on
from tensorrt_llm.logger import logger
from tensorrt_llm.lora_helper import (LoraConfig,
                                      get_default_trtllm_modules_to_hf_modules)
from tensorrt_llm.lora_manager import load_torch_lora
from tensorrt_llm.mapping import CpType, Mapping

from ..attention_backend import get_sparse_attn_kv_cache_manager
from ..model_config import ModelConfig
from ..speculative import (get_num_extra_kv_tokens, get_num_spec_layers,
                           get_spec_decoder, should_use_separate_draft_kv_cache)
from .config_utils import (get_qwen3_hybrid_layer_masks, is_mla,
                           is_nemotron_hybrid, is_qwen3_hybrid)
from .connectors.kv_cache_connector import KvCacheConnectorManager
from .dwdp import DwdpManager
from .guided_decoder import GuidedDecoder
from .kv_cache_transceiver import AttentionTypeCpp, create_kv_cache_transceiver
from .llm_request import ExecutorResponse
from .mamba_cache_manager import MambaHybridCacheManager
from .model_engine import PyTorchModelEngine
from .py_executor import PyExecutor
from .resource_manager import (KVCacheManager, KVCacheManagerV2,
                               PeftCacheManager, ResourceManager,
                               ResourceManagerType)
from .sampler import (EarlyStopSampler, EarlyStopWithMMResult, TorchSampler,
                      TRTLLMSampler)
from .scheduler import (BindCapacityScheduler, BindMicroBatchScheduler,
                        KVCacheV2Scheduler, SimpleScheduler,
                        SimpleUnifiedScheduler)
from .seq_slot_manager import SeqSlotManager

GB = 1 << 30


def ceil_div(a: int, b: int) -> int:
    return (a + b - 1) // b


def get_kv_cache_manager_cls(model_config: ModelConfig,
                             kv_cache_config: KvCacheConfig):
    config = model_config.pretrained_config
    sparse_attn_config = model_config.sparse_attention_config
    if sparse_attn_config is not None:
        return get_sparse_attn_kv_cache_manager(sparse_attn_config)
    elif is_nemotron_hybrid(config) or is_qwen3_hybrid(config):
        return MambaHybridCacheManager
    else:
        return KVCacheManagerV2 if kv_cache_config.use_kv_cache_manager_v2 else KVCacheManager


def is_vswa_enabled(kv_cache_config):
    max_attention_window = kv_cache_config.max_attention_window
    return max_attention_window is not None and len(
        set(max_attention_window)) > 1


class KvCacheCreator:
    """Groups together logic related to KV cache construction."""

    def __init__(
        self,
        *,
        model_engine: PyTorchModelEngine,
        draft_model_engine: Optional[PyTorchModelEngine],
        mapping: Mapping,
        net_max_seq_len: int,
        kv_connector_manager: Optional[KvCacheConnectorManager],
        max_num_tokens: int,
        max_beam_width: int,
        tokens_per_block: int,
        max_seq_len: int,
        max_batch_size: int,
        kv_cache_config: KvCacheConfig,
        llm_args: TorchLlmArgs,
        speculative_config: SpeculativeConfig,
        sparse_attention_config: SparseAttentionConfig,
        profiling_stage_data: Optional[dict],
        execution_stream: Optional[torch.cuda.Stream] = None,
        draft_config: Optional[ModelConfig] = None,
        skip_est: bool = False,
    ):
        self._model_engine = model_engine
        self._draft_model_engine = draft_model_engine
        self._mapping = mapping
        self._kv_cache_config = kv_cache_config
        self._max_kv_tokens_in = self._kv_cache_config.max_tokens
        self._max_num_tokens = max_num_tokens
        self._max_beam_width = max_beam_width
        self._kv_connector_manager = kv_connector_manager
        self._llm_args = llm_args
        # For V2 fallback use only, will be removed after V2 is stable
        self._cache_transceiver_config = llm_args.cache_transceiver_config
        self._speculative_config = speculative_config
        self._sparse_attention_config = sparse_attention_config
        self._tokens_per_block = tokens_per_block
        self._max_seq_len = max_seq_len
        self._max_batch_size = max_batch_size
        self._net_max_seq_len = net_max_seq_len
        self._dummy_reqs = None
        self._profiling_stage_data = profiling_stage_data
        self._kv_cache_manager_cls = get_kv_cache_manager_cls(
            model_engine.model.model_config, kv_cache_config)
        self._execution_stream = execution_stream
        if self._kv_cache_manager_cls == KVCacheManagerV2:
            if kv_connector_manager is not None or (
                    max_beam_width is not None and max_beam_width
                    > 1) or self._kv_cache_config.event_buffer_max_size > 0:
                logger.warning(
                    "KVCacheManagerV2 is not supported with kv_connector_manager or beam width > 1 or event buffer max size > 0. "
                    "Falling back to KVCacheManager.")
        self._draft_config = draft_config
        self._skip_est = skip_est

    def _get_model_kv_cache_manager_cls(self, model_engine: PyTorchModelEngine):
        return get_kv_cache_manager_cls(model_engine.model.model_config,
                                        self._kv_cache_config)

    def _get_kv_size_per_token(self):
        model_config = self._model_engine.model.model_config
        mapping = self._mapping
        kv_size_per_token = self._kv_cache_manager_cls.get_cache_size_per_token(
            model_config, mapping, tokens_per_block=self._tokens_per_block)
        if self._draft_model_engine is not None:
            draft_model_config = self._draft_model_engine.model.model_config
            draft_kv_cache_manager_cls = self._get_model_kv_cache_manager_cls(
                self._draft_model_engine)
            kv_size_per_token += draft_kv_cache_manager_cls.get_cache_size_per_token(
                draft_model_config,
                mapping,
                tokens_per_block=self._tokens_per_block)
        elif self._should_create_separate_draft_kv_cache():
            # One-model draft with separate KV cache layout.
            # Pass num_layers explicitly since the HF config may report a
            # different layer count than what is actually used at runtime
            # (e.g. EAGLE3: config says 1, runtime uses 4).
            # For PP, draft layers are only on the last rank (see
            # get_pp_layers), so only that rank should include draft cost.
            effective_draft_config = self._get_effective_draft_config()
            if self._speculative_config.spec_dec_mode.is_external_drafter():
                # External drafter: layers start from 0, normal PP distribution
                kv_size_per_token += self._kv_cache_manager_cls.get_cache_size_per_token(
                    effective_draft_config,
                    mapping,
                    tokens_per_block=self._tokens_per_block)
            elif mapping.is_last_pp_rank():
                # EAGLE3/MTP: draft layers only on last PP rank
                kv_size_per_token += self._kv_cache_manager_cls.get_cache_size_per_token(
                    effective_draft_config,
                    mapping,
                    tokens_per_block=self._tokens_per_block,
                    num_layers=self._get_num_draft_layers())
        return kv_size_per_token

    def _cal_max_memory(self, peak_memory, total_gpu_memory, fraction,
                        allocated_bytes: int) -> int:
        """
        Calculate the max KV cache capacity.

        NOTE: `allocated_bytes` is the total KV-cache memory that must be pre-allocated during the estimation phase (for both the main and draft models) so the estimation run can complete successfully. When computing `available_kv_mem`, add this amount back in.
        """
        kv_size_per_token = self._get_kv_size_per_token()

        available_kv_mem = (total_gpu_memory - peak_memory +
                            allocated_bytes) * fraction
        logger.info(
            f"Peak memory during memory usage profiling (torch + non-torch): {peak_memory / (GB):.2f} GiB, "
            f"available KV cache memory when calculating max tokens: {available_kv_mem / (GB):.2f} GiB, "
            f"fraction is set {fraction}, kv size per token is {kv_size_per_token}. device total memory {total_gpu_memory / (GB):.2f} GiB, "
            f"temporary kv cache memory during profiling {allocated_bytes / (GB):.2f} GiB"
        )
        return int(available_kv_mem)

    def _create_dummy_mm_context_request(
            self, input_seq_len: int) -> List[trtllm.Request]:
        requests = []
        if isinstance(
                self._profiling_stage_data,
                dict) and not self._profiling_stage_data.get("enable_mm_reqs"):
            return requests

        input_processor = self._model_engine.input_processor
        if not (hasattr(input_processor, "get_dummy_prompt")):
            logger.warning("The input processor of the model does not have the method [get_dummy_prompt] implemented." \
            "Profiling with the default input dummy context request. This may not take into account the memory consumption of " \
            "the image encoder")
            return requests

        max_num_tokens = self._max_num_tokens
        max_beam_width = self._max_beam_width
        vocab_size = self._model_engine.model.model_config.pretrained_config.vocab_size

        input_seq_len = min(max_num_tokens, input_seq_len)
        remaining_tokens = max_num_tokens
        while remaining_tokens > 0:
            input_seq_len = min(input_seq_len, remaining_tokens)
            dummy_mm_prompt = input_processor.get_dummy_prompt(input_seq_len)

            if dummy_mm_prompt is not None:
                prompt_token_ids, extra_processed_inputs = self._model_engine.input_processor_with_hash(
                    dummy_mm_prompt, sampling_params=None)

                multimodal_input = extra_processed_inputs.get(
                    'multimodal_input')
                multimodal_data = extra_processed_inputs.get('multimodal_data')
                req_mm_input = trtllm.MultimodalInput(
                    multimodal_hashes=multimodal_input.multimodal_hashes,
                    multimodal_positions=multimodal_input.multimodal_positions,
                    multimodal_lengths=multimodal_input.multimodal_lengths,
                    multimodal_uuids=multimodal_input.multimodal_uuids
                ) if multimodal_input else None

                request = trtllm.Request(prompt_token_ids,
                                         max_tokens=1,
                                         streaming=False,
                                         sampling_config=trtllm.SamplingConfig(
                                             beam_width=max_beam_width, ),
                                         output_config=trtllm.OutputConfig(),
                                         end_id=-1,
                                         multimodal_input=req_mm_input)
                request.py_multimodal_data = multimodal_data
            else:
                # Fall back to text-only prompt when we could not find the small image size.
                prompt_token_ids = torch.randint(
                    low=0, high=vocab_size, size=(input_seq_len, )).tolist()
                request = trtllm.Request(prompt_token_ids,
                                         max_tokens=1,
                                         streaming=False,
                                         sampling_config=trtllm.SamplingConfig(
                                             beam_width=max_beam_width, ),
                                         output_config=trtllm.OutputConfig(),
                                         end_id=-1)
                if self._model_engine.use_mrope:
                    request.py_multimodal_data = {
                        "mrope_config": {
                            "mrope_position_ids":
                            torch.zeros(3, 1, input_seq_len, dtype=torch.int32),
                            "mrope_position_deltas":
                            torch.zeros(1, 1, dtype=torch.int32)
                        }
                    }
            remaining_tokens -= len(prompt_token_ids)
            requests.append(request)

        if self._mapping.enable_attention_dp:
            requests = requests * self._mapping.tp_size

        return requests

    def _create_dummy_context_requests(
            self, input_seq_len: int) -> List[trtllm.Request]:
        requests = []
        if hasattr(self._model_engine.model,
                   "original_arch") and MODEL_CLASS_VISION_ENCODER_MAPPING.get(
                       self._model_engine.model.original_arch, None):
            requests = self._create_dummy_mm_context_request(input_seq_len)
        # if succeed profiling with multimodal requests then return, otherwise profile
        # with default case
        if requests:
            return requests
        vocab_size = self._model_engine.model.model_config.pretrained_config.vocab_size
        max_num_tokens = self._max_num_tokens
        max_beam_width = self._max_beam_width

        input_seq_len = min(max_num_tokens, input_seq_len)
        remaining_tokens = max_num_tokens
        while remaining_tokens > 0:
            input_seq_len = min(input_seq_len, remaining_tokens)
            input_tokens = torch.randint(low=0,
                                         high=vocab_size,
                                         size=(input_seq_len, )).tolist()
            request = trtllm.Request(input_tokens,
                                     max_tokens=1,
                                     streaming=False,
                                     sampling_config=trtllm.SamplingConfig(
                                         beam_width=max_beam_width, ),
                                     output_config=trtllm.OutputConfig(),
                                     end_id=-1)
            if self._model_engine.use_mrope:
                request.py_multimodal_data = {
                    "mrope_config": {
                        "mrope_position_ids":
                        torch.zeros(3, 1, input_seq_len, dtype=torch.int32),
                        "mrope_position_deltas":
                        torch.zeros(1, 1, dtype=torch.int32)
                    }
                }
            requests.append(request)
            remaining_tokens -= input_seq_len
        if self._mapping.enable_attention_dp:
            requests = requests * self._mapping.tp_size
        return requests

    def _get_token_num_for_estimation(self) -> int:
        """Compute KV cache capacity required for estimate_max_kv_cache_tokens to succeed."""
        if 'cp_type' in self._mapping.cp_config:
            raise ValueError(
                "KV cache size estimation not supported with context parallelism."
            )
        # estimate_max_kv_cache_tokens submits self._dummy_reqs
        num_cache_blocks = 0
        num_extra_tokens_per_seq = 1  # account for generated tokens
        spec_cfg = self._speculative_config
        if not self._llm_args.disable_overlap_scheduler and spec_cfg is not None:
            num_extra_tokens_per_seq += spec_cfg.tokens_per_gen_step - 1

        if spec_cfg is not None:
            num_extra_tokens_per_seq += spec_cfg.tokens_per_gen_step - 1
            num_extra_tokens_per_seq += get_num_extra_kv_tokens(spec_cfg)

        if self._dummy_reqs is None:
            self._dummy_reqs = self._create_dummy_context_requests(
                max(1, self._net_max_seq_len - 1))
        for req in self._dummy_reqs:
            num_req_tokens = len(req.input_token_ids) + num_extra_tokens_per_seq
            # Requests cannot share KV cache blocks. Round up to nearest integer multiple of block size.
            num_cache_blocks += ceil_div(num_req_tokens, self._tokens_per_block)

        # With ADP enabled, _create_dummy_context_requests produces tp_size
        # copies so each rank gets work during the estimation warmup. But the
        # scheduler distributes them evenly (1 per rank), so each rank's KV
        # cache only needs capacity for its own share, not all of them.
        if self._mapping.enable_attention_dp and self._mapping.tp_size > 1:
            num_cache_blocks = (num_cache_blocks + self._mapping.tp_size -
                                1) // self._mapping.tp_size

        # Max cuda graph warmup required tokens
        max_cuda_graph_bs = min(self._model_engine.batch_size,
                                self._model_engine._max_cuda_graph_batch_size)
        # Round up the max seq len to the block size
        max_seq_len_blocks = ceil_div(self._model_engine.max_seq_len + 1,
                                      self._tokens_per_block)
        cuda_graph_warmup_block = max_seq_len_blocks + max_cuda_graph_bs - 1
        num_cache_blocks = max(cuda_graph_warmup_block, num_cache_blocks)

        # This is the minimal blocks required to run with max bs
        # If not able to allocate self._model_engine.batch_size blocks, the max batch size should be adjusted.
        num_cache_blocks = max(num_cache_blocks, self._model_engine.batch_size)

        free_mem, total_mem = torch.cuda.mem_get_info()
        max_memory = self._kv_cache_config.free_gpu_memory_fraction * free_mem
        max_num_tokens_in_memory = max_memory // self._get_kv_size_per_token(
        ) // self._tokens_per_block * self._tokens_per_block

        # Multiply by beam width, to prevent rescaling of the max_seq_len caused by the influence of beam width during the preparation for kv_cache_estimation
        return min(
            num_cache_blocks * self._tokens_per_block *
            self._dummy_reqs[0].sampling_config.beam_width,
            max_num_tokens_in_memory)

    def try_prepare_estimation(self) -> bool:
        """Prepare for possible KV cache capacity estimation.

        This updates `kv_cache_config` and returns a boolean indicating whether KV cache
        estimation is to be performend.
        """
        if self._skip_est:
            return False
        estimating_kv_cache = False
        if 'cp_type' not in self._mapping.cp_config:
            estimating_kv_cache = True
            estimate_max_tokens = self._get_token_num_for_estimation()
            self._kv_cache_config.max_tokens = min(
                estimate_max_tokens, self._kv_cache_config.max_tokens
            ) if self._kv_cache_config.max_tokens is not None else estimate_max_tokens
        model_config = self._model_engine.model.model_config
        if model_config.attn_backend == "VANILLA":
            logger.info(
                "KV cache size estimation is not supported for Vanilla attention backend, disable it."
            )
            estimating_kv_cache = False
        return estimating_kv_cache

    def configure_kv_cache_capacity(self,
                                    py_executor: PyExecutor = None) -> None:
        """Perform KV cache capacity estimation.
        NOTE: for VSWA case, we calculate and set kv cache memory instead of using max_tokens in kv_cache_config.

        This updates `kv_cache_config`.
        """
        mapping = self._mapping

        # TODO: support CP by generating dummy requests for it.
        assert 'cp_type' not in mapping.cp_config

        fraction = self._kv_cache_config.free_gpu_memory_fraction

        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        end, total_gpu_memory = torch.cuda.mem_get_info()
        total_used_bytes = total_gpu_memory - end
        model_bytes = torch.cuda.memory_stats()["allocated_bytes.all.current"]
        logger.info(
            f"Memory used after loading model weights (inside torch) in memory usage profiling: {model_bytes / (GB):.2f} GiB"
        )
        logger.info(
            f"Memory used after loading model weights (outside torch) in memory usage profiling: {((total_used_bytes - model_bytes) if total_used_bytes > model_bytes else 0) / (GB):.2f} GiB"
        )

        if py_executor is not None and not self._skip_est:
            py_executor.set_gather_responses(True)
            origin_iter_stats = py_executor.enable_iter_perf_stats
            py_executor.enable_iter_perf_stats = False
            req_ids = []
            if py_executor.dist.mapping.rank == 0:
                req_ids = py_executor.enqueue_requests(self._dummy_reqs)
            req_ids = py_executor.dist.broadcast(req_ids, root=0)
            py_executor.is_warmup = True
            py_executor.start_worker()
            try:
                responses = py_executor.await_responses(req_ids)
                for response_or_list in responses:
                    response_list = [response_or_list] if isinstance(
                        response_or_list,
                        ExecutorResponse) else response_or_list
                    for response in response_list:
                        if response.has_error():
                            raise RuntimeError(response.error_msg)

                torch_peak_memory = torch.cuda.memory_stats(
                )["allocated_bytes.all.peak"]

                # Clear the caching allocator before measuring the current memory usage
                torch.cuda.empty_cache()
                end, total_gpu_memory = torch.cuda.mem_get_info()
                torch_used_bytes = torch.cuda.memory_stats(
                )["allocated_bytes.all.current"]
            finally:
                # get kv cache stats for both model and draft model
                kv_stats = py_executor.resource_manager.resource_managers.get(
                    ResourceManagerType.KV_CACHE_MANAGER).get_kv_cache_stats()
                # Get draft KV cache stats if present (either from two-model mode or one-model
                # mode with separate draft KV cache)
                draft_kv_cache_manager = py_executor.resource_manager.resource_managers.get(
                    ResourceManagerType.DRAFT_KV_CACHE_MANAGER)
                kv_stats_draft = draft_kv_cache_manager.get_kv_cache_stats(
                ) if draft_kv_cache_manager is not None else None

                # get total allocated bytes
                allocated_bytes = kv_stats.allocated_bytes + (
                    kv_stats_draft.allocated_bytes
                    if kv_stats_draft is not None else 0)
                py_executor.is_warmup = False
                py_executor.shutdown()
                py_executor.enable_iter_perf_stats = origin_iter_stats
                py_executor.set_gather_responses(False)

            total_used_bytes = total_gpu_memory - end
            activation_bytes = torch_peak_memory - model_bytes
            extra_cost = max(total_used_bytes - torch_used_bytes, 0)
            peak_memory = torch_peak_memory + extra_cost
            logger.info(
                f"Memory dynamically allocated during inference (inside torch) in memory usage profiling: {activation_bytes / (GB):.2f} GiB"
            )
            logger.info(
                f"Memory used outside torch (e.g., NCCL and CUDA graphs) in memory usage profiling: {extra_cost / (GB):.2f} GiB"
            )

        else:
            peak_memory = total_used_bytes
            allocated_bytes = 0
            activation_bytes = 0

        # calculate max memory from peak memory and free gpu memory fraction
        kv_cache_max_memory = self._cal_max_memory(peak_memory,
                                                   total_gpu_memory, fraction,
                                                   allocated_bytes)

        # NOTE:
        # For KVCacheManager, KvCacheCreator currently controls capacity using two parameters in KVCacheConfig:
        #   • max_tokens
        #   • max_gpu_total_bytes
        # For KVCacheManagerV2, KvCacheCreator controls capacity using max_gpu_total_bytes only.
        # This leaves max_tokens as a user-defined constraint.

        # ---------------------------handle max_tokens---------------------------------
        if issubclass(self._kv_cache_manager_cls, KVCacheManagerV2):
            # KVCacheManagerV2 doesn't rely on max_tokens to control capacity, so restore user provided value
            self._kv_cache_config.max_tokens = self._max_kv_tokens_in
        else:
            # handle user provided max_tokens
            if self._max_kv_tokens_in is not None:
                # raise error if it is VSWA case
                is_vswa = is_vswa_enabled(self._kv_cache_config)

                # raise error if it is VSWA case
                if is_vswa:
                    logger.warning(
                        "max_tokens should not be set for VSWA case as it is ambiguous concept for VSWA."
                    )
                # calculate max memory from max_tokens
                kv_cache_max_memory_from_max_tokens = self._max_kv_tokens_in * self._get_kv_size_per_token(
                )
                kv_cache_max_memory = min(kv_cache_max_memory,
                                          kv_cache_max_memory_from_max_tokens)
                logger.info(
                    f"max_tokens={self._max_kv_tokens_in} is provided. It limits max memory to {kv_cache_max_memory_from_max_tokens / (GB):.2f} GiB. "
                    f"New max_memory is set to {kv_cache_max_memory / (GB):.2f} GiB"
                )
            # For KvCacheManager, its logic still relies on max_tokens to control capacity
            self._kv_cache_config.max_tokens = int(
                kv_cache_max_memory // self._get_kv_size_per_token())
        # ---------------------------handle max_tokens---------------------------------

        # ---------------------------handle max_gpu_total_bytes---------------------------------
        # if user provided max_gpu_total_bytes, set max memory from max_gpu_total_bytes
        if self._kv_cache_config.max_gpu_total_bytes > 0:
            kv_cache_max_memory = min(kv_cache_max_memory,
                                      self._kv_cache_config.max_gpu_total_bytes)
            logger.info(
                f"max_gpu_total_bytes={self._kv_cache_config.max_gpu_total_bytes / (GB):.2f} GiB is provided. New max memory is {kv_cache_max_memory / (GB):.2f} GiB"
            )

        logger.info(
            f"Estimated max memory in KV cache : {kv_cache_max_memory / (GB):.2f} GiB"
        )
        # set max_gpu_total_bytes
        self._kv_cache_config.max_gpu_total_bytes = kv_cache_max_memory
        if isinstance(self._profiling_stage_data, dict):
            self._profiling_stage_data["activation_bytes"] = activation_bytes
        # ---------------------------handle max_gpu_total_bytes---------------------------------

    def _create_kv_cache_manager(
            self,
            model_engine: PyTorchModelEngine,
            estimating_kv_cache: bool = False) -> KVCacheManager:
        mapping = self._mapping
        assert model_engine.model.model_config.is_generation, "Only construct KV cache for generation models."
        kv_cache_manager_cls = self._get_model_kv_cache_manager_cls(
            model_engine)

        # When using separate draft KV cache in one-model speculative decoding,
        # use layer_mask to include only target layers. The draft layers should
        # only be in the separate draft KV cache manager.
        # We still pass spec_config so that num_extra_kv_tokens is calculated.
        spec_dec_layer_mask = None
        if self._should_create_separate_draft_kv_cache():
            num_target_layers = model_engine.model.model_config.pretrained_config.num_hidden_layers
            spec_dec_layer_mask = [True] * num_target_layers

        estimating_kv_cache = estimating_kv_cache and not self._skip_est
        kv_cache_manager = _create_kv_cache_manager(
            model_engine=model_engine,
            kv_cache_manager_cls=kv_cache_manager_cls,
            mapping=mapping,
            kv_cache_config=self._kv_cache_config,
            tokens_per_block=self._tokens_per_block,
            max_seq_len=self._max_seq_len,
            max_batch_size=self._max_batch_size,
            spec_config=self._speculative_config,
            sparse_attn_config=self._sparse_attention_config,
            max_num_tokens=self._max_num_tokens,
            max_beam_width=self._max_beam_width,
            kv_connector_manager=self._kv_connector_manager,
            estimating_kv_cache=estimating_kv_cache,
            execution_stream=self._execution_stream,
            layer_mask=spec_dec_layer_mask,
        )

        if not self._skip_est:
            # KVCacheManager (Non-draft) modifies the max_seq_len field, update it to self
            if model_engine.kv_cache_manager_key == ResourceManagerType.KV_CACHE_MANAGER:
                # When SWA is enabled, max_seq_len is updated inside kv_cache_manager.
                if kv_cache_manager is not None:
                    if kv_cache_manager.max_seq_len < self._max_seq_len:
                        self._dummy_reqs = self._create_dummy_context_requests(
                            max(
                                1, self._net_max_seq_len - 1 -
                                (self._max_seq_len -
                                 kv_cache_manager.max_seq_len)))
                    self._max_seq_len = kv_cache_manager.max_seq_len

                # When SWA is enabled, max_seq_len is updated inside kv_cache_manager.
                if kv_cache_manager is not None:
                    if kv_cache_manager.max_seq_len < self._max_seq_len:
                        self._dummy_reqs = self._create_dummy_context_requests(
                            max(1, kv_cache_manager.max_seq_len - 1))
                    self._max_seq_len = kv_cache_manager.max_seq_len
        else:
            if kv_cache_manager is not None:
                self._max_seq_len = kv_cache_manager.max_seq_len

        return kv_cache_manager

    def _should_create_separate_draft_kv_cache(self) -> bool:
        """
        Check if we need a separate draft KV cache manager for one-model mode.
        Returns True if the speculative config has use_separate_draft_kv_cache=True.

        Note: For MTP, _draft_config may be None since MTP layers are embedded
        in the target model and don't produce a separate ModelConfig. We fall
        back to the target model's config via _get_effective_draft_config().
        """
        if self._mapping.enable_attention_dp:
            logger.info(
                "Attention DP is enabled, separate draft KV cache is not supported."
            )
            return False
        return should_use_separate_draft_kv_cache(self._speculative_config)

    def _get_effective_draft_config(self) -> ModelConfig:
        """
        Return the ModelConfig to use for draft KV cache creation.

        For Eagle3 and draft-target one-model modes, a dedicated draft config
        is provided at construction time.  For MTP one-model mode, no separate
        draft config exists because the MTP layers share the same architecture
        as the target model.  In that case we fall back to the target model's
        config so that the draft KV cache is created with the correct layout.
        """
        if self._draft_config is not None:
            return self._draft_config
        # MTP: MTP layers reuse the target model architecture, so the target
        # model's config describes the correct KV cache layout for the draft
        # layers as well.
        return self._model_engine.model.model_config

    def _get_num_draft_layers(self) -> int:
        """Return the actual number of draft KV cache layers.

        This must stay in sync with the num_layers passed to the draft KV
        cache manager constructor in _create_one_model_draft_kv_cache_manager.
        """
        if self._speculative_config.spec_dec_mode.is_external_drafter():
            return self._draft_config.pretrained_config.num_hidden_layers
        return get_num_spec_layers(self._speculative_config)

    def _create_one_model_draft_kv_cache_manager(
        self,
        estimating_kv_cache: bool = False,
        kv_cache_config_override: Optional[KvCacheConfig] = None,
    ) -> Optional[KVCacheManager]:
        """
        Create a KV cache manager for draft model layers in one-model mode
        when target and draft have different KV cache layouts.
        """
        # Get target model's num_hidden_layers to compute correct layer indices.
        # Draft model layers in one-model mode start at target_num_layers.
        target_pretrained_config = self._model_engine.model.model_config.pretrained_config
        target_num_layers = target_pretrained_config.num_hidden_layers

        # PARD, External Drafter: draft is a separate model, layers start from 0.
        # Other methods (EAGLE3, MTP): draft layers are appended after target layers.
        num_draft_layers = self._get_num_draft_layers()
        if self._speculative_config.spec_dec_mode.is_external_drafter():
            spec_dec_layer_mask = [True] * num_draft_layers
        else:
            spec_dec_layer_mask = [False] * target_num_layers + [
                True
            ] * num_draft_layers

        # Get the effective draft config (explicit draft_config if available,
        # otherwise fall back to target model config for MTP).
        effective_draft_config = self._get_effective_draft_config()

        # Get the appropriate KV cache manager class for the draft model
        draft_kv_cache_manager_cls = get_kv_cache_manager_cls(
            effective_draft_config, self._kv_cache_config)

        # Use V2 if enabled and the base class is KVCacheManager
        if draft_kv_cache_manager_cls == KVCacheManagerV2:
            if self._kv_connector_manager is not None or (
                    self._max_beam_width is not None and self._max_beam_width
                    > 1) or self._kv_cache_config.event_buffer_max_size > 0 or (
                        self._cache_transceiver_config is not None
                        and self._cache_transceiver_config.backend is not None):
                logger.warning(
                    "KVCacheManagerV2 is not supported with disaggregated serving or beam width > 1 or event buffer max size > 0 or disagg config. "
                    "Falling back to KVCacheManager for draft model.")
                draft_kv_cache_manager_cls = KVCacheManager

        estimating_kv_cache = estimating_kv_cache and not self._skip_est
        # For MTP with models using sparse attention (e.g., DeepSeek V3 with DSA),
        # the draft layers share the same architecture as the target model and need
        # the sparse_attention_config. Get it from effective_draft_config which
        # falls back to the target model's config for MTP mode.
        sparse_attn_config = effective_draft_config.sparse_attention_config
        draft_kv_config = kv_cache_config_override if kv_cache_config_override is not None else self._kv_cache_config
        return _create_kv_cache_manager(
            model_engine=None,
            kv_cache_manager_cls=draft_kv_cache_manager_cls,
            mapping=self._mapping,
            kv_cache_config=draft_kv_config,
            tokens_per_block=self._tokens_per_block,
            max_seq_len=self._max_seq_len,
            max_batch_size=self._max_batch_size,
            spec_config=self._speculative_config,
            sparse_attn_config=sparse_attn_config,
            max_num_tokens=self._max_num_tokens,
            max_beam_width=self._max_beam_width,
            kv_connector_manager=self._kv_connector_manager,
            estimating_kv_cache=estimating_kv_cache,
            execution_stream=self._execution_stream,
            # One-model draft specific overrides
            model_config=effective_draft_config,
            dtype=effective_draft_config.pretrained_config.torch_dtype,
            is_draft=True,
            layer_mask=spec_dec_layer_mask,
            num_layers=num_draft_layers,
        )

    def _split_kv_cache_budget_for_draft(self) -> Optional[KvCacheConfig]:
        """Split max_gpu_total_bytes between target and draft KV caches.

        When using KVCacheManagerV2 with a separate draft KV cache,
        max_gpu_total_bytes represents the total budget for both target and
        draft combined.  This method splits the budget proportionally based
        on their per-token KV cache sizes.

        Returns a cloned KvCacheConfig for the draft, or None if no split is
        needed.  Also modifies self._kv_cache_config.max_gpu_total_bytes
        in-place for the target.
        """
        total_budget = self._kv_cache_config.max_gpu_total_bytes
        if total_budget is None or total_budget <= 0:
            return None

        total_kv = self._get_kv_size_per_token()
        target_kv = self._kv_cache_manager_cls.get_cache_size_per_token(
            self._model_engine.model.model_config,
            self._mapping,
            tokens_per_block=self._tokens_per_block)
        draft_kv = total_kv - target_kv
        if total_kv <= 0 or draft_kv <= 0:
            return None

        draft_budget = int(total_budget * draft_kv / total_kv)
        target_budget = total_budget - draft_budget

        logger.info(
            f"Splitting KV cache budget: total={total_budget / GB:.2f} GiB, "
            f"target={target_budget / GB:.2f} GiB ({target_kv}B/tok), "
            f"draft={draft_budget / GB:.2f} GiB ({draft_kv}B/tok)")

        self._kv_cache_config.max_gpu_total_bytes = target_budget

        draft_kv_cache_config = self._kv_cache_config.model_copy()
        draft_kv_cache_config.max_gpu_total_bytes = draft_budget
        return draft_kv_cache_config

    def build_managers(self,
                       resources: Dict,
                       estimating_kv_cache: bool = False) -> None:
        """Construct KV caches for model and draft model (if applicable)."""
        if self._skip_est:
            self.configure_kv_cache_capacity()

        # For V2 with separate one-model draft KV cache, split the total budget
        # between target and draft before creating either manager.
        # Only split for the final managers, not during estimation — estimation
        # uses max_tokens-based logic and must not have its config mutated.
        # Two-model draft is excluded: V2 does not support two-model mode.
        draft_kv_cache_config = None
        if (not estimating_kv_cache
                and self._should_create_separate_draft_kv_cache()
                and issubclass(self._kv_cache_manager_cls, KVCacheManagerV2)):
            draft_kv_cache_config = self._split_kv_cache_budget_for_draft()

        # Also split for V1 VSWA. The VSWA pool is sized directly from
        # max_gpu_total_bytes and ignores max_tokens, so without splitting
        # both target and draft each allocate the full combined budget.
        # V1 non-VSWA does not need this: max_tokens caps the block count
        # per model, giving each a proportional share of the budget.
        has_draft = (
            self._draft_model_engine is not None  # two-model
            or self._should_create_separate_draft_kv_cache())  # one-model
        if (not estimating_kv_cache and has_draft
                and draft_kv_cache_config is None
                and not issubclass(self._kv_cache_manager_cls, KVCacheManagerV2)
                and is_vswa_enabled(self._kv_cache_config)):
            draft_kv_cache_config = self._split_kv_cache_budget_for_draft()

        kv_cache_manager = self._create_kv_cache_manager(
            self._model_engine, estimating_kv_cache)

        if not estimating_kv_cache and self._kv_connector_manager is not None and self._draft_model_engine is not None:
            raise NotImplementedError(
                "Connector manager is not supported for draft model.")

        draft_kv_cache_manager = None

        # Two-model speculative decoding: draft model has separate engine
        if self._draft_model_engine is not None:
            if issubclass(self._kv_cache_manager_cls, KVCacheManagerV2):
                assert draft_kv_cache_config is None, (
                    "KVCacheManagerV2 does not support two-model speculative "
                    "decoding with separate draft KV cache budget splitting.")
            # For V1 VSWA, apply the draft's split budget temporarily
            if draft_kv_cache_config is not None:
                saved_budget = self._kv_cache_config.max_gpu_total_bytes
                self._kv_cache_config.max_gpu_total_bytes = draft_kv_cache_config.max_gpu_total_bytes
            draft_kv_cache_manager = self._create_kv_cache_manager(
                self._draft_model_engine, estimating_kv_cache)
            if draft_kv_cache_config is not None:
                self._kv_cache_config.max_gpu_total_bytes = saved_budget
        # One-model speculative decoding with different KV layouts
        elif self._should_create_separate_draft_kv_cache():
            draft_kv_cache_manager = self._create_one_model_draft_kv_cache_manager(
                estimating_kv_cache,
                kv_cache_config_override=draft_kv_cache_config)

        resources[ResourceManagerType.KV_CACHE_MANAGER] = kv_cache_manager
        resources[
            ResourceManagerType.DRAFT_KV_CACHE_MANAGER] = draft_kv_cache_manager

    def teardown_managers(self, resources: Dict) -> None:
        """Clean up KV caches for model and draft model (if applicable)."""
        resources[ResourceManagerType.KV_CACHE_MANAGER].shutdown()
        del resources[ResourceManagerType.KV_CACHE_MANAGER]
        draft_kv_cache_manager = resources[
            ResourceManagerType.DRAFT_KV_CACHE_MANAGER]
        if draft_kv_cache_manager:
            draft_kv_cache_manager.shutdown()
        del resources[ResourceManagerType.DRAFT_KV_CACHE_MANAGER]


def _build_per_layer_num_kv_heads(
    num_key_value_heads: int,
    num_hidden_layers: int,
    spec_config: Optional[SpeculativeConfig] = None,
    draft_config: Optional[ModelConfig] = None,
) -> Union[int, List[int]]:
    """
    Returns:
        An int when all layers share the same num_kv_heads (common case),
        or a list of num_kv_heads (one entry per layer) when target and
        draft models differ.
    """
    if spec_config is None or draft_config is None:
        return num_key_value_heads

    from ..speculative.utils import get_num_spec_layers
    draft_pretrained = draft_config.pretrained_config
    draft_num_kv_heads = getattr(
        draft_pretrained, 'num_key_value_heads',
        getattr(draft_pretrained, 'num_attention_heads', None))

    if draft_num_kv_heads is None or draft_num_kv_heads == num_key_value_heads:
        return num_key_value_heads

    num_spec_layers = get_num_spec_layers(spec_config)
    logger.info(f"Per-layer KV heads for speculative decoding: "
                f"target={num_key_value_heads} x {num_hidden_layers} layers, "
                f"draft={draft_num_kv_heads} x {num_spec_layers} layers, "
                f"total={num_hidden_layers + num_spec_layers} layers")
    return [num_key_value_heads] * num_hidden_layers + [draft_num_kv_heads
                                                        ] * num_spec_layers


def _create_kv_cache_manager(
        model_engine: Optional[PyTorchModelEngine],
        kv_cache_manager_cls,
        mapping: Mapping,
        kv_cache_config: KvCacheConfig,
        tokens_per_block: int,
        max_seq_len: int,
        max_batch_size: int,
        spec_config: Optional[SpeculativeConfig],
        sparse_attn_config: Optional[SparseAttentionConfig],
        max_num_tokens: int,
        max_beam_width: int,
        kv_connector_manager: Optional[KvCacheConnectorManager],
        estimating_kv_cache: bool = False,
        execution_stream: Optional[torch.cuda.Stream] = None,
        # Optional overrides for one-model draft case (when model_engine is None)
        model_config: Optional[ModelConfig] = None,
        dtype: Optional[torch.dtype] = None,
        is_draft: Optional[bool] = None,
        layer_mask: Optional[List[bool]] = None,
        num_layers: Optional[int] = None) -> KVCacheManager:
    """
    Returns:
        A KVCacheManager instance for the given model engine or model config
    """
    # Extract config from model_engine or use provided model_config
    if model_config is not None:
        config = model_config.pretrained_config
        quant_config = model_config.quant_config
        _model_config = model_config
    else:
        config = model_engine.model.model_config.pretrained_config
        quant_config = model_engine.model.model_config.quant_config
        _model_config = model_engine.model.model_config

    if dtype is None:
        dtype = model_engine.dtype

    if is_draft is None:
        is_draft = model_engine.is_draft_model

    hidden_size = config.hidden_size
    num_attention_heads = config.num_attention_heads
    num_key_value_heads = getattr(config, 'num_key_value_heads',
                                  num_attention_heads)
    head_dim = getattr(config, "head_dim", None)
    if not isinstance(head_dim, int):
        head_dim = hidden_size // num_attention_heads

    if quant_config is not None and quant_config.quant_mode.has_fp8_kv_cache():
        kv_cache_dtype = tensorrt_llm.bindings.DataType.FP8
    elif quant_config is not None and quant_config.quant_mode.has_fp4_kv_cache(
    ):
        kv_cache_dtype = tensorrt_llm.bindings.DataType.NVFP4
    else:
        kv_cache_dtype = str_dtype_to_binding(torch_dtype_to_str(dtype))

    # Use provided num_layers if available, otherwise use config
    num_hidden_layers = num_layers if num_layers is not None else config.num_hidden_layers
    # Only include draft KV heads in the per-layer list when draft layers
    # are NOT handled by a separate draft KV cache manager.  When layer_mask
    # is provided from the caller, it means the main KV cache covers only
    # the masked (target) layers and draft layers live in their own manager.
    draft_config_for_kv = None
    if layer_mask is None:
        draft_config_for_kv = (getattr(model_engine.model, 'draft_config', None)
                               if model_engine is not None else None)
    per_layer_num_kv_heads = _build_per_layer_num_kv_heads(
        num_key_value_heads, num_hidden_layers, spec_config,
        draft_config_for_kv)

    if is_mla(config):
        kv_cache_manager = kv_cache_manager_cls(
            kv_cache_config,
            tensorrt_llm.bindings.internal.batch_manager.CacheType.SELFKONLY,
            num_layers=num_hidden_layers,
            num_kv_heads=1,
            head_dim=config.kv_lora_rank + config.qk_rope_head_dim,
            tokens_per_block=tokens_per_block,
            max_seq_len=max_seq_len,
            max_batch_size=max_batch_size,
            mapping=mapping,
            dtype=kv_cache_dtype,
            spec_config=spec_config,
            vocab_size=config.vocab_size,
            max_beam_width=max_beam_width,
            is_draft=is_draft,
            kv_connector_manager=kv_connector_manager
            if not estimating_kv_cache else None,
            sparse_attn_config=sparse_attn_config,
            is_estimating_kv_cache=estimating_kv_cache,
            execution_stream=execution_stream,
            layer_mask=layer_mask,
        )
    elif is_nemotron_hybrid(config):
        if max_beam_width > 1:
            raise ValueError(
                "MambaHybridCacheManager + beam search is not supported yet.")

        if not estimating_kv_cache and kv_connector_manager is not None:
            raise NotImplementedError(
                "Connector manager is not supported for MambaHybridCacheManager."
            )

        # When layer_mask is provided (e.g., for one-model speculative decoding),
        # use it to determine which layers to include. The layer_mask may include
        # draft layers beyond the hybrid_override_pattern.
        if layer_mask is not None:
            # layer_mask specifies which layers to include in this KV cache manager.
            # For draft layers in one-model spec decoding, they are attention-only
            # (no Mamba states), so we use the passed layer_mask directly.
            #
            # Compute the hybrid_layer_mask based on layer_mask:
            # - If layer_mask[i] is True, include layer i
            # - For layers beyond hybrid_override_pattern, treat them as attention layers
            pattern_len = len(config.hybrid_override_pattern)
            hybrid_layer_mask = []
            mamba_layer_mask = []
            for i, include in enumerate(layer_mask):
                if i < pattern_len:
                    # Within the pattern range, use the pattern to determine layer type
                    is_attention = config.hybrid_override_pattern[i] == "*"
                    is_mamba = config.hybrid_override_pattern[i] == "M"
                else:
                    # Beyond the pattern (e.g., MTP/draft layers), treat as attention-only
                    is_attention = True
                    is_mamba = False
                hybrid_layer_mask.append(is_attention and include)
                mamba_layer_mask.append(is_mamba and include)
            num_layers = sum(hybrid_layer_mask)
            mamba_num_layers = sum(mamba_layer_mask)
        else:
            num_layers = config.hybrid_override_pattern.count("*")
            hybrid_layer_mask = [
                char == "*" for char in config.hybrid_override_pattern
            ]
            mamba_num_layers = config.hybrid_override_pattern.count("M")
            mamba_layer_mask = [
                char == "M" for char in config.hybrid_override_pattern
            ]
            # For hybrid models, hybrid_layer_mask is always passed as
            # layer_mask to KVCacheManager, which means get_pp_layers
            # sees a non-None layer_mask and won't auto-add spec layers.
            # We must extend the masks here to include MTP spec layers
            # (attention-only, no Mamba states) so they get KV cache entries.
            if spec_config is not None:
                from ..speculative.utils import get_num_spec_layers
                num_spec_layers = get_num_spec_layers(spec_config)
                if num_spec_layers > 0:
                    hybrid_layer_mask.extend([True] * num_spec_layers)
                    mamba_layer_mask.extend([False] * num_spec_layers)
                    num_layers += num_spec_layers
        kv_cache_manager = kv_cache_manager_cls(
            # mamba cache parameters
            config.ssm_state_size,
            config.conv_kernel,
            config.mamba_num_heads,
            config.n_groups,
            config.mamba_head_dim,
            mamba_num_layers,
            mamba_layer_mask,
            config.torch_dtype,
            quant_config.mamba_ssm_cache_dtype
            if quant_config is not None else None,
            # kv cache parameters
            kv_cache_config,
            tensorrt_llm.bindings.internal.batch_manager.CacheType.SELF,
            num_layers=num_layers,
            layer_mask=hybrid_layer_mask,
            num_kv_heads=per_layer_num_kv_heads,
            head_dim=head_dim,
            tokens_per_block=tokens_per_block,
            max_seq_len=max_seq_len,
            max_batch_size=max_batch_size,
            mapping=mapping,
            dtype=kv_cache_dtype,
            spec_config=spec_config,
            is_estimating_kv_cache=estimating_kv_cache,
            execution_stream=execution_stream,
            model_type="nemotron_hybrid",
        )
    elif is_qwen3_hybrid(config):
        if max_beam_width > 1:
            raise ValueError(
                "MambaHybridCacheManager + beam search is not supported yet.")

        if not estimating_kv_cache and kv_connector_manager is not None:
            raise NotImplementedError(
                "Connector manager is not supported for MambaHybridCacheManager."
            )
        hybrid_layer_mask, mamba_layer_mask = get_qwen3_hybrid_layer_masks(
            config)
        # For hybrid models, hybrid_layer_mask is always passed as
        # layer_mask to KVCacheManager, which means get_pp_layers
        # sees a non-None layer_mask and won't auto-add spec layers.
        # Extend the masks here to include MTP spec layers (full
        # attention, no linear states) so they get KV cache entries.
        if spec_config is not None:
            from ..speculative.utils import get_num_spec_layers
            num_spec_layers = get_num_spec_layers(spec_config)
            if num_spec_layers > 0:
                hybrid_layer_mask.extend([True] * num_spec_layers)
                mamba_layer_mask.extend([False] * num_spec_layers)
        num_layers = sum(hybrid_layer_mask)
        num_mamba_layers = sum(mamba_layer_mask)
        kv_cache_manager = kv_cache_manager_cls(
            # mamba cache parameters
            config.linear_key_head_dim,
            config.linear_conv_kernel_dim,
            config.linear_num_value_heads,
            config.linear_num_key_heads,
            config.linear_value_head_dim,
            num_mamba_layers,
            mamba_layer_mask,
            config.torch_dtype,
            quant_config.mamba_ssm_cache_dtype
            if quant_config is not None else None,
            # kv cache parameters
            kv_cache_config,
            tensorrt_llm.bindings.internal.batch_manager.CacheType.SELF,
            num_layers=num_layers,
            layer_mask=hybrid_layer_mask,
            num_kv_heads=per_layer_num_kv_heads,
            head_dim=head_dim,
            tokens_per_block=tokens_per_block,
            max_seq_len=max_seq_len,
            max_batch_size=max_batch_size,
            mapping=mapping,
            dtype=kv_cache_dtype,
            spec_config=spec_config,
            is_estimating_kv_cache=estimating_kv_cache,
            execution_stream=execution_stream,
            model_type="qwen3_next",
        )
    else:
        # NOTE: this is a workaround for VSWA to switch to calculate_max_num_blocks_for_vswa in KVCahceManager
        is_vswa = is_vswa_enabled(kv_cache_config)
        binding_model_config = _model_config.get_bindings_model_config(
            tokens_per_block=tokens_per_block) if is_vswa else None

        kv_cache_manager = kv_cache_manager_cls(
            kv_cache_config,
            tensorrt_llm.bindings.internal.batch_manager.CacheType.SELF,
            num_layers=num_hidden_layers,
            num_kv_heads=per_layer_num_kv_heads,
            head_dim=head_dim,
            tokens_per_block=tokens_per_block,
            max_seq_len=max_seq_len,
            max_batch_size=max_batch_size,
            mapping=mapping,
            dtype=kv_cache_dtype,
            spec_config=spec_config,
            vocab_size=config.vocab_size,
            max_num_tokens=max_num_tokens,
            model_config=binding_model_config,
            max_beam_width=max_beam_width,
            is_draft=is_draft,
            kv_connector_manager=kv_connector_manager
            if not estimating_kv_cache else None,
            sparse_attn_config=sparse_attn_config,
            is_estimating_kv_cache=estimating_kv_cache,
            execution_stream=execution_stream,
            layer_mask=layer_mask,
        )
    return kv_cache_manager


def create_py_executor_instance(
    *,
    dist,
    resources,
    mapping,
    llm_args,
    ctx_chunk_config,
    model_engine,
    start_worker,
    sampler,
    drafter,
    guided_decoder: Optional[GuidedDecoder] = None,
    lora_config: Optional[LoraConfig] = None,
    garbage_collection_gen0_threshold: Optional[int] = None,
    kv_connector_manager: Optional[KvCacheConnectorManager] = None,
    max_seq_len: Optional[int] = None,
    max_batch_size: Optional[int] = None,
    max_beam_width: Optional[int] = None,
    max_num_tokens: Optional[int] = None,
    peft_cache_config: Optional[PeftCacheConfig] = None,
    scheduler_config: Optional[SchedulerConfig] = None,
    cache_transceiver_config: Optional[CacheTransceiverConfig] = None,
    virtual_memory_pools: Optional[dict] = None,
    execution_stream: Optional[torch.cuda.Stream] = None,
    dwdp_manager: Optional[DwdpManager] = None,
) -> PyExecutor:
    kv_cache_manager = resources.get(ResourceManagerType.KV_CACHE_MANAGER, None)

    spec_config = model_engine.spec_config

    max_num_sequences = max_batch_size * mapping.pp_size

    logger.info(
        f"max_seq_len={max_seq_len}, max_num_requests={max_num_sequences}, max_num_tokens={max_num_tokens}, max_batch_size={max_batch_size}"
    )

    for key, value in llm_args.extra_resource_managers.items():
        if key in resources:
            raise ValueError(
                f"Cannot overwrite existing resource manager {key}.")
        resources[key] = value

    peft_cache_manager = None
    if lora_config is not None:
        # TODO: Refactor dimension resolution into a LoraModuleDimensions
        # dataclass to avoid ad-hoc getattr + TP-division blocks per model type.
        from tensorrt_llm.bindings import LoraModule

        if len(lora_config.lora_dir) == 1:
            # Route to appropriate loader based on checkpoint source
            load_torch_lora(lora_config)
        else:
            assert len(lora_config.lora_target_modules
                       ) >= 1, "Expecting at least one lora target module"
            if not bool(lora_config.trtllm_modules_to_hf_modules):
                lora_config.trtllm_modules_to_hf_modules = get_default_trtllm_modules_to_hf_modules(
                )

        model_binding_config = model_engine.model.model_config.get_bindings_model_config(
        )

        num_experts = _try_infer_num_experts(model_engine.model.model_config)

        num_kv_attention_heads_per_layer = model_binding_config.num_kv_heads_per_layer
        if max(num_kv_attention_heads_per_layer) != min(
                num_kv_attention_heads_per_layer):
            logger.warning(
                "Defining LORA with per-layer KV heads is not supported for LORA, using the max number of KV heads per layer"
            )
            num_kv_attention_heads = max(num_kv_attention_heads_per_layer)
        else:
            # all layers have the same number of KV heads
            num_kv_attention_heads = num_kv_attention_heads_per_layer[0]

        pretrained_config = model_engine.model.model_config.pretrained_config

        # Derive shared expert intermediate size from the LoRA adapter
        # weights, which are the source of truth for dimension validation.
        # The model config's shared_expert_intermediate_size may not match
        # the adapter (e.g., upcycled models).
        shared_expert_hidden_size = 0
        if lora_config.lora_dir:
            shared_expert_global = _infer_shared_expert_size_from_adapter(
                lora_config.lora_dir[0])
            if shared_expert_global > 0:
                shared_expert_hidden_size = shared_expert_global // mapping.tp_size

        moe_hidden_size = 0
        moe_intermediate = getattr(pretrained_config, 'moe_intermediate_size',
                                   None)
        if moe_intermediate is not None and moe_intermediate > 0:
            moe_hidden_size = moe_intermediate // mapping.tp_size

        # Mamba dimensions for hybrid models (e.g., Nemotron-H)
        # d_inner = mamba_head_dim * mamba_num_heads
        # d_in_proj = 2 * d_inner + 2 * n_groups * d_state + mamba_num_heads
        mamba_in_proj_size = 0
        mamba_inner_size = 0
        mamba_head_dim = getattr(pretrained_config, 'mamba_head_dim', 0)
        mamba_num_heads = getattr(pretrained_config, 'mamba_num_heads', 0)
        if mamba_head_dim > 0 and mamba_num_heads > 0:
            d_inner = mamba_head_dim * mamba_num_heads
            mamba_inner_size = d_inner // mapping.tp_size
            n_groups = getattr(pretrained_config, 'n_groups', 1)
            d_state = getattr(pretrained_config, 'ssm_state_size', 128)
            d_in_proj = 2 * d_inner + 2 * n_groups * d_state + mamba_num_heads
            mamba_in_proj_size = d_in_proj // mapping.tp_size

        # MoE latent size for latent MoE models (e.g., Nemotron-H SuperV3).
        # Latent projections are replicated (not TP-sharded), so pass the
        # raw config value without dividing by tp_size.
        moe_latent_size = getattr(pretrained_config, 'moe_latent_size', 0) or 0

        # For MoE models with shared experts: replace mlp_* target modules with
        # shared_expert_* equivalents. The shared expert uses different LoRA
        # module types with their own intermediate size. For pure MoE models
        # (no dense MLP layers), mlp_* modules don't exist in the model.
        target_modules = list(lora_config.lora_target_modules)
        if shared_expert_hidden_size > 0:
            has_dense_mlp = bool(
                getattr(pretrained_config, 'mlp_only_layers', None))
            mlp_to_shared_expert = {
                'mlp_h_to_4h': 'shared_expert_h_to_4h',
                'mlp_4h_to_h': 'shared_expert_4h_to_h',
                'mlp_gate': 'shared_expert_gate',
            }
            for mlp_mod, se_mod in mlp_to_shared_expert.items():
                if mlp_mod in target_modules:
                    if se_mod not in target_modules:
                        target_modules.append(se_mod)
                    if not has_dense_mlp:
                        target_modules.remove(mlp_mod)

        lora_modules = LoraModule.create_lora_modules(
            lora_module_names=target_modules,
            hidden_size=model_binding_config.hidden_size,
            mlp_hidden_size=model_binding_config.mlp_hidden_size,
            num_attention_heads=model_binding_config.num_heads,
            num_kv_attention_heads=num_kv_attention_heads,
            attention_head_size=model_binding_config.head_size,
            tp_size=mapping.tp_size,
            num_experts=num_experts,
            shared_expert_hidden_size=shared_expert_hidden_size,
            moe_hidden_size=moe_hidden_size,
            mamba_in_proj_size=mamba_in_proj_size,
            mamba_inner_size=mamba_inner_size,
            moe_latent_size=moe_latent_size)

        model_binding_config.use_lora_plugin = True
        model_binding_config.lora_modules = lora_modules
        model_binding_config.max_lora_rank = lora_config.max_lora_rank

        max_lora_rank = lora_config.max_lora_rank
        num_lora_modules = _compute_num_lora_modules(
            pretrained_config,
            target_modules + lora_config.missing_qkv_modules,
        )

        peft_cache_config_model = PeftCacheConfig(
        ) if peft_cache_config is None else peft_cache_config
        if lora_config.max_loras is not None:
            peft_cache_config_model.num_device_module_layer = \
                max_lora_rank * num_lora_modules * lora_config.max_loras
        if lora_config.max_cpu_loras is not None:
            peft_cache_config_model.num_host_module_layer = \
                max_lora_rank * num_lora_modules * lora_config.max_cpu_loras

        from tensorrt_llm.bindings import WorldConfig
        world_config = WorldConfig(
            tensor_parallelism=mapping.tp_size,
            pipeline_parallelism=mapping.pp_size,
            context_parallelism=mapping.cp_size,
            rank=dist.mapping.rank,
            gpus_per_node=dist.mapping.gpus_per_node,
        )
        peft_cache_manager = PeftCacheManager(
            peft_cache_config=peft_cache_config_model,
            lora_config=lora_config,
            model_config=model_binding_config,
            world_config=world_config,
            execution_stream=execution_stream,
        )
        resources[ResourceManagerType.PEFT_CACHE_MANAGER] = peft_cache_manager
        model_engine.set_lora_model_config(
            target_modules, lora_config.trtllm_modules_to_hf_modules,
            lora_config.swap_gate_up_proj_lora_b_weight)
        if isinstance(model_engine, PyTorchModelEngine):
            model_engine._init_cuda_graph_lora_manager(lora_config)

    resources[ResourceManagerType.SEQ_SLOT_MANAGER] = SeqSlotManager(
        max_num_sequences)

    resource_manager = ResourceManager(resources)

    # Make sure the kv cache manager is always invoked last as it could
    # depend on the results of other resource managers.
    if kv_cache_manager is not None:
        resource_manager.resource_managers.move_to_end(
            ResourceManagerType.KV_CACHE_MANAGER, last=True)

    # When scheduler_capacity == 1, attention dp dummy request will prevent the scheduling of DISAGG_GENERATION_INIT.
    # Enlarge scheduler capacity to avoid DISAGG_GENERATION_INIT stuck in the scheduler.
    scheduler_capacity = max_num_sequences
    if scheduler_capacity == 1 and mapping.enable_attention_dp and kv_cache_manager:
        scheduler_capacity += 1

    if isinstance(kv_cache_manager, KVCacheManagerV2):
        # V2: interleaved scheduler handles both capacity and budget
        draft_kv_cache_manager = resources.get(
            ResourceManagerType.DRAFT_KV_CACHE_MANAGER)
        scheduler_policy = (scheduler_config.capacity_scheduler_policy
                            if scheduler_config is not None else
                            CapacitySchedulerPolicy.MAX_UTILIZATION)
        scheduler = KVCacheV2Scheduler(
            max_batch_size=max_batch_size,
            max_num_tokens=max_num_tokens,
            kv_cache_manager=kv_cache_manager,
            scheduler_policy=scheduler_policy,
            ctx_chunk_config=ctx_chunk_config,
            peft_cache_manager=peft_cache_manager.impl
            if peft_cache_manager is not None else None,
            scheduler_capacity=scheduler_capacity,
            draft_kv_cache_manager=draft_kv_cache_manager,
        )
    elif (scheduler_config is not None
          and scheduler_config.use_python_scheduler):
        scheduler = SimpleUnifiedScheduler(
            max_batch_size=max_batch_size,
            max_num_tokens=max_num_tokens,
            kv_cache_manager=kv_cache_manager.impl
            if kv_cache_manager is not None else None,
            peft_cache_manager=peft_cache_manager.impl
            if peft_cache_manager is not None else None,
            scheduler_policy=scheduler_config.capacity_scheduler_policy,
            ctx_chunk_config=ctx_chunk_config,
            two_step_lookahead=mapping.has_pp(),
            scheduler_capacity=scheduler_capacity)
    else:
        capacity_scheduler = BindCapacityScheduler(
            scheduler_capacity,
            kv_cache_manager.impl if kv_cache_manager is not None else None,
            peft_cache_manager.impl if peft_cache_manager is not None else None,
            scheduler_config.capacity_scheduler_policy,
            two_step_lookahead=mapping.has_pp())

        mb_scheduler = BindMicroBatchScheduler(max_batch_size, max_num_tokens,
                                               ctx_chunk_config)
        scheduler = SimpleScheduler(capacity_scheduler, mb_scheduler)

    config = model_engine.model.model_config.pretrained_config
    attention_type = AttentionTypeCpp.MLA if is_mla(
        config) else AttentionTypeCpp.DEFAULT

    # For hybrid models, this has both impl and mamba_impl
    mamba_cache_manager = None
    if isinstance(kv_cache_manager, MambaHybridCacheManager):
        mamba_cache_manager = kv_cache_manager

    kv_cache_transceiver = create_kv_cache_transceiver(
        mapping, dist, kv_cache_manager, attention_type,
        cache_transceiver_config, mamba_cache_manager)

    waiting_queue_policy = (scheduler_config.waiting_queue_policy
                            if scheduler_config is not None else
                            WaitingQueuePolicy.FCFS)

    return PyExecutor(
        resource_manager,
        scheduler,
        model_engine=model_engine,
        sampler=sampler,
        drafter=drafter,
        dist=dist,
        max_num_sequences=max_num_sequences,
        disable_overlap_scheduler=llm_args.disable_overlap_scheduler,
        max_batch_size=max_batch_size,
        max_beam_width=max_beam_width,
        max_draft_len=spec_config.max_draft_len
        if spec_config is not None else 0,
        max_total_draft_tokens=(spec_config.tokens_per_gen_step -
                                1) if spec_config is not None else 0,
        kv_cache_transceiver=kv_cache_transceiver,
        guided_decoder=guided_decoder,
        start_worker=start_worker,
        garbage_collection_gen0_threshold=garbage_collection_gen0_threshold,
        kv_connector_manager=kv_connector_manager,
        max_seq_len=max_seq_len,
        peft_cache_config=peft_cache_config,
        virtual_memory_pools=virtual_memory_pools,
        execution_stream=execution_stream,
        waiting_queue_policy=waiting_queue_policy,
        dwdp_manager=dwdp_manager,
    )


def create_torch_sampler_args(
    mapping: Mapping,
    *,
    max_seq_len: int,
    max_batch_size: int,
    speculative_config: SpeculativeConfig,
    max_beam_width: int,
    disable_overlap_scheduler: bool,
    disable_flashinfer_sampling: bool,
    enable_async_worker: bool,
):
    max_num_sequences = max_batch_size * mapping.pp_size
    max_draft_len = (0 if speculative_config is None else
                     speculative_config.max_draft_len)
    max_total_draft_tokens = (0 if speculative_config is None else
                              speculative_config.tokens_per_gen_step - 1)

    return TorchSampler.Args(
        max_seq_len=max_seq_len,
        max_draft_len=max_draft_len,
        max_total_draft_tokens=max_total_draft_tokens,
        max_num_sequences=max_num_sequences,
        max_beam_width=max_beam_width,
        disable_flashinfer_sampling=disable_flashinfer_sampling,
        disable_overlap_scheduler=disable_overlap_scheduler,
        enable_async_worker=enable_async_worker)


def instantiate_sampler(
    engine: PyTorchModelEngine,
    llm_args: TorchLlmArgs,
    mapping: Mapping,
    *,
    max_batch_size: int,
    max_beam_width: int,
    max_seq_len: int,
    mm_encoder_only: bool,
    speculative_config: SpeculativeConfig,
    decoding_config: trtllm.DecodingConfig,
    kv_cache_config: KvCacheConfig,
    disable_flashinfer_sampling: bool,
):
    enable_async_worker = (confidential_compute_enabled()
                           or llm_args.sampler_force_async_worker)

    sampler_args = create_torch_sampler_args(
        mapping,
        max_seq_len=engine.max_seq_len,
        max_batch_size=max_batch_size,
        speculative_config=speculative_config,
        max_beam_width=max_beam_width,
        disable_overlap_scheduler=llm_args.disable_overlap_scheduler,
        disable_flashinfer_sampling=disable_flashinfer_sampling,
        enable_async_worker=enable_async_worker,
    )
    decoding_mode = get_decoding_mode(decoding_config=decoding_config,
                                      max_beam_width=max_beam_width)
    if mapping.cp_config.get('cp_type') == CpType.STAR:
        assert llm_args.attn_backend == "FLASHINFER_STAR_ATTENTION", "attention backend of star attention should be 'FLASHINFER_STAR_ATTENTION'"
        return TorchSampler(sampler_args)
    if engine.spec_config is not None and engine.spec_config.spec_dec_mode.has_spec_decoder(
    ):
        return get_spec_decoder(sampler_args, engine.spec_config)

    if mm_encoder_only:
        # NOTE: handle model outputs specially for mm encoder executor/engine
        return EarlyStopWithMMResult()
    if llm_args.sampler_type == SamplerType.TRTLLMSampler:
        logger.warning(
            "TRTLLMSampler is deprecated and will be removed in release 1.4. Please use TorchSampler instead."
        )
        logger.debug(f"DecodingMode: {decoding_mode.name}")
        return TRTLLMSampler(engine.model,
                             engine.dtype,
                             mapping,
                             decoding_mode,
                             llm_args.disable_overlap_scheduler,
                             max_seq_len=max_seq_len,
                             max_batch_size=max_batch_size,
                             max_beam_width=max_beam_width,
                             decoding_config=decoding_config,
                             kv_cache_config=kv_cache_config,
                             enable_async_worker=enable_async_worker)
    if not engine.model.model_config.is_generation:
        # NOTE: choose sampler based on model type
        return EarlyStopSampler()
    return TorchSampler(sampler_args)


def get_decoding_mode(
    decoding_config: trtllm.DecodingConfig,
    max_beam_width: int,
) -> DecodingMode:
    '''This implementation is based off trtGptModelInflightBatching.cpp getDecodingMode().'''
    if decoding_config and decoding_config.decoding_mode and not decoding_config.decoding_mode.isAuto(
    ):
        decoding_mode = decoding_config.decoding_mode
    elif max_beam_width == 1:
        decoding_mode = DecodingMode.TopKTopP()
    else:
        decoding_mode = DecodingMode.BeamSearch()

    # Override decoding mode when beam width is one
    if max_beam_width == 1 and decoding_mode.isBeamSearch():
        logger.warning(
            "Beam width is set to 1, but decoding mode is BeamSearch. Overwriting decoding mode to TopKTopP."
        )
        decoding_mode = DecodingMode.TopKTopP()

    return decoding_mode


_ATTN_MODULES = frozenset({
    "attn_q",
    "attn_k",
    "attn_v",
    "attn_qkv",
    "attn_dense",
    "cross_attn_q",
    "cross_attn_k",
    "cross_attn_v",
})
_MLP_MODULES = frozenset({
    "mlp_h_to_4h",
    "mlp_4h_to_h",
    "mlp_gate",
    "mlp_gate_up",
})


def _compute_num_lora_modules(pretrained_config,
                              all_target_modules: list[str]) -> int:
    """Compute the total number of LoRA module-layer slots for cache sizing.

    For models with per-layer block_configs (e.g. Nemotron-NAS / DeciLM),
    layers with no_op or replace_with_linear attention/FFN cannot host LoRA
    adapters, so they are excluded from the count.  For all other models,
    falls back to the uniform num_hidden_layers x len(target_modules).
    """
    num_layers = pretrained_config.num_hidden_layers
    block_configs = getattr(pretrained_config, "block_configs", None)

    if block_configs is None:
        return num_layers * len(all_target_modules)

    attn_modules = [m for m in all_target_modules if m in _ATTN_MODULES]
    mlp_modules = [m for m in all_target_modules if m in _MLP_MODULES]
    other_modules = [
        m for m in all_target_modules
        if m not in _ATTN_MODULES and m not in _MLP_MODULES
    ]

    def _has_lora_capable_attn(bc):
        return not bc.attention.no_op and not bc.attention.replace_with_linear

    def _has_lora_capable_ffn(bc):
        return not bc.ffn.no_op and not bc.ffn.replace_with_linear

    layers_with_attn = sum(1 for bc in block_configs
                           if _has_lora_capable_attn(bc))
    layers_with_mlp = sum(1 for bc in block_configs
                          if _has_lora_capable_ffn(bc))

    total = (layers_with_attn * len(attn_modules) +
             layers_with_mlp * len(mlp_modules) +
             num_layers * len(other_modules))

    logger.info(f"LoRA module-layer count: {total} "
                f"(attn: {layers_with_attn}x{len(attn_modules)}, "
                f"mlp: {layers_with_mlp}x{len(mlp_modules)}, "
                f"other: {num_layers}x{len(other_modules)}, "
                f"uniform would be {num_layers * len(all_target_modules)})")
    return total


def _infer_shared_expert_size_from_adapter(adapter_dir: str) -> int:
    """Infer shared expert intermediate size from LoRA adapter weights.

    Scans the adapter for shared_expert.down_proj lora_A weights and
    returns the global (unsharded) intermediate size. This is more reliable
    than the model config, which may not match the adapter (e.g., upcycled
    models).
    """
    import json

    try:
        from tensorrt_llm.lora_manager import get_model_path, load_state_dict
        model_path = get_model_path(adapter_dir, "adapter_model")
        if model_path is None:
            return 0
        adapter_weights = load_state_dict(model_path)
        if adapter_weights is None:
            return 0
        for key, tensor in adapter_weights.items():
            if 'shared_expert' in key and 'down_proj' in key and 'lora_A' in key:
                adapter_config_path = os.path.join(adapter_dir,
                                                   "adapter_config.json")
                with open(adapter_config_path) as f:
                    rank = json.load(f).get("r", 0)
                if rank > 0:
                    return tensor.shape[1] if tensor.shape[
                        0] == rank else tensor.shape[0]
    except Exception as e:
        logger.debug(f"Failed to infer shared expert size from adapter: {e}")
    return 0


def _try_infer_num_experts(model_config: ModelConfig) -> int:
    """
    Attempt to infer the number of experts from the model configuration.

    Different MoE models use different attribute names for storing the number of experts,
    so this function checks for various possible names and returns a default of 1 if none are found.
    However, this function is not exhaustive and may miss some cases, so it should be revised.
    """
    config = getattr(model_config, 'pretrained_config', model_config)

    expert_attr_names = [
        'num_experts', 'num_local_experts', 'moe_num_experts',
        'experts_per_router'
    ]
    num_experts = None
    for attr_name in expert_attr_names:
        if hasattr(config, attr_name):
            num_experts = getattr(config, attr_name)
            break

    # Default to 1 for non-MoE models or if no experts attribute is found
    if num_experts is None:
        return 1

    return num_experts


def _adjust_torch_mem_fraction():
    # If true, adjust PyTorch CUDA memory fraction to correspond to the
    # total GPU memory minus the statically allocated engine memory.
    # If false, set the PyTorch CUDA memory fraction to 1.0.
    _limit_torch_cuda_mem_fraction: bool = True

    # FIXME: PyTorch only uses the garbage_collection_threshold setting
    #        if a memory fraction is set, cf.
    #   https://github.com/pytorch/pytorch/blob/cd995bfb2aac8891465809be3ce29543bd524287/c10/cuda/CUDACachingAllocator.cpp#L1357
    logger.debug("Setting PyTorch memory fraction to 1.0")
    torch.cuda.set_per_process_memory_fraction(1.0)

    # FIXME: As soon as
    #     torch.cuda._set_allocator_settings (added in PyTorch 2.8.0-rc1)
    #   or a similar API is available, the warning below should be removed
    #   and the allocator GC threshold be set via the new API instead.
    torch_allocator_config = os.environ.get("PYTORCH_ALLOC_CONF", "")
    torch_mem_threshold_advised = (
        torch.cuda.get_allocator_backend() == "native"
        and "expandable_segments:True" not in torch_allocator_config)
    torch_mem_threshold_set = "garbage_collection_threshold:" in torch_allocator_config
    if torch_mem_threshold_advised and not torch_mem_threshold_set:
        logger.warning(
            "It is recommended to incl. 'garbage_collection_threshold:0.???' or 'backend:cudaMallocAsync'"
            " or 'expandable_segments:True' in PYTORCH_ALLOC_CONF.")

    # NOTE: Even if a memory threshold was not set (cf. warning above), setting a memory
    #       fraction < 1.0 is beneficial, because
    #         https://github.com/pytorch/pytorch/blob/5228986c395dc79f90d2a2b991deea1eef188260/c10/cuda/CUDACachingAllocator.cpp#L2719
    #       and
    #         https://github.com/pytorch/pytorch/blob/5228986c395dc79f90d2a2b991deea1eef188260/c10/cuda/CUDACachingAllocator.cpp#L1240
    #       lead PyTorch to release all unused memory before hitting the set fraction. This
    #       still mitigates OOM, although at a higher performance impact, because it
    #       effectively resets the allocator cache.
    if not _limit_torch_cuda_mem_fraction:
        return
    mem_reserved = torch.cuda.memory_reserved()
    mem_free, mem_total = torch.cuda.mem_get_info()
    safety_margin = 32 * 1024**2
    mem_torch_max = mem_free + mem_reserved - safety_margin
    mem_torch_fraction = mem_torch_max / mem_total
    logger.info(
        f"Setting PyTorch memory fraction to {mem_torch_fraction} ({mem_torch_max / 1024**3} GiB)"
    )
    torch.cuda.set_per_process_memory_fraction(mem_torch_fraction)


def validate_feature_combination(llm_args, model_engine, sampler_type):
    # Validate the flags for features' combination
    def init_feature_status(llm_args) -> Dict[str, bool]:
        assert isinstance(
            llm_args, TorchLlmArgs
        ), "Expect TorchLlmArgs used for feature status validation."
        feature_list = [
            "overlap_scheduler",
            "cuda_graph",
            "attention_dp",
            "disaggregated_serving",
            "chunked_prefill",
            "mtp",
            "eagle3_one_model",
            "eagle3_two_model",
            "torch_sampler",
            "trtllm_sampler",
            "kv_cache_reuse",
            "slide_window_attention",
            "guided_decoding",
        ]
        feature_status: Dict[str, bool] = dict.fromkeys(feature_list)
        feature_status[
            "overlap_scheduler"] = not llm_args.disable_overlap_scheduler
        feature_status["cuda_graph"] = llm_args.cuda_graph_config is not None
        feature_status["attention_dp"] = llm_args.enable_attention_dp
        feature_status[
            "disaggregated_serving"] = llm_args.cache_transceiver_config is not None
        feature_status["chunked_prefill"] = llm_args.enable_chunked_prefill
        feature_status["mtp"] = (
            isinstance(llm_args.speculative_config, MTPDecodingConfig)
            and llm_args.speculative_config.num_nextn_predict_layers > 0)
        feature_status["eagle3_one_model"] = (
            isinstance(llm_args.speculative_config, EagleDecodingConfig)
            and llm_args.speculative_config.eagle3_one_model)
        feature_status["eagle3_two_model"] = (
            isinstance(llm_args.speculative_config, EagleDecodingConfig)
            and not llm_args.speculative_config.eagle3_one_model)
        feature_status[
            "torch_sampler"] = sampler_type == SamplerType.TorchSampler
        feature_status[
            "trtllm_sampler"] = sampler_type == SamplerType.TRTLLMSampler

        feature_status[
            "kv_cache_reuse"] = llm_args.kv_cache_config is not None and llm_args.kv_cache_config.enable_block_reuse
        feature_status["slide_window_attention"] = (
            hasattr(model_engine.model.model_config.pretrained_config,
                    "layer_types") and "sliding_attention"
            in model_engine.model.model_config.pretrained_config.layer_types)
        feature_status[
            "guided_decoding"] = llm_args.guided_decoding_backend is not None
        assert all(v is not None for v in feature_status.values()
                   ), "feature status has not been fully initialized."
        assert all(
            k in feature_list for k in
            feature_status.keys()), "unexpected feature type in feature_status."
        return feature_status

    feature_status: Dict[str, bool] = init_feature_status(llm_args)

    ERR_MSG_TMPL = "{feature1} and {feature2} enabled together is not supported yet."

    CONFLICT_RULES = [
        {
            "features": ["trtllm_sampler", "mtp"],
            "message":
            ERR_MSG_TMPL.format(feature1="trtllm_sampler", feature2="mtp") +
            " Please use sampler type auto instead."
        },
        {
            "features": ["trtllm_sampler", "eagle3_one_model"],
            "message":
            ERR_MSG_TMPL.format(feature1="trtllm_sampler",
                                feature2="eagle3_one_model") +
            " Please use sampler type auto instead."
        },
        {
            "features": ["trtllm_sampler", "eagle3_two_model"],
            "message":
            ERR_MSG_TMPL.format(feature1="trtllm_sampler",
                                feature2="eagle3_two_model") +
            " Please use sampler type auto instead."
        },
        # Add new conflict rules here in the future
    ]
    for rule in CONFLICT_RULES:
        if all(feature_status[feature] for feature in rule["features"]):
            raise ValueError(rule["message"])
