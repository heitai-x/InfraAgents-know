import math
import pickle  # nosec B403
from abc import ABC, abstractmethod
from enum import IntEnum
from functools import lru_cache, wraps
from typing import Any, Callable, List, Optional, Tuple

import numpy as np
import torch
import torch.distributed as dist
from torch.distributed.distributed_c10d import (_object_to_tensor,
                                                _tensor_to_object)

try:
    from mpi4py import MPI
except Exception:
    MPI = None  # deferred; functions will error if used when ENABLE_MULTI_DEVICE is True

from tensorrt_llm._mnnvl_utils import init_helix_cp_comm
from tensorrt_llm._utils import (mpi_allgather, mpi_barrier, mpi_comm,
                                 mpi_disabled, mpi_isend, mpi_isend_object,
                                 mpi_recv, mpi_recv_object, mpi_send,
                                 mpi_send_object, mpi_world_size,
                                 torch_pybind11_abi)
from tensorrt_llm.bindings.BuildInfo import ENABLE_MULTI_DEVICE
from tensorrt_llm.bindings.internal.process_group import init_pg
from tensorrt_llm.logger import logger
from tensorrt_llm.mapping import Mapping

try:
    import ray
except ModuleNotFoundError:
    from tensorrt_llm import ray_stub as ray


class ReduceOp(IntEnum):
    SUM = 0
    PRODUCT = 1
    MIN = 2
    MAX = 3
    BAND = 4
    BOR = 5
    BXOR = 6


_reduce_op_to_torch_dict = {
    ReduceOp.SUM: torch.distributed.ReduceOp.SUM,
    ReduceOp.PRODUCT: torch.distributed.ReduceOp.PRODUCT,
    ReduceOp.MIN: torch.distributed.ReduceOp.MIN,
    ReduceOp.MAX: torch.distributed.ReduceOp.MAX,
    ReduceOp.BAND: torch.distributed.ReduceOp.BAND,
    ReduceOp.BOR: torch.distributed.ReduceOp.BOR,
    ReduceOp.BXOR: torch.distributed.ReduceOp.BXOR,
}


def reduce_op_to_torch(op: ReduceOp) -> torch.distributed.ReduceOp:
    return _reduce_op_to_torch_dict[op]


_reduce_op_to_mpi_dict = {
    ReduceOp.SUM: MPI.SUM,
    ReduceOp.PRODUCT: MPI.PROD,
    ReduceOp.MIN: MPI.MIN,
    ReduceOp.MAX: MPI.MAX,
    ReduceOp.BAND: MPI.BAND,
    ReduceOp.BOR: MPI.BOR,
    ReduceOp.BXOR: MPI.BXOR,
}


def reduce_op_to_mpi(op: ReduceOp) -> MPI.Op:
    return _reduce_op_to_mpi_dict[op]


class Distributed(ABC):

    def __init__(self, mapping: Mapping):
        self.mapping = mapping

    @staticmethod
    @lru_cache(maxsize=None)
    def get(mapping: Mapping) -> "Distributed":
        if mpi_disabled():
            return TorchDist(mapping)
        else:
            return MPIDist(mapping)

    @property
    def rank(self):
        return self.mapping.rank

    @property
    def world_size(self):
        return self.mapping.world_size

    @property
    def has_tp(self):
        return self.mapping.has_tp()

    @property
    def has_pp(self):
        return self.mapping.has_pp()

    @property
    def cp_size(self):
        return self.mapping.cp_size

    @property
    def pp_size(self):
        return self.mapping.pp_size

    @property
    def tp_size(self):
        return self.mapping.tp_size

    @property
    def cp_rank(self):
        return self.mapping.cp_rank

    @property
    def tp_rank(self):
        return self.mapping.tp_rank

    @property
    def pp_rank(self):
        return self.mapping.pp_rank

    @property
    def is_last_pp_rank(self):
        return self.mapping.is_last_pp_rank()

    @property
    def is_second_last_pp_rank(self):
        return self.mapping.is_second_last_pp_rank()

    @property
    def is_first_pp_rank(self):
        return self.mapping.is_first_pp_rank()

    @property
    def next_pp_rank(self):
        return self.mapping.next_pp_rank()

    @property
    def prev_pp_rank(self):
        return self.mapping.prev_pp_rank()

    @property
    def has_cp_ulysses(self):
        return self.mapping.has_cp_ulysses()

    @property
    def has_cp_helix(self):
        return self.mapping.has_cp_helix()

    @property
    def cp_config(self):
        return self.mapping.cp_config

    @abstractmethod
    def barrier(self):
        pass

    @abstractmethod
    def tp_barrier(self):
        pass

    @abstractmethod
    def broadcast(self, obj, root=0):
        pass

    @abstractmethod
    def allgather(self, obj, root=0):
        pass

    @abstractmethod
    def allreduce(self, obj, op: ReduceOp = ReduceOp.SUM):
        pass

    @abstractmethod
    def tp_broadcast(self, obj, root=0, **kwargs):
        pass

    @abstractmethod
    def cp_broadcast(self, obj, root=0, **kwargs):
        pass

    def tp_cp_broadcast(self, obj, root=0, **kwargs):
        """Broadcast object across both TP and CP groups.

        This is used when both TP and CP parallelism are enabled (e.g., helix parallelism).
        First broadcasts within the TP group, then within the CP group.
        """
        if self.tp_size > 1:
            obj = self.tp_broadcast(obj, root=root, **kwargs)
        if self.cp_size > 1:
            obj = self.cp_broadcast(obj, root=root, **kwargs)
        return obj

    @abstractmethod
    def tp_allgather(self, obj):
        pass

    @abstractmethod
    def cp_allgather(self, obj):
        pass

    def tp_cp_allgather(self, obj):
        """Allgather across both TP and CP dimensions.

        First gathers within CP group, then across TP groups, returning
        a flattened list with tp_size * cp_size entries.
        """
        # Gather across CP dimension.
        if self.cp_size > 1:
            obj = self.cp_allgather(obj)
        else:
            obj = [obj]  # Wrap to match cp_allgather output format.

        # Gather across TP dimension.
        if self.tp_size > 1:
            obj = self.tp_allgather(obj)
        else:
            obj = [obj]  # Wrap to match tp_allgather output format.

        # Flatten: [[cp0, cp1], [cp0, cp1], ...] -> [tp0_cp0, tp0_cp1, tp1_cp0, ...]
        return [entry for tp_group in obj for entry in tp_group]


def safe_broadcast(comm, obj, root=0, chunk_size: int = 4 * 1024 * 1024):
    """
    Safely broadcasts potentially large objects by splitting into fixed-size chunks,
    using raw-byte MPI.Bcast to avoid pickle5's out-of-band buffer allocations.

    Args:
        comm: communicator to broadcast
        obj: Python object to broadcast
        root: Rank of the broadcasting process
        chunk_size: Maximum size of each chunk in bytes (default: 4MB)

    Returns:
        The broadcasted object on all ranks
    """
    if not ENABLE_MULTI_DEVICE:
        return obj
    if ENABLE_MULTI_DEVICE and MPI is None:
        raise RuntimeError(
            "mpi4py is required when ENABLE_MULTI_DEVICE is True")
    if chunk_size <= 0:
        raise ValueError("chunk_size must be > 0")
    rank = comm.Get_rank()

    # ---- Serialization phase (root only) ----
    # Header layout: [ok_flag, total_size, num_chunks] as int64
    header = np.zeros(3, dtype=np.int64)
    if rank == root:
        try:
            serialized = pickle.dumps(obj, protocol=pickle.HIGHEST_PROTOCOL)
            total_size = len(serialized)
            num_chunks = math.ceil(total_size /
                                   chunk_size) if total_size > 0 else 0
            header[:] = (1, total_size, num_chunks)
        except Exception as e:
            # Signal failure to all ranks, then raise
            header[:] = (0, 0, 0)
            comm.Bcast([header, MPI.INT64_T], root=root)
            raise RuntimeError(f"Serialization failed: {str(e)}") from e
    else:
        serialized = None  # not used on non-root before Bcast

    # ---- Metadata broadcast (Bcast the fixed-size header) ----
    comm.Bcast([header, MPI.INT64_T], root=root)
    ok_flag, total_size, num_chunks = int(header[0]), int(header[1]), int(
        header[2])
    if not ok_flag:
        raise RuntimeError("Root rank failed during serialization")

    # ---- Allocate receive buffer (non-root) or build a view (root) ----
    # We broadcast raw bytes chunk by chunk.
    if rank == root:
        src_view = memoryview(serialized)
        dst_buf = None
        dst_view = None
    else:
        # Pre-allocate a contiguous byte buffer to receive the payload
        dst_buf = bytearray(total_size)
        dst_view = memoryview(dst_buf)
        src_view = None  # not used on non-root

    # ---- Chunked raw-byte broadcast with MPI.Bcast ----
    # Each round sends exactly `cur` bytes of the global payload.
    offset = 0
    for i in range(num_chunks):
        cur = min(chunk_size, total_size - offset)
        if cur <= 0:
            break  # safety guard for zero-size payloads

        if rank == root:
            # Root sends a slice of the source view
            part = src_view[offset:offset + cur]
            comm.Bcast([part, MPI.BYTE], root=root)
        else:
            # Non-root receives directly into the destination view
            part = dst_view[offset:offset + cur]
            comm.Bcast([part, MPI.BYTE], root=root)

        offset += cur

    # ---- Reconstruction and deserialization ----
    # Validate the received byte count and unpickle.
    if rank == root:
        # Root already has `serialized`
        if len(serialized) != total_size:
            raise RuntimeError(
                f"Data size mismatch at root: expected {total_size}, got {len(serialized)}"
            )
        try:
            return pickle.loads(serialized)  # nosec B301
        except Exception as e:
            raise RuntimeError(f"Deserialization failed: {str(e)}") from e
    else:
        if len(dst_buf) != total_size:
            raise RuntimeError(
                f"Data size mismatch at rank {rank}: expected {total_size}, got {len(dst_buf)}"
            )
        try:
            return pickle.loads(dst_buf)  # nosec B301
        except Exception as e:
            raise RuntimeError(f"Deserialization failed: {str(e)}") from e


def _prepare_chunked_transfer(
    comm: Any,
    obj: Any,
    chunk_size: int,
) -> Tuple[int, int, np.ndarray, np.ndarray, np.ndarray, int, int]:
    """Common preparation for safe_gather and safe_allgather.

    Validates chunk_size, serializes the object, exchanges payload lengths
    across all ranks, and computes displacements and round counts for a
    chunked MPI transfer.

    Args:
        comm: MPI communicator (``MPI.Comm`` instance).
        obj: Python object to transfer (must be picklable).
        chunk_size: Per-round max bytes each rank contributes.

    Returns:
        Tuple of ``(rank, size, lengths, displs, sendbuf, num_rounds,
        chunk_size)`` where:

        - **rank** (*int*) — this process's rank in *comm*.
        - **size** (*int*) — total number of ranks in *comm*.
        - **lengths** (*np.ndarray[int64]*) — per-rank serialized payload
          sizes.
        - **displs** (*np.ndarray[int64]*) — per-rank byte offsets into a
          concatenated receive buffer.
        - **sendbuf** (*np.ndarray[uint8]*) — this rank's serialized
          payload as a contiguous byte array.
        - **num_rounds** (*int*) — number of chunked transfer rounds
          needed.
        - **chunk_size** (*int*) — possibly reduced from the input to keep
          per-round displacements within int32.
    """
    if chunk_size <= 0:
        raise ValueError("chunk_size must be > 0")

    rank = comm.Get_rank()
    size = comm.Get_size()

    # Ensure chunk_size * size fits in int32 for per-round displacements.
    max_safe_chunk = np.iinfo(np.int32).max // size if size > 0 else chunk_size
    if chunk_size > max_safe_chunk:
        logger.info(
            "_prepare_chunked_transfer: reducing chunk_size from %d to %d "
            "to keep per-round displacements within int32 (size=%d)",
            chunk_size, max_safe_chunk, size)
        chunk_size = max_safe_chunk

    try:
        payload = pickle.dumps(obj, protocol=pickle.HIGHEST_PROTOCOL)
    except Exception as e:
        _ = comm.allgather(-1)
        raise RuntimeError(f"Rank {rank} serialization failed: {e}") from e

    lengths = np.array(comm.allgather(len(payload)), dtype=np.int64)
    if (lengths < 0).any():
        raise RuntimeError("Serialization failed on at least one rank")

    displs = np.zeros(size, dtype=np.int64)
    if size > 1:
        displs[1:] = np.cumsum(lengths[:-1])

    sendbuf = np.frombuffer(payload, dtype=np.uint8)
    max_len = int(lengths.max()) if size > 0 else 0
    num_rounds = math.ceil(max_len / chunk_size) if max_len > 0 else 0

    return rank, size, lengths, displs, sendbuf, num_rounds, chunk_size


def _chunked_transfer_loop(
    comm: Any,
    rank: int,
    size: int,
    lengths: np.ndarray,
    displs: np.ndarray,
    sendbuf: np.ndarray,
    num_rounds: int,
    chunk_size: int,
    recvbuf: Optional[np.ndarray],
    collective_fn: Callable[[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
                            None],
) -> None:
    """Run the chunked MPI transfer loop used by safe_gather/safe_allgather.

    Each round transfers at most ``chunk_size`` bytes per rank using a
    per-round temporary receive buffer with 0-based int32 displacements,
    then copies the received data into ``recvbuf`` at the correct absolute
    offsets using 64-bit Python-level indexing.

    Args:
        comm: MPI communicator (``MPI.Comm`` instance).
        rank: This rank's index in *comm*.
        size: Total number of ranks in *comm*.
        lengths: Per-rank serialized payload sizes (int64 array of shape
            ``(size,)``).
        displs: Per-rank byte offsets into *recvbuf* (int64 array of shape
            ``(size,)``).
        sendbuf: This rank's serialized payload (uint8 array).
        num_rounds: Number of chunked transfer rounds to execute.
        chunk_size: Per-round max bytes each rank contributes.
        recvbuf: Final contiguous receive buffer (uint8 array), or
            ``None`` for non-root ranks in gather mode (copy-back is
            skipped).
        collective_fn: Callable that performs the per-round MPI
            collective.  Signature: ``collective_fn(send_part,
            round_recvbuf, counts_this_round, round_displs)``.
    """
    for r in range(num_rounds):
        round_offs = r * chunk_size
        counts_this_round = np.minimum(np.maximum(lengths - round_offs, 0),
                                       chunk_size).astype(np.int32)
        sent_so_far = np.minimum(lengths, round_offs)

        round_recvbuf = (np.empty(counts_this_round.sum(), dtype=np.uint8)
                         if recvbuf is not None else None)
        round_displs = np.zeros(size, dtype=np.int32)
        if size > 1:
            round_displs[1:] = np.cumsum(counts_this_round[:-1])

        send_part = sendbuf[sent_so_far[rank]:sent_so_far[rank] +
                            counts_this_round[rank]]

        collective_fn(send_part, round_recvbuf, counts_this_round, round_displs)

        # Copy received chunks into the final buffer at correct
        # absolute offsets (using 64-bit Python-level indexing).
        if recvbuf is not None:
            src_offset = 0
            for i in range(size):
                n = counts_this_round[i]
                if n > 0:
                    dst = displs[i] + sent_so_far[i]
                    recvbuf[dst:dst +
                            n] = (round_recvbuf[src_offset:src_offset + n])
                src_offset += n


def _deserialize_recvbuf(
    recvbuf: np.ndarray,
    lengths: np.ndarray,
    displs: np.ndarray,
    size: int,
) -> List[Any]:
    """Deserialize gathered payloads from a contiguous receive buffer.

    Args:
        recvbuf: Contiguous receive buffer (uint8 array) containing the
            concatenated serialized payloads from all ranks.
        lengths: Per-rank serialized payload sizes (int64 array of shape
            ``(size,)``).
        displs: Per-rank byte offsets into *recvbuf* (int64 array of shape
            ``(size,)``).
        size: Total number of ranks.

    Returns:
        List of deserialized Python objects (``len == size``). Ranks whose
        payload length is zero are represented as ``None``.
    """
    return [
        pickle.loads(recvbuf[displs[i]:displs[i] + lengths[i]])  # nosec B301
        if lengths[i] > 0 else None for i in range(size)
    ]


def safe_gather(
    comm: Any,
    obj: Any,
    root: int = 0,
    chunk_size: int = 4 * 1024 * 1024,
) -> Optional[List[Any]]:
    """Safely gather potentially large objects by splitting into fixed-size
    chunks, using raw-byte MPI.Gatherv with a per-round temp buffer to
    keep counts and displacements within int32.

    Args:
        comm: MPI communicator (``MPI.Comm`` instance) to gather over.
        obj: Python object to gather (must be picklable).
        root: Rank that receives the gathered objects.
        chunk_size: Per-round max bytes each rank contributes (default:
            4 MB).

    Returns:
        On *root*: list of deserialized objects (``len == comm.size``).
        On non-root ranks: ``None``.
    """
    if not ENABLE_MULTI_DEVICE:
        return [obj]
    if MPI is None:
        raise RuntimeError(
            "mpi4py is required when ENABLE_MULTI_DEVICE is True")

    rank, size, lengths, displs, sendbuf, num_rounds, chunk_size = \
        _prepare_chunked_transfer(comm, obj, chunk_size)

    # Fast path: when all payloads fit in a single round, the simple
    # comm.gather avoids the chunked-loop overhead.
    if num_rounds <= 1:
        return comm.gather(obj, root=root)

    recvbuf = np.empty(lengths.sum(), dtype=np.uint8) if rank == root else None

    def _gatherv(send_part, round_recvbuf, counts, round_displs):
        if rank == root:
            comm.Gatherv([send_part, MPI.BYTE],
                         [round_recvbuf, counts, round_displs, MPI.BYTE],
                         root=root)
        else:
            comm.Gatherv([send_part, MPI.BYTE], None, root=root)

    _chunked_transfer_loop(comm, rank, size, lengths, displs, sendbuf,
                           num_rounds, chunk_size, recvbuf, _gatherv)

    if rank == root:
        return _deserialize_recvbuf(recvbuf, lengths, displs, size)
    return None


def safe_allgather(
    comm: Any,
    obj: Any,
    chunk_size: int = 4 * 1024 * 1024,
) -> List[Any]:
    """Safely allgather potentially large objects by splitting into
    fixed-size chunks, using raw-byte MPI.Allgatherv. Every rank ends
    up with the complete list of deserialized objects.

    Why "safe": mpi4py's ``comm.allgather(obj)`` internally calls
    ``MPI_Allgatherv`` with 32-bit ``int`` counts and displacements.
    When any rank's serialized payload or the cumulative displacement
    exceeds ~2 GB, this causes silent data corruption or segfaults.
    Additionally, mpi4py's pickle5-based protocol may allocate extra
    out-of-band buffers for large objects, causing unexpected memory
    spikes. This function avoids both issues by:

    1. Serializing once with ``pickle.dumps`` (no out-of-band buffers).
    2. Transferring raw bytes in rounds of at most ``chunk_size`` per
       rank, keeping each ``MPI_Allgatherv`` call's counts and
       displacements within 32-bit limits.

    For small objects the overhead is negligible (one extra allgather of
    int64 lengths, single-round transfer), so this can be used as a
    drop-in replacement for ``comm.allgather``.

    Args:
        comm: MPI communicator (``MPI.Comm`` instance) to allgather over.
        obj: Python object to allgather (must be picklable).
        chunk_size: Per-round max bytes each rank contributes (default:
            4 MB).

    Returns:
        List of deserialized objects from all ranks
        (``len == comm.size``).
    """
    if not ENABLE_MULTI_DEVICE:
        return [obj]
    if MPI is None:
        raise RuntimeError(
            "mpi4py is required when ENABLE_MULTI_DEVICE is True")

    rank, size, lengths, displs, sendbuf, num_rounds, chunk_size = \
        _prepare_chunked_transfer(comm, obj, chunk_size)

    # Fast path: when all payloads fit in a single round, the simple
    # comm.allgather avoids the chunked-loop overhead.
    if num_rounds <= 1:
        return comm.allgather(obj)

    recvbuf = np.empty(lengths.sum(), dtype=np.uint8)

    def _allgatherv(send_part, round_recvbuf, counts, round_displs):
        comm.Allgatherv([send_part, MPI.BYTE],
                        [round_recvbuf, counts, round_displs, MPI.BYTE])

    _chunked_transfer_loop(comm, rank, size, lengths, displs, sendbuf,
                           num_rounds, chunk_size, recvbuf, _allgatherv)

    return _deserialize_recvbuf(recvbuf, lengths, displs, size)


class MPIDist(Distributed):
    tp_comm: MPI.Comm

    def __init__(self, mapping: Mapping):
        super().__init__(mapping)
        self._cp_comm = None
        self._tp_comm = None
        self._pp_comm = None

    def _validate_world_size(self):
        """Validate world size before creating sub-communicators to prevent segfaults."""

        if ENABLE_MULTI_DEVICE:
            actual_world_size = mpi_world_size()
            max_rank_needed = self.mapping.world_size

            if max_rank_needed > actual_world_size:
                raise RuntimeError(
                    f"Mapping requires world_size={max_rank_needed} "
                    f"(tp_size={self.mapping.tp_size} * pp_size={self.mapping.pp_size} * cp_size={self.mapping.cp_size}), "
                    f"but MPI world size is only {actual_world_size}. ")

    def broadcast(self, obj, root=0, chunk_size: int = 4 * 1024 * 1024):
        comm = mpi_comm()
        return safe_broadcast(comm, obj, root=root, chunk_size=chunk_size)

    def allgather(self, obj):
        return mpi_allgather(obj)

    def barrier(self):
        mpi_barrier()

    def tp_barrier(self):
        self.tp_comm.Barrier()

    def isend(self, buf: np.ndarray, dest, tag=0):
        # non-blocking send numpy buffer
        return mpi_isend(buf, dest, tag)

    def send(self, buf: np.ndarray, dest, tag=0):
        # blocking send numpy buffer
        mpi_send(buf, dest, tag)

    def recv(self, buf: np.ndarray, src, tag=0):
        # in-place recv numpy buffer
        return mpi_recv(buf, src, tag)

    def send_object(self, obj, dest, tag=0):
        mpi_send_object(obj, dest, tag)

    def isend_object(self, obj, dest, tag=0):
        return mpi_isend_object(obj, dest, tag)

    def recv_object(self, src, tag=0):
        return mpi_recv_object(src, tag)

    @property
    def tp_comm(self):
        if self._tp_comm is None:
            self._validate_world_size()
            mapping = self.mapping
            new_group = mpi_comm().group.Incl(mapping.tp_group)
            self._tp_comm = mpi_comm().Create_group(new_group)
        return self._tp_comm

    @property
    def pp_comm(self):
        if self._pp_comm is None:
            self._validate_world_size()
            mapping = self.mapping
            new_group = mpi_comm().group.Incl(mapping.pp_group)
            self._pp_comm = mpi_comm().Create_group(new_group)
        return self._pp_comm

    @property
    def cp_comm(self):
        if self._cp_comm is None:
            self._validate_world_size()
            new_group = mpi_comm().group.Incl(self.mapping.cp_group)
            self._cp_comm = mpi_comm().Create_group(new_group)
        return self._cp_comm

    def cp_allgather(self, obj, chunk_size: int = 4 * 1024 * 1024):
        comm = self.cp_comm
        return safe_allgather(comm, obj, chunk_size=chunk_size)

    def cp_broadcast(self,
                     obj,
                     root=0,
                     chunk_size: int = 4 * 1024 * 1024,
                     **kwargs):
        comm = self.cp_comm
        return safe_broadcast(comm, obj, root=root, chunk_size=chunk_size)

    def tp_allgather(self, obj, chunk_size: int = 4 * 1024 * 1024):
        comm = self.tp_comm
        return safe_allgather(comm, obj, chunk_size=chunk_size)

    def tp_gather(self, obj, root=0, chunk_size: int = 4 * 1024 * 1024):
        comm = self.tp_comm
        return safe_gather(comm, obj, root=root, chunk_size=chunk_size)

    def tp_broadcast(self,
                     obj,
                     root=0,
                     chunk_size: int = 4 * 1024 * 1024,
                     **kwargs):
        comm = self.tp_comm
        return safe_broadcast(comm, obj, root=root, chunk_size=chunk_size)

    def pp_allgather(self, obj, chunk_size: int = 4 * 1024 * 1024):
        comm = self.pp_comm
        return safe_allgather(comm, obj, chunk_size=chunk_size)

    def pp_gather(self, obj, root=0, chunk_size: int = 4 * 1024 * 1024):
        comm = self.pp_comm
        return safe_gather(comm, obj, root=root, chunk_size=chunk_size)

    def pp_broadcast(self, obj, root=0):
        return self.pp_comm.bcast(obj, root)

    def allreduce(self, obj, op: ReduceOp = ReduceOp.SUM):
        reduce_op = reduce_op_to_mpi(op)
        return mpi_comm().allreduce(obj, reduce_op)


class MultiHandleWrapper:
    """
    Wrapper that encapsulates multiple handles and provides a single wait() interface
    to unify the API between MPIDist and TorchDist.
    """

    def __init__(self, handles):
        self.handles = handles if isinstance(handles, list) else [handles]

    def wait(self):
        for handle in self.handles:
            try:
                handle.wait()
            except Exception as e:
                raise RuntimeError(f"Asynchronous operation failed: {e}") from e


class TorchDist(Distributed):

    @property
    def rank(self):
        return torch.distributed.get_rank()

    def __init__(self, mapping: Mapping):
        super().__init__(mapping)
        assert dist.is_initialized(
        ), "torch.distributed should be initialized before TorchDist"

        self.cluster_info = None

        from tensorrt_llm._utils import set_torch_comm
        set_torch_comm(self)  # Set as global instance
        mapping.build_mesh()

        self.setup_local_comm()
        self.default_store = torch.distributed.distributed_c10d._get_default_store(
        )

        init_pg(torch.distributed.group.WORLD, self.local_comm,
                torch_pybind11_abi())

    def setup_local_comm(self):
        self._get_cluster_info()

        # node IP -> list of ranks
        ip_to_ranks = {}
        for rank, (node_ip, _) in enumerate(self.cluster_info):
            ip_to_ranks.setdefault(node_ip, []).append(int(rank))

        self.local_comm = None
        for ranks in ip_to_ranks.values():
            # All global ranks from the default process group to participate in the call,
            # even if some ranks are not part of the new process group being created
            pg = dist.new_group(ranks=ranks, backend='cuda:nccl,cpu:gloo')
            if int(self.rank) in ranks:
                logger.debug(
                    f"[Rank {self.rank}] Done setting local comm. ip_to_ranks: {ip_to_ranks}"
                )
                self.local_comm = pg

    def _get_cluster_info(self):
        if self.cluster_info is not None:
            return self.cluster_info

        if ray.is_initialized():
            node_ip = ray.util.get_node_ip_address()
        else:
            raise RuntimeError("Ray is not initialized")

        gpu_index = [int(id) for id in ray.get_gpu_ids()]

        assert len(gpu_index) == 1

        # Gather node ip
        node_list = [None] * torch.distributed.get_world_size()

        torch.distributed.all_gather_object(node_list, node_ip)

        # Gather gpu index
        gpu_list = [None] * torch.distributed.get_world_size()
        torch.distributed.all_gather_object(gpu_list, gpu_index[0])

        # Gather rank
        rank_list = [None] * torch.distributed.get_world_size()
        torch.distributed.all_gather_object(rank_list,
                                            torch.distributed.get_rank())

        rank_info_list = [None] * torch.distributed.get_world_size()
        for i in range(len(rank_list)):
            rank_info_list[rank_list[i]] = (node_list[i], gpu_list[i])

        self.cluster_info = rank_info_list

        logger.debug(f"Cluster info: {self.cluster_info}")
        return self.cluster_info

    @staticmethod
    def log_op(func, enable_log=False):

        @wraps(func)
        def wrapper(*args, **kwargs):
            if enable_log:
                logger.debug(
                    f"{func.__name__} enter: {args[1:]}, {kwargs}, rank: {torch.distributed.get_rank()}"
                )
            ret = func(*args, **kwargs)

            if enable_log:
                logger.debug(f"{func.__name__} exit: {ret}")
            return ret

        return wrapper

    @log_op
    def broadcast(self, obj, root=0):
        assert not (self.mapping.has_cp_ulysses() and self.mapping.has_tp()
                    ), 'Unsupported mix of Ulysses CP and TP.'

        if mpi_disabled():
            if isinstance(obj, torch.Tensor):
                dist.broadcast(obj, src=root)
                return obj
            else:
                obj_list = [obj]
                dist.broadcast_object_list(obj_list, src=root)
                return obj_list[0]

        if self.mapping.has_cp_ulysses():
            self.broadcast_cp(obj, root)
        elif self.mapping.has_tp():
            self.broadcast_tp(obj, root)

    @log_op
    def allgather(self, obj):
        if isinstance(obj, torch.Tensor):
            output_list = [
                torch.empty_like(obj) for _ in range(self.world_size)
            ]
            dist.all_gather(output_list, obj)
            return output_list
        else:
            obj_list = [None] * self.world_size
            dist.all_gather_object(obj_list, obj)
            return obj_list

    @log_op
    def barrier(self):
        dist.barrier()

    @log_op
    def tp_barrier(self):
        dist.barrier(group=self.mapping.tp_group_pg)

    @log_op
    def isend(self, buf: np.ndarray, dest, tag=0):
        # non-blocking send numpy buffer
        tensor = torch.from_numpy(buf)
        return dist.isend(tensor, dst=dest, tag=tag)

    @log_op
    def send(self, buf: np.ndarray, dest, tag=0):
        raise NotImplementedError(
            "blocking send is not implemented for TorchDist")

    @log_op
    def recv(self, buf: np.ndarray, src, tag=0):
        # in-place recv numpy buffer
        tensor = torch.empty_like(torch.from_numpy(buf))
        dist.recv(tensor, src=src, tag=tag)
        return tensor.numpy()

    @log_op
    def isend_tensor(self, tensor: torch.Tensor, dest, tag=0):
        return dist.isend(tensor, dst=dest, tag=tag)

    @log_op
    def recv_tensor(self, tensor: torch.Tensor, src, tag=0):
        dist.recv(tensor, src=src, tag=tag)
        return tensor

    @log_op
    def recv_object(self, src, tag=0):
        size_tensor = torch.tensor([0], dtype=torch.int32)
        torch.distributed.recv(size_tensor,
                               src=src,
                               tag=tag,
                               group=torch.distributed.group.WORLD)
        bytes_size = size_tensor.item()
        recv_tensor = torch.empty(bytes_size, dtype=torch.uint8)
        torch.distributed.recv(recv_tensor,
                               src=src,
                               tag=tag,
                               group=torch.distributed.group.WORLD)
        return _tensor_to_object(recv_tensor, bytes_size,
                                 torch.distributed.group.WORLD)

    @log_op
    def send_object(self, obj, dest, tag=0):
        self.isend_object(obj, dest, tag).wait()

    @log_op
    def isend_object(self, obj, dest, tag=0):
        input_tensor, local_size = _object_to_tensor(
            obj, torch.device("cpu"), torch.distributed.group.WORLD)

        # Send object size
        works = []
        works.append(
            torch.distributed.isend(torch.tensor([local_size],
                                                 dtype=torch.int32),
                                    dst=dest,
                                    tag=tag))
        works.append(torch.distributed.isend(input_tensor, dst=dest, tag=tag))
        return MultiHandleWrapper(works)

    @log_op
    def allreduce(
        self,
        obj: int | float | torch.Tensor,
        op: ReduceOp = ReduceOp.SUM,
    ):
        is_base_type = isinstance(obj, int) or isinstance(obj, float)
        if is_base_type:
            obj = torch.tensor(obj)

        dist.all_reduce(obj, op=reduce_op_to_torch(op))

        if is_base_type:
            obj = obj.item()

        return obj

    @log_op
    def tp_allgather(self, obj):
        if isinstance(obj, torch.Tensor):
            output_list = [
                torch.empty_like(obj)
                for _ in range(self.mapping.tp_group_pg.size())
            ]
            dist.all_gather(output_list, obj, group=self.mapping.tp_group_pg)
            return output_list
        else:
            output_list = [None] * self.mapping.tp_group_pg.size()
            dist.all_gather_object(output_list,
                                   obj,
                                   group=self.mapping.tp_group_pg)
            return output_list

    @log_op
    def tp_gather(self, obj, dst=0):
        global_rank = torch.distributed.get_rank()
        if isinstance(obj, torch.Tensor):
            if global_rank == dst:
                output_list = [
                    torch.empty_like(obj)
                    for _ in range(self.mapping.tp_group_pg.size())
                ]
            else:
                output_list = None
            dist.gather(obj,
                        output_list,
                        dst=dst,
                        group=self.mapping.tp_group_pg)
            return output_list
        else:
            output_list = [None] * self.mapping.tp_group_pg.size()
            if global_rank == dst:
                output_list = [None] * self.mapping.tp_group_pg.size()
            else:
                output_list = None
            dist.gather_object(obj,
                               output_list,
                               dst=dst,
                               group=self.mapping.tp_group_pg)
            return output_list

    @log_op
    def tp_broadcast(self, obj, root=0, **kwargs):
        if isinstance(obj, torch.Tensor):
            dist.broadcast(obj, src=root, group=self.mapping.tp_group_pg)
            return obj
        else:
            ret = [obj]
            torch.distributed.broadcast_object_list(
                ret,
                src=root,
                group=self.mapping.tp_group_pg,
                device=torch.device("cpu"))
            return ret[0]

    @log_op
    def cp_broadcast(self, obj, root=0, **kwargs):
        if isinstance(obj, torch.Tensor):
            dist.broadcast(obj, src=root, group=self.mapping.cp_group_pg)
            return obj
        else:
            ret = [obj]
            torch.distributed.broadcast_object_list(
                ret,
                src=root,
                group=self.mapping.cp_group_pg,
                device=torch.device("cpu"))
            return ret[0]

    @log_op
    def cp_allgather(self, obj):
        if isinstance(obj, torch.Tensor):
            output_list = [
                torch.empty_like(obj)
                for _ in range(self.mapping.cp_group_pg.size())
            ]
            dist.all_gather(output_list, obj, group=self.mapping.cp_group_pg)
            return output_list
        else:
            output_list = [None] * self.mapping.cp_group_pg.size()
            dist.all_gather_object(output_list,
                                   obj,
                                   group=self.mapping.cp_group_pg)
            return output_list

    @log_op
    def pp_allgather(self, obj):
        if isinstance(obj, torch.Tensor):
            output_list = [
                torch.empty_like(obj)
                for _ in range(self.mapping.pp_group_pg.size())
            ]
            dist.all_gather(output_list, obj, group=self.mapping.pp_group_pg)
            return output_list
        else:
            output_list = [None] * self.mapping.pp_group_pg.size()
            dist.all_gather_object(output_list,
                                   obj,
                                   group=self.mapping.pp_group_pg)
            return output_list

    @log_op
    def pp_gather(self, obj, dst=0):
        global_rank = torch.distributed.get_rank()
        if isinstance(obj, torch.Tensor):
            if global_rank == dst:
                output_list = [
                    torch.empty_like(obj)
                    for _ in range(self.mapping.pp_group_pg.size())
                ]
            else:
                output_list = None
            dist.gather(obj,
                        output_list,
                        dst=dst,
                        group=self.mapping.pp_group_pg)
            return output_list
        else:
            output_list = [None] * self.mapping.pp_group_pg.size()
            if global_rank == dst:
                output_list = [None] * self.mapping.pp_group_pg.size()
            else:
                output_list = None
            dist.gather_object(obj,
                               output_list,
                               dst=dst,
                               group=self.mapping.pp_group_pg)
            return output_list

    @log_op
    def pp_broadcast(self, obj, root=0):
        if isinstance(obj, torch.Tensor):
            dist.broadcast(obj, src=root, group=self.mapping.pp_group_pg)
            return obj
        else:
            ret = [obj]
            torch.distributed.broadcast_object_list(
                ret,
                src=root,
                group=self.mapping.pp_group_pg,
                device=torch.device("cpu"))
            return ret[0]


class PPCommNCCL:

    def __init__(self, global_mapping: Mapping):
        self.mapping = global_mapping
        self.nccl_comm = torch.classes.trtllm.NcclCommunicatorOp(
            self.mapping.world_size,
            self.mapping.rank,
        )
        self.tensor_ready_event = torch.cuda.Event()
        self.send_stream = torch.cuda.Stream()

    def send(self, tensor: torch.Tensor, dest: Optional[int] = None):
        if dest is None:
            dest = self.mapping.next_pp_rank()

        # NCCL send kernel in send_stream cannot be captured,
        # so we send in the current stream instead in CUDA graph cases.
        if torch.cuda.is_current_stream_capturing():
            self.nccl_comm.send(tensor, dest)
            return

        # If the tensor is allocated from non-default memory pool
        # like userbuffers, its underlying memory may be reused
        # before the send operation is completed.
        # We clone the tensor to avoid write-write conflicts.
        tensor = tensor.clone()
        self.send_stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(self.send_stream):
            self.nccl_comm.send(tensor, dest)

    def recv(self, tensor: torch.Tensor, src: Optional[int] = None):
        if src is None:
            src = self.mapping.prev_pp_rank()
        self.nccl_comm.recv(tensor, src)


class PPCommTorch:

    def __init__(self, global_mapping: Mapping):
        self.mapping = global_mapping
        self.pg = self.mapping.pp_group_pg
        self.pg_group = self.mapping.pp_group

    def _global_to_local_rank(self, global_rank: int):
        assert global_rank in self.pg_group
        return self.pg_group.index(global_rank)

    def send(self, tensor: torch.Tensor, dest: Optional[int] = None):
        if dest is None:
            dest = self.mapping.next_pp_rank()

        work = self.pg.send([tensor], self._global_to_local_rank(dest), tag=0)
        # Send operation cannot be captured without blocking wait,
        # so we block the current stream in CUDA graph cases.
        if torch.cuda.is_current_stream_capturing():
            work.block_current_stream()

    def recv(self, tensor: torch.Tensor, src: Optional[int] = None):
        if src is None:
            src = self.mapping.prev_pp_rank()

        work = self.pg.recv([tensor], self._global_to_local_rank(src), tag=0)
        work.block_current_stream()


_pp_comm = None


def init_pp_comm(mapping):
    """Initialize PPComm once at startup"""
    global _pp_comm
    if mpi_disabled():
        _pp_comm = PPCommTorch(mapping)
    else:
        _pp_comm = PPCommNCCL(mapping)
    init_helix_cp_comm(mapping)


@TorchDist.log_op
def pp_recv(tensor):
    """Receive tensors from previous pp rank."""
    _pp_comm.recv(tensor)


@TorchDist.log_op
def pp_send(tensor):
    """Send tensors to next pp rank."""
    _pp_comm.send(tensor)


@torch.library.custom_op("trtllm::pp_recv_tensors", mutates_args=("tensors", ))
def pp_recv_tensors(tensors: List[torch.Tensor]) -> None:
    """
    Receive tensors from previous pp rank.
    """
    for tensor in tensors:
        pp_recv(tensor)


@torch.library.custom_op("trtllm::pp_send_tensors", mutates_args=("tensors", ))
def pp_send_tensors(tensors: List[torch.Tensor]) -> None:
    """Send tensors to next pp rank."""
    for tensor in tensors:
        pp_send(tensor)
