"""
Quantization Config Reader Registry.

This module defines a registry system for parsing quantization configurations
from various sources (e.g., 'modelopt'). It enables extensible support for different
quantization producers by delegating parsing logic to dedicated subclasses.
"""

import json
import os
from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, Optional, Tuple, Type

from tensorrt_llm._torch.auto_deploy.utils.logger import ad_logger


class QuantConfigReader(ABC):
    """Base class for reading and parsing quantization config."""

    def __init__(self):
        self._quant_config: Optional[Dict] = {}

    def get_config(self) -> Dict:
        """Return the parsed quantization config."""
        return self._quant_config

    @abstractmethod
    def read_config(self, config: Dict) -> Dict:
        """
        Parse and normalize a quantization config dictionary.

        Args:
            config: The raw parsed JSON object.

        Returns:
            A dictionary of extra model kwargs derived from the quantization config.
            Implementations must also populate self._quant_config with the normalized
            quantization config.
        """
        pass

    @classmethod
    @abstractmethod
    def from_file(cls, file_path: str) -> Optional[Tuple["QuantConfigReader", Dict[str, Any]]]:
        """
        Load and parse a quantization config file from disk.

        This method is implemented by each reader to handle loading and parsing logic.

        Args:
            file_path: Path to the quant config JSON file.

        Returns:
            A (reader, extra_model_kwargs) tuple, or None if the file doesn't exist.
        """
        pass

    # optional hook; default is no-op
    def post_process_model(self, model, model_config):
        """Optional hook to mutate model after construction (e.g., dtype moves)."""
        return model


class QuantConfigReaderRegistry:
    _registry: Dict[str, Type[QuantConfigReader]] = {}

    @classmethod
    def register(cls, name: str) -> Callable[[Type[QuantConfigReader]], Type[QuantConfigReader]]:
        def inner(reader_cls: Type[QuantConfigReader]) -> Type[QuantConfigReader]:
            cls._registry[name] = reader_cls
            return reader_cls

        return inner

    @classmethod
    def get(cls, name: str) -> Type[QuantConfigReader]:
        if name not in cls._registry:
            raise ValueError(f"QuantConfigReader for '{name}' not registered.")
        return cls._registry[name]

    @classmethod
    def has(cls, reader_cls: str) -> bool:
        return reader_cls in cls._registry


@QuantConfigReaderRegistry.register("modelopt")
class ModelOPTQuantConfigReader(QuantConfigReader):
    _ALWAYS_EXCLUDE = (
        "lm_head",
        "model.embed_tokens",
        "*.embed_tokens",
        "*.mixer.gate*",
        "*.mlp.gate",
    )
    DEFAULT_TORCH_DTYPE = "float16"
    DEFAULT_KV_CACHE_DTYPE = "fp8"

    def read_config(self, config: Dict) -> Dict:
        producer = config.get("producer", {}).get("name")
        # sanity check
        if producer != "modelopt":
            raise ValueError(f"Expected producer 'modelopt', got '{producer}'")

        quant_config = config.get("quantization", {})

        quant_algo = quant_config.get("quant_algo", "").upper()

        if quant_algo == "MIXED_PRECISION":
            self._read_mixed_precision_config(quant_config)
        else:
            self._read_single_algo_config(quant_config)

        return {}

    def _read_single_algo_config(self, quant_config: Dict) -> None:
        """Parse a single-algorithm quantization config (e.g. NVFP4, FP8)."""
        excludes = quant_config.get("exclude_modules", [])
        quant_config["exclude_modules"] = excludes + [
            n for n in self._ALWAYS_EXCLUDE if n not in excludes
        ]

        if "torch_dtype" not in quant_config:
            ad_logger.warning(
                f"torch_dtype not found in quant_config, using default {self.DEFAULT_TORCH_DTYPE}"
            )
            quant_config["torch_dtype"] = self.DEFAULT_TORCH_DTYPE

        self._handle_kv_cache(quant_config)
        self._quant_config = quant_config

    def _read_mixed_precision_config(self, quant_config: Dict) -> None:
        """Parse a MIXED_PRECISION quantization config with per-layer algo assignments."""
        quantized_layers = quant_config.get("quantized_layers", {})
        if not quantized_layers:
            raise ValueError(
                "MIXED_PRECISION quant_algo requires a non-empty 'quantized_layers' mapping."
            )

        unique_algos = {v.get("quant_algo", "").upper() for v in quantized_layers.values()}
        algo_counts = {}
        for v in quantized_layers.values():
            algo = v.get("quant_algo", "UNKNOWN").upper()
            algo_counts[algo] = algo_counts.get(algo, 0) + 1
        ad_logger.info(
            f"Mixed precision checkpoint detected: {len(quantized_layers)} layers, "
            f"algos: {unique_algos}, per-algo counts: {algo_counts}"
        )

        quant_config["exclude_modules"] = list(self._ALWAYS_EXCLUDE)

        if "torch_dtype" not in quant_config:
            ad_logger.warning(
                f"torch_dtype not found in quant_config, using default {self.DEFAULT_TORCH_DTYPE}"
            )
            quant_config["torch_dtype"] = self.DEFAULT_TORCH_DTYPE

        self._handle_kv_cache(quant_config)
        self._quant_config = quant_config

    def _handle_kv_cache(self, quant_config: Dict) -> None:
        kv_algo = quant_config.get("kv_cache_quant_algo")
        if kv_algo:
            if kv_algo != "FP8":
                raise ValueError(f"KV cache quantization format {kv_algo} not supported.")
            quant_config["kv_cache_dtype"] = "fp8"

    @classmethod
    def from_file(
        cls, ckpt_dir: str
    ) -> Optional[Tuple["ModelOPTQuantConfigReader", Dict[str, Any]]]:
        """
        Load and parse a modelopt-style quantization config from a checkpoint directory.

        Args:
            ckpt_dir: Path to the root directory containing the checkpoint.

        Returns:
            An initialized ModelOPTQuantConfigReader instance, or None if the file doesn't exist.
        """
        quant_file = os.path.join(ckpt_dir, "hf_quant_config.json")
        if not os.path.exists(quant_file):
            return None

        with open(quant_file, "r") as f:
            raw = json.load(f)
        reader = cls()
        extra_model_kwargs = reader.read_config(raw)
        return reader, extra_model_kwargs


@QuantConfigReaderRegistry.register("hf")
class HFQuantConfigReader(QuantConfigReader):
    """
    Quantization reader that process transformers.quantizers.HFQuantizer functionality
    """

    _ALWAYS_EXCLUDE = ("lm_head", "model.embed_tokens")
    _SUPPORTED_QUANT_METHODS = ("mxfp4", "gptq", "fp8")

    def __init__(self):
        super().__init__()
        self._hf_quantizer = None

    def read_config(self, config: Dict) -> Dict:
        # 'config' here is the full HF config.json object
        qconf = config.get("quantization_config")
        if not qconf:
            raise ValueError("HF quantization_config not found.")

        # Inject default exclusion, add "model.embed_tokens" for "tie_word_embedding:true" case
        excludes = qconf.get("exclude_modules", [])
        qconf["exclude_modules"] = excludes + [n for n in self._ALWAYS_EXCLUDE if n not in excludes]

        self._quant_config = qconf
        from transformers.quantizers import AutoHfQuantizer

        try:
            self._hf_quantizer = AutoHfQuantizer.from_config(qconf, pre_quantized=True)
        except Exception:
            self._hf_quantizer = None

        return {}

    @classmethod
    def from_file(cls, ckpt_dir: str) -> Optional[Tuple["HFQuantConfigReader", Dict[str, Any]]]:
        config_file = os.path.join(ckpt_dir, "config.json")
        if not os.path.exists(config_file):
            return None
        with open(config_file, "r") as f:
            raw = json.load(f)
        qconf = raw.get("quantization_config")
        if not isinstance(qconf, dict):
            return None

        # TODO(Fridah-nv):this class is only verified with GPT-OSS MXFP4 and INT4-GPTQ, other hf quantizers
        # should have similar workflow and will be added to the pipeline
        quant_method = str(qconf.get("quant_method", "")).lower()
        if quant_method not in cls._SUPPORTED_QUANT_METHODS:
            return None

        # Validate GPTQ config: currently only INT4 with group_size=128 is supported
        if quant_method == "gptq":
            bits = qconf.get("bits")
            group_size = qconf.get("group_size")
            if bits != 4:
                raise ValueError(f"GPTQ quantization only supports bits=4, got bits={bits}")
            if group_size != 128:
                raise ValueError(
                    f"GPTQ quantization only supports group_size=128, got group_size={group_size}"
                )

        reader = cls()
        extra_model_kwargs = reader.read_config(raw)
        return reader, extra_model_kwargs

    # Apply dtype using HF quantizer, this is needed for GPT-OSS MXFP4 integration into AD pipeline,
    # more features to be added
    def post_process_model(self, model, model_config):
        if self._hf_quantizer is None:
            return model
        dtype = getattr(model_config, "dtype", None)
        new_dtype = self._hf_quantizer.update_dtype(dtype)
        if new_dtype is None:
            return model
        model.to(new_dtype)
        return model


def autodetect_quant_config_reader(
    fetched_dir: str,
) -> Optional[Tuple["QuantConfigReader", Dict[str, Any]]]:
    """Try ModelOPT first; if not found, fall back to HF. Returns (reader, extra_kwargs) or None."""
    reader_cls = QuantConfigReaderRegistry.get("modelopt")
    result = reader_cls.from_file(fetched_dir)
    # Fallback to HF reader if ModelOPT not present
    if result is None:
        hf_cls = QuantConfigReaderRegistry.get("hf")
        try:
            result = hf_cls.from_file(fetched_dir)
        except Exception:
            # Skip HF reader if it errors out during probing
            result = None
    return result
