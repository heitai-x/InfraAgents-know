# SPDX-FileCopyrightText: Copyright (c) 2022-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import List, Optional

import torch
import triton
import triton.language as tl

from tensorrt_llm._torch.auto_deploy.utils.quantization_utils import (
    cutlass_fp4_scale_to_modelopt_fp4_scale,
    unpack_uint8_to_int4_weight_2d,
)
from tensorrt_llm.quantization.utils.fp8_matrix_weight_dequant import (
    dequant_fp8_weight_two_dim_block_grid,
)

# FP4 tables (E2M1)
e2m1_bounds = torch.tensor([0.25, 0.75, 1.25, 1.75, 2.5, 3.5, 5])
e2m1_values = torch.tensor([0, 0.5, 1, 1.5, 2, 3, 4, 6, 0, -0.5, -1, -1.5, -2, -3, -4, -6])


# ===== Helpers =====
def _expect_single_scale(scales: List[Optional[torch.Tensor]], name: str) -> torch.Tensor:
    if len(scales) == 0 or scales[0] is None:
        raise ValueError(f"{name} must provide at least one scale tensor (scales[0]).")
    return scales[0]


def _to_fp8_fake(x: torch.Tensor, scale: torch.Tensor) -> torch.Tensor:
    return (x / scale).to(torch.float8_e4m3fn)


def _from_fp8(x_fp8: torch.Tensor, scale: torch.Tensor, dtype: torch.dtype) -> torch.Tensor:
    return x_fp8.to(dtype) * scale


def _dequant_weight_fp8(
    weight_fp8: torch.Tensor,
    weight_scale: torch.Tensor,
    out_features: int,
    dtype: torch.dtype,
) -> torch.Tensor:
    return weight_fp8.to(dtype) * weight_scale


# The NVFP4 helpers below are adapted from modelopt.torch.quantization.qtensor.nvfp4_tensor.NVFP4QTensor
def _nvfp4_get_weights_scaling_factor(
    input: torch.Tensor,
    block_size: int,
    weights_scaling_factor_2: torch.Tensor | None = None,
    keep_high_precision: bool = False,
):
    """Returns quantized per block weight scaling factor."""
    if weights_scaling_factor_2 is None:
        # per-tensor scale-2 = amax / (6 * 448)
        weights_scaling_factor_2 = input.abs().amax().float() / (6.0 * 448.0)

    # Get per_block amax
    [n, k] = input.shape[-2:]
    assert block_size != 0, "Block size is zero. Cannot return per_block amax for given input."

    assert k % block_size == 0, (
        "Weight shape is not divisible for block size for block quantization."
    )

    input = input.reshape((*tuple(input.shape[:-2]), n, k // block_size, block_size))
    # Get per block amax
    per_block_amax = input.abs().amax(dim=-1).float()
    # Get per-block-scale
    per_block_scale = per_block_amax / 6.0
    # Quantize per_block_scale to FP8
    q_per_block_scale = per_block_scale / weights_scaling_factor_2
    # Set all zero values in scale to 1.0
    q_per_block_scale[per_block_scale == 0] = 1.0
    # Convert to torch.float8_e4m3fn
    if not keep_high_precision:
        q_per_block_scale = q_per_block_scale.to(torch.float8_e4m3fn)
    return q_per_block_scale, weights_scaling_factor_2


def _cast_fp4(weight: torch.Tensor):
    """Converts tensor to uint4."""
    # Get device
    device = weight.device

    # Define mask to perform rounding
    mask = torch.tensor([0, 1, 0, 1, 0, 1, 0], dtype=torch.uint8).to(device)
    mask_shape = list(weight.shape)
    mask = mask.expand([*mask_shape, 7])

    sign_bit = (weight < 0).to(torch.uint8)

    weight_abs = weight.abs()  # avoid in-place modification to input
    # Calculate the ordinal value based on the bounds
    ord = torch.searchsorted(e2m1_bounds.to(device), weight_abs, out_int32=True).to(torch.uint8)
    # All values equal to e2m1_bounds at odd indices are rounded up and even indices are rounded down
    round = torch.any((weight_abs.unsqueeze(-1) == e2m1_bounds.to(device)) * mask, dim=-1)
    fp4_val = (sign_bit * 0b1000 + ord + round).to(torch.uint8)
    return fp4_val


def _quantize_nvfp4(
    input: torch.Tensor,
    block_size: int,
    weights_scaling_factor_2: torch.Tensor | None = None,
):
    """Converting a tensor to a quantized format based on NVFP4 quantization.

    Args:
        input (torch.Tensor): The input tensor to be quantized.
        block_size (int): The size of each block for quantization.
        weights_scaling_factor_2 (torch.Tensor): The per-tensor scaling factor for the weights.
    Returns:
    tuple: Contains quantized data and quantized per block scaling factor
    """

    weights_scaling_factor, weights_scaling_factor_2 = _nvfp4_get_weights_scaling_factor(
        input, block_size, weights_scaling_factor_2
    )

    # Reshape the weight and scale factors
    input = input.view((*tuple(input.shape[:-1]), -1, block_size))

    # Scale weights
    scaled_weight = input / (
        (weights_scaling_factor.to(torch.float32) * weights_scaling_factor_2).unsqueeze(-1)
    )

    # Reshape weights to original
    scaled_weight = scaled_weight.view((*tuple(scaled_weight.shape[:-2]), -1))

    # Cast weights to fp4
    q_weight = _cast_fp4(scaled_weight)
    # Pack weights
    packed_weight = (q_weight[..., 1::2] << 4) | q_weight[..., 0::2]
    return packed_weight, weights_scaling_factor


def _dequantize_nvfp4(
    quantized_t: torch.Tensor,  # [N, K/2] uint8
    scale_1: torch.Tensor,  # q_per_block_scale (FP8/FP32), flat or shaped
    scale_2: torch.Tensor,  # per-tensor scale-2 (FP32 scalar)
    orig_shape: tuple,  # (N, K)
    orig_dtype: torch.dtype,
) -> torch.Tensor:
    device = quantized_t.device
    N, K = orig_shape
    # slice/pad handling for the scale vector: take exactly N*K/16 entries
    num_blocks = N * (K // 16)
    s1 = scale_1.reshape(-1)[:num_blocks]

    high = (quantized_t >> 4) & 0x0F
    low = quantized_t & 0x0F
    idx = torch.empty(N, (K // 2) * 2, dtype=torch.long, device=device)
    idx[..., 0::2] = low.long()
    idx[..., 1::2] = high.long()

    vals = e2m1_values.to(device)[idx]  # [N, K], float32

    scale_real = (s1.to(torch.float32) * scale_2.to(torch.float32)).view(N, K // 16, 1)
    vals = vals.view(N, K // 16, 16) * scale_real
    return vals.view(N, K).to(orig_dtype)


@torch.library.custom_op("auto_deploy::torch_fake_quant_fp8_linear", mutates_args=())
def torch_fake_quant_fp8_linear(
    input: torch.Tensor,
    weight_quantized: torch.Tensor,
    bias: torch.Tensor,
    input_scale: List[torch.Tensor],
    weight_scale: List[torch.Tensor],
    input_zp: List[torch.Tensor],
    weight_zp: List[torch.Tensor],
    tp_mode: str = "none",
    output_sizes: Optional[List[int]] = None,
    tp_min_local_shape: int = 1,
    layer_type: str = "unknown",
) -> torch.Tensor:
    """
    Reference (eager) implementation for multiple quant formats via `format_type`.
    For FP8:
      - input_scale[0] and weight_scale[0] are required (amax/448 style)
      - input_zp / weight_zp ignored
    """
    if weight_quantized.dtype != torch.float8_e4m3fn:
        raise TypeError("FP8 path requires weight_quantized.dtype == torch.float8_e4m3fn")
    s_in = _expect_single_scale(input_scale, "input_scale")
    s_w = _expect_single_scale(weight_scale, "weight_scale")

    in_dtype = input.dtype
    out_features, in_features = weight_quantized.shape

    input_fp8 = _to_fp8_fake(input, s_in)
    input_deq = _from_fp8(input_fp8, s_in, in_dtype)

    weight_deq = _dequant_weight_fp8(weight_quantized, s_w, out_features, in_dtype)

    out = torch.matmul(input_deq.reshape(-1, in_features), weight_deq.t())
    if bias is not None:
        out = out + bias
    return out.reshape(*input.shape[:-1], out_features)


@torch_fake_quant_fp8_linear.register_fake
def torch_fake_quant_fp8_linear(
    input: torch.Tensor,
    weight_quantized: torch.Tensor,
    bias: torch.Tensor,
    input_scale: List[torch.Tensor],
    weight_scale: List[torch.Tensor],
    input_zp: List[torch.Tensor],
    weight_zp: List[torch.Tensor],
    tp_mode: str = "none",
    output_sizes: Optional[List[int]] = None,
    tp_min_local_shape: int = 1,
    layer_type: str = "unknown",
) -> torch.Tensor:
    w = weight_quantized.to(input.dtype)
    return torch.ops.aten.linear(input, w, bias)


@torch.library.custom_op("auto_deploy::torch_fake_quant_nvfp4_linear", mutates_args=())
def torch_fake_quant_nvfp4_linear(
    input: torch.Tensor,
    weight_quantized: torch.Tensor,
    bias: torch.Tensor,
    input_scale: List[torch.Tensor],
    weight_scale: List[torch.Tensor],
    input_zp: List[torch.Tensor],
    weight_zp: List[torch.Tensor],
    tp_mode: str = "none",
    output_sizes: Optional[List[int]] = None,
    tp_min_local_shape: int = 1,
    layer_type: str = "unknown",
) -> torch.Tensor:
    """
    Reference (eager) implementation for multiple quant formats via `format_type`.
    For FP4:
      - input_scale[0]  = s_in2   (scalar, amax/(448*6))
      - weight_scale[0] = q_per_block_scale_w  (len >= N*K/16; may be padded)
      - weight_scale[1] = alpha = s_in2 * s_w2 (combined per-tensor scales)
    """
    if weight_quantized.dtype != torch.uint8:
        raise TypeError("NVFP4 path requires packed uint8 weights (2x FP4 per byte).")

    inv_x = _expect_single_scale(input_scale, "input_scale")
    if len(weight_scale) < 2 or weight_scale[0] is None or weight_scale[1] is None:
        raise ValueError(
            "NVFP4 needs weight_scale[0] (per-block vector) and weight_scale[1] (alpha)."
        )
    cutlass_qscale = weight_scale[0]
    alpha = weight_scale[1]

    if cutlass_qscale.dtype != torch.uint8:
        raise TypeError("NVFP4 expects CUTLASS per-block scale vector in uint8 (same as fused op).")

    inv_w = 1 / (inv_x * alpha)
    s2_x = 1.0 / inv_x
    s2_w = 1.0 / inv_w

    # Shapes
    in_dtype = input.dtype
    input_shape = input.shape
    N, K_packed = weight_quantized.shape[-2], weight_quantized.shape[-1]
    K = K_packed * 2
    assert K % 16 == 0, "NVFP4 requires K to be a multiple of 16"
    num_blocks_w = N * (K // 16)

    q_scale_w_slice = cutlass_fp4_scale_to_modelopt_fp4_scale(cutlass_qscale, (N, K))
    # (1) Dequantize weights with scale_1 = q_scale_w (sliced), scale_2 = s_w2
    q_scale_w_slice = q_scale_w_slice.reshape(-1)[:num_blocks_w]
    W_deq = _dequantize_nvfp4(weight_quantized, q_scale_w_slice, s2_w, (N, K), in_dtype)  # [N, K]

    # (2) Quantize+dequantize inputs with _quantize_nvfp4/_dequantize_nvfp4
    # Flatten batch for NVFP4 block processing
    X_2d = input.reshape(-1, K)

    X_packed, X_q_scale = _quantize_nvfp4(X_2d, block_size=16, weights_scaling_factor_2=s2_x)
    X_deq = _dequantize_nvfp4(X_packed, X_q_scale, s2_x, (X_2d.shape[0], K), in_dtype)  # [B, K]

    # (3) GEMM + bias (float GEMM with codec error baked in)
    out_2d = torch.matmul(X_deq, W_deq.t())  # [B, N]
    if bias is not None:
        out_2d = out_2d + bias
    return out_2d.reshape(*input_shape[:-1], N)


@torch_fake_quant_nvfp4_linear.register_fake
def torch_fake_quant_nvfp4_linear(
    input: torch.Tensor,
    weight_quantized: torch.Tensor,
    bias: torch.Tensor,
    input_scale: List[torch.Tensor],
    weight_scale: List[torch.Tensor],
    input_zp: List[torch.Tensor],
    weight_zp: List[torch.Tensor],
    tp_mode: str = "none",
    output_sizes: Optional[List[int]] = None,
    tp_min_local_shape: int = 1,
    layer_type: str = "unknown",
) -> torch.Tensor:
    return torch.ops.aten.linear(input, weight_quantized.repeat(1, 2).to(input.dtype), bias)


@torch.library.custom_op("auto_deploy::torch_fake_quant_int4_linear", mutates_args=())
def torch_fake_quant_int4_linear(
    input: torch.Tensor,  # [..., K]
    weight_quantized: torch.Tensor,  # [N//2, K] unit8 (packed)
    bias: Optional[torch.Tensor],  # [N] or None
    input_scale: List[torch.Tensor],  # [ pre_quant_scale ]
    weight_scale: List[torch.Tensor],  # [ weight_scale ]
    input_zp: List[torch.Tensor],
    weight_zp: List[torch.Tensor],
    tp_mode: str = "none",
    output_sizes: Optional[List[int]] = None,
    tp_min_local_shape: int = 1,
    layer_type: str = "unknown",
) -> torch.Tensor:
    BLOCK_SIZE = 128
    # activation pre-scale
    pre_quant_scale = input_scale[0].to(dtype=input.dtype)
    x_scaled = torch.mul(input, pre_quant_scale)

    q_int4 = unpack_uint8_to_int4_weight_2d(weight_quantized, weight_scale[0])  # (N,K), int8
    amax_2d = (weight_scale[0] * 7.0).to(input.dtype)  # (N, K//128)

    scale_blocks = (7.0 / amax_2d).to(torch.float32)  # (N, K//128)
    scale_full = scale_blocks.repeat_interleave(BLOCK_SIZE, dim=1)  # (N,K)

    # Dequantize
    w_deq = (q_int4.to(torch.float32) / scale_full).to(input.dtype)

    return torch.ops.auto_deploy.torch_linear_simple.default(
        x_scaled,
        w_deq,
        bias,
        tp_mode=tp_mode,
        output_sizes=output_sizes,
        tp_min_local_shape=tp_min_local_shape,
        layer_type=layer_type,
    )


@torch_fake_quant_int4_linear.register_fake
def _fake(
    input: torch.Tensor,
    weight_quantized: torch.Tensor,
    bias: Optional[torch.Tensor],
    input_scale: List[torch.Tensor],
    weight_scale: List[torch.Tensor],
    input_zp: List[torch.Tensor],
    weight_zp: List[torch.Tensor],
    tp_mode: str = "none",
    output_sizes: Optional[List[int]] = None,
    tp_min_local_shape: int = 1,
    layer_type: str = "unknown",
) -> torch.Tensor:
    N_half = weight_quantized.shape[-2]
    N = N_half * 2
    return torch.empty((*input.shape[:-1], N), dtype=input.dtype, device=input.device)


@torch.library.custom_op("auto_deploy::torch_fake_quant_int4_gptq_linear", mutates_args=())
def torch_fake_quant_int4_gptq_linear(
    input: torch.Tensor,  # [..., K]
    weight_quantized: torch.Tensor,  # qweight [K/8, N] int32 (packed)
    bias: Optional[torch.Tensor],  # [N] or None
    input_scale: List[torch.Tensor],  # unused for GPTQ
    weight_scale: List[torch.Tensor],  # GPTQ scales [G, N]
    input_zp: List[torch.Tensor],  # unused for GPTQ
    weight_zp: List[torch.Tensor],  # GPTQ qzeros [G, N/8] int32
    tp_mode: str = "none",
    output_sizes: Optional[List[int]] = None,
    tp_min_local_shape: int = 1,
    layer_type: str = "unknown",
) -> torch.Tensor:
    """
    GPTQ INT4 linear with compatible signature to other quant ops.
    - weight_quantized: qweight [K/8, N] packed int32
    - weight_scale[0]: scales [G, N]
    - weight_zp[0]: qzeros [G, N/8] packed int32
    """
    PACK_FACTOR = 8
    MAXQ = 15
    dequant_dtype = torch.int8

    qweight = weight_quantized
    scales = _expect_single_scale(weight_scale, "weight_scale")
    qzeros = _expect_single_scale(weight_zp, "weight_zp")

    dev = qweight.device
    input_shape = input.shape
    in_features = input_shape[-1]

    if qweight.dim() != 2:
        raise RuntimeError("qweight must be 2D [K/8, N]")
    K = qweight.size(0) * PACK_FACTOR
    N = qweight.size(1)

    if scales.dim() != 2 or scales.size(1) != N:
        raise RuntimeError(f"scales must be [G, N={N}]")
    G = scales.size(0)

    if K % G != 0:
        raise RuntimeError(f"K ({K}) must be divisible by G ({G})")
    block_size = K // G

    if qzeros.dim() != 2 or qzeros.size(0) != G or qzeros.size(1) * PACK_FACTOR != N:
        raise RuntimeError(f"qzeros must be [G={G}, N/8={N // 8}]")

    # Reshape input to 2D if needed
    x_2d = input.reshape(-1, in_features)

    # Build g_idx and shift tables
    g_idx = torch.arange(K, device=dev, dtype=torch.int32) // block_size  # [K]
    wf = torch.arange(PACK_FACTOR, device=dev, dtype=torch.int32) * 4  # [8]
    wf_unsqueeze_zero = wf.view(1, 1, PACK_FACTOR)  # [1,1,8]
    wf_unsqueeze_neg_one = wf.view(1, PACK_FACTOR, 1)  # [1,8,1]

    zeros = torch.bitwise_right_shift(
        torch.unsqueeze(qzeros, 2).expand(-1, -1, PACK_FACTOR),
        wf_unsqueeze_zero,
    ).to(dequant_dtype)
    zeros = torch.bitwise_and(zeros, MAXQ).reshape(scales.shape)

    weight = torch.bitwise_and(
        torch.bitwise_right_shift(
            torch.unsqueeze(qweight, 1).expand(-1, PACK_FACTOR, -1),
            wf_unsqueeze_neg_one,
        ).to(dequant_dtype),
        MAXQ,
    )
    weight = weight.reshape(weight.shape[0] * weight.shape[1], weight.shape[2])

    weights = (scales[g_idx.long()] * (weight - zeros[g_idx.long()])).to(input.dtype)

    out = torch.matmul(x_2d, weights)

    if bias is not None:
        out = out + bias

    # Reshape output back to match input batch dimensions
    out = out.reshape(*input_shape[:-1], N)

    return out


@torch_fake_quant_int4_gptq_linear.register_fake
def torch_fake_quant_int4_gptq_linear_fake(
    input: torch.Tensor,
    weight_quantized: torch.Tensor,
    bias: Optional[torch.Tensor],
    input_scale: List[torch.Tensor],
    weight_scale: List[torch.Tensor],
    input_zp: List[torch.Tensor],
    weight_zp: List[torch.Tensor],
    tp_mode: str = "none",
    output_sizes: Optional[List[int]] = None,
    tp_min_local_shape: int = 1,
    layer_type: str = "unknown",
) -> torch.Tensor:
    N = weight_quantized.size(1)
    return torch.empty((*input.shape[:-1], N), dtype=input.dtype, device=input.device)


@triton.jit
def _act_quant_kernel(x_ptr, y_ptr, s_ptr, BLOCK_SIZE: tl.constexpr):
    """Block-wise FP8 activation quantization, safe for all-zero blocks.

    Identical to HuggingFace's act_quant_kernel except that the per-block scale
    is clamped to a minimum of 1e-12 before dividing.  This avoids 0/0 = NaN
    when every element in a block is zero.
    """
    pid = tl.program_id(axis=0)
    offs = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    x = tl.load(x_ptr + offs).to(tl.float32)
    s = tl.max(tl.abs(x)) / 448.0
    # Clamp scale so that all-zero blocks produce 0/eps = 0 instead of 0/0 = NaN.
    s = tl.maximum(s, 1e-12)
    y = x / s
    y = y.to(y_ptr.dtype.element_ty)
    tl.store(y_ptr + offs, y)
    tl.store(s_ptr + pid, s)


def _safe_act_quant(x: torch.Tensor, block_size: int = 128) -> tuple:
    """Block-wise FP8 activation quantization (CUDA-graph safe).

    Drop-in replacement for ``transformers.integrations.finegrained_fp8.act_quant``
    that fixes the NaN-on-zero-block bug by clamping the per-block scale inside
    the Triton kernel itself.  No post-hoc fixup tensors are created, so the
    op is fully compatible with CUDA graphs.
    """
    assert x.is_contiguous()
    assert x.shape[-1] % block_size == 0
    y = torch.empty_like(x, dtype=torch.float8_e4m3fn)
    # Keep scale metadata in the model dtype to avoid FP32->BF16 cast kernels
    # when the tensor is consumed by downstream MoE/quantized paths.
    s = x.new_empty(*x.shape[:-1], x.shape[-1] // block_size, dtype=x.dtype)

    grid = lambda meta: (triton.cdiv(x.numel(), meta["BLOCK_SIZE"]),)  # noqa: E731
    _act_quant_kernel[grid](x, y, s, BLOCK_SIZE=block_size)
    return y, s


def _dequant_block_fp8_weight(weight_fp8, weight_scale, block_n, block_k, dtype=torch.bfloat16):
    """Dequantize block-scaled FP8 weight to BF16 for tiny projections."""
    return dequant_fp8_weight_two_dim_block_grid(
        weight_fp8, weight_scale, block_n, block_k, dtype=dtype
    )


@torch.library.custom_op("auto_deploy::torch_fake_quant_finegrained_fp8_linear", mutates_args=())
def torch_fake_quant_finegrained_fp8_linear(
    input: torch.Tensor,  # [..., K]
    weight_quantized: torch.Tensor,  # [N, K] float8_e4m3fn
    bias: Optional[torch.Tensor],  # [N] or None
    input_scale: List[torch.Tensor],  # unused for FineGrained FP8 (input quantized on the fly)
    weight_scale: List[torch.Tensor],  # [weight_scale_inv]
    input_zp: List[torch.Tensor],  # unused
    weight_zp: List[torch.Tensor],  # unused
    tp_mode: str = "none",
    output_sizes: Optional[List[int]] = None,
    tp_min_local_shape: int = 1,
    layer_type: str = "unknown",
) -> torch.Tensor:
    """FineGrainedFP8 linear operation.
    - weight_scale[0] = weight_scale_inv (per-block weight scale)
    - input_scale, input_zp, weight_zp are unused
    - block_size is inferred from weight and weight_scale_inv shapes
    """
    from transformers.integrations.finegrained_fp8 import w8a8_block_fp8_matmul_triton

    weight_scale_inv = weight_scale[0]

    # Infer block_size from weight and weight_scale_inv shapes
    # weight shape: [N, K], weight_scale_inv shape: [ceil(N/block_n), ceil(K/block_k)]
    N, K = weight_quantized.shape
    scale_n, scale_k = weight_scale_inv.shape
    block_n = triton.cdiv(N, scale_n)
    block_k = triton.cdiv(K, scale_k)
    block_size = [block_n, block_k]

    qinput, scale = _safe_act_quant(input, block_size[1])
    output = w8a8_block_fp8_matmul_triton(
        qinput,
        weight_quantized,
        scale,
        weight_scale_inv,
        block_size,
        output_dtype=input.dtype,
    )

    if bias is not None:
        output = output + bias

    return output.to(dtype=input.dtype)


@torch_fake_quant_finegrained_fp8_linear.register_fake
def _torch_fake_quant_finegrained_fp8_linear_fake(
    input: torch.Tensor,
    weight_quantized: torch.Tensor,
    bias: Optional[torch.Tensor],
    input_scale: List[torch.Tensor],
    weight_scale: List[torch.Tensor],
    input_zp: List[torch.Tensor],
    weight_zp: List[torch.Tensor],
    tp_mode: str = "none",
    output_sizes: Optional[List[int]] = None,
    tp_min_local_shape: int = 1,
    layer_type: str = "unknown",
) -> torch.Tensor:
    """Fake implementation for torch.export tracing."""
    out_features = weight_quantized.shape[0]
    return torch.empty((*input.shape[:-1], out_features), dtype=input.dtype, device=input.device)


@torch.library.custom_op("auto_deploy::trtllm_finegrained_fp8_linear", mutates_args=())
def trtllm_finegrained_fp8_linear(
    input: torch.Tensor,  # [..., K] bfloat16
    weight: torch.Tensor,  # [N, K] float8_e4m3fn
    bias: Optional[torch.Tensor],  # [N] or None
    weight_scale: torch.Tensor,  # [N/128, K/128] per-block weight scale
    tp_mode: str = "none",
    output_sizes: Optional[List[int]] = None,
    tp_min_local_shape: int = 1,
    layer_type: str = "unknown",
) -> torch.Tensor:
    """TRT-LLM optimized FineGrainedFP8 linear operation.

    Uses TRT-LLM's optimized fp8_block_scaling_gemm kernel instead of HF's triton kernel.
    - weight_scale: per-block weight scale with shape [ceil(N/128), ceil(K/128)]
    - Input is dynamically quantized using fp8_quantize_1x128
    - Assumes 128x128 block size (standard for DeepSeek/MiniMax style FP8)
    """
    from tensorrt_llm._utils import get_sm_version

    # Ensure input is bfloat16 for the optimized kernel
    if input.dtype == torch.float8_e4m3fn:
        raise ValueError("trtllm_finegrained_fp8_linear expects bfloat16 input, not FP8")

    # TRT-LLM fp8_block_scaling_gemm requires float32 scales; HF checkpoints may
    # store weight_scale_inv in bfloat16 to save space, so cast here.
    if weight_scale.dtype != torch.float32:
        weight_scale = weight_scale.float()

    # Derive effective block size from weight and scale shapes.
    input_shape = input.shape
    N, K = weight.shape
    scale_n, scale_k = weight_scale.shape
    if scale_n == 0 or scale_k == 0:
        raise ValueError(
            f"trtllm_finegrained_fp8_linear: weight_scale has zero dimension "
            f"(shape={weight_scale.shape}), weight shape={weight.shape}. "
            f"This usually means scale tensor sharding produced an empty tensor."
        )
    # Ceiling division is required because the weight dimension may not be
    # evenly divisible by the number of scale blocks (e.g. after TP sharding).
    block_n = triton.cdiv(N, scale_n)
    block_k = triton.cdiv(K, scale_k)

    # TRT-LLM fp8_block_scaling_gemm requires exact 128x128 blocks.
    # For small layers where a dimension < 128 (e.g. N=64), the derived block
    # size will be < 128.  Fall back to BF16 dequant + cuBLAS.
    if block_n != 128 or block_k != 128:
        # BF16 fallback: the Triton FP8 kernel launches Grid=1x1x1 for tiny N,
        # wasting 99% of SM capacity. Dequantize weight + cuBLAS is faster.
        weight_dequant = _dequant_block_fp8_weight(
            weight, weight_scale, block_n, block_k, dtype=input.dtype
        )
        output = torch.nn.functional.linear(input, weight_dequant, bias)
        return output.reshape(*input_shape[:-1], N) if len(input_shape) > 2 else output

    # Flatten input for GEMM: [..., K] -> [M, K]
    input_2d = input.reshape(-1, input_shape[-1])

    # SM version-specific activation quantization
    if get_sm_version() == 120:
        from tensorrt_llm._torch.modules.linear import per_token_quant_and_transform

        act_fp8, act_sf = per_token_quant_and_transform(input_2d)
    else:
        # Hopper (SM90) and Blackwell (SM100+) share the same path
        act_fp8, act_sf = torch.ops.trtllm.fp8_quantize_1x128(input_2d)
    output = torch.ops.trtllm.fp8_block_scaling_gemm(act_fp8, weight, act_sf, weight_scale)

    if bias is not None:
        output = output + bias

    # Reshape back to original batch dimensions: [M, N] -> [..., N]
    return output.reshape(*input_shape[:-1], weight.shape[0])


@trtllm_finegrained_fp8_linear.register_fake
def _trtllm_finegrained_fp8_linear_fake(
    input: torch.Tensor,
    weight: torch.Tensor,
    bias: Optional[torch.Tensor],
    weight_scale: torch.Tensor,
    tp_mode: str = "none",
    output_sizes: Optional[List[int]] = None,
    tp_min_local_shape: int = 1,
    layer_type: str = "unknown",
) -> torch.Tensor:
    """Fake implementation for torch.export tracing."""
    out_features = weight.shape[0]
    return torch.empty((*input.shape[:-1], out_features), dtype=input.dtype, device=input.device)
