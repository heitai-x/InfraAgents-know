# SPDX-FileCopyrightText: Copyright (c) 2022-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Linear operations.

This module provides linear layer implementations:
- linear: Linear layer operations
- torch_router: MoE router operations
- swiglu: SwiGLU MLP custom operations
- silu_mul: Fused SiLU+Mul activation operation
"""

__all__ = [
    "linear",
    "torch_router",
    "swiglu",
    "silu_mul",
]
