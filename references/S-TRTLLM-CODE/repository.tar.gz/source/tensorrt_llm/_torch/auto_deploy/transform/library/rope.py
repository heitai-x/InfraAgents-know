"""
This transformation defines two main RoPE (Rotary Positional Embedding) pattern matchers used
to identify and replace RoPE subgraphs with a custom op (`torch.ops.auto_deploy.flashinfer_rope`).

Supported RoPE variants:

1. Explicit Cos/Sin Multiplication (HF-style, e.g., LLaMA, Mixtral, Qwen)
   - Input layout: non-interleaved, [B, N, S, D] with unsqueeze_dim=1 and
        [B, S, N, D] with unsqueeze_dim=2, default is [B, N, S, D]
   - Frequencies are provided as separate `cos` and `sin` tensors of shape [B, S, head_dim].
   - Source code:
        def rotate_half(x):
            x1 = x[..., : x.shape[-1] // 2]
            x2 = x[..., x.shape[-1] // 2 :]
            return torch.cat((-x2, x1), dim=-1)

        def apply_rotary_pos_emb(q, k, cos, sin, unsqueeze_dim=1):
            cos = cos.unsqueeze(unsqueeze_dim)
            sin = sin.unsqueeze(unsqueeze_dim)
            q_embed = (q * cos) + (rotate_half(q) * sin)
            k_embed = (k * cos) + (rotate_half(k) * sin)
            return q_embed, k_embed

2. Complex Multiplication (GPTJ/Llama-stack-style, interleaved)
   - Input layout: [B, S, N, D] (interleaved)
   - Frequencies are combined into a single complex-valued tensor `freqs_cis` of shape [B, S, head_dim // 2].
   - Source code:
        def apply_rotary_emb(
            xq: torch.Tensor,
            xk: torch.Tensor,
            freqs_cis: torch.Tensor,  # Expected shape: (B, seq, head_dim//2)
        ) -> Tuple[torch.Tensor, torch.Tensor]:
            xq_ = torch.view_as_complex(xq.float().reshape(*xq.shape[:-1], -1, 2))
            xk_ = torch.view_as_complex(xk.float().reshape(*xk.shape[:-1], -1, 2))
            xq_out = torch.view_as_real(xq_ * freqs_cis[:, :, None, :]).flatten(3)
            xk_out = torch.view_as_real(xk_ * freqs_cis[:, :, None, :]).flatten(3)
            return xq_out.type_as(xq), xk_out.type_as(xk)

Supported Minor variants:
- DeepSeekV3:   reshape + transpose before applying RoPE.
                dynamic position-based updates to frequency cache.

TODO: Support other variants:
- Phi-4: rotary applied only to part of the hidden dimension (q_rot, q_pass split).
- LLaMA4 Vision: 2D rotary frequencies constructed from image patches.
"""

import operator
from collections import defaultdict
from typing import Any, DefaultDict, Dict, Optional, Sequence, Tuple, Type

import torch
from pydantic import Field
from torch.fx import GraphModule, Node

from ...models.factory import ModelFactory
from ...shim.interface import CachedSequenceInterface
from ...utils.node_utils import extract_op_args, extract_output_tuple, is_any_view_op, is_op
from ...utils.pattern_matcher import ADPatternMatcherPass, Match, register_ad_pattern
from ..interface import (
    BaseTransform,
    SharedConfig,
    TransformConfig,
    TransformInfo,
    TransformRegistry,
)


def _rotate_half(x):
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)


def _explicit_rope_pattern(q, k, cos, sin, unsqueeze_dim=1):
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (_rotate_half(q) * sin)
    k_embed = (k * cos) + (_rotate_half(k) * sin)
    return q_embed, k_embed


def _explicit_rope_repl(q, k, cos, sin, unsqueeze_dim):
    return torch.ops.auto_deploy.torch_rope_with_explicit_cos_sin.default(
        q, k, cos, sin, unsqueeze_dim
    )


def _interleaved_rope_pattern(q, k, cos, sin, unsqueeze_dim=1):
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    b, h, s, d = q.shape
    q = q.view(b, h, s, d // 2, 2).transpose(4, 3).reshape(b, h, s, d)
    b, h, s, d = k.shape
    k = k.view(b, h, s, d // 2, 2).transpose(4, 3).reshape(b, h, s, d)
    q_embed = (q * cos) + (_rotate_half(q) * sin)
    k_embed = (k * cos) + (_rotate_half(k) * sin)
    return q_embed, k_embed


def _interleaved_rope_repl(q, k, cos, sin, unsqueeze_dim):
    return torch.ops.auto_deploy.torch_rope_with_qk_interleaving.default(
        q, k, cos, sin, unsqueeze_dim
    )


# exporting with {"unsqueeze_dim": 2},
# would confuse the pattern matcher since '2' is arg of other ops
def _complex_rope_pattern(xq, xk, freqs_cis, unsqueeze_dim=1):
    xq_ = torch.view_as_complex(xq.float().reshape(*xq.shape[:-1], -1, 2))
    xk_ = torch.view_as_complex(xk.float().reshape(*xk.shape[:-1], -1, 2))
    freqs_q = freqs_cis.unsqueeze(unsqueeze_dim)
    freqs_k = freqs_cis.unsqueeze(unsqueeze_dim)
    xq_out = torch.view_as_real(xq_ * freqs_q).flatten(3)
    xk_out = torch.view_as_real(xk_ * freqs_k).flatten(3)
    return xq_out.type_as(xq), xk_out.type_as(xk)


def _complex_rope_repl(q, k, freqs_cis, unsqueeze_dim):
    return torch.ops.auto_deploy.torch_rope_with_complex_freqs.default(
        q, k, freqs_cis, unsqueeze_dim
    )


def _explicit_not_interleaved(match: Match) -> bool:
    q, k = match.kwargs.get("q"), match.kwargs.get("k")
    return not any(isinstance(n, Node) and _match_input_interleave_pattern(n) for n in (q, k))


@TransformRegistry.register("match_rope_pattern")
class MatchRopePattern(BaseTransform):
    def _apply(
        self,
        gm: GraphModule,
        cm: CachedSequenceInterface,
        factory: ModelFactory,
        shared_config: SharedConfig,
    ) -> Tuple[GraphModule, TransformInfo]:
        graph = gm.graph
        patterns = ADPatternMatcherPass()

        # dummy shapes: can be arbitrary
        batch_size = 8
        seq_len = 16
        num_heads = 8
        hidden_size = 512
        head_dim = hidden_size // num_heads

        dummy_explicit = [
            torch.randn(
                batch_size, num_heads, seq_len, head_dim, device="meta", dtype=torch.float16
            ),
            torch.randn(
                batch_size, num_heads, seq_len, head_dim, device="meta", dtype=torch.float16
            ),
            torch.randn(batch_size, seq_len, head_dim, device="meta", dtype=torch.float16),
            torch.randn(batch_size, seq_len, head_dim, device="meta", dtype=torch.float16),
        ]
        dummy_complex = [
            torch.randn(
                batch_size, num_heads, seq_len, head_dim, device="meta", dtype=torch.float16
            ),
            torch.randn(
                batch_size, num_heads, seq_len, head_dim, device="meta", dtype=torch.float16
            ),
            torch.randn(batch_size, seq_len, head_dim // 2, device="meta", dtype=torch.float16),
        ]
        dummy_complex_2 = [
            torch.randn(
                batch_size, num_heads, seq_len, head_dim, device="meta", dtype=torch.float32
            ),
            torch.randn(
                batch_size, num_heads, seq_len, head_dim, device="meta", dtype=torch.float32
            ),
            torch.randn(batch_size, seq_len, head_dim // 2, device="meta", dtype=torch.float32),
        ]
        register_ad_pattern(
            search_fn=_explicit_rope_pattern,
            replace_fn=_explicit_rope_repl,
            patterns=patterns,
            dummy_args=dummy_explicit,
            op_ignore_types={torch.ops.aten.slice.Tensor: (int,)},
            scalar_workaround={"unsqueeze_dim": 1},
            extra_check=_explicit_not_interleaved,
        )
        register_ad_pattern(
            search_fn=_interleaved_rope_pattern,
            replace_fn=_interleaved_rope_repl,
            patterns=patterns,
            dummy_args=dummy_explicit,
            op_ignore_types={
                torch.ops.aten.slice.Tensor: (int,),
                torch.ops.aten.reshape.default: (int,),
                torch.ops.aten.view.default: (int,),
                torch.ops.auto_deploy.view.default: (int,),
            },
            scalar_workaround={"unsqueeze_dim": 1},
        )
        register_ad_pattern(
            search_fn=_complex_rope_pattern,
            replace_fn=_complex_rope_repl,
            patterns=patterns,
            dummy_args=dummy_complex,
            op_ignore_types={
                torch.ops.aten.reshape.default: (int,),
                torch.ops.auto_deploy.view.default: (int,),
            },
            scalar_workaround={"unsqueeze_dim": 1},
        )
        register_ad_pattern(
            search_fn=_complex_rope_pattern,
            replace_fn=_complex_rope_repl,
            patterns=patterns,
            dummy_args=dummy_complex_2,
            op_ignore_types={
                torch.ops.aten.reshape.default: (int,),
                torch.ops.auto_deploy.view.default: (int,),
            },
            scalar_workaround={"unsqueeze_dim": 1},
        )

        num_matches = patterns.apply(graph)

        info = TransformInfo(
            skipped=False,
            num_matches=num_matches,
            is_clean=num_matches == 0,
            has_valid_shapes=num_matches == 0,
        )

        return gm, info


class MatchRopeLayoutConfig(TransformConfig):
    """Configuration for the match rope layout transform."""

    expected_layout: str = Field(
        default="bsnd",
        description="The expected layout of the rope operation. Must be one of 'bsnd' or 'bnsd'.",
    )


@TransformRegistry.register("match_rope_layout")
class MatchRopeLayout(BaseTransform):
    """
    Match and transform input and output of rope ops to the layout specified to meet requirements of optimized ops.
    Supported layout is 'bsnd' (batch, seq, head, dim).
    """

    config: MatchRopeLayoutConfig

    @classmethod
    def get_config_class(cls) -> Type[TransformConfig]:
        return MatchRopeLayoutConfig

    def _apply(
        self,
        gm: GraphModule,
        cm: CachedSequenceInterface,
        factory: ModelFactory,
        shared_config: SharedConfig,
    ) -> Tuple[GraphModule, TransformInfo]:
        supported = {"bsnd", "bnsd"}
        if self.config.expected_layout.lower() not in supported:
            return gm, TransformInfo(
                skipped=True, num_matches=0, is_clean=True, has_valid_shapes=True
            )

        graph = gm.graph
        rope_ops = {
            torch.ops.auto_deploy.torch_rope_with_explicit_cos_sin,
            torch.ops.auto_deploy.torch_rope_with_qk_interleaving,
            torch.ops.auto_deploy.torch_rope_with_complex_freqs,
        }

        need_transpose = False
        num_rope_layout_matches = 0
        for node in graph.nodes:
            if not is_op(node, rope_ops):
                continue

            if is_op(node, torch.ops.auto_deploy.torch_rope_with_complex_freqs):
                q_node, k_node, freqs_node, unsq = extract_op_args(
                    node,
                    "xq",  # argument name in schema
                    "xk",
                    "freqs_cis",
                    "unsqueeze_dim",
                )
            else:
                q_node, k_node, cos_node, sin_node, unsq = extract_op_args(
                    node, "q", "k", "cos", "sin", "unsqueeze_dim"
                )

            if unsq == 2:
                current_layout = "bsnd"
            elif unsq == 1:
                current_layout = "bnsd"
            else:
                continue

            need_transpose = self.config.expected_layout.lower() != current_layout

            if not need_transpose:
                continue

            num_rope_layout_matches += 1
            # retrieve q and k output node from node
            q_rope_old, k_rope_old = extract_output_tuple(node, 2)
            if q_rope_old is None or k_rope_old is None:
                continue

            with graph.inserting_before(node):
                q_for_op = graph.call_function(torch.ops.aten.transpose, args=(q_node, 1, 2))
                k_for_op = graph.call_function(torch.ops.aten.transpose, args=(k_node, 1, 2))
                q_for_op_contig = graph.call_function(torch.ops.aten.contiguous, args=(q_for_op,))
                k_for_op_contig = graph.call_function(torch.ops.aten.contiguous, args=(k_for_op,))

            q_for_op_contig.meta["val"] = q_node.meta["val"].transpose(1, 2)
            k_for_op_contig.meta["val"] = k_node.meta["val"].transpose(1, 2)

            if is_op(node, torch.ops.auto_deploy.torch_rope_with_complex_freqs):
                new_args = (
                    q_for_op_contig,
                    k_for_op_contig,
                    freqs_node,
                    2 if self.config.expected_layout.lower() == "bsnd" else 1,
                )  # unsqueeze_dim updated
            else:
                new_args = (
                    q_for_op_contig,
                    k_for_op_contig,
                    cos_node,
                    sin_node,
                    2 if self.config.expected_layout.lower() == "bsnd" else 1,
                )  # unsqueeze_dim updated
            node.args = new_args

            with graph.inserting_after(q_rope_old):
                q_rope_new = graph.call_function(torch.ops.aten.transpose, args=(q_rope_old, 1, 2))
            with graph.inserting_after(k_rope_old):
                k_rope_new = graph.call_function(torch.ops.aten.transpose, args=(k_rope_old, 1, 2))

            # Preserve fake tensor in meta["val"] for the transposed inputs
            q_rope_new.meta["val"] = q_rope_old.meta["val"]
            q_rope_old.meta["val"] = q_rope_old.meta["val"].transpose(1, 2)
            k_rope_new.meta["val"] = k_rope_old.meta["val"]
            k_rope_old.meta["val"] = k_rope_old.meta["val"].transpose(1, 2)

            q_rope_old.replace_all_uses_with(q_rope_new)
            k_rope_old.replace_all_uses_with(k_rope_new)
            q_rope_new.args = (q_rope_old, 1, 2)
            k_rope_new.args = (k_rope_old, 1, 2)

        info = TransformInfo(
            skipped=False,
            num_matches=num_rope_layout_matches,
            is_clean=num_rope_layout_matches == 0,
            has_valid_shapes=num_rope_layout_matches == 0,
        )

        return gm, info


@TransformRegistry.register("optimize_rope")
class OptimizeRope(BaseTransform):
    """
    Scan the FX graph and replace calls to the torch-reference RoPE ops with
    optimized kernels:
    - ``torch_rope_with_explicit_cos_sin`` → ``flashinfer_rope``
    - ``torch_rope_with_complex_freqs``    → ``flashinfer_rope``
    - ``torch_rope_with_qk_interleaving``  → ``triton_rope_on_interleaved_qk_inputs``

    Precomputes positional IDs and the fused cosine-sine cache as explicit nodes,
    and reuses those nodes when possible.
    """

    def _apply(
        self,
        gm: GraphModule,
        cm: CachedSequenceInterface,
        factory: ModelFactory,
        shared_config: SharedConfig,
    ) -> Tuple[GraphModule, TransformInfo]:
        graph = gm.graph
        rope_flash_cache: DefaultDict[Any, Optional[Node]] = defaultdict(lambda: None)
        rope_position_ids_cache: Dict[str, Node] = {}
        max_seq_len = getattr(factory, "max_seq_len", 0)

        num_rope_optimizations = 0
        for node in list(graph.nodes):
            if is_op(node, torch.ops.auto_deploy.torch_rope_with_explicit_cos_sin):
                _optimize_explicit(
                    graph, node, rope_flash_cache, rope_position_ids_cache, max_seq_len
                )
            elif is_op(node, torch.ops.auto_deploy.torch_rope_with_complex_freqs):
                _optimize_complex(graph, node, rope_flash_cache, rope_position_ids_cache)
            elif is_op(node, torch.ops.auto_deploy.torch_rope_with_qk_interleaving):
                if not _optimize_interleaved(graph, node):
                    continue
            else:
                continue
            num_rope_optimizations += 1

        skipped = num_rope_optimizations == 0
        info = TransformInfo(
            skipped=skipped,
            num_matches=num_rope_optimizations,
            is_clean=skipped,
            has_valid_shapes=True,
        )
        return gm, info


def _trace_to_buffer_source(node: Node) -> Optional[Node]:
    """Trace back through unary call_function nodes to find the source get_attr/placeholder."""
    visited = set()
    current = node
    while id(current) not in visited:
        visited.add(id(current))
        if current.op in ("get_attr", "placeholder"):
            return current
        if (
            current.op == "call_function"
            and len(current.args) > 0
            and isinstance(current.args[0], Node)
        ):
            current = current.args[0]
        else:
            return None
    return None


def _get_nested_attr(module: torch.nn.Module, target: str) -> torch.Tensor:
    """Access a nested module attribute via dotted path (e.g. 'model.rotary_emb._ad_cos_cached')."""
    parts = target.split(".")
    obj = module
    for p in parts:
        obj = getattr(obj, p)
    return obj


def _try_prefuse_cos_sin_cache(
    graph: torch.fx.Graph,
    cos_table_node: Node,
    sin_table_node: Node,
    half_head_dim: int,
) -> Optional[Node]:
    """Try to precompute the fused cos_sin cache as a graph constant.

    First checks if a pre-fused cache (_ad_rope_cos_sin_cache) already exists
    as a sibling buffer of the cos/sin tables.  If found, reuses it directly.
    Otherwise, computes the fused cache from the cos/sin table tensor values.

    Returns a get_attr Node for the fused cache, or None if precomputation
    is not possible (caller should fall back to runtime slice+concat).
    """
    gm = graph.owning_module
    if gm is None:
        return None

    cos_source = _trace_to_buffer_source(cos_table_node)
    sin_source = _trace_to_buffer_source(sin_table_node)

    if cos_source is None or sin_source is None:
        return None

    if cos_source.op != "get_attr" or sin_source.op != "get_attr":
        return None

    try:
        cos_tensor = _get_nested_attr(gm, cos_source.target)
        sin_tensor = _get_nested_attr(gm, sin_source.target)
    except AttributeError:
        return None

    if cos_tensor.is_meta or sin_tensor.is_meta:
        return None

    # Try to reuse an existing pre-fused cache (_ad_rope_cos_sin_cache)
    # that lives as a sibling buffer of the cos/sin tables.
    cos_target = cos_source.target
    parent_path = cos_target.rsplit(".", 1)[0] if "." in cos_target else ""
    prefused_path = (
        f"{parent_path}._ad_rope_cos_sin_cache" if parent_path else "_ad_rope_cos_sin_cache"
    )
    try:
        prefused_tensor = _get_nested_attr(gm, prefused_path)
        if not prefused_tensor.is_meta:
            # Ensure the buffer is float32 (FlashInfer requires float32 cache).
            # model.to(dtype) may have cast it to a lower precision.
            if prefused_tensor.dtype != torch.float32:
                prefused_tensor = prefused_tensor.to(torch.float32)
                # Update the buffer on the module so the get_attr reads float32.
                parts = prefused_path.rsplit(".", 1)
                parent = _get_nested_attr(gm, parts[0]) if len(parts) > 1 else gm
                attr_name = parts[-1]
                parent.register_buffer(attr_name, prefused_tensor, persistent=False)

            # Reuse the existing buffer directly
            with graph.inserting_after(_get_last_node([cos_source, sin_source])):
                fused_node = graph.create_node("get_attr", prefused_path)
            fused_node.meta["val"] = prefused_tensor
            return fused_node
    except AttributeError:
        pass

    # Fallback: compute fused cache from cos/sin tables
    # Format: [cos_0..cos_{d/2-1}, sin_0..sin_{d/2-1}]
    fused = torch.cat([cos_tensor[:, :half_head_dim], sin_tensor[:, :half_head_dim]], dim=-1).to(
        torch.float32
    )

    # Register as a new buffer on the GraphModule with a unique name
    attr_name = "_prefused_rope_cache"
    counter = 0
    while hasattr(gm, attr_name):
        counter += 1
        attr_name = f"_prefused_rope_cache_{counter}"

    gm.register_buffer(attr_name, fused, persistent=False)

    # Create get_attr node
    with graph.inserting_after(_get_last_node([cos_source, sin_source])):
        fused_node = graph.create_node("get_attr", attr_name)
    fused_node.meta["val"] = fused

    return fused_node


def _try_build_cache_from_dynamic_cos_sin(
    graph: torch.fx.Graph,
    cos_table_node: Node,
    sin_table_node: Node,
    half_head_dim: int,
    max_seq_len: int,
) -> Optional[Node]:
    """Build a static fused cos_sin cache from dynamically computed cos/sin tables.

    When cos/sin tables are computed in the forward graph (not stored as buffers),
    traces the computation back to find ``inv_freq`` (a buffer) and an optional
    scale factor, then pre-computes the full ``cos_sin_cache`` and registers it
    as a buffer on the GraphModule.

    Expected graph pattern::

        inv_freq (get_attr) → outer(arange, inv_freq) → cat([freqs, freqs])
            → cos/sin → [optional mul(_, scale)] → cos_table / sin_table

    Returns a ``get_attr`` Node for the fused cache, or ``None`` if the pattern
    is not detected.
    """
    gm = graph.owning_module
    if gm is None:
        return None

    # Step 1: Detect cos/sin pattern.  cos_table_node may be:
    #   (a) aten.cos(emb)                         — no scale
    #   (b) aten.mul(aten.cos(emb), scale_float)  — with scale
    #   (c) aten.to(aten.mul(aten.cos(emb), scale_float), dtype) — with scale + dtype cast
    # Similarly for sin_table_node.

    def _unwrap_cos_sin_table(node: Node) -> Tuple[Optional[Node], float]:
        """Unwrap optional mul/to around aten.cos or aten.sin, returning (trig_node, scale)."""
        scale = 1.0
        current = node
        # Skip dtype casts (aten.to)
        if is_op(current, torch.ops.aten.to.dtype):
            current = current.args[0]
            if not isinstance(current, Node):
                return None, 1.0
        # Check for scale multiplication
        if is_op(current, torch.ops.aten.mul.Tensor) or is_op(current, torch.ops.aten.mul.Scalar):
            lhs, rhs = current.args[0], current.args[1]
            if isinstance(rhs, (int, float)):
                scale = float(rhs)
                current = lhs
            elif isinstance(lhs, (int, float)):
                scale = float(lhs)
                current = rhs
            if not isinstance(current, Node):
                return None, 1.0
        # Now current should be aten.cos or aten.sin
        if is_op(current, torch.ops.aten.cos.default) or is_op(current, torch.ops.aten.sin.default):
            return current, scale
        return None, 1.0

    cos_trig_node, cos_scale = _unwrap_cos_sin_table(cos_table_node)
    sin_trig_node, sin_scale = _unwrap_cos_sin_table(sin_table_node)

    if cos_trig_node is None or sin_trig_node is None:
        return None
    if not is_op(cos_trig_node, torch.ops.aten.cos.default):
        return None
    if not is_op(sin_trig_node, torch.ops.aten.sin.default):
        return None
    if abs(cos_scale - sin_scale) > 1e-6:
        return None  # scale must match

    scale = cos_scale

    # Step 2: The inputs to cos and sin should share a common emb node.
    cos_emb = cos_trig_node.args[0]
    sin_emb = sin_trig_node.args[0]
    if not isinstance(cos_emb, Node) or not isinstance(sin_emb, Node):
        return None
    if cos_emb is not sin_emb:
        return None

    emb_node = cos_emb

    # Step 3: BFS backward from emb_node to find inv_freq (get_attr buffer).
    # Limit search depth to avoid traversing large portions of the graph.
    _MAX_BFS_STEPS = 50
    visited = set()
    queue = [emb_node]
    inv_freq_node = None
    inv_freq_tensor = None

    while queue and len(visited) < _MAX_BFS_STEPS:
        current = queue.pop(0)
        if id(current) in visited:
            continue
        visited.add(id(current))

        if not isinstance(current, Node):
            continue

        if current.op == "get_attr":
            # Check if this is a 1D tensor of size half_head_dim (inv_freq candidate)
            try:
                tensor = _get_nested_attr(gm, current.target)
                if not tensor.is_meta and tensor.dim() == 1 and tensor.shape[0] == half_head_dim:
                    inv_freq_node = current
                    inv_freq_tensor = tensor
                    break
            except AttributeError:
                pass
        elif current.op == "call_function":
            for arg in current.args:
                if isinstance(arg, Node):
                    queue.append(arg)
                elif isinstance(arg, (list, tuple)):
                    for item in arg:
                        if isinstance(item, Node):
                            queue.append(item)

    if inv_freq_node is None or inv_freq_tensor is None:
        return None

    # Step 4: Pre-compute the full cos_sin_cache from inv_freq.
    # Format: [cos_0..cos_{d/2-1}, sin_0..sin_{d/2-1}] in float32
    t = torch.arange(max_seq_len, dtype=inv_freq_tensor.dtype, device=inv_freq_tensor.device)
    freqs = torch.outer(t, inv_freq_tensor)  # [max_seq_len, half_head_dim]
    fused = torch.cat([freqs.cos() * scale, freqs.sin() * scale], dim=-1).to(torch.float32)

    # Register as a new buffer on the GraphModule with a unique name
    attr_name = "_prefused_rope_cache"
    counter = 0
    while hasattr(gm, attr_name):
        counter += 1
        attr_name = f"_prefused_rope_cache_{counter}"

    gm.register_buffer(attr_name, fused, persistent=False)

    # Create get_attr node.  Store the real tensor in meta["val"] so that
    # downstream passes (e.g. move_to_device) can .to(device) it directly.
    with graph.inserting_after(cos_table_node):
        fused_node = graph.create_node("get_attr", attr_name)
    fused_node.meta["val"] = fused

    return fused_node


def _build_fused_cos_sin_cache(
    graph: torch.fx.Graph,
    cos_src: Node,
    sin_src: Node,
    half_head_dim: int,
    reshape_to_2d: Optional[Node] = None,
) -> Node:
    """Slice cos/sin to half_head_dim, concat, and cast to float32.

    If *reshape_to_2d* is provided (a node representing B*S), the fused
    tensor is reshaped to ``[B*S, head_dim]`` before the dtype cast.
    """
    with graph.inserting_after(cos_src):
        cos_prefix = graph.call_function(torch.ops.aten.slice, args=(cos_src, -1, 0, half_head_dim))
    with graph.inserting_after(sin_src):
        sin_prefix = graph.call_function(torch.ops.aten.slice, args=(sin_src, -1, 0, half_head_dim))
    with graph.inserting_after(_get_last_node([cos_prefix, sin_prefix])):
        fused = graph.call_function(torch.ops.aten.cat, args=((cos_prefix, sin_prefix), -1))
    if reshape_to_2d is not None:
        with graph.inserting_after(_get_last_node([reshape_to_2d, fused])):
            fused = graph.call_function(torch.ops.aten.view, args=(fused, (reshape_to_2d, -1)))
    with graph.inserting_after(fused):
        fused_to = graph.call_function(torch.ops.aten.to, args=(fused, torch.float32))
    return fused_to


def _optimize_explicit(
    graph: GraphModule,
    node: Node,
    cache: Dict[Any, Node],
    pos_cache: Dict[str, Node],
    max_seq_len: int = 0,
) -> None:
    # node.args may be (q, k, cos, sin) or (q, k, cos, sin, unsq)
    q_node, k_node, cos_node, sin_node, *rest = node.args
    # retrieve q and k output node from node
    q_rope_old, k_rope_old = extract_output_tuple(node, 2)
    if q_rope_old is None or k_rope_old is None:
        return

    # Sanity check on head_dim
    if not _validate_rope_inputs(q_node, k_node):
        return

    # Sanity check that input layout is BSND (no transpose needed).
    q_fake = q_node.meta.get("val", None)
    if q_fake is not None and len(q_fake.shape) > 2:
        if not (isinstance(q_fake.shape[1], torch.SymInt) and isinstance(q_fake.shape[2], int)):
            return
    elif q_fake is not None:
        return

    head_dim = cos_node.meta["val"].shape[-1]
    half_head_dim = head_dim // 2

    # Try trace-back to find full cos/sin tables and real position_ids.
    # When cos/sin are produced by aten.index.Tensor(table, [position_ids]),
    # we can build the fused cache from the full table once and pass the real
    # position_ids to flashinfer, eliminating per-forward index/slice/cat ops.
    cos_traced = _trace_back_index(cos_node)
    sin_traced = _trace_back_index(sin_node)

    use_full_table = False
    if cos_traced is not None and sin_traced is not None:
        cos_table_node, cos_pos_ids = cos_traced
        sin_table_node, sin_pos_ids = sin_traced
        if cos_pos_ids is sin_pos_ids:
            use_full_table = True

    if use_full_table:
        # Full-table path: build fused cache from the original 2-D tables
        # (shared across all layers that index the same table).
        cache_key = (cos_table_node, sin_table_node)
        if cache_key in cache:
            fused_cos_sin_to = cache[cache_key]
        else:
            # Try to precompute the fused cache as a graph constant
            prefused_node = _try_prefuse_cos_sin_cache(
                graph, cos_table_node, sin_table_node, half_head_dim
            )
            if prefused_node is not None:
                fused_cos_sin_to = prefused_node
            else:
                # Try to trace dynamic cos/sin computation back to inv_freq
                dynamic_node = None
                if max_seq_len > 0:
                    dynamic_node = _try_build_cache_from_dynamic_cos_sin(
                        graph,
                        cos_table_node,
                        sin_table_node,
                        half_head_dim,
                        max_seq_len,
                    )
                if dynamic_node is not None:
                    fused_cos_sin_to = dynamic_node
                else:
                    # Fallback: build fused cache at runtime (slice + concat)
                    fused_cos_sin_to = _build_fused_cos_sin_cache(
                        graph, cos_table_node, sin_table_node, half_head_dim
                    )
            cache[cache_key] = fused_cos_sin_to

        # Flatten real position_ids from [B, S] to [B*S] and ensure int32
        # (FlashInfer requires int; converting once here avoids a per-layer
        # dtype cast inside the opaque custom op).
        if "full_table_position_ids" in pos_cache:
            position_ids = pos_cache["full_table_position_ids"]
        else:
            with graph.inserting_before(node):
                flat_pos_ids = graph.call_function(
                    torch.ops.aten.reshape, args=(cos_pos_ids, (-1,))
                )
                position_ids = graph.call_function(
                    torch.ops.aten.to, args=(flat_pos_ids, torch.int32)
                )
            pos_cache["full_table_position_ids"] = position_ids
    else:
        # Fallback: build fused cache from already-indexed cos/sin values.
        cache_key = (cos_node, sin_node)
        if cache_key in cache:
            fused_cos_sin_to = cache[cache_key]
        else:
            with graph.inserting_after(q_node):
                sym_batch = graph.call_function(torch.ops.aten.sym_size.int, args=(q_node, 0))
                sym_seq = graph.call_function(torch.ops.aten.sym_size.int, args=(q_node, 1))
            with graph.inserting_after(_get_last_node([sym_batch, sym_seq])):
                bs_seq = graph.call_function(operator.mul, args=(sym_batch, sym_seq))
            fused_cos_sin_to = _build_fused_cos_sin_cache(
                graph, cos_node, sin_node, half_head_dim, reshape_to_2d=bs_seq
            )
            cache[cache_key] = fused_cos_sin_to

        with graph.inserting_before(node):
            position_ids = _get_position_ids(
                graph,
                q_node,
                batch_dim=0,
                seq_dim=1,
                rope_position_ids_cache=pos_cache,
            )

    with graph.inserting_before(node):
        flash_node = graph.call_function(
            torch.ops.auto_deploy.flashinfer_rope,
            args=(q_node, k_node, position_ids, fused_cos_sin_to, True),
        )

    with graph.inserting_after(flash_node):
        q_rope_new = graph.call_function(operator.getitem, args=(flash_node, 0))
        k_rope_new = graph.call_function(operator.getitem, args=(flash_node, 1))

    q_rope_new.meta["val"] = q_rope_old.meta.get("val", None)
    k_rope_new.meta["val"] = k_rope_old.meta.get("val", None)

    q_rope_old.replace_all_uses_with(q_rope_new)
    k_rope_old.replace_all_uses_with(k_rope_new)

    graph.erase_node(q_rope_old)
    graph.erase_node(k_rope_old)


def _optimize_complex(
    graph: GraphModule, node: Node, cache: Dict[Any, Node], pos_cache: Dict[str, Node]
) -> None:
    # q_node, k_node, inv_freq_node = node.args
    q_node, k_node, inv_freq_node = extract_op_args(
        node,
        "xq",  # argument name in schema
        "xk",
        "freqs_cis",
    )

    # Sanity check on head_dim
    if not _validate_rope_inputs(q_node, k_node):
        return

    # Sanity check that input layout is BSND (no transpose needed).
    q_fake = q_node.meta.get("val", None)
    if q_fake is not None and len(q_fake.shape) > 2:
        if not (isinstance(q_fake.shape[1], torch.SymInt) and isinstance(q_fake.shape[2], int)):
            return
    elif q_fake is not None:
        return

    # Retrieve or register the lookup table for inv_freq_node -> cos_sin_flash
    if inv_freq_node in cache:
        cos_sin_flash = cache[inv_freq_node]
    else:
        # Compute the fused cosine/sine cache.
        with graph.inserting_after(inv_freq_node):
            real_part = graph.call_function(torch.ops.aten.real, args=(inv_freq_node,))
            imag_part = graph.call_function(torch.ops.aten.imag, args=(inv_freq_node,))
        with graph.inserting_after(real_part):
            cos_sin_flash_3d = graph.call_function(
                torch.ops.aten.cat, args=((real_part, imag_part), -1)
            )
        with graph.inserting_after(q_node):
            sym_batch = graph.call_function(torch.ops.aten.sym_size.int, args=(q_node, 0))
            sym_seq = graph.call_function(torch.ops.aten.sym_size.int, args=(q_node, 1))
        with graph.inserting_after(_get_last_node([sym_batch, sym_seq])):
            bs_seq = graph.call_function(operator.mul, args=(sym_batch, sym_seq))
        with graph.inserting_after(_get_last_node([bs_seq, cos_sin_flash_3d])):
            fused_cos_sin_flat = graph.call_function(
                torch.ops.aten.view, args=(cos_sin_flash_3d, (bs_seq, -1))
            )
        with graph.inserting_after(fused_cos_sin_flat):
            cos_sin_flash = graph.call_function(
                torch.ops.aten.to, args=(fused_cos_sin_flat, torch.float32)
            )
        cache[inv_freq_node] = cos_sin_flash

    with graph.inserting_before(node):
        position_ids = _get_position_ids(
            graph, q_node, batch_dim=0, seq_dim=1, rope_position_ids_cache=pos_cache
        )
        flash_node = graph.call_function(
            torch.ops.auto_deploy.flashinfer_rope,
            args=(q_node, k_node, position_ids, cos_sin_flash, False),
        )

    flash_node.meta["val"] = node.meta.get("val", None)
    node.replace_all_uses_with(flash_node)
    graph.erase_node(node)


def _trace_back_index(node: Node) -> Optional[Tuple[Node, Node]]:
    """Trace back from a node to find an aten.index.Tensor producer.

    If ``node`` was produced by ``aten.index.Tensor(cache, [position_ids])``,
    return ``(cache_node, position_ids_node)``.  Otherwise return ``None``.
    """
    if not is_op(node, torch.ops.aten.index.Tensor):
        return None
    cache_node = node.args[0]
    indices = node.args[1]
    if not isinstance(indices, (list, tuple)) or len(indices) != 1:
        return None
    position_ids_node = indices[0]
    if not isinstance(cache_node, Node) or not isinstance(position_ids_node, Node):
        return None
    return cache_node, position_ids_node


def _validate_interleaved_rope_inputs(q_node: Node, k_node: Node) -> bool:
    """Validate q/k inputs for the interleaved triton RoPE kernel.

    Relaxed compared to ``_validate_rope_inputs``: requires even head_dim
    (not head_dim % 64 == 0) since the triton kernel pads to next-power-of-2.
    """
    for node in (q_node, k_node):
        fake_val = node.meta.get("val", None)
        if fake_val is None:
            return False

        # dtype must be half-precision
        if fake_val.dtype not in (torch.float16, torch.bfloat16):
            return False

        # Must be at least 4-D
        if len(fake_val.shape) < 4:
            return False

        # head_dim must be even
        head_dim = fake_val.shape[-1]
        if isinstance(head_dim, int) and head_dim % 2 != 0:
            return False

        # BSND layout: dim 1 (S) should be symbolic, dim 2 (N) should be static
        if not isinstance(fake_val.shape[1], torch.SymInt):
            return False
        if not isinstance(fake_val.shape[2], int):
            return False

    return True


def _optimize_interleaved(graph: torch.fx.Graph, node: Node) -> bool:
    """Replace ``torch_rope_with_qk_interleaving`` with ``triton_rope_on_interleaved_qk_inputs``.

    Traces back from cos/sin nodes to find the original ``aten.index.Tensor``
    producer and extracts the cached cos/sin tensors and position_ids, passing
    them directly to the triton kernel (which fuses the position lookup).

    Returns True if the replacement was made, False if skipped.
    """
    # --- extract arguments ---------------------------------------------------
    q_node, k_node, cos_node, sin_node, *rest = node.args
    q_rope_old, k_rope_old = extract_output_tuple(node, 2)
    if q_rope_old is None or k_rope_old is None:
        return False

    # --- validate inputs -----------------------------------------------------
    if not _validate_interleaved_rope_inputs(q_node, k_node):
        return False

    # --- trace back cos/sin to find cache + position_ids ---------------------
    cos_traced = _trace_back_index(cos_node)
    if cos_traced is None:
        return False
    cos_cache_node, cos_position_ids_node = cos_traced

    sin_traced = _trace_back_index(sin_node)
    if sin_traced is None:
        return False
    sin_cache_node, sin_position_ids_node = sin_traced

    # Both cos and sin must use the same position_ids
    if cos_position_ids_node is not sin_position_ids_node:
        return False

    position_ids_node = cos_position_ids_node

    # --- insert the triton op ------------------------------------------------
    with graph.inserting_before(node):
        triton_node = graph.call_function(
            torch.ops.auto_deploy.triton_rope_on_interleaved_qk_inputs,
            args=(q_node, k_node, cos_cache_node, sin_cache_node, position_ids_node),
        )

    with graph.inserting_after(triton_node):
        q_rope_new = graph.call_function(operator.getitem, args=(triton_node, 0))
        k_rope_new = graph.call_function(operator.getitem, args=(triton_node, 1))

    # --- rewire outputs ------------------------------------------------------
    q_rope_new.meta["val"] = q_rope_old.meta.get("val", None)
    k_rope_new.meta["val"] = k_rope_old.meta.get("val", None)

    q_rope_old.replace_all_uses_with(q_rope_new)
    k_rope_old.replace_all_uses_with(k_rope_new)

    graph.erase_node(q_rope_old)
    graph.erase_node(k_rope_old)

    return True


def _match_input_interleave_pattern(node: Node) -> Optional[Dict[str, Node]]:
    """
    Detect DeepSeek-style interleave on Q/K:
      reshape(transpose(view(raw, [b,h,s,d//2,2]), 4, 3), [b,h,s,d])
    Returns:
      {"interleaved": raw_node} if matched, else None.
    """
    if not is_any_view_op(node):
        return None
    transpose_node = node.args[0]
    if not is_op(transpose_node, torch.ops.aten.transpose):
        return None
    view_node = transpose_node.args[0]
    if not is_any_view_op(view_node):
        return None
    raw_node = view_node.args[0]
    if not isinstance(raw_node, Node):
        return None
    return {"interleaved": raw_node}


def _get_last_node(nodes: Sequence[Node]) -> Node:
    """
    Given a list of FX Nodes,
    return the one that appears last in the graph's execution order.
    """
    if not nodes:
        raise ValueError("`nodes` must be a non-empty sequence of FX Node objects")

    graph = nodes[0].graph
    ordering = list(graph.nodes)

    # Sanity check that all nodes are in same graph
    valid = [n for n in nodes if n in ordering]
    if not valid:
        raise ValueError("None of the provided nodes belong to the same graph")

    last = max(valid, key=lambda n: ordering.index(n))
    return last


def _validate_rope_inputs(q_node: Node, k_node: Node) -> bool:
    """
    Validates that:
    - The last dimension (head_dim) of both q and k is a multiple of 64.
    - The dtype of q and k is half precision (bfloat16 or float16).
    - Layout should be [B,S,N,D] (dim 1 should be symbolic)
    """
    for name, node in [("q", q_node), ("k", k_node)]:
        fake_val = node.meta.get("val", None)
        if fake_val is None:
            return False

        # Check dtype
        if fake_val.dtype not in (torch.float16, torch.bfloat16):
            return False

        # Check head_dim
        if len(fake_val.shape) < 1:
            return False
        head_dim = fake_val.shape[-1]
        if isinstance(head_dim, int) and head_dim % 64 != 0:
            return False

        # Check shape
        if not isinstance(fake_val.shape[1], torch.SymInt):
            return False

    return True


def _get_position_ids(
    graph: GraphModule,
    q_node: Node,
    batch_dim: int = 0,
    seq_dim: int = 1,
    rope_position_ids_cache: Dict[str, Node] = None,
) -> Node:
    """
    Retrieves the cached position_ids from the graph if available, or computes and caches them.
    It uses the symbolic batch and sequence sizes from q_node with the provided dimension indices.
    """
    if rope_position_ids_cache is None:
        rope_position_ids_cache = {}

    if "position_ids" in rope_position_ids_cache:
        return rope_position_ids_cache["position_ids"]

    sym_batch = graph.call_function(torch.ops.aten.sym_size.int, args=(q_node, batch_dim))
    sym_seq = graph.call_function(torch.ops.aten.sym_size.int, args=(q_node, seq_dim))
    bs_seq = graph.call_function(operator.mul, args=(sym_batch, sym_seq))

    # Retrieve device information, ensuring it is a torch.device.
    device = q_node.meta.get("device", "cpu")
    if isinstance(device, str):
        device = torch.device(device)

    position_ids = graph.call_function(
        torch.ops.aten.arange,
        args=(bs_seq,),
        kwargs={"dtype": torch.int32, "device": device, "pin_memory": False},
    )
    rope_position_ids_cache["position_ids"] = position_ids
    return position_ids
