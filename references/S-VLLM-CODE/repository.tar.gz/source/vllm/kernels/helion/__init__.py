# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Helion integration for vLLM."""

import vllm.kernels.helion.ops  # noqa: F401  Auto-register all Helion ops
from vllm.kernels.helion.case_key import CaseKey
from vllm.kernels.helion.config_manager import (
    ConfigManager,
    ConfigSet,
)
from vllm.kernels.helion.register import (
    ConfigPicker,
    ConfiguredHelionKernel,
    HelionKernelWrapper,
    get_kernel_by_name,
    get_registered_kernels,
    register_kernel,
    vllm_helion_lib,
)
from vllm.kernels.helion.utils import canonicalize_gpu_name, get_canonical_gpu_name

__all__ = [
    # Config management
    "CaseKey",
    "ConfigManager",
    "ConfigSet",
    # Kernel registration
    "ConfigPicker",
    "ConfiguredHelionKernel",
    "HelionKernelWrapper",
    "get_kernel_by_name",
    "get_registered_kernels",
    "register_kernel",
    "vllm_helion_lib",
    # Utilities
    "canonicalize_gpu_name",
    "get_canonical_gpu_name",
]
