#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../" && pwd)

python3 "$SCRIPT_DIR/tools/ci/run_fa4_ci.py" \
  --repo-root "$SCRIPT_DIR" \
  "$@"
