# SPDX-License-Identifier: MIT
# Copyright (C) 2024-2026, Advanced Micro Devices, Inc. All rights reserved.

from collections.abc import Sequence
from dataclasses import dataclass

import torch
import triton
from torch import Tensor

from ..jit.core import compile_ops
from .triton._triton_kernels.gated_delta_rule.utils.prefill_metadata import (
    GatedDeltaRulePrefillMetadata,
    build_gated_delta_rule_prefill_metadata,
)

MD_NAME = "module_chunk_gdr_fwd_h"
RCP_LN2 = 1.4426950408889634

_BV_FIXED_LDS_BYTES = 32 * 1024
_BV_LDS_BYTES_PER_BV = 512
_BV_RESIDENT_WGS_CAP = 2
_BV_CANDIDATES = (64, 32, 16)
_BV_CACHE: dict[tuple[int, int, int, int], int] = {}


def _device_idx(device: torch.device) -> int:
    if device.index is not None:
        return int(device.index)
    return int(torch.cuda.current_device())


def _get_shared_memory_per_cu(props: object) -> int:
    """Query per-CU shared memory with architecture-based fallback."""
    shared_per_cu = getattr(props, "shared_memory_per_multiprocessor", None)
    if shared_per_cu is not None:
        return int(shared_per_cu)
    arch = getattr(props, "gcnArchName", "")
    if arch:
        arch = arch.split(":")[0]
    _ARCH_LDS = {"gfx95": 128 * 1024, "gfx94": 64 * 1024}
    for prefix, size in _ARCH_LDS.items():
        if arch.startswith(prefix):
            return size
    shared_per_block = getattr(props, "shared_memory_per_block", None)
    if shared_per_block is not None:
        return int(shared_per_block)
    raise RuntimeError("Unable to determine shared memory per CU.")


def _compute_bv(
    device: torch.device,
    total_chunks: int,
    max_seq_chunks: int,
    num_heads: int,
) -> int:
    props = torch.cuda.get_device_properties(device)
    num_cus = props.multi_processor_count
    lds_per_cu = _get_shared_memory_per_cu(props)

    for bv in _BV_CANDIDATES:
        lds_per_wg = _BV_FIXED_LDS_BYTES + _BV_LDS_BYTES_PER_BV * bv
        resident = min(max(1, lds_per_cu // lds_per_wg), _BV_RESIDENT_WGS_CAP)
        total_wgs = (128 // bv) * num_heads * total_chunks
        threshold = max(1, (num_cus * resident) // 2) * max_seq_chunks
        if total_wgs >= threshold:
            return bv
    return 16


def _select_bv(
    device: torch.device, num_heads: int, total_chunks: int, max_seq_chunks: int
) -> int:
    key = (_device_idx(device), num_heads, total_chunks, max_seq_chunks)
    cached = _BV_CACHE.get(key)
    if cached is not None:
        return cached
    bv = _compute_bv(device, total_chunks, max_seq_chunks, num_heads)
    _BV_CACHE[key] = bv
    return bv


def _get_varlen_host_metadata(chunk_offsets: torch.Tensor) -> tuple[int, int]:
    """Return total and maximum per-sequence chunk counts.

    Reading CUDA offsets requires one device-to-host transfer.
    """
    offsets = chunk_offsets.tolist()
    total_chunks = offsets[-1]
    max_seq_chunks = max(offsets[i + 1] - offsets[i] for i in range(len(offsets) - 1))
    return total_chunks, max_seq_chunks


@compile_ops(MD_NAME, develop=True)
def chunk_gated_delta_rule_fwd_h_hip(
    k: Tensor,
    w: Tensor,
    u: Tensor,
    g: Tensor,
    gk: Tensor,
    initial_state: Tensor,
    initial_state_indices: Tensor,
    cu_seqlens: Tensor,
    chunk_offsets: Tensor,
    h: Tensor,
    v_new: Tensor,
    final_state: Tensor,
    selected_bv: int,
    has_initial_state: bool,
    output_final_state: bool,
    save_new_value: bool,
    use_exp2: bool,
    g_head_major: bool,
) -> None: ...


@dataclass(frozen=True)
class _StateArgs:
    tensor: Tensor
    has_initial_state: bool


def _prepare_state_args(
    *,
    initial_state: Tensor | None,
    state_dtype: torch.dtype | None,
    device: torch.device,
) -> _StateArgs:
    if initial_state is not None and initial_state.dtype not in (
        torch.float32,
        torch.bfloat16,
    ):
        raise ValueError(
            f"`initial_state.dtype` must be fp32 or bf16, got {initial_state.dtype}."
        )
    dtype = torch.float32 if state_dtype is None else state_dtype
    if dtype not in (torch.float32, torch.bfloat16):
        raise ValueError(f"`state_dtype` must be fp32 or bf16, got {dtype}.")
    if (
        state_dtype is not None
        and initial_state is not None
        and initial_state.dtype != dtype
    ):
        raise ValueError(
            f"`initial_state.dtype` ({initial_state.dtype}) must match `state_dtype` ({dtype})."
        )
    tensor = (
        initial_state.to(dtype=dtype).contiguous()
        if initial_state is not None
        else torch.empty(0, device=device, dtype=dtype)
    )
    return _StateArgs(
        tensor=tensor,
        has_initial_state=(initial_state is not None),
    )


def _resolve_snapshot_dtype(
    snapshot_dtype: torch.dtype | None, input_dtype: torch.dtype
) -> torch.dtype:
    dtype = input_dtype if snapshot_dtype is None else snapshot_dtype
    if dtype not in (torch.float32, torch.bfloat16):
        raise ValueError(f"`snapshot_dtype` must be fp32 or bf16, got {dtype}.")
    return dtype


def _normalize_g_tensor(
    g: Tensor | None,
    *,
    batch_size: int,
    seq_len: int,
    num_heads: int,
    device: torch.device,
    head_major: bool = False,
) -> Tensor:
    expected_shape = (
        (batch_size, num_heads, seq_len)
        if head_major
        else (batch_size, seq_len, num_heads)
    )
    if g is None:
        return torch.zeros(expected_shape, device=device, dtype=torch.float32)

    if g.dtype != torch.float32:
        g = g.to(torch.float32)

    if g.dim() != 3:
        raise ValueError(f"`g` must be 3-D, got shape {tuple(g.shape)}.")

    if tuple(g.shape) == expected_shape:
        return g.contiguous()

    raise ValueError(
        f"`g` shape mismatch, expected {expected_shape} for "
        f"{'head-major [B, H, T]' if head_major else 'token-major [B, T, H]'} layout, "
        f"got {tuple(g.shape)}."
    )


def chunk_gated_delta_rule_fwd_h_hip_fn(
    k: Tensor,
    w: Tensor,
    u: Tensor,
    g: Tensor | None = None,
    gk: Tensor | None = None,
    initial_state: Tensor | None = None,
    output_final_state: bool = False,
    chunk_size: int = 64,
    save_new_value: bool = True,
    cu_seqlens: Tensor | None = None,
    selected_bv: int | None = None,
    state_dtype: torch.dtype | None = None,
    use_exp2: bool = True,
    g_head_major: bool = False,
    initial_state_indices: Tensor | None = None,
    inplace_final_state: bool | None = None,
    seq_lens_cpu: Sequence[int] | None = None,
    prefill_metadata: GatedDeltaRulePrefillMetadata | None = None,
    num_decodes: int = 0,
    num_decode_tokens: int = 0,
    snapshot_dtype: torch.dtype | None = None,
) -> tuple[Tensor, Tensor | None, Tensor | None]:
    """
    HIP hidden-state forward with h layout [V, K] (K=128, V=128), always
    returning ``(h, v_new, final_state)``.

    w, u: [B, H, T, K/V] head-major contiguous.
    h snapshots: [B, NT, H, V, K]; v_new output: [B, H, T_flat, V].
    `g` is a 3-D tensor, token-major [B, T, H] or head-major [B, H, T].
    ``state_dtype`` controls initial/final persistent state. ``snapshot_dtype``
    independently controls temporary chunk snapshots and defaults to ``k.dtype``.
    use_exp2 selects whether cumulative gates are interpreted in log2 space.
    In varlen mode, pass ``prefill_metadata`` (preferred for reuse) or
    ``seq_lens_cpu`` to avoid reading chunk scheduling values back from the GPU.

    State handling:
      * Dense (default): ``initial_state`` is ``[N, H, V, K]`` (``slot == i_n``)
        and ``final_state`` is a freshly allocated ``[N, H, V, K]`` tensor.
      * Indexed pool: pass ``initial_state`` as the pool ``[pool_size, H, V, K]``
        plus ``initial_state_indices`` ``[N]`` (int32); each sequence's slot is
        gathered from the index array.
      * ``inplace_final_state`` (default: ``True`` when ``initial_state_indices``
        is given) writes the final state back into ``initial_state`` in place and
        returns that same buffer as ``final_state`` (no extra allocation).
    """
    if chunk_size != 64:
        raise ValueError("HIP kernel requires chunk_size=64.")
    if k.shape[-1] != 128 or w.shape[-1] != 128 or u.shape[-1] != 128:
        raise ValueError("HIP kernel requires K=128 and V=128.")
    if any(t.dtype != torch.bfloat16 for t in (k, w, u)):
        raise TypeError("HIP kernel requires `k`, `w`, and `u` to be bfloat16.")

    B, T, _Hg, K = k.shape
    H = w.shape[1]
    V = u.shape[-1]
    T_flat = w.shape[2]
    is_varlen = cu_seqlens is not None
    NT = triton.cdiv(T, chunk_size)

    if is_varlen and prefill_metadata is None and seq_lens_cpu is not None:
        prefill_metadata = build_gated_delta_rule_prefill_metadata(
            seq_lens_cpu,
            cu_seqlens=cu_seqlens,
            chunk_size=chunk_size,
            num_decodes=num_decodes,
            num_decode_tokens=num_decode_tokens,
        )

    has_indices = initial_state_indices is not None
    inplace = has_indices if inplace_final_state is None else inplace_final_state
    if inplace and initial_state is None:
        raise ValueError("`inplace_final_state` requires `initial_state`.")
    # Indexed slots address the pool, so the final state must be written back
    # into that pool in place; a dense `[N, ...]` final_state cannot hold them.
    if has_indices and not inplace:
        raise ValueError(
            "`initial_state_indices` requires in-place update; "
            "leave `inplace_final_state` unset or set it to True."
        )
    if has_indices and not output_final_state:
        raise ValueError(
            "`initial_state_indices` requires `output_final_state=True` "
            "(the indexed path writes the final state back into the pool)."
        )

    k_hip = k.contiguous()
    w_hip = w.contiguous()
    u_hip = u.contiguous()

    g_hip = _normalize_g_tensor(
        g,
        batch_size=B,
        seq_len=T_flat,
        num_heads=H,
        device=k.device,
        head_major=g_head_major,
    )

    if is_varlen:
        from aiter.ops.triton._triton_kernels.gated_delta_rule.utils import (
            prepare_chunk_offsets,
            prepare_rebased_cu_seqlens,
        )

        assert B == 1, "Varlen mode expects B=1 (flattened input)."
        if prefill_metadata is not None:
            prefill_metadata.validate(
                cu_seqlens=cu_seqlens,
                chunk_size=chunk_size,
                num_decodes=num_decodes,
                num_decode_tokens=num_decode_tokens,
                total_prefill_tokens=T_flat,
                num_sequences=len(cu_seqlens) - 1,
            )
            schedule = prefill_metadata.get_chunk_schedule(
                chunk_size,
                num_decodes=num_decodes,
                num_decode_tokens=num_decode_tokens,
            )
            cu_seqlens_int32 = schedule.kernel_cu_seqlens
            chunk_offsets_int32 = schedule.chunk_offsets
            N = schedule.n_prefill
            total_chunks = schedule.total_chunks
            max_seq_chunks = schedule.max_seq_chunks
        else:
            cu_seqlens_int32 = prepare_rebased_cu_seqlens(
                cu_seqlens, num_decodes, num_decode_tokens
            ).to(torch.int32)
            chunk_offsets_int32 = prepare_chunk_offsets(
                cu_seqlens, chunk_size, num_decodes, num_decode_tokens
            ).to(torch.int32)
            N = len(cu_seqlens_int32) - 1
            total_chunks, max_seq_chunks = _get_varlen_host_metadata(
                chunk_offsets_int32
            )
    else:
        cu_seqlens_int32 = torch.empty(0, device=k.device, dtype=torch.int32)
        chunk_offsets_int32 = torch.arange(
            0, (B + 1) * NT, NT, dtype=torch.int32, device=k.device
        )
        N = B
        total_chunks = B * NT
        max_seq_chunks = NT

    if selected_bv is None:
        selected_bv = _select_bv(k.device, H, total_chunks, max_seq_chunks)

    if gk is not None:
        total_gk_tokens = T_flat if is_varlen else B * T_flat
        expected_gk_shape = (total_gk_tokens, H, K)
        if tuple(gk.shape) != expected_gk_shape:
            raise ValueError(
                f"`gk` shape mismatch, expected {expected_gk_shape}, got {tuple(gk.shape)}."
            )
        gk_arg = gk.to(torch.float32)
        if use_exp2:
            # gk is provided in natural-log space; convert once before exp2 kernels consume it.
            gk_arg = gk_arg * RCP_LN2
        gk_arg = gk_arg.contiguous()
    else:
        gk_arg = torch.empty(0, device=k.device, dtype=torch.float32)

    v_new = (
        torch.empty((B, H, T_flat, V), device=k.device, dtype=torch.bfloat16)
        if save_new_value
        else torch.empty(0, device=k.device, dtype=torch.bfloat16)
    )
    # In-place mode runs directly on the caller's `initial_state` and writes the
    # final state back into it; otherwise use the copy/cast path.
    if inplace:
        if initial_state.dtype not in (torch.float32, torch.bfloat16):
            raise ValueError(
                f"`initial_state.dtype` must be fp32 or bf16, got {initial_state.dtype}."
            )
        if state_dtype is not None and initial_state.dtype != state_dtype:
            raise ValueError(
                f"`initial_state.dtype` ({initial_state.dtype}) must match "
                f"`state_dtype` ({state_dtype})."
            )
        if not initial_state.is_contiguous():
            raise ValueError("`initial_state` must be contiguous for in-place update.")
        state_tensor = initial_state
        has_initial_state = True
        resolved_state_dtype = initial_state.dtype
    else:
        state = _prepare_state_args(
            initial_state=initial_state,
            state_dtype=state_dtype,
            device=k.device,
        )
        state_tensor = state.tensor
        has_initial_state = state.has_initial_state
        resolved_state_dtype = state_tensor.dtype

    resolved_snapshot_dtype = _resolve_snapshot_dtype(snapshot_dtype, k.dtype)
    h = torch.empty(
        (1, total_chunks, H, V, K) if is_varlen else (B, NT, H, V, K),
        device=k.device,
        dtype=resolved_snapshot_dtype,
    )

    if not output_final_state:
        final_state = torch.empty(0, device=k.device, dtype=resolved_state_dtype)
    elif inplace:
        final_state = state_tensor
    else:
        final_state = torch.empty(
            (N, H, V, K), device=k.device, dtype=resolved_state_dtype
        )

    # No indices => dense identity mapping (slot == i_n).
    if has_indices:
        state_indices = initial_state_indices.to(torch.int32).contiguous()
    else:
        state_indices = torch.empty(0, device=k.device, dtype=torch.int32)

    chunk_gated_delta_rule_fwd_h_hip(
        k_hip,
        w_hip,
        u_hip,
        g_hip,
        gk_arg,
        state_tensor,
        state_indices,
        cu_seqlens_int32,
        chunk_offsets_int32,
        h,
        v_new,
        final_state,
        selected_bv,
        has_initial_state,
        output_final_state,
        save_new_value,
        use_exp2,
        g_head_major,
    )

    if not is_varlen:
        h = h.view(B, NT, H, V, K)

    if not save_new_value:
        v_new = None

    if not output_final_state:
        final_state = None

    return h, v_new, final_state
