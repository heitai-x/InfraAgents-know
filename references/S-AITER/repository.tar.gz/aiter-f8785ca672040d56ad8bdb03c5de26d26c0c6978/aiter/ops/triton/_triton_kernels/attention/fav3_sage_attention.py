import triton
import triton.language as tl

from aiter.ops.triton._triton_kernels.flash_attn_triton_amd.common import (
    compute_alibi_block,
)
from aiter.ops.triton.utils._triton.kernel_repr import make_kernel_repr


def map_dims(shape, indices):
    return [shape[i] for i in indices]


@triton.jit
def _sage_fwd_no_mask(
    acc,
    l_i,
    m_i,
    q,
    k_base_ptrs,
    v_base_ptrs,
    bias_base_ptrs,
    stride_kn,
    stride_vk,
    stride_bn,
    stride_sn,
    stride_sm,
    start_m,
    seqlen_k,
    seqlen_q,
    dropout_p,
    philox_seed,
    philox_offset_base,
    sd_mask,
    stride_sz,
    stride_sh,
    off_z,
    off_h_q,
    offs_m,
    offs_d_qk,
    offs_d_v,
    block_min,
    block_max,
    alibi_slope,
    q_descale,
    k_descale_base_ptr,
    stride_ksblk,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    PRE_LOAD_V: tl.constexpr,
    USE_BIAS: tl.constexpr,
    ENABLE_DROPOUT: tl.constexpr,
    PADDED_HEAD_QK: tl.constexpr,
    PADDED_HEAD_V: tl.constexpr,
    ACTUAL_BLOCK_DMODEL_QK: tl.constexpr,
    ACTUAL_BLOCK_DMODEL_V: tl.constexpr,
    USE_ALIBI: tl.constexpr,
    USE_EXP2: tl.constexpr,
    RETURN_SCORES: tl.constexpr,
    ACCUMULATOR_TYPE,
):
    k_descale_ptr = k_descale_base_ptr

    # loop over k, v, and update accumulator
    for start_n in range(block_min, block_max, BLOCK_N):
        # get ptrs
        k_ptrs = k_base_ptrs + start_n * stride_kn
        v_ptrs = v_base_ptrs + start_n * stride_vk

        kv_offs_n = start_n + tl.arange(0, BLOCK_N)
        # Load K
        if PADDED_HEAD_QK:
            k_mask = offs_d_qk[:, None] < ACTUAL_BLOCK_DMODEL_QK
            k = tl.load(k_ptrs, mask=k_mask, other=0.0)
        else:
            k = tl.load(k_ptrs)

        k_descale = tl.load(k_descale_ptr)
        k_descale_ptr += stride_ksblk

        # Optionally preload V
        if PRE_LOAD_V:
            if PADDED_HEAD_V:
                v_mask = offs_d_v[None, :] < ACTUAL_BLOCK_DMODEL_V
                v = tl.load(v_ptrs, mask=v_mask, other=0.0)
            else:
                v = tl.load(v_ptrs)

        # -- compute qk ----
        # Optimization (vs. eagerly scaled qk): defer the (q_descale * k_descale)
        # descale until softmax so it can be fused with the m_ij subtract into a
        # single FMA. Mathematically equivalent because scale > 0:
        #   max(qk_int * scale) == max(qk_int) * scale
        #   (qk_int * scale) - m_ij == fma(qk_int, scale, -m_ij)
        # The fast path (no bias/alibi) skips the per-element scale multiply that
        # the original code emitted as 64 v_fma_f32 with a zero addend, and instead
        # folds the scale into the subtract from m_ij as a real fused FMA.
        qk_int = tl.dot(q, k)
        scale = q_descale * k_descale

        if USE_ALIBI or USE_BIAS:
            # Bias / alibi live in the scaled domain, so we materialize the
            # scaled qk eagerly to add them, exactly as before.
            qk = qk_int.to(ACCUMULATOR_TYPE) * scale

            if USE_ALIBI:
                q_offs_m = start_m * BLOCK_M + tl.arange(0, BLOCK_M)
                alibi_block = compute_alibi_block(
                    alibi_slope, seqlen_q, seqlen_k, q_offs_m, kv_offs_n
                )
                qk += alibi_block

            if USE_BIAS:
                offs_kv = tl.arange(0, BLOCK_N)
                bias_mask = (start_n + offs_kv) < seqlen_k
                bias = tl.load(
                    bias_base_ptrs + start_n * stride_bn + offs_kv * stride_bn,
                    mask=bias_mask,
                    other=0.0,
                )
                qk += bias[None, :]

            m_ij = tl.maximum(m_i, tl.max(qk, 1))
            if USE_BIAS:
                q_shifted = tl.where(
                    m_ij[:, None] == float("-inf"),
                    float("-inf"),
                    qk - m_ij[:, None],
                )
            else:
                q_shifted = qk - m_ij[:, None]
        else:
            # Fast path: keep qk in unscaled f32 and fuse scale into the FMA.
            qk = qk_int.to(ACCUMULATOR_TYPE)
            row_max_unscaled = tl.max(qk, 1)
            m_ij = tl.maximum(m_i, row_max_unscaled * scale)
            q_shifted = qk * scale - m_ij[:, None]

        # Compute scaled QK and softmax probabilities
        if USE_EXP2:
            # p = tl.math.exp2(q_shifted * RCP_LN2)
            p = tl.math.exp2(q_shifted)
        else:
            p = tl.math.exp(q_shifted)

        # CAVEAT: Must update l_ij before applying dropout
        l_ij = tl.sum(p, 1)
        if ENABLE_DROPOUT:
            # Compute pointers for this block
            philox_base = philox_offset_base + off_z * stride_sz + off_h_q * stride_sh
            philox_ptrs = (
                philox_base
                + offs_m[:, None] * stride_sm
                + kv_offs_n[None, :] * stride_sn
            )

            # compute dropout mask
            rng_output = tl.rand(philox_seed, philox_ptrs)
            dropout_mask = rng_output > dropout_p

            # return scores with negative values for dropped vals (only if RETURN_SCORES is True)
            if RETURN_SCORES:
                sd_mask_value = tl.where(dropout_mask, p, -p)
                sd_mask_base = sd_mask + off_z * stride_sz + off_h_q * stride_sh
                sd_mask_ptrs = (
                    sd_mask_base
                    + offs_m[:, None] * stride_sm
                    + kv_offs_n[None, :] * stride_sn
                )

                # Compute mask for sd_mask storage
                sd_store_mask = (offs_m[:, None] < seqlen_q) & (
                    kv_offs_n[None, :] < seqlen_k
                )
                tl.store(sd_mask_ptrs, sd_mask_value, mask=sd_store_mask)

            # apply dropout mask in place
            p = tl.where(dropout_mask, p, 0.0)
        elif RETURN_SCORES:
            # NOTE: the returned score is not the same as the reference because we need to adjust as we find new maxes per block. We are not doing that
            sd_mask_base = sd_mask + off_z * stride_sz + off_h_q * stride_sh
            sd_mask_ptrs = (
                sd_mask_base
                + offs_m[:, None] * stride_sm
                + kv_offs_n[None, :] * stride_sn
            )

            # Compute mask for sd_mask storage
            sd_store_mask = (offs_m[:, None] < seqlen_q) & (
                kv_offs_n[None, :] < seqlen_k
            )
            tl.store(sd_mask_ptrs, p, mask=sd_store_mask)

        # -- update output accumulator --
        # alpha is an adjustment factor for acc and li as we loop and find new maxes
        # store the diff in maxes to adjust acc and li as we discover new maxes
        if USE_BIAS:
            m_diff = tl.where(m_ij == float("-inf"), float("-inf"), m_i - m_ij)
        else:
            m_diff = m_i - m_ij
        if USE_EXP2:
            # alpha = tl.math.exp2(m_diff * RCP_LN2)
            alpha = tl.math.exp2(m_diff)
        else:
            alpha = tl.math.exp(m_diff)
        acc = acc * alpha[:, None]
        if not PRE_LOAD_V:
            if PADDED_HEAD_V:
                v_mask = offs_d_v[None, :] < ACTUAL_BLOCK_DMODEL_V
                v = tl.load(v_ptrs, mask=v_mask, other=0.0)
            else:
                v = tl.load(v_ptrs)

        # -- update m_i and l_i
        l_i = l_i * alpha + l_ij
        m_i = m_ij

        acc = tl.dot((p).to(v.type.element_ty), v, out_dtype=tl.float32, acc=acc)

    return acc, l_i, m_i


@triton.jit
def _sage_fwd_blocksparse_nomask(
    acc,
    l_i,
    m_i,
    q,
    k_base_ptrs,
    v_base_ptrs,
    bias_base_ptrs,
    stride_kn,
    stride_vk,
    stride_bn,
    stride_sn,
    stride_sm,
    start_m,
    seqlen_k,
    seqlen_q,
    dropout_p,
    philox_seed,
    philox_offset_base,
    sd_mask,
    stride_sz,
    stride_sh,
    off_z,
    off_h_q,
    offs_m,
    offs_d_qk,
    offs_d_v,
    alibi_slope,
    q_descale,
    k_descale_offset,
    stride_ksblk,
    kv_block_indices,
    lut_start_val,
    n_blocks,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    PRE_LOAD_V: tl.constexpr,
    ENABLE_DROPOUT: tl.constexpr,
    PADDED_HEAD_QK: tl.constexpr,
    PADDED_HEAD_V: tl.constexpr,
    ACTUAL_BLOCK_DMODEL_QK: tl.constexpr,
    ACTUAL_BLOCK_DMODEL_V: tl.constexpr,
    USE_ALIBI: tl.constexpr,
    USE_EXP2: tl.constexpr,
    USE_BIAS: tl.constexpr,
    RETURN_SCORES: tl.constexpr,
    ACCUMULATOR_TYPE,
):
    for i in range(n_blocks):
        start_b = tl.load(kv_block_indices + lut_start_val + i)
        start_n = start_b * BLOCK_N
        k_ptrs = k_base_ptrs + start_n * stride_kn
        v_ptrs = v_base_ptrs + start_n * stride_vk
        kv_offs_n = start_n + tl.arange(0, BLOCK_N)
        k_descale_ptr_cur = k_descale_offset + start_b * stride_ksblk
        if PADDED_HEAD_QK:
            k_mask = offs_d_qk[:, None] < ACTUAL_BLOCK_DMODEL_QK
            k = tl.load(k_ptrs, mask=k_mask, other=0.0)
        else:
            k = tl.load(k_ptrs)
        k_descale = tl.load(k_descale_ptr_cur)
        if PRE_LOAD_V:
            if PADDED_HEAD_V:
                v_mask = offs_d_v[None, :] < ACTUAL_BLOCK_DMODEL_V
                v = tl.load(v_ptrs, mask=v_mask, other=0.0)
            else:
                v = tl.load(v_ptrs)

        # -- compute qk ----
        # Same optimization as in `_sage_fwd_no_mask`: defer the
        # (q_descale * k_descale) descale until softmax so it can be fused
        # with the m_ij subtract into a single FMA. Mathematically equivalent
        # because scale > 0:
        #   max(qk_int * scale) == max(qk_int) * scale
        #   (qk_int * scale) - m_ij == fma(qk_int, scale, -m_ij)
        qk_int = tl.dot(q, k)
        scale = q_descale * k_descale

        if USE_ALIBI or USE_BIAS:
            # Bias / alibi live in the scaled domain, materialize scaled qk.
            qk_scaled = qk_int.to(ACCUMULATOR_TYPE) * scale
            if USE_ALIBI:
                q_offs_m = start_m * BLOCK_M + tl.arange(0, BLOCK_M)
                alibi_block = compute_alibi_block(
                    alibi_slope, seqlen_q, seqlen_k, q_offs_m, kv_offs_n
                )
                qk_scaled += alibi_block
            if USE_BIAS:
                offs_kv = tl.arange(0, BLOCK_N)
                bias_mask = (start_n + offs_kv) < seqlen_k
                bias = tl.load(
                    bias_base_ptrs + start_n * stride_bn + offs_kv * stride_bn,
                    mask=bias_mask,
                    other=0.0,
                )
                qk_scaled += bias[None, :]

            m_ij = tl.maximum(m_i, tl.max(qk_scaled, 1))
            if USE_BIAS:
                q_shifted = tl.where(
                    m_ij[:, None] == float("-inf"),
                    float("-inf"),
                    qk_scaled - m_ij[:, None],
                )
            else:
                q_shifted = qk_scaled - m_ij[:, None]
        else:
            # Fast path: keep qk in unscaled f32 and fuse scale into the FMA.
            qk = qk_int.to(ACCUMULATOR_TYPE)
            row_max_unscaled = tl.max(qk, 1)
            m_ij = tl.maximum(m_i, row_max_unscaled * scale)
            q_shifted = qk * scale - m_ij[:, None]

        if USE_EXP2:
            p = tl.math.exp2(q_shifted)
        else:
            p = tl.math.exp(q_shifted)
        l_ij = tl.sum(p, 1)
        if ENABLE_DROPOUT:
            philox_base = philox_offset_base + off_z * stride_sz + off_h_q * stride_sh
            philox_ptrs = (
                philox_base
                + offs_m[:, None] * stride_sm
                + kv_offs_n[None, :] * stride_sn
            )
            rng_output = tl.rand(philox_seed, philox_ptrs)
            dropout_mask = rng_output > dropout_p
            if RETURN_SCORES:
                sd_mask_value = tl.where(dropout_mask, p, -p)
                sd_mask_base = sd_mask + off_z * stride_sz + off_h_q * stride_sh
                sd_mask_ptrs = (
                    sd_mask_base
                    + offs_m[:, None] * stride_sm
                    + kv_offs_n[None, :] * stride_sn
                )
                sd_store_mask = (offs_m[:, None] < seqlen_q) & (
                    kv_offs_n[None, :] < seqlen_k
                )
                tl.store(sd_mask_ptrs, sd_mask_value, mask=sd_store_mask)
            p = tl.where(dropout_mask, p, 0.0)
        elif RETURN_SCORES:
            sd_mask_base = sd_mask + off_z * stride_sz + off_h_q * stride_sh
            sd_mask_ptrs = (
                sd_mask_base
                + offs_m[:, None] * stride_sm
                + kv_offs_n[None, :] * stride_sn
            )
            sd_store_mask = (offs_m[:, None] < seqlen_q) & (
                kv_offs_n[None, :] < seqlen_k
            )
            tl.store(sd_mask_ptrs, p, mask=sd_store_mask)
        if USE_BIAS:
            m_diff = tl.where(m_ij == float("-inf"), float("-inf"), m_i - m_ij)
        else:
            m_diff = m_i - m_ij
        if USE_EXP2:
            alpha = tl.math.exp2(m_diff)
        else:
            alpha = tl.math.exp(m_diff)
        acc = acc * alpha[:, None]
        if not PRE_LOAD_V:
            if PADDED_HEAD_V:
                v_mask = offs_d_v[None, :] < ACTUAL_BLOCK_DMODEL_V
                v = tl.load(v_ptrs, mask=v_mask, other=0.0)
            else:
                v = tl.load(v_ptrs)
        l_i = l_i * alpha + l_ij
        m_i = m_ij
        acc = tl.dot((p).to(v.type.element_ty), v, out_dtype=tl.float32, acc=acc)
    return acc, l_i, m_i


@triton.jit
def _sage_fwd_blocksparse_mask(
    acc,
    l_i,
    m_i,
    q,
    k_base_ptrs,
    v_base_ptrs,
    bias_base_ptrs,
    stride_kn,
    stride_vk,
    stride_bn,
    stride_sn,
    stride_sm,
    start_m,
    seqlen_k,
    seqlen_q,
    dropout_p,
    philox_seed,
    philox_offset_base,
    sd_mask,
    stride_sz,
    stride_sh,
    off_z,
    off_h_q,
    offs_m,
    offs_d_qk,
    offs_d_v,
    alibi_slope,
    q_descale,
    k_descale_offset,
    stride_ksblk,
    kv_block_indices,
    lut_start_val,
    n_blocks,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    PRE_LOAD_V: tl.constexpr,
    ENABLE_DROPOUT: tl.constexpr,
    PADDED_HEAD_QK: tl.constexpr,
    PADDED_HEAD_V: tl.constexpr,
    ACTUAL_BLOCK_DMODEL_QK: tl.constexpr,
    ACTUAL_BLOCK_DMODEL_V: tl.constexpr,
    USE_ALIBI: tl.constexpr,
    USE_EXP2: tl.constexpr,
    USE_BIAS: tl.constexpr,
    RETURN_SCORES: tl.constexpr,
    ACCUMULATOR_TYPE,
):
    for i in range(n_blocks):
        start_b = tl.load(kv_block_indices + lut_start_val + i)
        start_n = start_b * BLOCK_N
        k_ptrs = k_base_ptrs + start_n * stride_kn
        v_ptrs = v_base_ptrs + start_n * stride_vk
        kv_offs_n = start_n + tl.arange(0, BLOCK_N)
        k_descale_ptr_cur = k_descale_offset + start_b * stride_ksblk
        k_n_mask = kv_offs_n[None, :] < seqlen_k
        if PADDED_HEAD_QK:
            k_mask = (offs_d_qk[:, None] < ACTUAL_BLOCK_DMODEL_QK) & k_n_mask
        else:
            k_mask = k_n_mask
        k = tl.load(k_ptrs, mask=k_mask, other=0.0)
        k_descale = tl.load(k_descale_ptr_cur)
        if PRE_LOAD_V:
            v_n_mask = kv_offs_n[:, None] < seqlen_k
            if PADDED_HEAD_V:
                v_mask = v_n_mask & (offs_d_v[None, :] < ACTUAL_BLOCK_DMODEL_V)
            else:
                v_mask = v_n_mask
            v = tl.load(v_ptrs, mask=v_mask, other=0.0)

        # -- compute qk ----
        # Same optimization as `_sage_fwd_no_mask`: defer the
        # (q_descale * k_descale) descale until softmax so it can be fused
        # with the m_ij subtract into a single FMA. Padding positions are
        # masked to -inf, which is invariant under multiplication by the
        # positive scale, so we can apply the mask in either domain.
        qk_int = tl.dot(q, k)
        scale = q_descale * k_descale
        qk_mask = (offs_m[:, None] < seqlen_q) & (kv_offs_n[None, :] < seqlen_k)
        if USE_ALIBI or USE_BIAS:
            # Bias / alibi live in the scaled domain, materialize scaled qk.
            qk_scaled = qk_int.to(ACCUMULATOR_TYPE) * scale
            if USE_ALIBI:
                q_offs_m = start_m * BLOCK_M + tl.arange(0, BLOCK_M)
                alibi_block = compute_alibi_block(
                    alibi_slope, seqlen_q, seqlen_k, q_offs_m, kv_offs_n
                )
                qk_scaled += alibi_block
            if USE_BIAS:
                offs_kv = tl.arange(0, BLOCK_N)
                bias_mask = (start_n + offs_kv) < seqlen_k
                bias = tl.load(
                    bias_base_ptrs + start_n * stride_bn + offs_kv * stride_bn,
                    mask=bias_mask,
                    other=0.0,
                )
                qk_scaled += bias[None, :]
            qk_scaled = tl.where(
                qk_mask, qk_scaled, float("-inf")
            )  # mask padding before softmax
            m_ij = tl.maximum(m_i, tl.max(qk_scaled, 1))
            q_shifted = tl.where(
                m_ij[:, None] == float("-inf"),
                float("-inf"),
                qk_scaled - m_ij[:, None],
            )
        else:
            # Fast path: keep qk in unscaled f32 and fuse scale into the FMA.
            qk = qk_int.to(ACCUMULATOR_TYPE)
            qk = tl.where(qk_mask, qk, float("-inf"))
            row_max_unscaled = tl.max(qk, 1)
            m_ij = tl.maximum(m_i, row_max_unscaled * scale)
            q_shifted = tl.where(
                m_ij[:, None] == float("-inf"),
                float("-inf"),
                qk * scale - m_ij[:, None],
            )

        if USE_EXP2:
            p = tl.math.exp2(q_shifted)
        else:
            p = tl.math.exp(q_shifted)
        l_ij = tl.sum(p, 1)
        if ENABLE_DROPOUT:
            philox_base = philox_offset_base + off_z * stride_sz + off_h_q * stride_sh
            philox_ptrs = (
                philox_base
                + offs_m[:, None] * stride_sm
                + kv_offs_n[None, :] * stride_sn
            )
            rng_output = tl.rand(philox_seed, philox_ptrs)
            dropout_mask = rng_output > dropout_p
            if RETURN_SCORES:
                sd_mask_value = tl.where(dropout_mask, p, -p)
                sd_mask_base = sd_mask + off_z * stride_sz + off_h_q * stride_sh
                sd_mask_ptrs = (
                    sd_mask_base
                    + offs_m[:, None] * stride_sm
                    + kv_offs_n[None, :] * stride_sn
                )
                sd_store_mask = (offs_m[:, None] < seqlen_q) & (
                    kv_offs_n[None, :] < seqlen_k
                )
                tl.store(sd_mask_ptrs, sd_mask_value, mask=sd_store_mask)
            p = tl.where(dropout_mask, p, 0.0)
        elif RETURN_SCORES:
            sd_mask_base = sd_mask + off_z * stride_sz + off_h_q * stride_sh
            sd_mask_ptrs = (
                sd_mask_base
                + offs_m[:, None] * stride_sm
                + kv_offs_n[None, :] * stride_sn
            )
            sd_store_mask = (offs_m[:, None] < seqlen_q) & (
                kv_offs_n[None, :] < seqlen_k
            )
            tl.store(sd_mask_ptrs, p, mask=sd_store_mask)
        m_diff = tl.where(m_ij == float("-inf"), float("-inf"), m_i - m_ij)
        if USE_EXP2:
            alpha = tl.math.exp2(m_diff)
        else:
            alpha = tl.math.exp(m_diff)
        acc = acc * alpha[:, None]
        if not PRE_LOAD_V:
            v_n_mask = kv_offs_n[:, None] < seqlen_k
            if PADDED_HEAD_V:
                v_mask = v_n_mask & (offs_d_v[None, :] < ACTUAL_BLOCK_DMODEL_V)
            else:
                v_mask = v_n_mask
            v = tl.load(v_ptrs, mask=v_mask, other=0.0)
        l_i = l_i * alpha + l_ij
        m_i = m_ij
        acc = tl.dot((p).to(v.type.element_ty), v, out_dtype=tl.float32, acc=acc)
    return acc, l_i, m_i


@triton.jit
def _sage_fwd_mask(
    acc,
    l_i,
    m_i,
    q,
    k_base_ptrs,
    v_base_ptrs,
    bias_base_ptrs,
    stride_kn,
    stride_vk,
    stride_bn,
    stride_sn,
    stride_sm,
    start_m,
    seqlen_k,
    seqlen_q,
    dropout_p,
    philox_seed,
    philox_offset_base,
    sd_mask,
    stride_sz,
    stride_sh,
    off_z,
    off_h_q,
    offs_m,
    offs_n,
    offs_d_qk,
    offs_d_v,
    block_min,
    block_max,
    n_extra_tokens,
    alibi_slope,
    q_descale,
    k_descale_base_ptr,
    stride_ksblk,
    IS_CAUSAL: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    PRE_LOAD_V: tl.constexpr,
    USE_BIAS: tl.constexpr,
    ENABLE_DROPOUT: tl.constexpr,
    PADDED_HEAD_QK: tl.constexpr,
    PADDED_HEAD_V: tl.constexpr,
    ACTUAL_BLOCK_DMODEL_QK: tl.constexpr,
    ACTUAL_BLOCK_DMODEL_V: tl.constexpr,
    USE_ALIBI: tl.constexpr,
    USE_EXP2: tl.constexpr,
    RETURN_SCORES: tl.constexpr,
    USE_SLIDING_WINDOW: tl.constexpr,
    WINDOW_SIZE_LEFT: tl.constexpr,
    WINDOW_SIZE_RIGHT: tl.constexpr,
    ACCUMULATOR_TYPE,
):
    # seqlen diff
    seqlen_delta_qk = seqlen_k - seqlen_q

    k_descale_ptr = k_descale_base_ptr

    # loop over k, v, and update accumulator
    for start_n in range(block_min, block_max, BLOCK_N):
        # get ptrs
        k_ptrs = k_base_ptrs + start_n * stride_kn
        v_ptrs = v_base_ptrs + start_n * stride_vk

        # For padded blocks, we will overrun the tensor size if
        # we load all BLOCK_N. For others, the blocks are all within range.
        kv_offs_n = start_n + tl.arange(0, BLOCK_N)
        k_mask = kv_offs_n[None, :] < seqlen_k
        v_mask = kv_offs_n[:, None] < seqlen_k
        if PADDED_HEAD_QK:
            k_mask = k_mask & (offs_d_qk[:, None] < ACTUAL_BLOCK_DMODEL_QK)
        if PADDED_HEAD_V:
            v_mask = v_mask & (offs_d_v[None, :] < ACTUAL_BLOCK_DMODEL_V)

        # load k and if preload_v then v
        k = tl.load(k_ptrs, mask=k_mask, other=0.0)
        k_descale = tl.load(k_descale_ptr)
        k_descale_ptr += stride_ksblk

        if PRE_LOAD_V:
            v = tl.load(v_ptrs, mask=v_mask, other=0.0)

        # setup qk accumlator
        qk = tl.zeros([BLOCK_M, BLOCK_N], dtype=ACCUMULATOR_TYPE)

        # We start from end of seqlen_k so only the first iteration would need
        # to be checked for padding if it is not a multiple of block_n
        # TODO: This can be optimized to only be true for the padded block.
        # If this is the last block / iteration, we want to
        # mask if the sequence length is not a multiple of block size
        # a solution is to always do BLOCK_M // BLOCK_N + 1 steps if not is_modulo_mn.
        # last step might get wasted but that is okay. check if this masking works For
        # that case.
        if (n_extra_tokens != 0) and (start_n + BLOCK_N == block_max):
            boundary_m = tl.full([BLOCK_M], seqlen_k, dtype=tl.int32)
            size_n = start_n + offs_n[None, :]
            mask = size_n < boundary_m[:, None]
            qk = tl.where(mask, qk, float("-inf"))

        # -- compute qk ----
        qk += tl.dot(q, k) * (q_descale * k_descale)

        if USE_ALIBI:
            # compute the global position of each token within the sequence
            q_offs_m = start_m * BLOCK_M + tl.arange(0, BLOCK_M)
            alibi_block = compute_alibi_block(
                alibi_slope, seqlen_q, seqlen_k, q_offs_m, kv_offs_n
            )
            qk += alibi_block

        if USE_SLIDING_WINDOW:
            if IS_CAUSAL:
                # ========== CAUSAL SLIDING WINDOW MASKING ==========
                # For causal sliding window, we need to apply both constraints:
                # 1. Causal: col_idx <= row_idx + (seqlen_k - seqlen_q)
                # 2. Sliding window: row_idx - window_left <= col_idx <= row_idx + window_right

                # Get positions
                row_idx = offs_m  # Query positions
                col_idx = kv_offs_n  # Key positions

                # Expand for broadcasting
                row_idx_expanded = row_idx[:, None]  # [BLOCK_M, 1]
                col_idx_expanded = col_idx[None, :]  # [1, BLOCK_N]

                # Apply causal constraint: can only attend to positions before or at the diagonal
                causal_offset = seqlen_k - seqlen_q
                causal_mask = col_idx_expanded > (row_idx_expanded + causal_offset)

                # Apply sliding window constraint
                if WINDOW_SIZE_LEFT < 0:
                    # Only right window constraint
                    window_mask = col_idx_expanded > (
                        row_idx_expanded + causal_offset + WINDOW_SIZE_RIGHT
                    )
                else:
                    # Both left and right window constraints
                    # Adjust window bounds by causal offset
                    left_bound = row_idx_expanded + causal_offset - WINDOW_SIZE_LEFT
                    right_bound = row_idx_expanded + causal_offset + WINDOW_SIZE_RIGHT

                    # Can't attend to positions outside the window
                    window_mask = (col_idx_expanded < left_bound) | (
                        col_idx_expanded > right_bound
                    )

                # Final mask is the union of both constraints (True = cannot attend)
                mask = causal_mask | window_mask

                # Apply mask
                qk = tl.where(mask, float("-inf"), qk)
            else:
                # ========== NON-CAUSAL SLIDING WINDOW MASKING ==========
                # Exactly matching reference construct_local_mask:
                # row_idx = query positions, col_idx = key positions
                # sk = seqlen_k, sq = seqlen_q

                # Get positions
                row_idx = offs_m  # Query positions
                col_idx = kv_offs_n  # Key positions

                # sk and sq from reference (no padding masks in this test)
                sk = seqlen_k
                sq = seqlen_q

                # Expand for broadcasting
                row_idx_expanded = row_idx[:, None]  # [BLOCK_M, 1]
                col_idx_expanded = col_idx[None, :]  # [1, BLOCK_N]

                # Reference logic for mask computation
                if WINDOW_SIZE_LEFT < 0:
                    # Reference: return col_idx > row_idx + sk - sq + window_size[1]
                    mask = col_idx_expanded > (
                        row_idx_expanded + sk - sq + WINDOW_SIZE_RIGHT
                    )
                else:
                    # Reference:
                    # sk = torch.full_like(col_idx, seqlen_k) if key_padding_mask is None else sk
                    # return torch.logical_or(
                    #     col_idx > torch.minimum(row_idx + sk - sq + window_size[1], sk),
                    #     col_idx < row_idx + sk - sq - window_size[0],
                    # )
                    # Create sk tensor with proper shape for broadcasting
                    # sk represents the key sequence length, which should be compared per column
                    sk_full = tl.full((1, BLOCK_N), sk, dtype=tl.int32)

                    # Compute boundaries
                    right_bound_val = row_idx_expanded + sk - sq + WINDOW_SIZE_RIGHT
                    right_bound = tl.minimum(right_bound_val, sk_full)
                    left_bound = row_idx_expanded + sk - sq - WINDOW_SIZE_LEFT

                    # Mask where True = cannot attend (matching reference)
                    mask = (col_idx_expanded > right_bound) | (
                        col_idx_expanded < left_bound
                    )

                # Apply mask (set to -inf where mask is True)
                qk = tl.where(mask, float("-inf"), qk)
        else:
            if IS_CAUSAL:
                causal_boundary = start_n + offs_n - seqlen_delta_qk
                causal_mask = offs_m[:, None] >= causal_boundary[None, :]
                qk = tl.where(causal_mask, qk, float("-inf"))

        # compute bias (delta_s: constant across Q rows in a block)
        if USE_BIAS:
            offs_kv = tl.arange(0, BLOCK_N)
            bias_mask = (start_n + offs_kv) < seqlen_k
            bias = tl.load(
                bias_base_ptrs + start_n * stride_bn + offs_kv * stride_bn,
                mask=bias_mask,
                other=0.0,
            )
            qk += bias[None, :]

        # get max scores so far
        m_ij = tl.maximum(m_i, tl.max(qk, 1))

        # scale and subtract max
        # IMPORTANT: Handle the case where all values are -inf
        # When m_ij = -inf and qk = -inf, subtraction gives NaN
        # We need to handle this explicitly
        # Check if this block has any valid values (m_ij != -inf)
        # For rows where everything is -inf, set q_shifted to -inf (not NaN)
        q_shifted = tl.where(
            m_ij[:, None] == float("-inf"), float("-inf"), qk - m_ij[:, None]
        )

        # Compute scaled QK and softmax probabilities
        if USE_EXP2:
            # p = tl.math.exp2(q_shifted * RCP_LN2)
            p = tl.math.exp2(q_shifted)
        else:
            p = tl.math.exp(q_shifted)

        # CAVEAT: Must update l_ij before applying dropout
        l_ij = tl.sum(p, 1)
        if ENABLE_DROPOUT:
            # Compute pointers for this block
            philox_base = philox_offset_base + off_z * stride_sz + off_h_q * stride_sh
            philox_ptrs = (
                philox_base
                + offs_m[:, None] * stride_sm
                + kv_offs_n[None, :] * stride_sn
            )

            # compute dropout mask
            rng_output = tl.rand(philox_seed, philox_ptrs)
            dropout_mask = rng_output > dropout_p

            # return scores with negative values for dropped vals (only if RETURN_SCORES is True)
            if RETURN_SCORES:
                sd_mask_value = tl.where(dropout_mask, p, -p)
                sd_mask_base = sd_mask + off_z * stride_sz + off_h_q * stride_sh
                sd_mask_ptrs = (
                    sd_mask_base
                    + offs_m[:, None] * stride_sm
                    + kv_offs_n[None, :] * stride_sn
                )

                # Compute mask for sd_mask storage - include bounds check
                sd_store_mask = (offs_m[:, None] < seqlen_q) & (
                    kv_offs_n[None, :] < seqlen_k
                )

                # Add causal mask if applicable to prevent writing to invalid positions
                if IS_CAUSAL:
                    seqlen_delta_qk = seqlen_k - seqlen_q
                    causal_constraint = kv_offs_n[None, :] <= (
                        offs_m[:, None] + seqlen_delta_qk
                    )
                    sd_store_mask = sd_store_mask & causal_constraint

                # Add sliding window mask if applicable
                if USE_SLIDING_WINDOW:
                    seqlen_delta_qk = seqlen_k - seqlen_q
                    if WINDOW_SIZE_LEFT < 0:
                        # Only right window constraint
                        window_constraint = kv_offs_n[None, :] <= (
                            offs_m[:, None] + seqlen_delta_qk + WINDOW_SIZE_RIGHT
                        )
                    else:
                        # Both left and right window constraints
                        left_bound = (
                            offs_m[:, None] + seqlen_delta_qk - WINDOW_SIZE_LEFT
                        )
                        right_bound = (
                            offs_m[:, None] + seqlen_delta_qk + WINDOW_SIZE_RIGHT
                        )
                        window_constraint = (kv_offs_n[None, :] >= left_bound) & (
                            kv_offs_n[None, :] <= right_bound
                        )
                    sd_store_mask = sd_store_mask & window_constraint

                tl.store(sd_mask_ptrs, sd_mask_value, mask=sd_store_mask)

            # apply dropout mask in place
            p = tl.where(dropout_mask, p, 0.0)
        elif RETURN_SCORES:
            # NOTE: the returned score is not the same as the reference because we need to adjust as we find new maxes per block. We are not doing that
            sd_mask_base = sd_mask + off_z * stride_sz + off_h_q * stride_sh
            sd_mask_ptrs = (
                sd_mask_base
                + offs_m[:, None] * stride_sm
                + kv_offs_n[None, :] * stride_sn
            )

            # Compute mask for sd_mask storage - include bounds check
            sd_store_mask = (offs_m[:, None] < seqlen_q) & (
                kv_offs_n[None, :] < seqlen_k
            )

            # Add causal mask if applicable
            if IS_CAUSAL:
                seqlen_delta_qk = seqlen_k - seqlen_q
                causal_constraint = kv_offs_n[None, :] <= (
                    offs_m[:, None] + seqlen_delta_qk
                )
                sd_store_mask = sd_store_mask & causal_constraint

            # Add sliding window mask if applicable
            if USE_SLIDING_WINDOW:
                seqlen_delta_qk = seqlen_k - seqlen_q
                if WINDOW_SIZE_LEFT < 0:
                    # Only right window constraint
                    window_constraint = kv_offs_n[None, :] <= (
                        offs_m[:, None] + seqlen_delta_qk + WINDOW_SIZE_RIGHT
                    )
                else:
                    # Both left and right window constraints
                    left_bound = offs_m[:, None] + seqlen_delta_qk - WINDOW_SIZE_LEFT
                    right_bound = offs_m[:, None] + seqlen_delta_qk + WINDOW_SIZE_RIGHT
                    window_constraint = (kv_offs_n[None, :] >= left_bound) & (
                        kv_offs_n[None, :] <= right_bound
                    )
                sd_store_mask = sd_store_mask & window_constraint

            tl.store(sd_mask_ptrs, p, mask=sd_store_mask)

        # -- update output accumulator --
        # alpha is an adjustment factor for acc and li as we loop and find new maxes
        # store the diff in maxes to adjust acc and li as we discover new maxes
        m_diff = tl.where(m_ij == float("-inf"), float("-inf"), m_i - m_ij)
        if USE_EXP2:
            # alpha = tl.math.exp2(m_diff * RCP_LN2)
            alpha = tl.math.exp2(m_diff)
        else:
            alpha = tl.math.exp(m_diff)
        acc = acc * alpha[:, None]
        if not PRE_LOAD_V:
            v = tl.load(v_ptrs, mask=v_mask, other=0.0)

        # -- update m_i and l_i
        l_i = l_i * alpha + l_ij
        m_i = m_ij
        acc = tl.dot((p).to(v.type.element_ty), v, out_dtype=tl.float32, acc=acc)

    return acc, l_i, m_i


@triton.jit
def compute_window_bounds(
    q_start,
    q_end,
    diag,
    seqlen_k,
    WINDOW_SIZE_LEFT: tl.constexpr,
    WINDOW_SIZE_RIGHT: tl.constexpr,
    IS_CAUSAL: tl.constexpr,
):
    """Calculate the window boundaries for a query block."""
    # Left boundary
    if WINDOW_SIZE_LEFT < 0:
        left_min = 0
        left_max = 0
    else:
        left_min = tl.maximum(0, q_start + diag - WINDOW_SIZE_LEFT)
        left_max = tl.maximum(0, q_end + diag - WINDOW_SIZE_LEFT)

    # Right boundary
    if IS_CAUSAL:
        # Causal cap: col ≤ row + diag
        right_min = tl.minimum(seqlen_k - 1, q_start + diag)
        right_max = tl.minimum(seqlen_k - 1, q_end + diag)
    else:
        if WINDOW_SIZE_RIGHT < 0:
            right_min = tl.minimum(seqlen_k - 1, q_start + diag + WINDOW_SIZE_RIGHT)
            right_max = tl.minimum(seqlen_k - 1, q_end + diag + WINDOW_SIZE_RIGHT)
        else:
            # Non-causal doesn't have the diagonal constraint
            right_min = tl.minimum(seqlen_k - 1, q_start + diag + WINDOW_SIZE_RIGHT)
            right_max = tl.minimum(seqlen_k - 1, q_end + diag + WINDOW_SIZE_RIGHT)

    return left_min, left_max, right_min, right_max


@triton.jit
def classify_window_blocks(
    left_min, left_max, right_min, right_max, BLOCK_N: tl.constexpr
):
    """Classify blocks based on window boundaries."""
    # First and last blocks that have ANY overlap with window
    first_block = left_min // BLOCK_N
    last_block = right_max // BLOCK_N

    # First block that is FULLY visible for all rows in Q block
    full_left_block = left_max // BLOCK_N + (left_max % BLOCK_N != 0)
    clipped_left = tl.minimum(full_left_block, last_block + 1)

    # Last block that is FULLY visible for all rows in Q block
    last_full_block_candidate = right_min // BLOCK_N
    if (last_full_block_candidate + 1) * BLOCK_N - 1 > right_min:
        last_full_block_candidate -= 1
    full_right_block = tl.maximum(last_full_block_candidate, clipped_left - 1)

    # Calculate counts
    n_front_skip_blocks = first_block
    n_front_masked_blocks = tl.maximum(0, clipped_left - first_block)
    n_full_blocks = tl.maximum(0, full_right_block - clipped_left + 1)
    n_back_masked_blocks = tl.maximum(0, last_block - full_right_block)

    return (
        n_front_skip_blocks,
        n_front_masked_blocks,
        n_full_blocks,
        n_back_masked_blocks,
        clipped_left,
    )  # Return clipped_left for padded block handling


@triton.jit
def handle_padded_last_block(
    n_extra_tokens,
    last_block,
    total_k_blocks,
    clipped_left,
    n_front_masked_blocks,
    n_full_blocks,
    n_back_masked_blocks,
):
    """Ensure a padded last K-block is never classified as 'full'.

    We move the padded last block (if visible) into the back-masked bucket.
    If it's already back-masked, we do nothing.  If it was counted in the
    front-masked range, we decrement front-masked; if it was counted as full,
    we decrement full.  Then we increment back-masked.
    """
    padded_last_k = (n_extra_tokens != 0) & (last_block == total_k_blocks - 1)

    if padded_last_k:
        # current 'full' range right edge
        full_right_block = clipped_left + n_full_blocks - 1

        # If last_block is already beyond full_right_block, it's already in back-masked → nothing to do
        last_already_back_masked = last_block > full_right_block
        if not last_already_back_masked:
            # If the window starts past last_block, it was counted in front-masked
            if clipped_left > last_block:
                n_front_masked_blocks = tl.maximum(0, n_front_masked_blocks - 1)
            else:
                # Otherwise it was counted 'full' → move it out of full
                n_full_blocks = tl.maximum(0, n_full_blocks - 1)
            # In both cases we need one more back-masked block
            n_back_masked_blocks = n_back_masked_blocks + 1

    return n_front_masked_blocks, n_full_blocks, n_back_masked_blocks


@triton.jit
def compute_padding_info(seqlen_k, BLOCK_N: tl.constexpr):
    """Calculate padding information for the last K block."""
    # check if we will need to do masking due either BLOCK_N being bigger than seqlen_k or seqlen_k not being a factor of BLOCK_N
    # n_extra_tokens = 10 % 4 = 2
    # This means the last K block has 2 valid tokens and 2 padding positions
    # K blocks visualization:
    #         Block 0         Block 1         Block 2 (last)
    #         K0 K1 K2 K3    K4 K5 K6 K7     K8 K9 ?? ??
    #         ↑---------↑    ↑---------↑     ↑---↑ ↑---↑
    #         full block     full block      valid  pad
    if seqlen_k < BLOCK_N:
        n_extra_tokens = BLOCK_N - seqlen_k
    elif seqlen_k % BLOCK_N:
        n_extra_tokens = seqlen_k % BLOCK_N
    else:
        n_extra_tokens = 0
    return n_extra_tokens


@triton.jit
def compute_block_masking(
    seqlen_k,
    seqlen_q,
    start_m,
    IS_CAUSAL: tl.constexpr,
    USE_SLIDING_WINDOW: tl.constexpr,
    WINDOW_SIZE_LEFT: tl.constexpr,
    WINDOW_SIZE_RIGHT: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    """
    Classify K blocks for attention computation with sliding window support.

    Returns:
        - n_front_skip_blocks: Blocks completely before the window
        - n_front_masked_blocks: Blocks partially overlapping window front
        - n_full_blocks: Blocks completely inside the window
        - n_back_masked_blocks: Blocks partially overlapping window back
        - n_extra_tokens: Padding tokens in last K block
    """

    # common
    q_start = start_m * BLOCK_M
    q_end = tl.minimum((start_m + 1) * BLOCK_M - 1, seqlen_q - 1)
    diag = seqlen_k - seqlen_q
    total_k_blocks = tl.cdiv(seqlen_k, BLOCK_N)
    n_extra_tokens = compute_padding_info(seqlen_k, BLOCK_N)

    if USE_SLIDING_WINDOW:
        # get window bounds
        left_min, left_max, right_min, right_max = compute_window_bounds(
            q_start,
            q_end,
            diag,
            seqlen_k,
            WINDOW_SIZE_LEFT,
            WINDOW_SIZE_RIGHT,
            IS_CAUSAL,
        )

        # window vanishes → early exit
        if right_max < left_min:
            return 0, 0, 0, 0, n_extra_tokens

        # classify blocks
        (
            n_front_skip_blocks,
            n_front_masked_blocks,
            n_full_blocks,
            n_back_masked_blocks,
            clipped_left,
        ) = classify_window_blocks(left_min, left_max, right_min, right_max, BLOCK_N)

        # handle padded last block if needed
        if n_extra_tokens != 0:
            last_block = right_max // BLOCK_N
            n_front_masked_blocks, n_full_blocks, n_back_masked_blocks = (
                handle_padded_last_block(
                    n_extra_tokens,
                    last_block,
                    total_k_blocks,
                    clipped_left,
                    n_front_masked_blocks,
                    n_full_blocks,
                    n_back_masked_blocks,
                )
            )
        return (
            n_front_skip_blocks,
            n_front_masked_blocks,
            n_full_blocks,
            n_back_masked_blocks,
            n_extra_tokens,
        )
    else:
        if IS_CAUSAL:
            # ========== CAUSAL MODE: Classify K Blocks ==========
            # Calculate causal boundary for this Q block
            #          [K0 K1 K2 K3] [K4 K5 K6 K7] [K8 K9 ?? ??]
            # Q0-Q3:   [ 1  0  0  0] [ 0  0  0  0] [ 0  0 -- --]  ← Q0
            #          [ 1  1  0  0] [ 0  0  0  0] [ 0  0 -- --]  ← Q1
            #          [ 1  1  1  0] [ 0  0  0  0] [ 0  0 -- --]  ← Q2
            #          [ 1  1  1  1] [ 1  1  0  0] [ 0  0 -- --]  ← Q3
            #                            ↑ can see up to K5
            #
            # Q4-Q7:   [ 1  1  1  1] [ 1  1  1  0] [ 0  0 -- --]  ← Q4
            #          [ 1  1  1  1] [ 1  1  1  1] [ 0  0 -- --]  ← Q5
            #          [ 1  1  1  1] [ 1  1  1  1] [ 1  0 -- --]  ← Q6
            #          [ 1  1  1  1] [ 1  1  1  1] [ 1  1 -- --]  ← Q7

            # ------------------------------------------------------------
            # 1. figure out, in tokens, the right-most K position
            #    this Q-block may attend to
            # ------------------------------------------------------------
            k_max_token = q_end + diag  # last visible K index

            # this Q-block is entirely above the diagonal ⇒ nothing to do
            if k_max_token < 0:
                return 0, 0, 0, 0, n_extra_tokens

            k_max_token = tl.minimum(k_max_token, seqlen_k - 1)

            # ------------------------------------------------------------
            # 2. translate token indices into K-block indices
            # ------------------------------------------------------------
            last_visible_k_block = k_max_token // BLOCK_N
            n_visible_k_blocks = tl.minimum(last_visible_k_block + 1, total_k_blocks)

            # ------------------------------------------------------------
            # 3. classify those visible blocks
            #    – we *never* skip or mask blocks in front, because causal
            #      attention always starts at K0
            #    – the back side can require several masked blocks:
            #         • intersection of the causal diagonal with K-grid
            #           (at most  ⌈BLOCK_M / BLOCK_N⌉ blocks)
            #         • plus one extra block if this Q-block stops in the
            #           middle of a K-block or the last K-block is padded
            # ------------------------------------------------------------
            padded_last_k = n_extra_tokens != 0
            is_modulo_mn = (not padded_last_k) & (seqlen_q % BLOCK_M == 0)

            n_back_masked_blocks = BLOCK_M // BLOCK_N + tl.where(is_modulo_mn, 0, 1)
            n_back_masked_blocks = tl.minimum(n_back_masked_blocks, n_visible_k_blocks)

            n_front_skip_blocks = 0  # causal never skips the left side
            n_front_masked_blocks = 0  # ditto
            n_full_blocks = n_visible_k_blocks - n_back_masked_blocks
        else:
            # ========== NON-CAUSAL MODE ==========
            # Without causal mask, all positions can attend to all positions
            # Only need to handle the padding in the last block
            #          [K0 K1 K2 K3] [K4 K5 K6 K7] [K8 K9 ?? ??]
            # Q0-Q3:   [ 1  1  1  1] [ 1  1  1  1] [ 1  1 -∞ -∞]
            #          [ 1  1  1  1] [ 1  1  1  1] [ 1  1 -∞ -∞]
            #          [ 1  1  1  1] [ 1  1  1  1] [ 1  1 -∞ -∞]
            #          [ 1  1  1  1] [ 1  1  1  1] [ 1  1 -∞ -∞]
            #
            # Q4-Q7:   [ 1  1  1  1] [ 1  1  1  1] [ 1  1 -∞ -∞]
            #          [ 1  1  1  1] [ 1  1  1  1] [ 1  1 -∞ -∞]
            #          [ 1  1  1  1] [ 1  1  1  1] [ 1  1 -∞ -∞]
            #          [ 1  1  1  1] [ 1  1  1  1] [ 1  1 -∞ -∞]

            n_front_skip_blocks = 0  # never skips the left side
            n_front_masked_blocks = 0  # ditto
            if n_extra_tokens != 0:
                n_back_masked_blocks = 1  # Last block needs padding mask
                n_full_blocks = total_k_blocks - 1
            else:
                n_back_masked_blocks = 0  # All blocks are aligned
                n_full_blocks = total_k_blocks

        return (
            n_front_skip_blocks,
            n_front_masked_blocks,
            n_full_blocks,
            n_back_masked_blocks,
            n_extra_tokens,
        )


_sage_fwd_repr = make_kernel_repr(
    "sage_fwd",
    [
        "RETURN_LSE",
        "HQ",
        "HK",
        "ACTUAL_BLOCK_DMODEL_QK",
        "ACTUAL_BLOCK_DMODEL_V",
        "IS_CAUSAL",
        "USE_SLIDING_WINDOW",
        "BLOCK_M",
        "BLOCK_N",
        "PRE_LOAD_V",
        "USE_BIAS",
        "USE_BLOCK_SPARSE",
    ],
)


@triton.jit(repr=_sage_fwd_repr)
def sage_fwd(
    Q,
    K,
    V,
    bias,
    Q_Descale,
    K_Descale,
    V_Descale,
    stride_qsz,
    stride_qsh,
    stride_qsblk,
    stride_ksz,
    stride_ksh,
    stride_ksblk,
    stride_vsz,
    stride_vsh,
    LSE,
    Out,
    SD_MASK,
    ALIBI_SLOPES,
    stride_qz,
    stride_qh,
    stride_qm,
    stride_qk,
    stride_kz,
    stride_kh,
    stride_kn,
    stride_kk,
    stride_vz,
    stride_vh,
    stride_vk,
    stride_vn,
    stride_oz,
    stride_oh,
    stride_om,
    stride_on,
    stride_bz,
    stride_bh,
    stride_bm,
    stride_bn,
    stride_az,
    stride_ah,
    stride_sz,
    stride_sh,
    stride_sm,
    stride_sn,
    stride_lse_z,
    stride_lse_h,
    stride_lse_m,
    cu_seqlens_q,
    cu_seqlens_k,
    seqused_q,
    seqused_k,  # Add seqused parameters
    kv_block_indices,
    lut_start,
    lut_count,
    num_q_blocks,
    dropout_p,
    philox_seed,
    philox_offset_base,
    RETURN_LSE: tl.constexpr,
    HQ: tl.constexpr,
    HK: tl.constexpr,
    ACTUAL_BLOCK_DMODEL_QK: tl.constexpr,
    ACTUAL_BLOCK_DMODEL_V: tl.constexpr,
    MAX_SEQLENS_Q: tl.constexpr,
    MAX_SEQLENS_K: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    IS_CAUSAL: tl.constexpr,
    USE_SLIDING_WINDOW: tl.constexpr,
    WINDOW_SIZE_LEFT: tl.constexpr,
    WINDOW_SIZE_RIGHT: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_DMODEL_QK: tl.constexpr,
    BLOCK_DMODEL_V: tl.constexpr,
    BLOCK_N: tl.constexpr,
    PRE_LOAD_V: tl.constexpr,
    USE_BIAS: tl.constexpr,
    ENABLE_DROPOUT: tl.constexpr,
    RETURN_SCORES: tl.constexpr,
    USE_ALIBI: tl.constexpr,
    USE_EXP2: tl.constexpr,
    USE_SEQUSED: tl.constexpr,
    USE_BLOCK_SPARSE: tl.constexpr,
):
    # set params
    ACCUMULATOR_TYPE = tl.float32  # for q*k product

    # compute offsets
    start_m = tl.program_id(0).to(tl.int64)
    off_h_q = tl.program_id(1).to(tl.int64)
    off_z = tl.program_id(2).to(tl.int64)
    # If MQA / GQA, set the K and V head offsets appropriately.
    GROUP_SIZE: tl.constexpr = HQ // HK
    if GROUP_SIZE != 1:
        off_h_k = off_h_q // GROUP_SIZE
    else:
        off_h_k = off_h_q
    # Determine if we need to mask the heads
    PADDED_HEAD_QK: tl.constexpr = ACTUAL_BLOCK_DMODEL_QK != BLOCK_DMODEL_QK
    PADDED_HEAD_V: tl.constexpr = ACTUAL_BLOCK_DMODEL_V != BLOCK_DMODEL_V

    offs_m = start_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = tl.arange(0, BLOCK_N)
    offs_d_qk = tl.arange(0, BLOCK_DMODEL_QK)
    offs_d_v = tl.arange(0, BLOCK_DMODEL_V)
    (tl.multiple_of(offs_m, BLOCK_M),)
    # N dimension
    offs_n = tl.arange(0, BLOCK_N)
    (tl.multiple_of(offs_n, BLOCK_N),)

    # D dimensions (MOST IMPORTANT)
    offs_d_qk = tl.max_contiguous(
        tl.multiple_of(offs_d_qk, BLOCK_DMODEL_QK), BLOCK_DMODEL_QK
    )
    offs_d_v = tl.max_contiguous(
        tl.multiple_of(offs_d_v, BLOCK_DMODEL_V), BLOCK_DMODEL_V
    )

    # handle seqlen
    if IS_VARLEN:
        cu_seqlens_q_start = tl.load(cu_seqlens_q + off_z)
        cu_seqlens_q_end = tl.load(cu_seqlens_q + off_z + 1)

        # If seqused is provided, use it to limit the actual sequence length
        if USE_SEQUSED:
            actual_seqlen_q = (
                tl.load(seqused_q + off_z)
                if seqused_q is not None
                else cu_seqlens_q_end - cu_seqlens_q_start
            )
            seqlen_q = tl.minimum(
                actual_seqlen_q, cu_seqlens_q_end - cu_seqlens_q_start
            )
        else:
            seqlen_q = cu_seqlens_q_end - cu_seqlens_q_start

        # we have a one-size-fits-all grid in id(0). Some seqlens might be too small for all start_m so for those we return early.
        if start_m * BLOCK_M > seqlen_q:
            return
        cu_seqlens_k_start = tl.load(cu_seqlens_k + off_z)
        cu_seqlens_k_end = tl.load(cu_seqlens_k + off_z + 1)

        # If seqused is provided, use it to limit the actual sequence length for keys
        if USE_SEQUSED:
            actual_seqlen_k = (
                tl.load(seqused_k + off_z)
                if seqused_k is not None
                else cu_seqlens_k_end - cu_seqlens_k_start
            )
            seqlen_k = tl.minimum(
                actual_seqlen_k, cu_seqlens_k_end - cu_seqlens_k_start
            )
        else:
            seqlen_k = cu_seqlens_k_end - cu_seqlens_k_start
    else:
        cu_seqlens_q_start = 0
        cu_seqlens_k_start = 0
        seqlen_q = MAX_SEQLENS_Q
        seqlen_k = MAX_SEQLENS_K

    # figure out masking pattern
    if USE_BLOCK_SPARSE:
        n_extra_tokens = compute_padding_info(seqlen_k, BLOCK_N)
        lut_idx = off_z * (HQ * num_q_blocks) + off_h_q * num_q_blocks + start_m
        n_blocks = tl.load(lut_count + lut_idx)
        has_any_range = n_blocks > 0
    else:
        (
            n_front_skip_blocks,
            n_front_masked_blocks,
            n_full_blocks,
            n_back_masked_blocks,
            n_extra_tokens,
        ) = compute_block_masking(
            seqlen_k,
            seqlen_q,
            start_m.to(
                tl.int32
            ),  # int32 for consistent compute_block_masking return types
            IS_CAUSAL,
            USE_SLIDING_WINDOW,
            WINDOW_SIZE_LEFT,
            WINDOW_SIZE_RIGHT,
            BLOCK_M,
            BLOCK_N,
        )
        has_any_range = True  # unused in this branch

    # ============================================================
    #          PROGRAM EARLY EXIT (All K Blocks Skipped)
    # ============================================================
    if not USE_BLOCK_SPARSE:
        total_visible_blocks = (
            n_front_masked_blocks + n_full_blocks + n_back_masked_blocks
        )
    # Early exit: no K blocks to process
    if USE_BLOCK_SPARSE:
        _no_blocks = not has_any_range
    else:
        _no_blocks = total_visible_blocks == 0
    if _no_blocks:
        """
        No K blocks visible - write zeros and exit.
        """
        # Write zeros to output
        o_offset = (
            Out
            + off_z * stride_oz
            + off_h_q * stride_oh
            + cu_seqlens_q_start * stride_om
        )
        o_ptrs = o_offset + offs_m[:, None] * stride_om + offs_d_v[None, :] * stride_on
        o_mask = offs_m[:, None] < seqlen_q
        if PADDED_HEAD_V:
            o_mask = o_mask & (offs_d_v[None, :] < ACTUAL_BLOCK_DMODEL_V)
        tl.store(
            o_ptrs,
            tl.zeros([BLOCK_M, BLOCK_DMODEL_V], dtype=Out.type.element_ty),
            mask=o_mask,
        )

        # Write -inf to LSE
        if RETURN_LSE:
            l_ptrs = (
                LSE
                + off_z * stride_lse_z
                + off_h_q * stride_lse_h
                + cu_seqlens_q_start * stride_lse_m
                + offs_m * stride_lse_m
            )
            tl.store(
                l_ptrs,
                tl.full([BLOCK_M], float("-inf"), dtype=tl.float32),
                mask=offs_m < seqlen_q,
            )
        return

    # ============================================================
    #         NORMAL PROCESSING (Some K Blocks Visible)
    # ============================================================
    """
    This program has visible K blocks to process.
    We'll use two calls to handle different block types efficiently.
    """

    # Initialize for processing
    # Compute pointers for all the tensors used in this kernel.
    q_offset = (
        Q + off_z * stride_qz + off_h_q * stride_qh + cu_seqlens_q_start * stride_qm
    )
    q_ptrs = q_offset + offs_m[:, None] * stride_qm + offs_d_qk[None, :] * stride_qk
    k_offset = (
        K + off_z * stride_kz + off_h_k * stride_kh + cu_seqlens_k_start * stride_kn
    )
    k_ptrs = k_offset + offs_d_qk[:, None] * stride_kk + offs_n[None, :] * stride_kn
    v_offset = (
        V + off_z * stride_vz + off_h_k * stride_vh + cu_seqlens_k_start * stride_vk
    )
    v_ptrs = v_offset + offs_n[:, None] * stride_vk + offs_d_v[None, :] * stride_vn
    q_descale_ptr = (
        Q_Descale
        + off_z * stride_qsz
        + off_h_q * stride_qsh
        + (start_m + cu_seqlens_q_start) * stride_qsblk
    )
    k_descale_offset = (
        K_Descale
        + off_z * stride_ksz
        + off_h_k * stride_ksh
        + cu_seqlens_k_start * stride_ksblk
    )
    v_descale_ptr = V_Descale + off_z * stride_vsz + off_h_k * stride_vsh + offs_d_v

    q_descale = tl.load(q_descale_ptr)  # MHA: use q head index

    if USE_BIAS:
        bias_ptrs = bias + off_z * stride_bz + off_h_q * stride_bh + start_m * stride_bm
    else:
        bias_ptrs = None

    if USE_ALIBI:
        a_offset = off_z * stride_az + off_h_q * stride_ah
        alibi_slope = tl.load(ALIBI_SLOPES + a_offset)
    else:
        alibi_slope = None

    # initialize pointer to m and l
    m_i = tl.full([BLOCK_M], float("-inf"), dtype=ACCUMULATOR_TYPE)
    l_i = tl.full([BLOCK_M], 1.0, dtype=ACCUMULATOR_TYPE)
    acc = tl.zeros([BLOCK_M, BLOCK_DMODEL_V], dtype=ACCUMULATOR_TYPE)

    # Q is loaded once at the beginning and shared by all N blocks.
    q_ptrs_mask = offs_m[:, None] < seqlen_q
    if PADDED_HEAD_QK:
        q_ptrs_mask = q_ptrs_mask & (offs_d_qk[None, :] < ACTUAL_BLOCK_DMODEL_QK)
    q = tl.load(q_ptrs, mask=q_ptrs_mask, other=0.0)

    # ========== Process K Blocks: either three-phase (causal/window) or block-sparse ranges ==========
    if not USE_BLOCK_SPARSE:
        # ========== Process MASKED K Blocks in the front ==========
        # NOTE: we use USE_SLIDING_WINDOW as guard because the compiler will crash other wise. front masking is only for sliding window so that is fine.
        if n_front_masked_blocks > 0 and USE_SLIDING_WINDOW:
            block_min = n_front_skip_blocks * BLOCK_N
            block_max = (n_front_skip_blocks + n_front_masked_blocks) * BLOCK_N

            k_descale_ptr = k_descale_offset + n_front_skip_blocks * stride_ksblk

            acc, l_i, m_i = _sage_fwd_mask(
                acc,
                l_i,
                m_i,
                q,
                k_ptrs,
                v_ptrs,
                bias_ptrs,
                stride_kn,
                stride_vk,
                stride_bn,
                stride_sn,
                stride_sm,
                start_m,
                seqlen_k,
                seqlen_q,
                dropout_p,
                philox_seed,
                philox_offset_base,
                SD_MASK,
                stride_sz,
                stride_sh,
                off_z,
                off_h_q,
                offs_m,
                offs_n,
                offs_d_qk,
                offs_d_v,
                block_min,  # Start of front masked blocks
                block_max,  # End of front masked blocks
                0,  # n_extra_tokens (0 for front blocks, only relevant for last block)
                alibi_slope,
                q_descale,
                k_descale_ptr,
                stride_ksblk,
                IS_CAUSAL,
                BLOCK_M,
                BLOCK_N,
                PRE_LOAD_V,
                ENABLE_DROPOUT,
                PADDED_HEAD_QK,
                PADDED_HEAD_V,
                ACTUAL_BLOCK_DMODEL_QK,
                ACTUAL_BLOCK_DMODEL_V,
                USE_ALIBI=USE_ALIBI,
                USE_EXP2=USE_EXP2,
                RETURN_SCORES=RETURN_SCORES,
                USE_SLIDING_WINDOW=USE_SLIDING_WINDOW,
                WINDOW_SIZE_LEFT=WINDOW_SIZE_LEFT,
                WINDOW_SIZE_RIGHT=WINDOW_SIZE_RIGHT,
                ACCUMULATOR_TYPE=ACCUMULATOR_TYPE,
            )

        # ========== Process FULL K Blocks (Fast Path) ==========
        if n_full_blocks > 0:
            block_min = (n_front_skip_blocks + n_front_masked_blocks) * BLOCK_N
            block_max = (
                n_front_skip_blocks + n_front_masked_blocks + n_full_blocks
            ) * BLOCK_N

            k_descale_ptr = (
                k_descale_offset
                + (n_front_skip_blocks + n_front_masked_blocks) * stride_ksblk
            )

            acc, l_i, m_i = _sage_fwd_no_mask(
                acc,
                l_i,
                m_i,
                q,
                k_ptrs,
                v_ptrs,
                bias_ptrs,
                stride_kn,
                stride_vk,
                stride_bn,
                stride_sn,
                stride_sm,
                start_m,
                seqlen_k,
                seqlen_q,
                dropout_p,
                philox_seed,
                philox_offset_base,
                SD_MASK,
                stride_sz,
                stride_sh,
                off_z,
                off_h_q,
                offs_m,
                offs_d_qk,
                offs_d_v,
                block_min,  # Start of range: 0
                block_max,  # End of range: n_full_blocks * BLOCK_N
                alibi_slope,
                q_descale,
                k_descale_ptr,
                stride_ksblk,
                BLOCK_M,
                BLOCK_N,
                PRE_LOAD_V,
                USE_BIAS,
                ENABLE_DROPOUT,
                PADDED_HEAD_QK,
                PADDED_HEAD_V,
                ACTUAL_BLOCK_DMODEL_QK,
                ACTUAL_BLOCK_DMODEL_V,
                USE_ALIBI=USE_ALIBI,
                USE_EXP2=USE_EXP2,
                RETURN_SCORES=RETURN_SCORES,
                ACCUMULATOR_TYPE=ACCUMULATOR_TYPE,
            )

        # ========== Process MASKED K Blocks in the back ==========
        if n_back_masked_blocks > 0:
            block_min = (
                n_front_skip_blocks + n_front_masked_blocks + n_full_blocks
            ) * BLOCK_N
            block_max = (
                n_front_skip_blocks
                + n_front_masked_blocks
                + n_full_blocks
                + n_back_masked_blocks
            ) * BLOCK_N

            k_descale_ptr = (
                k_descale_offset
                + (n_front_skip_blocks + n_front_masked_blocks + n_full_blocks)
                * stride_ksblk
            )

            acc, l_i, m_i = _sage_fwd_mask(
                acc,
                l_i,
                m_i,
                q,
                k_ptrs,
                v_ptrs,
                bias_ptrs,
                stride_kn,
                stride_vk,
                stride_bn,
                stride_sn,
                stride_sm,
                start_m,
                seqlen_k,
                seqlen_q,
                dropout_p,
                philox_seed,
                philox_offset_base,
                SD_MASK,
                stride_sz,
                stride_sh,
                off_z,
                off_h_q,
                offs_m,
                offs_n,
                offs_d_qk,
                offs_d_v,
                block_min,  # Start of range: n_full_blocks * BLOCK_N
                block_max,  # End of range: n_visible_k_blocks * BLOCK_N
                n_extra_tokens,  # Padding tokens in last block
                alibi_slope,
                q_descale,
                k_descale_ptr,
                stride_ksblk,
                IS_CAUSAL,  # Use actual causal flag
                BLOCK_M,
                BLOCK_N,
                PRE_LOAD_V,
                USE_BIAS,
                ENABLE_DROPOUT,
                PADDED_HEAD_QK,
                PADDED_HEAD_V,
                ACTUAL_BLOCK_DMODEL_QK,
                ACTUAL_BLOCK_DMODEL_V,
                USE_ALIBI=USE_ALIBI,
                USE_EXP2=USE_EXP2,
                RETURN_SCORES=RETURN_SCORES,
                USE_SLIDING_WINDOW=USE_SLIDING_WINDOW,
                WINDOW_SIZE_LEFT=WINDOW_SIZE_LEFT,
                WINDOW_SIZE_RIGHT=WINDOW_SIZE_RIGHT,
                ACCUMULATOR_TYPE=ACCUMULATOR_TYPE,
            )
    else:
        # ========== USE_BLOCK_SPARSE: nomask then mask (last block) ==========
        lut_start_val = tl.load(lut_start + lut_idx)
        acc, l_i, m_i = _sage_fwd_blocksparse_nomask(
            acc,
            l_i,
            m_i,
            q,
            k_ptrs,
            v_ptrs,
            bias_ptrs,
            stride_kn,
            stride_vk,
            stride_bn,
            stride_sn,
            stride_sm,
            start_m,
            seqlen_k,
            seqlen_q,
            dropout_p,
            philox_seed,
            philox_offset_base,
            SD_MASK,
            stride_sz,
            stride_sh,
            off_z,
            off_h_q,
            offs_m,
            offs_d_qk,
            offs_d_v,
            alibi_slope,
            q_descale,
            k_descale_offset,
            stride_ksblk,
            kv_block_indices,
            lut_start_val,
            n_blocks - 1,
            BLOCK_M,
            BLOCK_N,
            PRE_LOAD_V,
            ENABLE_DROPOUT,
            PADDED_HEAD_QK,
            PADDED_HEAD_V,
            ACTUAL_BLOCK_DMODEL_QK,
            ACTUAL_BLOCK_DMODEL_V,
            USE_ALIBI=USE_ALIBI,
            USE_EXP2=USE_EXP2,
            USE_BIAS=USE_BIAS,
            RETURN_SCORES=RETURN_SCORES,
            ACCUMULATOR_TYPE=ACCUMULATOR_TYPE,
        )
        invalid_q_rows = offs_m >= seqlen_q
        m_i = tl.where(invalid_q_rows, float("-inf"), m_i)
        l_i = tl.where(invalid_q_rows, 1.0, l_i)
        acc = tl.where(invalid_q_rows[:, None], 0.0, acc)
        acc, l_i, m_i = _sage_fwd_blocksparse_mask(
            acc,
            l_i,
            m_i,
            q,
            k_ptrs,
            v_ptrs,
            bias_ptrs,
            stride_kn,
            stride_vk,
            stride_bn,
            stride_sn,
            stride_sm,
            start_m,
            seqlen_k,
            seqlen_q,
            dropout_p,
            philox_seed,
            philox_offset_base,
            SD_MASK,
            stride_sz,
            stride_sh,
            off_z,
            off_h_q,
            offs_m,
            offs_d_qk,
            offs_d_v,
            alibi_slope,
            q_descale,
            k_descale_offset,
            stride_ksblk,
            kv_block_indices,
            lut_start_val + (n_blocks - 1),
            1,
            BLOCK_M,
            BLOCK_N,
            PRE_LOAD_V,
            ENABLE_DROPOUT,
            PADDED_HEAD_QK,
            PADDED_HEAD_V,
            ACTUAL_BLOCK_DMODEL_QK,
            ACTUAL_BLOCK_DMODEL_V,
            USE_ALIBI=USE_ALIBI,
            USE_EXP2=USE_EXP2,
            USE_BIAS=USE_BIAS,
            RETURN_SCORES=RETURN_SCORES,
            ACCUMULATOR_TYPE=ACCUMULATOR_TYPE,
        )

    # ============================================================
    #                        EPILOGUE
    # ============================================================
    # For rows where m_i is still -inf, no keys were valid. Use l_i_safe to avoid
    # 1/l_i = inf and log(l_i) = -inf (and to guard l_i underflow) in all paths.
    invalid_mask = m_i == float("-inf")
    l_i_safe = tl.where(invalid_mask, 1.0, l_i)
    l_i_safe = tl.maximum(l_i_safe, 1e-7)
    l_recip = 1 / l_i_safe[:, None]

    v_descale = tl.load(
        v_descale_ptr,
        mask=offs_d_v < ACTUAL_BLOCK_DMODEL_V,
        other=0.0,
    )

    acc = acc * l_recip * v_descale
    z = 0.0
    acc = tl.where(invalid_mask[:, None], z.to(acc.type.element_ty), acc)
    if ENABLE_DROPOUT:
        dropout_scale = 1 / (1 - dropout_p)
        acc = acc * dropout_scale

    # compute log-sum-exp
    if RETURN_LSE:
        if USE_EXP2:
            # RCP_LN2: tl.constexpr = 1.4426950408889634
            LN2: tl.constexpr = 0.6931471824645996
            # compute log-sum-exp in base 2 units
            # mi_base2 = m_i * RCP_LN2
            mi_base2 = m_i
            # For invalid rows, log(l_i) would be -inf, but we want LSE to be -inf
            log_l_i = tl.where(invalid_mask, 0.0, tl.math.log2(l_i_safe))
            softmax_lse = tl.where(invalid_mask, float("-inf"), mi_base2 + log_l_i)
            # convert back to natural units
            softmax_lse *= LN2
        else:
            log_l_i = tl.where(invalid_mask, 0.0, tl.math.log(l_i_safe))
            softmax_lse = tl.where(invalid_mask, float("-inf"), m_i + log_l_i)

    # handle masking edge cases
    if USE_SLIDING_WINDOW:
        if IS_CAUSAL:
            pass
        else:
            pass
    else:
        if IS_CAUSAL:
            # When seqlen_q > seqlen_k, some rows are completely above the causal diagonal
            # These rows have all -inf attention scores, resulting in NaN after softmax
            # e.g.
            # Q length: 6, K length: 4
            # Causal mask (X = can attend, . = cannot):
            #    K0 K1 K2 K3
            # Q0   .  .  .  .  <- All masked, would give NaN
            # Q1   .  .  .  .  <- All masked, would give NaN
            # Q2   X  .  .  .  <- First valid row
            # Q3   X  X  .  .
            # Q4   X  X  X  .
            # Q5   X  X  X  X
            causal_start_idx = seqlen_q - seqlen_k
            start_m_idx = start_m * BLOCK_M

            # Create mask for rows that need zeroing
            row_indices = start_m_idx + tl.arange(0, BLOCK_M)
            causal_mask = row_indices < causal_start_idx

            # Zero out both acc and LSE for these rows
            if causal_start_idx > start_m_idx:
                end_m_idx = (start_m + 1) * BLOCK_M
                if causal_start_idx < end_m_idx:
                    # This block contains the boundary - need to mask acc
                    out_mask_boundary = tl.full(
                        (BLOCK_DMODEL_V,), causal_start_idx, dtype=tl.int32
                    )
                    out_ptrs_mask = row_indices[:, None] >= out_mask_boundary[None, :]
                    z = 0.0
                    acc = tl.where(out_ptrs_mask, acc, z.to(acc.type.element_ty))

            # Set LSE to -inf for rows above the causal diagonal (logsumexp over empty set).
            if RETURN_LSE:
                softmax_lse = tl.where(causal_mask, float("-inf"), softmax_lse)

    # write back LSE(Log Sum Exponents), the log of the normalization constant
    if RETURN_LSE:
        l_offset = (
            LSE
            + off_z * stride_lse_z
            + off_h_q * stride_lse_h
            + cu_seqlens_q_start * stride_lse_m
        )
        l_ptrs = l_offset + offs_m * stride_lse_m

    # If seqlen_q not multiple of BLOCK_M, we need to mask out the last few rows.
    # This is only true for the last Q block. For others, overflow_size will be -ve
    end_m_idx = (start_m + 1) * BLOCK_M
    overflow_size = end_m_idx - seqlen_q
    if RETURN_LSE:
        if overflow_size > 0:
            boundary = tl.full((BLOCK_M,), BLOCK_M - overflow_size, dtype=tl.int32)
            l_ptrs_mask = tl.arange(0, BLOCK_M) < boundary
            tl.store(l_ptrs, softmax_lse, mask=l_ptrs_mask)
        else:
            tl.store(l_ptrs, softmax_lse)

    # write back O
    o_offset = (
        Out + off_z * stride_oz + off_h_q * stride_oh + cu_seqlens_q_start * stride_om
    )
    o_ptrs = o_offset + offs_m[:, None] * stride_om + offs_d_v[None, :] * stride_on
    o_ptrs_mask = tl.full([BLOCK_M, BLOCK_DMODEL_V], 1, dtype=tl.int1)
    if overflow_size > 0:
        o_ptrs_mask = o_ptrs_mask & (offs_m[:, None] < seqlen_q)
    if PADDED_HEAD_V:
        o_ptrs_mask = o_ptrs_mask & (offs_d_v[None, :] < ACTUAL_BLOCK_DMODEL_V)

    tl.store(o_ptrs, acc.to(Out.dtype.element_ty), mask=o_ptrs_mask)
