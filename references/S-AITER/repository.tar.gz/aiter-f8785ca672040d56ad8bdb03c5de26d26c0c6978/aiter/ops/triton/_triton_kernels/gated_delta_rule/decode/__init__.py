# SPDX-License-Identifier: MIT
# Copyright (C) 2024-2026, Advanced Micro Devices, Inc. All rights reserved.
# Adapted from flash-linear-attention: Copyright (c) 2023-2025, Songlin Yang, Yu Zhang

"""
Gated Delta Rule Decode Operations (Forward Only).

This module provides optimized Triton kernels for decode/inference operations.
"""

from aiter.ops.triton._triton_kernels.gated_delta_rule.decode.fused_rearrange_sigmoid_gdr import (
    fused_rearrange_sigmoid_gated_delta_rule_update_kernel,
)
from aiter.ops.triton._triton_kernels.gated_delta_rule.decode.fused_recurrent import (
    _fused_recurrent_gated_delta_rule_fwd_kernel,
)
from aiter.ops.triton._triton_kernels.gated_delta_rule.decode.fused_sigmoid_gating_recurrent import (
    fused_sigmoid_gating_delta_rule_update,
)

__all__ = [
    "_fused_recurrent_gated_delta_rule_fwd_kernel",
    "fused_rearrange_sigmoid_gated_delta_rule_update_kernel",
    "fused_sigmoid_gating_delta_rule_update",
]
