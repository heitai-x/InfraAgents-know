# SPDX-License-Identifier: MIT
# Copyright (C) 2024-2026, Advanced Micro Devices, Inc. All rights reserved.
# Adapted from flash-linear-attention: Copyright (c) 2023-2025, Songlin Yang, Yu Zhang

"""
WY representation utilities for chunk gated delta rule.

This module provides functions for computing the WY representation used in
chunk-based gated delta rule operations.
"""

import torch
import triton
import triton.language as tl

from aiter.ops.triton._triton_kernels.gated_delta_rule.gated_delta_rule_utils import (
    autotune_cache_kwargs,
)
from aiter.ops.triton._triton_kernels.gated_delta_rule.utils.index import (
    prepare_chunk_indices,
)
from aiter.ops.triton._triton_kernels.gated_delta_rule.utils.op import exp
from aiter.ops.triton.utils.tuned_config_utils import autotune_configs


@triton.heuristics(
    {
        "USE_G": lambda args: args["g"] is not None,
        "IS_VARLEN": lambda args: args["cu_seqlens"] is not None,
    }
)
@triton.autotune(
    configs=autotune_configs(
        "GATED_DELTA_RULE",
        [
            triton.Config({"BK": BK}, num_warps=num_warps, num_stages=num_stages)
            for BK in [32, 64, 128]
            for num_warps in [2, 4, 8]
            for num_stages in [2, 3, 4]
        ],
    ),
    key=["H", "K", "BT", "IS_VARLEN"],
    **autotune_cache_kwargs,
)
@triton.jit(do_not_specialize=["T"])
def chunk_scaled_dot_kkt_fwd_kernel(
    k,
    g,
    beta,
    A,
    cu_seqlens,
    chunk_indices,
    T,
    H: tl.constexpr,
    K: tl.constexpr,
    BT: tl.constexpr,
    BK: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    USE_G: tl.constexpr,
):
    i_t, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H
    if IS_VARLEN:
        i_n, i_t = tl.load(chunk_indices + i_t * 2).to(tl.int32), tl.load(
            chunk_indices + i_t * 2 + 1
        ).to(tl.int32)
        bos, eos = tl.load(cu_seqlens + i_n).to(tl.int32), tl.load(
            cu_seqlens + i_n + 1
        ).to(tl.int32)
        T = eos - bos
    else:
        bos, eos = i_b * T, i_b * T + T
    o_t = i_t * BT + tl.arange(0, BT)
    m_t = o_t < T

    _p_b_0 = (i_t * BT) + tl.arange(0, BT)
    b_b = tl.load(beta + bos * H + i_h + _p_b_0 * (H), mask=(_p_b_0 < (T)), other=0.0)

    b_A = tl.zeros([BT, BT], dtype=tl.float32)
    for i_k in range(tl.cdiv(K, BK)):
        _p_k_0 = (i_t * BT) + tl.arange(0, BT)
        _p_k_1 = (i_k * BK) + tl.arange(0, BK)
        b_k = tl.load(
            k + (bos * H + i_h) * K + _p_k_0[:, None] * (H * K) + _p_k_1[None, :] * (1),
            mask=(_p_k_0[:, None] < (T)) & (_p_k_1[None, :] < (K)),
            other=0.0,
        )
        b_A = tl.dot(b_k, tl.trans(b_k), acc=b_A)

    if USE_G:
        _p_g_0 = (i_t * BT) + tl.arange(0, BT)
        b_g = tl.load(g + bos * H + i_h + _p_g_0 * (H), mask=(_p_g_0 < (T)), other=0.0)
        b_g_diff = b_g[:, None] - b_g[None, :]
        b_A *= exp(b_g_diff)
    b_A *= b_b[:, None]

    m_A = (o_t[:, None] > o_t[None, :]) & (m_t[:, None] & m_t)
    b_A = tl.where(m_A, b_A, 0)
    _p_A_0 = (i_t * BT) + tl.arange(0, BT)
    _p_A_1 = (0) + tl.arange(0, BT)
    tl.store(
        A + (bos * H + i_h) * BT + _p_A_0[:, None] * (BT * H) + _p_A_1[None, :] * (1),
        b_A.to(A.dtype.element_ty),
        mask=(_p_A_0[:, None] < (T)) & (_p_A_1[None, :] < (BT)),
    )


def chunk_scaled_dot_kkt_fwd(
    k: torch.Tensor,
    g: torch.Tensor | None = None,
    beta: torch.Tensor | None = None,
    cu_seqlens: torch.LongTensor | None = None,
    chunk_size: int = 64,
    output_dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    r"""
    Compute beta * K * K^T for each chunk.

    Args:
        k (torch.Tensor):
            The key tensor of shape `[B, T, H, K]`.
        g (torch.Tensor, optional):
            The cumulative sum of the gate tensor of shape `[B, T, H]`. Default: `None`.
        beta (torch.Tensor, optional):
            The beta tensor of shape `[B, T, H]`. Default: `None`.
        cu_seqlens (torch.LongTensor, optional):
            The cumulative sequence lengths of the input tensor. Default: None
        chunk_size (int):
            The chunk size. Default: 64.
        output_dtype (torch.dtype):
            The dtype of the output tensor. Default: `torch.float32`

    Returns:
        beta * K * K^T of shape `[B, T, H, BT]` where `BT` is the chunk size.
    """
    B, T, H, K = k.shape
    BT = chunk_size
    chunk_indices = (
        prepare_chunk_indices(cu_seqlens, BT) if cu_seqlens is not None else None
    )
    NT = triton.cdiv(T, BT) if cu_seqlens is None else len(chunk_indices)
    A = torch.empty(B, T, H, BT, device=k.device, dtype=output_dtype)
    chunk_scaled_dot_kkt_fwd_kernel[(NT, B * H)](
        k=k,
        g=g,
        beta=beta,
        A=A,
        cu_seqlens=cu_seqlens,
        chunk_indices=chunk_indices,
        T=T,
        H=H,
        K=K,
        BT=BT,
    )
    return A


@triton.heuristics(
    {
        "USE_G": lambda args: args["g"] is not None,
        "IS_VARLEN": lambda args: args["cu_seqlens"] is not None,
    }
)
@triton.autotune(
    configs=autotune_configs(
        "GATED_DELTA_RULE",
        [
            triton.Config({}, num_warps=num_warps, num_stages=num_stages)
            for num_warps in [2, 4, 8]
            for num_stages in [2, 3, 4]
        ],
        triton.Config({}, num_warps=2, num_stages=2),
    ),
    key=["H", "K", "V", "BT", "BK", "BV", "IS_VARLEN"],
    **autotune_cache_kwargs,
)
@triton.jit(do_not_specialize=["T"])
def recompute_w_u_fwd_kernel(
    k,
    v,
    beta,
    w,
    u,
    A,
    g,
    cu_seqlens,
    chunk_indices,
    T,
    H: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BT: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
    USE_G: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    i_t, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H
    if IS_VARLEN:
        i_n, i_t = tl.load(chunk_indices + i_t * 2).to(tl.int32), tl.load(
            chunk_indices + i_t * 2 + 1
        ).to(tl.int32)
        bos, eos = tl.load(cu_seqlens + i_n).to(tl.int32), tl.load(
            cu_seqlens + i_n + 1
        ).to(tl.int32)
        T = eos - bos
    else:
        bos, eos = i_b * T, i_b * T + T
    _p_b_0 = (i_t * BT) + tl.arange(0, BT)
    b_b = tl.load(beta + bos * H + i_h + _p_b_0 * (H), mask=(_p_b_0 < (T)), other=0.0)

    _p_A_0 = (i_t * BT) + tl.arange(0, BT)
    _p_A_1 = (0) + tl.arange(0, BT)
    b_A = tl.load(
        A + (bos * H + i_h) * BT + _p_A_0[:, None] * (H * BT) + _p_A_1[None, :] * (1),
        mask=(_p_A_0[:, None] < (T)) & (_p_A_1[None, :] < (BT)),
        other=0.0,
    )

    for i_v in range(tl.cdiv(V, BV)):
        _p_v_0 = (i_t * BT) + tl.arange(0, BT)
        _p_v_1 = (i_v * BV) + tl.arange(0, BV)
        b_v = tl.load(
            v + (bos * H + i_h) * V + _p_v_0[:, None] * (H * V) + _p_v_1[None, :] * (1),
            mask=(_p_v_0[:, None] < (T)) & (_p_v_1[None, :] < (V)),
            other=0.0,
        )
        b_vb = (b_v * b_b[:, None]).to(b_v.dtype)
        b_u = tl.dot(b_A, b_vb, allow_tf32=False)
        _p_u_0 = (i_t * BT) + tl.arange(0, BT)
        _p_u_1 = (i_v * BV) + tl.arange(0, BV)
        tl.store(
            u + (bos * H + i_h) * V + _p_u_0[:, None] * (H * V) + _p_u_1[None, :] * (1),
            b_u.to(u.dtype.element_ty),
            mask=(_p_u_0[:, None] < (T)) & (_p_u_1[None, :] < (V)),
        )

    if USE_G:
        _p_g_0 = (i_t * BT) + tl.arange(0, BT)
        b_g = exp(
            tl.load(g + (bos * H + i_h) + _p_g_0 * (H), mask=(_p_g_0 < (T)), other=0.0)
        )

    for i_k in range(tl.cdiv(K, BK)):
        _p_k_0 = (i_t * BT) + tl.arange(0, BT)
        _p_k_1 = (i_k * BK) + tl.arange(0, BK)
        b_k = tl.load(
            k + (bos * H + i_h) * K + _p_k_0[:, None] * (H * K) + _p_k_1[None, :] * (1),
            mask=(_p_k_0[:, None] < (T)) & (_p_k_1[None, :] < (K)),
            other=0.0,
        )
        b_kb = b_k * b_b[:, None]
        if USE_G:
            b_kb *= b_g[:, None]
        b_w = tl.dot(b_A, b_kb.to(b_k.dtype))
        _p_w_0 = (i_t * BT) + tl.arange(0, BT)
        _p_w_1 = (i_k * BK) + tl.arange(0, BK)
        tl.store(
            w + (bos * H + i_h) * K + _p_w_0[:, None] * (H * K) + _p_w_1[None, :] * (1),
            b_w.to(w.dtype.element_ty),
            mask=(_p_w_0[:, None] < (T)) & (_p_w_1[None, :] < (K)),
        )


def recompute_w_u_fwd(
    k: torch.Tensor,
    v: torch.Tensor,
    beta: torch.Tensor,
    A: torch.Tensor,
    g: torch.Tensor | None = None,
    cu_seqlens: torch.LongTensor | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Recompute w and u in WY representation.

    Args:
        k: keys [B, T, H, K]
        v: values [B, T, H, V]
        beta: betas [B, T, H]
        A: WY matrix [B, T, H, BT]
        g: gates (optional) [B, T, H]
        cu_seqlens: cumulative sequence lengths (optional)

    Returns:
        w: [B, T, H, K]
        u: [B, T, H, V]
    """
    B, T, H, K, V = *k.shape, v.shape[-1]
    BT = A.shape[-1]
    BK = 64
    BV = 64

    chunk_indices = (
        prepare_chunk_indices(cu_seqlens, BT) if cu_seqlens is not None else None
    )
    NT = triton.cdiv(T, BT) if cu_seqlens is None else len(chunk_indices)

    w = torch.empty_like(k)
    u = torch.empty_like(v)
    recompute_w_u_fwd_kernel[(NT, B * H)](
        k=k,
        v=v,
        beta=beta,
        w=w,
        u=u,
        A=A,
        g=g,
        cu_seqlens=cu_seqlens,
        chunk_indices=chunk_indices,
        T=T,
        H=H,
        K=K,
        V=V,
        BT=BT,
        BK=BK,
        BV=BV,
    )
    return w, u
