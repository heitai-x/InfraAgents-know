# SPDX-License-Identifier: MIT
# Copyright (C) 2024-2026, Advanced Micro Devices, Inc. All rights reserved.
# Adapted from flash-linear-attention: Copyright (c) 2023-2025, Songlin Yang, Yu Zhang

"""
Lower triangular matrix solver utilities.

This module provides functions for solving lower triangular linear systems
using Triton kernels, optimized for chunk-based operations.
"""

import os

import torch
import triton
import triton.language as tl

from aiter.ops.triton._triton_kernels.gated_delta_rule.gated_delta_rule_utils import (
    IS_TMA_SUPPORTED,
    autotune_cache_kwargs,
    input_guard,
)
from aiter.ops.triton._triton_kernels.gated_delta_rule.utils.index import (
    prepare_chunk_indices,
)
from aiter.ops.triton._triton_kernels.gated_delta_rule.utils.op import (
    make_tensor_descriptor,
)
from aiter.ops.triton.utils.tuned_config_utils import autotune_configs

FLA_TRIL_PRECISION = os.environ.get("FLA_TRIL_PRECISION", "ieee")
assert FLA_TRIL_PRECISION in [
    "ieee",
    "tf32",
    "tf32x3",
], f"FLA_TRIL_PRECISION must be one of 'ieee', 'tf32', or 'tf32x3', but got {FLA_TRIL_PRECISION}"
DOT_PRECISION_AUTOTUNE_LIST = (
    ["ieee"] if not IS_TMA_SUPPORTED else list({"ieee", FLA_TRIL_PRECISION})
)


# tl.make_block_ptr was removed in Triton 3.8 ("Block pointers have been removed
# in favor of the tensor descriptor API"). Every block access in this file is a
# row-major (BR, BC) tile with unit column stride, so plain pointer arithmetic
# with an explicit bounds mask reproduces the boundary_check=(0, 1) behaviour.
@triton.jit
def _bp_ld2d(base, R, C, rs, r0, c0, BR: tl.constexpr, BC: tl.constexpr):
    r = r0 + tl.arange(0, BR)
    c = c0 + tl.arange(0, BC)
    return tl.load(
        base + r[:, None] * rs + c[None, :],
        mask=(r < R)[:, None] & (c < C)[None, :],
        other=0.0,
    )


@triton.jit
def _bp_st2d(base, R, C, rs, r0, c0, val, BR: tl.constexpr, BC: tl.constexpr):
    r = r0 + tl.arange(0, BR)
    c = c0 + tl.arange(0, BC)
    tl.store(
        base + r[:, None] * rs + c[None, :],
        val,
        mask=(r < R)[:, None] & (c < C)[None, :],
    )


@triton.heuristics(
    {
        "IS_VARLEN": lambda args: args["cu_seqlens"] is not None,
    }
)
@triton.autotune(
    configs=autotune_configs(
        "GATED_DELTA_RULE",
        [
            triton.Config(
                {"DOT_PRECISION": "ieee"}, num_warps=num_warps, num_stages=num_stages
            )
            for num_warps in [1, 2, 4, 8]
            for num_stages in [2, 3, 4, 5]
        ],
        triton.Config({"DOT_PRECISION": "ieee"}, num_warps=4, num_stages=3),
    ),
    key=["BT"],
    **autotune_cache_kwargs,
)
@triton.jit(do_not_specialize=["T"])
def solve_tril_16x16_kernel(
    A,
    Ai,
    cu_seqlens,
    sequence_ids,
    chunk_ids,
    T,
    H: tl.constexpr,
    BT: tl.constexpr,
    USE_TMA: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    INDEX_STRIDE: tl.constexpr,
    DOT_PRECISION: tl.constexpr,
):
    i_t, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H
    if IS_VARLEN:
        i_n, i_t = tl.load(sequence_ids + i_t * INDEX_STRIDE).to(tl.int32), tl.load(
            chunk_ids + i_t * INDEX_STRIDE
        ).to(tl.int32)
        bos, eos = tl.load(cu_seqlens + i_n).to(tl.int32), tl.load(
            cu_seqlens + i_n + 1
        ).to(tl.int32)
        T = eos - bos
    else:
        bos, eos = i_b * T, i_b * T + T
    o_i = tl.arange(0, 16)
    m_A = o_i[:, None] > o_i[None, :]
    m_I = o_i[:, None] == o_i[None, :]

    A = A + (bos * H + i_h) * BT
    Ai = Ai + (bos * H + i_h) * 16

    offset = (i_t * 16) % BT
    if not USE_TMA:
        # [16, 16]
        b_A = _bp_ld2d(A, T, BT, H * BT, i_t * 16, offset, 16, 16).to(tl.float32)
        b_A = tl.where(m_A, b_A, 0)
    else:
        desc = make_tensor_descriptor(A, [T, BT], [H * BT, 1], [16, 16])
        desc_o = make_tensor_descriptor(Ai, [T, 16], [H * 16, 1], [16, 16])
        b_A = desc.load([i_t * 16, offset]).to(tl.float32)
        b_A = tl.where(m_A, b_A, 0)
    b_A = -b_A

    for i in range(2, min(16, T - i_t * 16)):
        # [16]; A is strictly lower triangular (enforced by the fused
        # cumsum+KKT kernel) so the
        # upper-tri elements are already zero, no defensive mask needed.
        b_a = -tl.load(A + (i_t * 16 + i) * H * BT + o_i + offset)
        b_a = b_a + tl.sum(b_a[:, None] * b_A, 0)
        b_A = tl.where((o_i == i)[:, None], b_a, b_A)
    b_A += m_I
    if not USE_TMA:
        _bp_st2d(
            Ai,
            T,
            16,
            H * 16,
            i_t * 16,
            0,
            b_A.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
    else:
        desc_o.store([i_t * 16, 0], b_A.to(desc_o.dtype, fp_downcast_rounding="rtne"))


@triton.heuristics(
    {
        "IS_VARLEN": lambda args: args["cu_seqlens"] is not None,
    }
)
@triton.autotune(
    configs=autotune_configs(
        "GATED_DELTA_RULE",
        [
            triton.Config(
                {"DOT_PRECISION": DOT_PRECISION},
                num_warps=num_warps,
                num_stages=num_stages,
            )
            for num_warps in [1, 2, 4, 8]
            for num_stages in [2, 3, 4, 5]
            for DOT_PRECISION in DOT_PRECISION_AUTOTUNE_LIST
        ],
        triton.Config({"DOT_PRECISION": "ieee"}, num_warps=4, num_stages=3),
    ),
    key=["H", "BT", "IS_VARLEN"],
    **autotune_cache_kwargs,
)
@triton.jit(do_not_specialize=["T"])
def merge_16x16_to_32x32_inverse_kernel(
    A,
    Ai,
    cu_seqlens,
    sequence_ids,
    chunk_ids,
    T,
    H: tl.constexpr,
    BT: tl.constexpr,
    USE_TMA: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    INDEX_STRIDE: tl.constexpr,
    DOT_PRECISION: tl.constexpr,
):
    i_t, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H
    if IS_VARLEN:
        i_n, i_t = tl.load(sequence_ids + i_t * INDEX_STRIDE).to(tl.int32), tl.load(
            chunk_ids + i_t * INDEX_STRIDE
        ).to(tl.int32)
        bos, eos = tl.load(cu_seqlens + i_n).to(tl.int32), tl.load(
            cu_seqlens + i_n + 1
        ).to(tl.int32)
        T = eos - bos
    else:
        bos, eos = i_b * T, i_b * T + T

    o_i = tl.arange(0, 16)
    m_A = o_i[:, None] > o_i[None, :]
    m_I = o_i[:, None] == o_i[None, :]
    A += (bos * H + i_h) * BT
    Ai += (bos * H + i_h) * BT

    if not USE_TMA:
        b_Ai_11 = _bp_ld2d(A, T, BT, H * BT, i_t * BT, 0, 16, 16).to(tl.float32)
        b_Ai_22 = _bp_ld2d(A, T, BT, H * BT, i_t * BT + 16, 16, 16, 16).to(tl.float32)
    else:
        desc = make_tensor_descriptor(A, [T, BT], [H * BT, 1], [16, 16])
        desc_o = make_tensor_descriptor(Ai, [T, BT], [H * BT, 1], [16, 16])
        b_Ai_11 = desc.load([i_t * BT + 0, 0]).to(tl.float32)
        b_Ai_22 = desc.load([i_t * BT + 16, 16]).to(tl.float32)

    # [16, 16]
    b_Ai_11 = -tl.where(m_A, b_Ai_11, 0)
    b_Ai_22 = -tl.where(m_A, b_Ai_22, 0)

    for i in range(2, min(16, T - i_t * BT)):
        b_a_11 = -tl.load(A + (i_t * BT + i) * H * BT + o_i)
        b_a_11 += tl.sum(b_a_11[:, None] * b_Ai_11, 0)
        b_Ai_11 = tl.where((o_i == i)[:, None], b_a_11, b_Ai_11)
    for i in range(16 + 2, min(32, T - i_t * BT)):
        b_a_22 = -tl.load(A + (i_t * BT + i) * H * BT + o_i + 16)
        b_a_22 += tl.sum(b_a_22[:, None] * b_Ai_22, 0)
        b_Ai_22 = tl.where((o_i == i - 16)[:, None], b_a_22, b_Ai_22)

    b_Ai_11 += m_I
    b_Ai_22 += m_I

    if not USE_TMA:
        b_A_21 = _bp_ld2d(A, T, BT, H * BT, i_t * BT + 16, 0, 16, 16).to(tl.float32)
    else:
        b_A_21 = desc.load([i_t * BT + 16, 0]).to(tl.float32)

    b_Ai_21 = -tl.dot(
        tl.dot(b_Ai_22, b_A_21, input_precision=DOT_PRECISION),
        b_Ai_11,
        input_precision=DOT_PRECISION,
    )

    # Ai has strict-lower + identity structure. The strict-upper 16x16 block
    # Ai_12 is implicitly zero -- write it explicitly so the caller can
    # allocate Ai via `torch.empty_like` instead of `torch.zeros_like` and
    # skip the memset on the critical path.
    z16 = tl.zeros([16, 16], dtype=b_Ai_11.dtype)

    if not USE_TMA:
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT,
            0,
            b_Ai_11.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT + 16,
            16,
            b_Ai_22.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT + 16,
            0,
            b_Ai_21.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(Ai, T, BT, H * BT, i_t * BT, 16, z16.to(Ai.dtype.element_ty), 16, 16)
    else:
        desc_o.store(
            [i_t * BT + 0, 0], b_Ai_11.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store(
            [i_t * BT + 16, 0], b_Ai_21.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store(
            [i_t * BT + 16, 16], b_Ai_22.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store([i_t * BT + 0, 16], z16.to(desc_o.dtype))


@triton.heuristics(
    {
        "IS_VARLEN": lambda args: args["cu_seqlens"] is not None,
    }
)
@triton.autotune(
    configs=autotune_configs(
        "GATED_DELTA_RULE",
        [
            triton.Config(
                {"DOT_PRECISION": DOT_PRECISION},
                num_warps=num_warps,
                num_stages=num_stages,
            )
            for num_warps in [1, 2, 4, 8]
            for num_stages in [2, 3, 4, 5]
            for DOT_PRECISION in DOT_PRECISION_AUTOTUNE_LIST
        ],
        triton.Config({"DOT_PRECISION": "ieee"}, num_warps=4, num_stages=3),
    ),
    key=["H", "BT", "IS_VARLEN"],
    **autotune_cache_kwargs,
)
@triton.jit(do_not_specialize=["T"])
def merge_16x16_to_64x64_inverse_kernel(
    A,
    Ai,
    cu_seqlens,
    sequence_ids,
    chunk_ids,
    T,
    H: tl.constexpr,
    BT: tl.constexpr,
    USE_TMA: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    INDEX_STRIDE: tl.constexpr,
    DOT_PRECISION: tl.constexpr,
):
    i_t, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H
    if IS_VARLEN:
        i_n, i_t = tl.load(sequence_ids + i_t * INDEX_STRIDE).to(tl.int32), tl.load(
            chunk_ids + i_t * INDEX_STRIDE
        ).to(tl.int32)
        bos, eos = tl.load(cu_seqlens + i_n).to(tl.int32), tl.load(
            cu_seqlens + i_n + 1
        ).to(tl.int32)
        T = eos - bos
    else:
        bos, eos = i_b * T, i_b * T + T

    o_i = tl.arange(0, 16)
    m_A = o_i[:, None] > o_i[None, :]
    m_I = o_i[:, None] == o_i[None, :]
    A += (bos * H + i_h) * BT
    Ai += (bos * H + i_h) * BT

    if not USE_TMA:
        b_Ai_11 = _bp_ld2d(A, T, BT, H * BT, i_t * BT, 0, 16, 16).to(tl.float32)
        b_Ai_22 = _bp_ld2d(A, T, BT, H * BT, i_t * BT + 16, 16, 16, 16).to(tl.float32)
        b_Ai_33 = _bp_ld2d(A, T, BT, H * BT, i_t * BT + 32, 32, 16, 16).to(tl.float32)
        b_Ai_44 = _bp_ld2d(A, T, BT, H * BT, i_t * BT + 48, 48, 16, 16).to(tl.float32)
    else:
        desc = make_tensor_descriptor(A, [T, BT], [H * BT, 1], [16, 16])
        desc_o = make_tensor_descriptor(Ai, [T, BT], [H * BT, 1], [16, 16])
        b_Ai_11 = desc.load([i_t * BT + 0, 0]).to(tl.float32)
        b_Ai_22 = desc.load([i_t * BT + 16, 16]).to(tl.float32)
        b_Ai_33 = desc.load([i_t * BT + 32, 32]).to(tl.float32)
        b_Ai_44 = desc.load([i_t * BT + 48, 48]).to(tl.float32)

    # [16, 16]
    b_Ai_11 = -tl.where(m_A, b_Ai_11, 0)
    b_Ai_22 = -tl.where(m_A, b_Ai_22, 0)
    b_Ai_33 = -tl.where(m_A, b_Ai_33, 0)
    b_Ai_44 = -tl.where(m_A, b_Ai_44, 0)

    # A is strict-lower-tri (the fused cumsum+KKT kernel enforces it), so
    # defensive `o_i < i` masks
    # inside the loops are redundant; dropping them saves a `tl.where`
    # per iteration in the serial triangular solve.
    for i in range(2, min(16, T - i_t * BT)):
        b_a_11 = -tl.load(A + (i_t * BT + i) * H * BT + o_i)
        b_a_11 += tl.sum(b_a_11[:, None] * b_Ai_11, 0)
        b_Ai_11 = tl.where((o_i == i)[:, None], b_a_11, b_Ai_11)
    for i in range(16 + 2, min(32, T - i_t * BT)):
        b_a_22 = -tl.load(A + (i_t * BT + i) * H * BT + o_i + 16)
        b_a_22 += tl.sum(b_a_22[:, None] * b_Ai_22, 0)
        b_Ai_22 = tl.where((o_i == i - 16)[:, None], b_a_22, b_Ai_22)
    for i in range(32 + 2, min(48, T - i_t * BT)):
        b_a_33 = -tl.load(A + (i_t * BT + i) * H * BT + o_i + 32)
        b_a_33 += tl.sum(b_a_33[:, None] * b_Ai_33, 0)
        b_Ai_33 = tl.where((o_i == i - 32)[:, None], b_a_33, b_Ai_33)
    for i in range(48 + 2, min(64, T - i_t * BT)):
        b_a_44 = -tl.load(A + (i_t * BT + i) * H * BT + o_i + 48)
        b_a_44 += tl.sum(b_a_44[:, None] * b_Ai_44, 0)
        b_Ai_44 = tl.where((o_i == i - 48)[:, None], b_a_44, b_Ai_44)
    b_Ai_11 += m_I
    b_Ai_22 += m_I
    b_Ai_33 += m_I
    b_Ai_44 += m_I

    if not USE_TMA:
        b_A_21 = _bp_ld2d(A, T, BT, H * BT, i_t * BT + 16, 0, 16, 16).to(tl.float32)
        b_A_31 = _bp_ld2d(A, T, BT, H * BT, i_t * BT + 32, 0, 16, 16).to(tl.float32)
        b_A_32 = _bp_ld2d(A, T, BT, H * BT, i_t * BT + 32, 16, 16, 16).to(tl.float32)
        b_A_41 = _bp_ld2d(A, T, BT, H * BT, i_t * BT + 48, 0, 16, 16).to(tl.float32)
        b_A_42 = _bp_ld2d(A, T, BT, H * BT, i_t * BT + 48, 16, 16, 16).to(tl.float32)
        b_A_43 = _bp_ld2d(A, T, BT, H * BT, i_t * BT + 48, 32, 16, 16).to(tl.float32)
    else:
        b_A_21 = desc.load([i_t * BT + 16, 0]).to(tl.float32)
        b_A_31 = desc.load([i_t * BT + 32, 0]).to(tl.float32)
        b_A_32 = desc.load([i_t * BT + 32, 16]).to(tl.float32)
        b_A_41 = desc.load([i_t * BT + 48, 0]).to(tl.float32)
        b_A_42 = desc.load([i_t * BT + 48, 16]).to(tl.float32)
        b_A_43 = desc.load([i_t * BT + 48, 32]).to(tl.float32)

    b_Ai_21 = -tl.dot(
        tl.dot(b_Ai_22, b_A_21, input_precision=DOT_PRECISION),
        b_Ai_11,
        input_precision=DOT_PRECISION,
    )
    b_Ai_32 = -tl.dot(
        tl.dot(b_Ai_33, b_A_32, input_precision=DOT_PRECISION),
        b_Ai_22,
        input_precision=DOT_PRECISION,
    )
    b_Ai_43 = -tl.dot(
        tl.dot(b_Ai_44, b_A_43, input_precision=DOT_PRECISION),
        b_Ai_33,
        input_precision=DOT_PRECISION,
    )

    b_Ai_31 = -tl.dot(
        b_Ai_33,
        tl.dot(b_A_31, b_Ai_11, input_precision=DOT_PRECISION)
        + tl.dot(b_A_32, b_Ai_21, input_precision=DOT_PRECISION),
        input_precision=DOT_PRECISION,
    )
    b_Ai_42 = -tl.dot(
        b_Ai_44,
        tl.dot(b_A_42, b_Ai_22, input_precision=DOT_PRECISION)
        + tl.dot(b_A_43, b_Ai_32, input_precision=DOT_PRECISION),
        input_precision=DOT_PRECISION,
    )
    b_Ai_41 = -tl.dot(
        b_Ai_44,
        tl.dot(b_A_41, b_Ai_11, input_precision=DOT_PRECISION)
        + tl.dot(b_A_42, b_Ai_21, input_precision=DOT_PRECISION)
        + tl.dot(b_A_43, b_Ai_31, input_precision=DOT_PRECISION),
        input_precision=DOT_PRECISION,
    )

    # Ai has strict-lower + identity structure. The 6 strict-upper sub-blocks
    # Ai_12, Ai_13, Ai_14, Ai_23, Ai_24, Ai_34 are implicitly zero -- write
    # them explicitly so the caller can allocate Ai via `torch.empty_like`
    # instead of `torch.zeros_like` (skips the memset on the critical path).
    z16 = tl.zeros([16, 16], dtype=b_Ai_11.dtype)

    if not USE_TMA:
        # 6 strict-upper sub-block zero ptrs
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT,
            0,
            b_Ai_11.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT + 16,
            16,
            b_Ai_22.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT + 32,
            32,
            b_Ai_33.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT + 48,
            48,
            b_Ai_44.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT + 16,
            0,
            b_Ai_21.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT + 32,
            0,
            b_Ai_31.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT + 32,
            16,
            b_Ai_32.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT + 48,
            0,
            b_Ai_41.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT + 48,
            16,
            b_Ai_42.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(
            Ai,
            T,
            BT,
            H * BT,
            i_t * BT + 48,
            32,
            b_Ai_43.to(Ai.dtype.element_ty, fp_downcast_rounding="rtne"),
            16,
            16,
        )
        _bp_st2d(Ai, T, BT, H * BT, i_t * BT, 16, z16.to(Ai.dtype.element_ty), 16, 16)
        _bp_st2d(Ai, T, BT, H * BT, i_t * BT, 32, z16.to(Ai.dtype.element_ty), 16, 16)
        _bp_st2d(Ai, T, BT, H * BT, i_t * BT, 48, z16.to(Ai.dtype.element_ty), 16, 16)
        _bp_st2d(
            Ai, T, BT, H * BT, i_t * BT + 16, 32, z16.to(Ai.dtype.element_ty), 16, 16
        )
        _bp_st2d(
            Ai, T, BT, H * BT, i_t * BT + 16, 48, z16.to(Ai.dtype.element_ty), 16, 16
        )
        _bp_st2d(
            Ai, T, BT, H * BT, i_t * BT + 32, 48, z16.to(Ai.dtype.element_ty), 16, 16
        )
    else:
        desc_o.store(
            [i_t * BT + 0, 0], b_Ai_11.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store(
            [i_t * BT + 16, 16], b_Ai_22.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store(
            [i_t * BT + 32, 32], b_Ai_33.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store(
            [i_t * BT + 48, 48], b_Ai_44.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store(
            [i_t * BT + 16, 0], b_Ai_21.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store(
            [i_t * BT + 32, 0], b_Ai_31.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store(
            [i_t * BT + 32, 16], b_Ai_32.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store(
            [i_t * BT + 48, 0], b_Ai_41.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store(
            [i_t * BT + 48, 16], b_Ai_42.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store(
            [i_t * BT + 48, 32], b_Ai_43.to(desc_o.dtype, fp_downcast_rounding="rtne")
        )
        desc_o.store([i_t * BT + 0, 16], z16.to(desc_o.dtype))
        desc_o.store([i_t * BT + 0, 32], z16.to(desc_o.dtype))
        desc_o.store([i_t * BT + 0, 48], z16.to(desc_o.dtype))
        desc_o.store([i_t * BT + 16, 32], z16.to(desc_o.dtype))
        desc_o.store([i_t * BT + 16, 48], z16.to(desc_o.dtype))
        desc_o.store([i_t * BT + 32, 48], z16.to(desc_o.dtype))


@input_guard
def solve_tril(
    A: torch.Tensor,
    cu_seqlens: torch.Tensor | None = None,
    chunk_indices: torch.Tensor | None = None,
    output_dtype: torch.dtype = torch.float,
    *,
    sequence_ids: torch.Tensor | None = None,
    chunk_ids: torch.Tensor | None = None,
    index_stride: int = 1,
) -> torch.Tensor:
    """
    Compute the inverse of the matrix I + A where A is strictly lower triangular.

    Args:
        A (torch.Tensor):
            [B, T, H, BT], where BT should only be 16, 32, or 64.
            A should be strictly lower triangular, i.e., A.triu() == 0.
        cu_seqlens (torch.Tensor):
            Integer cumulative sequence lengths with shape `[N+1]`. Supplying
            it enables variable-length indexing. Default: `None`.
        chunk_indices (torch.Tensor):
            Integer `[num_chunks, 2]` tensor containing interleaved sequence
            and local chunk IDs. Used only for variable-length inputs when
            separate IDs are not supplied. Default: `None`.
        output_dtype (torch.dtype):
            The dtype of the output tensor. Default: `torch.float`.
            If `None`, the output dtype will be the same as the input dtype.
        sequence_ids (torch.Tensor):
            One-dimensional integer sequence IDs on the same device as `A`.
            Must be passed together with `chunk_ids` for variable-length input.
        chunk_ids (torch.Tensor):
            One-dimensional integer local chunk IDs on the same device as `A`.
            Must be passed together with `sequence_ids`.
        index_stride (int):
            Element stride between IDs. Use `1` for separate contiguous ID
            tensors and `2` for flattened interleaved chunk indices.
            Default: `1`.

    Returns:
        (I + A)^-1 with the same shape as A
    """
    assert A.shape[-1] in [16, 32, 64], f"BT must be 16, 32, or 64, got {A.shape[-1]}"
    output_dtype = A.dtype if output_dtype is None else output_dtype

    B, T, H, BT = A.shape
    if (sequence_ids is None) != (chunk_ids is None):
        raise ValueError("`sequence_ids` and `chunk_ids` must be provided together.")
    if index_stride <= 0:
        raise ValueError(f"`index_stride` must be positive, got {index_stride}.")
    if cu_seqlens is not None and sequence_ids is None:
        if chunk_indices is None:
            chunk_indices = prepare_chunk_indices(cu_seqlens, BT)
        flat_chunk_indices = chunk_indices.reshape(-1)
        sequence_ids = flat_chunk_indices
        chunk_ids = flat_chunk_indices[1:]
        index_stride = 2
    NT = (
        len(sequence_ids) // index_stride
        if cu_seqlens is not None
        else triton.cdiv(T, BT)
    )

    # `empty_like` is safe because the kernels below explicitly write every
    # in-bounds element of Ai's chunked layout (strict-lower + diagonal + the
    # strict-upper blocks zeroed by tl.store). Out-of-bounds tail rows past
    # T-1 are never read by the downstream recompute_w_u kernel since it also
    # uses boundary_check.
    Ai = torch.empty_like(A, dtype=output_dtype)
    if BT == 16:
        merge_fn = solve_tril_16x16_kernel
    elif BT == 32:
        merge_fn = merge_16x16_to_32x32_inverse_kernel
    elif BT == 64:
        merge_fn = merge_16x16_to_64x64_inverse_kernel

    merge_fn[NT, B * H](
        A=A,
        Ai=Ai,
        cu_seqlens=cu_seqlens,
        sequence_ids=sequence_ids,
        chunk_ids=chunk_ids,
        T=T,
        H=H,
        BT=BT,
        INDEX_STRIDE=index_stride,
        USE_TMA=IS_TMA_SUPPORTED,
    )
    return Ai
