import torch
import triton
import triton.language as tl

from aiter.ops.triton._triton_kernels.gated_delta_rule.gated_delta_rule_utils import (
    IS_AMD,
    RCP_LN2,
    autotune_cache_kwargs,
)
from aiter.ops.triton._triton_kernels.gated_delta_rule.utils import (
    GatedDeltaRulePrefillMetadata,
    prepare_chunk_indices,
    prepare_rebased_cu_seqlens,
)
from aiter.ops.triton._triton_kernels.gated_delta_rule.utils.op import exp
from aiter.ops.triton.utils.tuned_config_utils import autotune_configs


@triton.jit
def safe_exp(x):
    return tl.exp(tl.where(x <= 0, x, float("-inf")))


@triton.heuristics({"IS_VARLEN": lambda args: args["cu_seqlens"] is not None})
@triton.jit(do_not_specialize=["T"])
def _fused_cumsum_kkt_kernel(
    g_ptr,
    k_ptr,
    beta_ptr,
    g_cumsum_ptr,
    A_ptr,
    cu_seqlens,
    chunk_indices,
    T,
    H: tl.constexpr,
    Hg: tl.constexpr,
    K: tl.constexpr,
    BT: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    i_t, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H

    if IS_VARLEN:
        i_n = tl.load(chunk_indices + i_t * 2).to(tl.int32)
        i_t_local = tl.load(chunk_indices + i_t * 2 + 1).to(tl.int32)
        bos = tl.load(cu_seqlens + i_n).to(tl.int32)
        eos = tl.load(cu_seqlens + i_n + 1).to(tl.int32)
        T_seq = eos - bos
        i_t = i_t_local
    else:
        bos = i_b * T
        T_seq = T

    o_t = tl.arange(0, BT)

    # Plain pointer arithmetic rather than tl.make_block_ptr, which is not
    # available in every Triton build we target.
    o_abs = i_t * BT + o_t
    m_t = o_abs < T_seq
    o_k = tl.arange(0, K)

    b_g = tl.load(g_ptr + bos * H + i_h + o_abs * H, mask=m_t, other=0.0).to(tl.float32)
    b_g_cumsum = tl.cumsum(b_g, axis=0)
    g_out_ptrs = g_cumsum_ptr + bos * H + i_h + o_abs * H
    tl.store(g_out_ptrs, b_g_cumsum.to(g_cumsum_ptr.dtype.element_ty), mask=m_t)

    b_beta = tl.load(beta_ptr + bos * H + i_h + o_abs * H, mask=m_t, other=0.0).to(
        tl.float32
    )

    b_k = tl.load(
        k_ptr
        + (bos * Hg + i_h // (H // Hg)) * K
        + o_abs[:, None] * (Hg * K)
        + o_k[None, :],
        mask=m_t[:, None],
        other=0.0,
    ).to(tl.float32)

    b_A = tl.dot(b_k, tl.trans(b_k))
    b_g_diff = b_g_cumsum[:, None] - b_g_cumsum[None, :]
    b_A = b_A * safe_exp(b_g_diff) * b_beta[:, None]
    b_A = tl.where(o_t[:, None] > o_t[None, :], b_A, 0.0)

    tl.store(
        A_ptr + (bos * H + i_h) * BT + o_abs[:, None] * (BT * H) + o_t[None, :],
        b_A.to(A_ptr.dtype.element_ty),
        mask=m_t[:, None],
    )


def fused_cumsum_kkt(
    g: torch.Tensor,
    k: torch.Tensor,
    beta: torch.Tensor,
    chunk_size: int = 64,
    cu_seqlens: torch.Tensor | None = None,
):
    """
    Fused cumsum + KKT.

    Args:
        g: [B, T, H]
        k: [B, T, Hg, K]
        beta: [B, T, H]

    Returns:
        g_cumsum: [B, H, T]
        A: [B, T, H, chunk_size], strictly lower triangular
    """
    B, T, H = g.shape
    Hg, K = k.shape[2], k.shape[3]

    if cu_seqlens is not None:
        chunk_indices = prepare_chunk_indices(cu_seqlens, chunk_size)
        NT = len(chunk_indices)
    else:
        chunk_indices = None
        NT = triton.cdiv(T, chunk_size)

    g_cumsum = torch.empty(B, T, H, device=g.device, dtype=torch.float32)
    A = torch.empty(B, T, H, chunk_size, device=k.device, dtype=torch.float32)

    _fused_cumsum_kkt_kernel[(NT, B * H)](
        g,
        k,
        beta,
        g_cumsum,
        A,
        cu_seqlens,
        chunk_indices,
        T,
        H,
        Hg,
        K,
        chunk_size,
        num_warps=4,
        num_stages=3,
    )
    return g_cumsum, A


if IS_AMD:
    _CUMSUM_KKT_CONFIGS = [
        triton.Config({"BK": 32}, num_warps=4, num_stages=2),
        triton.Config({"BK": 32}, num_warps=2, num_stages=2),
        triton.Config({"BK": 32}, num_warps=8, num_stages=2),
        triton.Config({"BK": 32}, num_warps=4, num_stages=3),
        triton.Config({"BK": 32}, num_warps=2, num_stages=3),
        triton.Config({"BK": 64}, num_warps=4, num_stages=2),
    ]
else:
    _CUMSUM_KKT_CONFIGS = [
        triton.Config({"BK": BK}, num_warps=nw, num_stages=ns)
        for BK in [32, 64]
        for nw in [2, 4]
        for ns in ([2, 3] if IS_AMD else [2, 3, 4])
    ]

_CUMSUM_KKT_DEFAULT_CONFIG = triton.Config({"BK": 32}, num_warps=4, num_stages=2)


@triton.heuristics({"IS_VARLEN": lambda args: args["cu_seqlens"] is not None})
@triton.autotune(
    configs=autotune_configs(
        "GATED_DELTA_RULE",
        _CUMSUM_KKT_CONFIGS,
        default_config=_CUMSUM_KKT_DEFAULT_CONFIG,
    ),
    key=["H", "K", "BT", "IS_VARLEN"],
    **autotune_cache_kwargs,
)
@triton.jit(do_not_specialize=["T"])
def fused_chunk_local_cumsum_scaled_dot_kkt_fwd_kernel(
    g,
    k,
    beta,
    g_cumsum_out,
    A_out,
    cu_seqlens,
    sequence_ids,
    chunk_ids,
    T,
    H: tl.constexpr,
    Hg: tl.constexpr,
    K: tl.constexpr,
    BT: tl.constexpr,
    BK: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    INDEX_STRIDE: tl.constexpr,
    USE_EXP2: tl.constexpr = False,
    G_SCALE: tl.constexpr = 1.0,
):
    i_t, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H
    T_flat = T
    if IS_VARLEN:
        i_n, i_t = (
            tl.load(sequence_ids + i_t * INDEX_STRIDE).to(tl.int32),
            tl.load(chunk_ids + i_t * INDEX_STRIDE).to(tl.int32),
        )
        bos, eos = (
            tl.load(cu_seqlens + i_n).to(tl.int32),
            tl.load(cu_seqlens + i_n + 1).to(tl.int32),
        )
        T = eos - bos
    else:
        bos = i_b * T

    o_t = i_t * BT + tl.arange(0, BT)
    m_t = o_t < T

    # Plain pointer arithmetic rather than tl.make_block_ptr, which is not
    # available in every Triton build we target.
    b_g = tl.load(g + bos * H + i_h + o_t * H, mask=m_t, other=0.0).to(tl.float32)
    b_g_cumsum = tl.cumsum(b_g, axis=0)
    # Store g_cumsum in log2 space when downstream kernels consume it with exp2:
    # exp2(x * RCP_LN2) == exp(x), keeping results identical. The scale arrives
    # as the constexpr G_SCALE (RCP_LN2 when use_exp2 else 1.0) so the kernel
    # never reads a module-level global; cumsum's linearity makes scaling before
    # or after the cumsum equivalent.
    if G_SCALE != 1.0:
        b_g_cumsum = b_g_cumsum * G_SCALE

    # g_cumsum is stored head-major [B, H, T] (stride 1 along T) so the
    # downstream solve/recompute, hidden-state and output kernels can read it
    # contiguously per (batch, head).
    if IS_VARLEN:
        g_out_base = g_cumsum_out + i_h * T_flat + bos
    else:
        g_out_base = g_cumsum_out + (i_b * H + i_h) * T_flat
    tl.store(
        g_out_base + o_t,
        b_g_cumsum.to(g_out_base.dtype.element_ty),
        mask=m_t,
    )

    b_beta = tl.load(beta + bos * H + i_h + o_t * H, mask=m_t, other=0.0)

    b_A = tl.zeros([BT, BT], dtype=tl.float32)
    k_base = k + (bos * Hg + i_h // (H // Hg)) * K
    for i_k in range(tl.cdiv(K, BK)):
        o_k = i_k * BK + tl.arange(0, BK)
        m_k = o_k < K
        b_k = tl.load(
            k_base + o_t[:, None] * (Hg * K) + o_k[None, :],
            mask=m_t[:, None] & m_k[None, :],
            other=0.0,
        )
        b_kb = b_k * b_beta[:, None]
        b_A = tl.dot(b_kb.to(b_k.dtype), tl.trans(b_k), acc=b_A)

    b_g_diff = b_g_cumsum[:, None] - b_g_cumsum[None, :]
    m_A = (o_t[:, None] > o_t[None, :]) & (m_t[:, None] & m_t)
    b_gate = tl.math.exp2(b_g_diff) if USE_EXP2 else exp(b_g_diff)
    b_A = tl.where(m_A, b_A * b_gate, 0.0)

    o_bt = tl.arange(0, BT)
    tl.store(
        A_out + (bos * H + i_h) * BT + o_t[:, None] * (BT * H) + o_bt[None, :],
        b_A.to(A_out.dtype.element_ty),
        mask=m_t[:, None],
    )


def fused_chunk_local_cumsum_scaled_dot_kkt_fwd(
    k: torch.Tensor,
    beta: torch.Tensor,
    g: torch.Tensor,
    cu_seqlens: torch.LongTensor | None = None,
    chunk_size: int = 64,
    g_output_dtype: torch.dtype = torch.float32,
    A_output_dtype: torch.dtype = torch.float32,
    use_exp2: bool = True,
    num_decodes: int = 0,
    num_decode_tokens: int = 0,
    prefill_metadata: GatedDeltaRulePrefillMetadata | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Fused cumsum + scaled dot KKT (optimized, with autotuning).

    Args:
        k: [B, T, Hg, K]
        beta: [B, T, H]
        g: [B, T, H], raw forget gate increments
        cu_seqlens: [N+1]
        chunk_size: int (must be 64)
        g_output_dtype: dtype for g_cumsum (default fp32)
        A_output_dtype: dtype for A_raw (default fp32)
        use_exp2: when True, store g_cumsum in log2 space (scaled by RCP_LN2)
            so downstream kernels can use exp2; A_raw is unaffected.

    Returns:
        g_cumsum: [B, H, T], head-major
        A_raw: [B, T, H, 64]
    """
    B, T, Hg, K = k.shape
    H = beta.shape[-1]
    BT = chunk_size

    # Pass the ORIGINAL (cache-stable) cu_seqlens to prepare_chunk_indices
    # together with num_decodes/num_decode_tokens, so the chunk-index build
    # caches on the stable tensor identity and never re-fires the .tolist()
    # D2H across forward calls. The kernel walks the pre-sliced prefill data
    # via the rebased cu_seqlens.
    if cu_seqlens is not None:
        if prefill_metadata is not None:
            prefill_metadata.validate(
                cu_seqlens=cu_seqlens,
                chunk_size=BT,
                num_decodes=num_decodes,
                num_decode_tokens=num_decode_tokens,
                total_prefill_tokens=T,
                num_sequences=len(cu_seqlens) - 1,
            )
            schedule = prefill_metadata.get_chunk_schedule(
                BT,
                num_decodes=num_decodes,
                num_decode_tokens=num_decode_tokens,
            )
            sequence_ids = schedule.sequence_ids
            chunk_ids = schedule.chunk_ids
            kernel_cu_seqlens = schedule.kernel_cu_seqlens
            index_stride = 1
        else:
            chunk_indices = prepare_chunk_indices(
                cu_seqlens, BT, num_decodes, num_decode_tokens
            )
            flat_chunk_indices = chunk_indices.reshape(-1)
            sequence_ids = flat_chunk_indices
            chunk_ids = flat_chunk_indices[1:]
            kernel_cu_seqlens = prepare_rebased_cu_seqlens(
                cu_seqlens, num_decodes, num_decode_tokens
            )
            index_stride = 2
        NT = len(sequence_ids) // index_stride
    else:
        sequence_ids = None
        chunk_ids = None
        kernel_cu_seqlens = None
        index_stride = 1
        NT = triton.cdiv(T, BT)

    g_cumsum_out = torch.empty(B, H, T, device=g.device, dtype=g_output_dtype)
    A_out = torch.empty(B, T, H, BT, device=k.device, dtype=A_output_dtype)

    fused_chunk_local_cumsum_scaled_dot_kkt_fwd_kernel[(NT, B * H)](
        g,
        k,
        beta,
        g_cumsum_out,
        A_out,
        kernel_cu_seqlens,
        sequence_ids,
        chunk_ids,
        T=T,
        H=H,
        Hg=Hg,
        K=K,
        BT=BT,
        INDEX_STRIDE=index_stride,
        USE_EXP2=use_exp2,
        G_SCALE=RCP_LN2 if use_exp2 else 1.0,
    )
    return g_cumsum_out, A_out
