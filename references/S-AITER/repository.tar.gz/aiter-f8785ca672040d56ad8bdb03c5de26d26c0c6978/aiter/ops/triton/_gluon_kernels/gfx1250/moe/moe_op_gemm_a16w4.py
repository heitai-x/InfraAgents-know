import torch
import triton.experimental.gluon.language as gl
import triton.language as tl
from triton.experimental import gluon

from aiter.ops.triton._triton_kernels.moe.activations import _swiglu
from aiter.ops.triton.utils._triton.pid_preprocessing import pid_grid, remap_xcd


def matmul_launch_metadata(grid, kernel, args):
    ret = {}
    M, N, K = None, args["N"], args["K"]
    Y, X, W = args["Y"], args["X"], args["W"]
    hist = args["ExptHist"]
    if hist is not None:
        n_rows = int(hist.float().mean())
        n_tokens = float(hist.sum())
        n_w_bytes = (W.numel() * W.element_size() // hist.numel()) * (hist > 0).sum()
    else:
        n_tokens = None
        n_w_bytes = W.numel() * W.element_size()

    def repr(s, x):
        return f"{s}={x}" if x is not None else f"E_{len(hist)}({s})={n_rows}"

    nbits = X.dtype.itemsize * 8
    ret["name"] = f"{kernel.name} [{repr('M', M)}, {repr('N', N)}, {repr('K', K)}]"
    gindx = args.get("GatherIndx", None)
    if gindx is not None:
        ret["name"] += "_layer1"
    else:
        ret["name"] += "_layer2"
    if args["B"] is not None:
        ret["name"] += "_bias"
    if args["APPLY_SWIGLU"]:
        ret["name"] += "_swiglu"

    fM = n_tokens
    fK = K if K is not None else n_tokens
    ret[f"flops{nbits}"] = 2.0 * fM * N * fK

    gindx = args.get("GatherIndx", None)
    n_x_bytes = X.numel() * X.element_size()
    n_y_bytes = Y.numel() * Y.element_size()
    if hist is not None:
        assert n_tokens is not None
        n_expts_act = args["N_EXPTS_ACT"]

        if gindx is not None:
            # recreate inverse GatherIndx.
            dst = torch.full_like(gindx, -1)
            idx = torch.arange(len(gindx), device=gindx.device, dtype=torch.int32)
            mask = gindx != -1
            dst[gindx[mask]] = idx[mask]
            n_read_rows = (dst.view((-1, n_expts_act)) != -1).any(dim=1).sum()
        else:
            n_read_rows = n_tokens
        n_x_bytes = n_read_rows * X.shape[-1] * X.element_size()
        n_y_bytes = n_tokens * Y.shape[-1] * Y.element_size()
    ret["bytes"] = int(n_x_bytes + n_y_bytes + n_w_bytes)

    return ret


# TODO: using aiter swizzle instead can lead to perf degradation in rare cases
@gluon.jit
def xcd_swizzle(pid, domain_size, XCD_SWIZZLE: gl.constexpr):
    """
    Swizzle the program id based on integer XCD_SWIZZLE.
    """
    pids_per_group = domain_size // XCD_SWIZZLE
    extra_pid_groups = domain_size % XCD_SWIZZLE
    group = pid % XCD_SWIZZLE
    local_pid = pid // XCD_SWIZZLE
    new_pid = group * pids_per_group + min(group, extra_pid_groups) + local_pid
    return new_pid


@gluon.jit
def unswizzle_mx_scale_gfx1250(
    scale, BLOCK_N, MX_SCALE_BLOCK_K, PRESHUFFLE_FACTOR, SCALE_KWIDTH, MX_PACK_DIVISOR
):
    # Step 1: invert the host-side preshuffle. The loaded compact tile is
    # (BLOCK_N // PRESHUFFLE_FACTOR, MX_SCALE_BLOCK_K * PRESHUFFLE_FACTOR); the
    # contiguous dim packs (k0, n1, k1), so reshape + permute reassembles the
    # logical compact scale (BLOCK_N, MX_SCALE_BLOCK_K) (one byte per 32-elem group).
    scale = (
        scale.reshape(
            (
                BLOCK_N // PRESHUFFLE_FACTOR,
                MX_SCALE_BLOCK_K // SCALE_KWIDTH,
                PRESHUFFLE_FACTOR,
                SCALE_KWIDTH,
            )
        )
        .permute((0, 2, 1, 3))
        .reshape((BLOCK_N, MX_SCALE_BLOCK_K))
    )

    return scale


@gluon.jit(launch_metadata=matmul_launch_metadata)
def _moe_gemm_a16w4(
    Y,
    stride_y_k,
    stride_y_m,
    stride_y_n,
    X,
    stride_x_m,
    stride_x_k,
    W,
    stride_w_e,
    stride_w_k,
    stride_w_n,
    WMxScale,  # E8M0 compact scale (one byte per 32 values along K)
    stride_w_mx_e,
    stride_w_mx_n,
    stride_w_mx_k,
    B,
    stride_b_e,  # Bias
    Gammas,
    num_tokens,
    N,
    K,  # shapes
    # expt data
    GatherIndx,
    ExptHist,
    ExptOffs,
    ExptOffsSum,
    ExptData,
    # true grid size
    grid_m,
    grid_n,
    # fused activation function
    APPLY_SWIGLU: gl.constexpr,
    alpha,
    limit,
    ACTIVATION_REDUCTION_N: gl.constexpr,
    ADD_RESIDUAL: gl.constexpr,
    # MoE config
    N_EXPTS_ACT: gl.constexpr,
    # optimization config
    BLOCK_M: gl.constexpr,
    BLOCK_N: gl.constexpr,
    BLOCK_K: gl.constexpr,
    GROUP_M: gl.constexpr,
    XCD_SWIZZLE: gl.constexpr,
    NUM_BUFFERS: gl.constexpr,
    # Must be None: the kernel takes pre-expanded e8m0 scales (one byte per fp4 element).
    SWIZZLE_MX_SCALE: gl.constexpr,
    EVEN_K: gl.constexpr,
    SPLIT_K: gl.constexpr,
    W_CACHE_MODIFIER: gl.constexpr,
    num_warps: gl.constexpr,
    UPCAST_INDICES: gl.constexpr = False,
):
    MX_PACK_DIVISOR: gl.constexpr = 32
    NUM_TDM_OPS: gl.constexpr = 3  # X, W (fp4 packed), W_scale (e8m0 expanded)
    w_type: gl.constexpr = W.dtype.element_ty
    gl.static_assert(w_type == gl.uint8, "mx_weight_ptr must be uint8")
    gl.static_assert(
        WMxScale.dtype.element_ty == gl.uint8, "mx_scale_ptr must be uint8"
    )
    gl.static_assert(
        BLOCK_K % MX_PACK_DIVISOR == 0, "BLOCK_K must be a multiple of MX_PACK_DIVISOR"
    )
    gl.static_assert(num_warps == 4 or num_warps == 8, "num_warps must be 4 or 8")

    OUT_BLOCK_N: gl.constexpr = BLOCK_N // ACTIVATION_REDUCTION_N
    yN = N // ACTIVATION_REDUCTION_N
    CLAMP_BOUNDS: gl.constexpr = not EVEN_K

    pid = gl.program_id(0)

    index_type: gl.constexpr = gl.int64 if UPCAST_INDICES else gl.int32

    if XCD_SWIZZLE != 1:
        padding_m = grid_m - gl.load(ExptOffsSum)
        unpadded_m = grid_m - padding_m
        total_actual_tiles = unpadded_m * grid_n
        if padding_m > 0 and pid >= total_actual_tiles:
            return
        pid = remap_xcd(pid, total_actual_tiles, XCD_SWIZZLE)
    else:
        unpadded_m = grid_m

    pid_m, pid_n = pid_grid(pid, unpadded_m, grid_n, 1)

    # unpack expert data
    expt_data = gl.load(ExptData + pid_m)
    if XCD_SWIZZLE == 1 and expt_data == -1:
        return
    expt_id = expt_data & 0x0000FFFF
    block_id = expt_data >> 16
    M = gl.load(ExptHist + expt_id)
    start_m = gl.load(ExptOffs + expt_id)
    expt_id = expt_id.to(index_type)

    # X / gather offsets
    offs_x_m_scalar = BLOCK_M * block_id
    if GatherIndx is None:
        X += start_m * stride_x_m
        offs_x_m = offs_x_m_scalar  # unused in non-gather path
    else:
        if GatherIndx.dtype.element_ty == gl.uint16:
            IDX_LAYOUT: gl.constexpr = gl.SliceLayout(
                0, gl.BlockedLayout([1, 16], [32, 1], [1, num_warps], [0, 1])
            )
            oob_idx = (num_tokens).to(gl.uint16)
        else:
            gl.static_assert(
                GatherIndx.dtype.element_ty == gl.int32,
                "Gather index datatype should be uint16 or int32",
            )
            IDX_LAYOUT: gl.constexpr = gl.SliceLayout(
                0, gl.BlockedLayout([1, 8], [32, 1], [1, num_warps], [0, 1])
            )
            oob_idx = num_tokens

        offs_x_m = BLOCK_M * block_id + gl.arange(0, BLOCK_M, layout=IDX_LAYOUT)
        mask_idx = offs_x_m < M
        offs_x_m = offs_x_m % M
        GatherIndx += start_m
        offs_x_m = gl.load(GatherIndx + offs_x_m) // N_EXPTS_ACT
        offs_x_m = gl.where(mask_idx, offs_x_m, oob_idx)

    W_K_DIVISOR: gl.constexpr = 2  # fp4: two values packed per uint8 along K
    W_N_DIVISOR: gl.constexpr = 1
    PACKED_BLOCK_K_W: gl.constexpr = BLOCK_K // W_K_DIVISOR
    PACKED_BLOCK_N_W: gl.constexpr = BLOCK_N // W_N_DIVISOR
    MX_SCALE_BLOCK_K: gl.constexpr = BLOCK_K // MX_PACK_DIVISOR

    off_w_n = pid_n * PACKED_BLOCK_N_W

    W += expt_id * stride_w_e
    WMxScale += expt_id * stride_w_mx_e
    if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
        gl.static_assert(stride_w_mx_k is not None)
        gl.static_assert(stride_w_mx_n is not None)
        PRESHUFFLE_FACTOR: gl.constexpr = 32
        PACKED_MX_BLOCK: gl.constexpr = MX_SCALE_BLOCK_K * PRESHUFFLE_FACTOR
        SCALE_BLOCK_N: gl.constexpr = BLOCK_N // PRESHUFFLE_FACTOR
        SCALE_KWIDTH: gl.constexpr = 8
    else:
        PRESHUFFLE_FACTOR: gl.constexpr = 1
        PACKED_MX_BLOCK: gl.constexpr = MX_SCALE_BLOCK_K
        SCALE_BLOCK_N: gl.constexpr = BLOCK_N

    # Scale tile offsets are in units of the scale descriptor's own blocking
    # (N block = SCALE_BLOCK_N, K block = PACKED_MX_BLOCK) -- NOT the weight's
    # BLOCK_N / BLOCK_K. For the compact (non-swizzle) scale the K dimension is
    # cdiv(K, 32), so the per-tile K step is PACKED_MX_BLOCK (= MX_SCALE_BLOCK_K),
    # not BLOCK_K.
    off_w_n_scale = pid_n * SCALE_BLOCK_N

    # WMMA layout for plain bf16 x bf16: instr_shape [16, 16, 32], k_width=8.
    if num_warps == 4:
        WARP_BASES: gl.constexpr = [[0, 1], [0, 2]]
    else:
        if BLOCK_M == 16:
            WARP_BASES: gl.constexpr = [[0, 1], [0, 2], [0, 4]]
        else:
            WARP_BASES: gl.constexpr = [[0, 1], [0, 2], [1, 0]]

    WMMA_LAYOUT: gl.constexpr = gl.amd.AMDWMMALayout(
        version=3,
        transposed=True,
        warp_bases=WARP_BASES,
        reg_bases=[],
        instr_shape=[16, 16, 32],
    )
    DOT_LAYOUT_X: gl.constexpr = gl.DotOperandLayout(
        operand_index=0, parent=WMMA_LAYOUT, k_width=8
    )
    DOT_LAYOUT_W: gl.constexpr = gl.DotOperandLayout(
        operand_index=1, parent=WMMA_LAYOUT, k_width=8
    )

    # Blocked layouts for fp4-packed W (BLOCK_N, BLOCK_K // 2) and its expanded e8m0
    # scale (BLOCK_N, BLOCK_K). size_per_thread along K doubles for the scale layout
    # so the unpack along K lines up element-for-element with the scale.
    # threads_per_warp = [8, 4] = 32 (wave32 on gfx1250).

    PACKED_LOAD_LAYOUT: gl.constexpr = gl.DistributedLinearLayout(
        reg_bases=[
            [0, 1],
            [0, 2],
            [0, 4],
            [0, 8],
            [0, 32],
            [0, 64],
            [0, 128],
            [64, 0],
        ],
        lane_bases=[[1, 0], [2, 0], [4, 0], [8, 0], [0, 16]],
        warp_bases=[[16, 0], [32, 0]],
        block_bases=[],
        shape=[128, 256],
    )
    PACKED_DOT_LAYOUT: gl.constexpr = gl.DistributedLinearLayout(
        reg_bases=[
            [0, 1],
            [0, 2],
            [0, 8],
            [0, 16],
            [0, 32],
            [0, 64],
            [0, 128],
            [64, 0],
        ],
        lane_bases=[[1, 0], [2, 0], [4, 0], [8, 0], [0, 4]],
        warp_bases=[[16, 0], [32, 0]],
        block_bases=[],
        shape=[128, 256],
    )
    COMPACT_SCALE_LAYOUT: gl.constexpr = gl.DistributedLinearLayout(
        reg_bases=[[0, 1], [0, 2], [0, 4], [0, 8], [64, 0]],
        lane_bases=[[1, 0], [2, 0], [4, 0], [8, 0], [0, 0]],
        warp_bases=[[16, 0], [32, 0]],
        block_bases=[],
        shape=[128, 16],
    )

    SHARED_LAYOUT_X: gl.constexpr = gl.PaddedSharedLayout.with_identity_for(
        [[BLOCK_K, 8]], [BLOCK_M, BLOCK_K], [1, 0]
    )
    SHARED_LAYOUT_W: gl.constexpr = gl.PaddedSharedLayout.with_identity_for(
        [[PACKED_BLOCK_K_W, 16]], [BLOCK_N, PACKED_BLOCK_K_W], [1, 0]
    )
    SHARED_LAYOUT_W_SCALES: gl.constexpr = gl.PaddedSharedLayout.with_identity_for(
        [[PACKED_MX_BLOCK, 16]],
        [SCALE_BLOCK_N, PACKED_MX_BLOCK],
        [1, 0],
    )
    SHARED_LAYOUT_Y: gl.constexpr = gl.PaddedSharedLayout.with_identity_for(
        [[OUT_BLOCK_N, 8]], [BLOCK_M, OUT_BLOCK_N], [1, 0]
    )

    if GatherIndx is None:
        x_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=X,
            shape=(M, K),
            strides=(stride_x_m, stride_x_k),
            block_shape=(BLOCK_M, BLOCK_K),
            layout=SHARED_LAYOUT_X,
        )
    else:
        x_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=X,
            shape=(num_tokens, K),
            strides=(stride_x_m, stride_x_k),
            block_shape=(BLOCK_M, BLOCK_K),
            layout=SHARED_LAYOUT_X,
        )

    w_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
        base=W,
        shape=(N, K // W_K_DIVISOR),
        strides=(stride_w_n, stride_w_k),
        block_shape=(BLOCK_N, PACKED_BLOCK_K_W),
        layout=SHARED_LAYOUT_W,
    )

    ws_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
        base=WMxScale,
        shape=(N // PRESHUFFLE_FACTOR, tl.cdiv(K, MX_PACK_DIVISOR) * PRESHUFFLE_FACTOR),
        strides=(stride_w_mx_n, stride_w_mx_k),
        block_shape=(SCALE_BLOCK_N, PACKED_MX_BLOCK),
        layout=SHARED_LAYOUT_W_SCALES,
    )

    x_buffer = gl.allocate_shared_memory(
        x_desc.dtype, shape=[NUM_BUFFERS] + x_desc.block_shape, layout=x_desc.layout
    )
    w_buffer = gl.allocate_shared_memory(
        w_desc.dtype, shape=[NUM_BUFFERS] + w_desc.block_shape, layout=w_desc.layout
    )
    ws_buffer = gl.allocate_shared_memory(
        ws_desc.dtype,
        shape=[NUM_BUFFERS] + ws_desc.block_shape,
        layout=ws_desc.layout,
    )

    write_idx = 0
    read_idx = 0

    # Prologue: prime NUM_BUFFERS - 1 tile loads (X, W-packed, W-scale-expanded).
    for _ in gl.static_range(NUM_BUFFERS - 1):
        w_idx = write_idx % NUM_BUFFERS
        if GatherIndx is None:
            gl.amd.gfx1250.tdm.async_load(
                x_desc, [offs_x_m_scalar, 0], x_buffer.index(w_idx)
            )
        else:
            gl.amd.gfx1250.tdm.async_gather(x_desc, offs_x_m, x_buffer.index(w_idx))
        gl.amd.gfx1250.tdm.async_load(w_desc, [off_w_n, 0], w_buffer.index(w_idx))
        gl.amd.gfx1250.tdm.async_load(
            ws_desc, [off_w_n_scale, 0], ws_buffer.index(w_idx)
        )

        x_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            x_desc, add_offsets=[0, BLOCK_K], clamp_bounds=CLAMP_BOUNDS
        )
        w_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            w_desc, add_offsets=[0, PACKED_BLOCK_K_W], clamp_bounds=CLAMP_BOUNDS
        )
        ws_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            ws_desc, add_offsets=[0, PACKED_MX_BLOCK], clamp_bounds=CLAMP_BOUNDS
        )

        write_idx += 1

    num_k_iter = tl.cdiv(K, BLOCK_K)

    acc = gl.zeros((BLOCK_M, BLOCK_N), dtype=gl.float32, layout=WMMA_LAYOUT)

    # Steady state: each iteration issues 1 tile and consumes 1 tile.
    # NUM_BUFFERS - 1 tiles stay in flight.
    for _ in range(num_k_iter - (NUM_BUFFERS - 1)):
        # issue next tile
        w_idx = write_idx % NUM_BUFFERS
        if GatherIndx is None:
            gl.amd.gfx1250.tdm.async_load(
                x_desc, [offs_x_m_scalar, 0], x_buffer.index(w_idx)
            )
        else:
            gl.amd.gfx1250.tdm.async_gather(x_desc, offs_x_m, x_buffer.index(w_idx))
        gl.amd.gfx1250.tdm.async_load(w_desc, [off_w_n, 0], w_buffer.index(w_idx))
        gl.amd.gfx1250.tdm.async_load(
            ws_desc, [off_w_n_scale, 0], ws_buffer.index(w_idx)
        )

        x_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            x_desc, add_offsets=[0, BLOCK_K], clamp_bounds=CLAMP_BOUNDS
        )
        w_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            w_desc, add_offsets=[0, PACKED_BLOCK_K_W], clamp_bounds=CLAMP_BOUNDS
        )
        ws_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            ws_desc, add_offsets=[0, PACKED_MX_BLOCK], clamp_bounds=CLAMP_BOUNDS
        )

        write_idx += 1

        # wait for the oldest in-flight tile, then consume it
        gl.amd.gfx1250.tdm.async_wait((NUM_BUFFERS - 1) * NUM_TDM_OPS)
        r_idx = read_idx % NUM_BUFFERS
        x_tile = x_buffer.index(r_idx).load(layout=DOT_LAYOUT_X)
        w_packed = w_buffer.index(r_idx).load(layout=PACKED_LOAD_LAYOUT)
        w_packed = gl.convert_layout(w_packed, layout=PACKED_DOT_LAYOUT)
        ws_buffer_slice = ws_buffer.index(r_idx)
        if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
            ws_buffer_slice = unswizzle_mx_scale_gfx1250(
                ws_buffer_slice,
                BLOCK_N,
                MX_SCALE_BLOCK_K,
                PRESHUFFLE_FACTOR,
                SCALE_KWIDTH,
                MX_PACK_DIVISOR,
            )
        w_scale = ws_buffer_slice.load(layout=COMPACT_SCALE_LAYOUT)
        # fp4 -> bf16 with compact per-32 e8m0 scale folded in directly.
        w_bf16 = gl.amd.gfx1250.scaled_upcast(w_packed, w_scale, gl.bfloat16, axis=1)
        # (N, K) -> (K, N) for the B operand of WMMA, then move to the dot-operand layout.
        w_kn = gl.convert_layout(w_bf16.trans(1, 0), DOT_LAYOUT_W)
        acc = gl.amd.gfx1250.wmma(x_tile, w_kn, acc)
        read_idx += 1

    if B is not None:
        BPtrs = B + expt_id * stride_b_e
        SHARED_LAYOUT_BIAS: gl.constexpr = gl.SwizzledSharedLayout(1, 1, 1, [1, 0])
        bias_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=BPtrs,
            shape=(1, N),
            strides=(N, 1),
            block_shape=(1, BLOCK_N),
            layout=SHARED_LAYOUT_BIAS,
        )
        bias_buffer = gl.allocate_shared_memory(
            bias_desc.dtype, shape=[1, BLOCK_N], layout=bias_desc.layout
        )
        gl.amd.gfx1250.tdm.async_load(
            bias_desc,
            [0, pid_n * BLOCK_N],
            bias_buffer,
        )
        TDM_BIAS_WAIT: gl.constexpr = 1
    else:
        TDM_BIAS_WAIT: gl.constexpr = 0

    # Epilogue: drain remaining NUM_BUFFERS - 1 tiles with a counting-down wait threshold.
    for i in gl.static_range(NUM_BUFFERS - 1):
        gl.amd.gfx1250.tdm.async_wait(
            (NUM_BUFFERS - 2 - i) * NUM_TDM_OPS + TDM_BIAS_WAIT
        )
        r_idx = read_idx % NUM_BUFFERS
        x_tile = x_buffer.index(r_idx).load(layout=DOT_LAYOUT_X)
        w_packed = w_buffer.index(r_idx).load(layout=PACKED_LOAD_LAYOUT)
        w_packed = gl.convert_layout(w_packed, layout=PACKED_DOT_LAYOUT)
        ws_buffer_slice = ws_buffer.index(r_idx)

        if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
            ws_buffer_slice = unswizzle_mx_scale_gfx1250(
                ws_buffer_slice,
                BLOCK_N,
                MX_SCALE_BLOCK_K,
                PRESHUFFLE_FACTOR,
                SCALE_KWIDTH,
                MX_PACK_DIVISOR,
            )
        w_scale = ws_buffer_slice.load(layout=COMPACT_SCALE_LAYOUT)
        w_bf16 = gl.amd.gfx1250.scaled_upcast(w_packed, w_scale, gl.bfloat16, axis=1)
        w_kn = gl.convert_layout(w_bf16.trans(1, 0), DOT_LAYOUT_W)
        acc = gl.amd.gfx1250.wmma(x_tile, w_kn, acc)
        read_idx += 1

    # bias / activation / write-back
    if B is not None:
        gl.amd.gfx1250.tdm.async_wait(0)
        bias = bias_buffer.reshape((BLOCK_N,)).load(
            layout=gl.SliceLayout(0, WMMA_LAYOUT)
        )
        acc = acc + bias[None, :]

    if APPLY_SWIGLU:
        out = _swiglu(acc, alpha, limit, ADD_RESIDUAL=ADD_RESIDUAL)
        # out = _swiglu(acc, alpha=1.0, limit=1.0, ADD_RESIDUAL=ADD_RESIDUAL)
        tl.static_assert(
            out.shape[1] == OUT_BLOCK_N,
            f"Activation fn out.shape[1] ({out.shape[1]}) doesn't match computed OUT_BLOCK_N ({OUT_BLOCK_N})",
        )
    else:
        tl.static_assert(
            ACTIVATION_REDUCTION_N == 1,
            "Activation reduction must be 1 if no activation fn is provided",
        )
        out = acc

    if Gammas is not None:
        offs_m = BLOCK_M * block_id + gl.arange(0, BLOCK_M)
        mask_m = offs_m < M
        gammas = gl.amd.cdna3.buffer_load(
            Gammas, start_m + offs_m, mask=mask_m, other=0.0
        )
        out *= gammas[:, None]

    out = out.to(gl.bfloat16)

    # TDM Store: accumulator -> shared memory -> global memory
    Y += start_m * stride_y_m
    y_buffer = gl.allocate_shared_memory(
        Y.type.element_ty,
        shape=[BLOCK_M, OUT_BLOCK_N],
        layout=SHARED_LAYOUT_Y,
    )
    y_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
        base=Y,
        shape=(M, yN),
        strides=(stride_y_m, stride_y_n),
        block_shape=(BLOCK_M, OUT_BLOCK_N),
        layout=SHARED_LAYOUT_Y,
    )
    y_buffer.store(out)
    gl.amd.gfx1250.tdm.async_store(
        y_desc, [block_id * BLOCK_M, pid_n * OUT_BLOCK_N], y_buffer
    )
    gl.amd.gfx1250.tdm.async_wait(0)
