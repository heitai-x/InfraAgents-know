import torch
import triton.experimental.gluon.language as gl
from triton._C.libtriton.gluon_ir import make_cga_layout
from triton.experimental import gluon

from aiter.ops.triton._triton_kernels.moe.activations import _swiglu
from aiter.ops.triton._triton_kernels.quant.quant import _mxfp4_quant_op
from aiter.ops.triton.utils._triton.kernel_repr import make_kernel_repr
from aiter.ops.triton.utils._triton.pid_preprocessing import pid_grid, remap_xcd

_MOE_GEMM_A4W4_REPR_KEYS = [
    "BLOCK_M",
    "BLOCK_N",
    "BLOCK_K",
    "SWIZZLE_MX_SCALE",
    "APPLY_SWIGLU",
    "num_warps",
    "NUM_BUFFERS",
    "HAS_MX_OUT",
    "EP_SCATTER",
]

_MOE_GEMM_A4W4_PREFILL_REPR_KEYS = _MOE_GEMM_A4W4_REPR_KEYS + [
    "PRELOAD_X_SCALES",
    "XS_SLAB_COLS",
    "L2_PREFETCH_DISTANCE",
]

_moe_gemm_a4w4_prefill_repr = make_kernel_repr(
    "_moe_gemm_a4w4_prefill", _MOE_GEMM_A4W4_PREFILL_REPR_KEYS
)

_moe_gemm_a4w4_decode_repr = make_kernel_repr(
    "_moe_gemm_a4w4_decode", _MOE_GEMM_A4W4_REPR_KEYS
)


def matmul_launch_metadata(grid, kernel, args):
    ret = {}
    M, N, K = None, args["N"], args["K"]
    Y, X, W = args["Y"], args["X"], args["W"]
    hist = args["ExptHist"]
    if hist is not None:
        n_rows = int(hist.float().mean())
        n_tokens = float(hist.sum())
        n_w_bytes = (W.numel() * W.element_size() // hist.numel()) * (hist > 0).sum()
    else:
        n_tokens = None
        n_w_bytes = W.numel() * W.element_size()

    def repr(s, x):
        return f"{s}={x}" if x is not None else f"E_{len(hist)}({s})={n_rows}"

    nbits = X.dtype.itemsize * 8
    ret["name"] = f"{kernel.name} [{repr('M', M)}, {repr('N', N)}, {repr('K', K)}]"
    gindx = args.get("GatherIndx", None)
    # sindx = args.get("WriteBackIndx", None)
    if gindx is not None:
        gindx = gindx.to(torch.int32)
        ret["name"] += "_layer1"
    else:
        ret["name"] += "_layer2"
    if args["B"] is not None:
        ret["name"] += "_bias"
    if args["APPLY_SWIGLU"]:
        ret["name"] += "_swiglu"

    fM = n_tokens
    fK = K if K is not None else n_tokens
    ret[f"flops{nbits}"] = 2.0 * fM * N * fK

    n_x_bytes = X.numel() * X.element_size()
    n_y_bytes = Y.numel() * Y.element_size()
    if hist is not None:
        assert n_tokens is not None
        n_expts_act = args["N_EXPTS_ACT"]

        if gindx is not None:
            # recreate inverse GatherIndx.
            dst = torch.full_like(gindx, -1)
            idx = torch.arange(len(gindx), device=gindx.device, dtype=torch.int32)
            mask = gindx != -1
            dst[gindx[mask]] = idx[mask]
            n_read_rows = (dst.view((-1, n_expts_act)) != -1).any(dim=1).sum()
        else:
            n_read_rows = n_tokens
        n_x_bytes = n_read_rows * X.shape[-1] * X.element_size()
        n_y_bytes = n_tokens * Y.shape[-1] * Y.element_size()
    ret["bytes"] = int(n_x_bytes + n_y_bytes + n_w_bytes)

    return ret


def get_moe_a4w4_layouts_prefill(
    BLOCK_M,
    BLOCK_N,
    BLOCK_K,
    num_warps,
    num_ctas,
    ACTIVATION_REDUCTION_N,
    PRESHUFFLE_WEIGHTS,
    SWIZZLE_MX_SCALE,
    GatherIndx,
    X_SCALES_TDM=False,
):
    OUT_BLOCK_N = BLOCK_N // ACTIVATION_REDUCTION_N
    PACKED_BLOCK_M_X = BLOCK_M
    PACKED_BLOCK_K_X = BLOCK_K // 2
    PACKED_BLOCK_K_W = BLOCK_K // 2
    PACKED_BLOCK_N_W = BLOCK_N

    # weight preshuffling
    if PRESHUFFLE_WEIGHTS:
        PRESHUFFLE_FACTOR_W = 16
        SHUFFLED_BLOCK_K_W = PACKED_BLOCK_K_W * PRESHUFFLE_FACTOR_W
        SHUFFLED_BLOCK_N_W = PACKED_BLOCK_N_W // PRESHUFFLE_FACTOR_W
    else:
        PRESHUFFLE_FACTOR_W = 1
        SHUFFLED_BLOCK_K_W = PACKED_BLOCK_K_W
        SHUFFLED_BLOCK_N_W = PACKED_BLOCK_N_W

    # scale preshuffling
    MX_SCALE_BLOCK_K = BLOCK_K // 32
    if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
        PRESHUFFLE_FACTOR_WS = 32
        SHUFFLED_BLOCK_K_WS = MX_SCALE_BLOCK_K * PRESHUFFLE_FACTOR_WS
        SHUFFLED_BLOCK_N_WS = PACKED_BLOCK_N_W // PRESHUFFLE_FACTOR_WS
    else:
        PRESHUFFLE_FACTOR_WS = 1
        SHUFFLED_BLOCK_K_WS = MX_SCALE_BLOCK_K
        SHUFFLED_BLOCK_N_WS = PACKED_BLOCK_N_W

    # cga layout
    if num_ctas == 4:
        ctas_per_cga = [2, 2]
    elif num_ctas == 8:
        ctas_per_cga = [2, 4]
    elif num_ctas == 16:
        ctas_per_cga = [4, 4]
    else:
        ctas_per_cga = [1, num_ctas]
    cga_layout_c = make_cga_layout(
        ctas_per_cga, [ctas_per_cga[0], ctas_per_cga[1]], [0, 1]
    )

    # wmma layouts
    if num_warps == 4:
        if BLOCK_M == 16:
            warp_bases = [[0, 1], [0, 2]]
        else:
            warp_bases = [[0, 1], [1, 0]]
    else:
        if BLOCK_M == 16:
            warp_bases = [[0, 1], [0, 2], [0, 4]]
        else:
            warp_bases = [[0, 1], [1, 0], [2, 0]]
    WMMA_LAYOUT = gl.amd.AMDWMMALayout(
        version=3,
        transposed=True,
        warp_bases=warp_bases,
        reg_bases=[],
        instr_shape=[32, 16, 128],
        cga_layout=cga_layout_c,
    )
    WMMA_LAYOUT_PACKED = gl.amd.AMDWMMALayout(
        version=3,
        transposed=True,
        warp_bases=warp_bases,
        reg_bases=[],
        instr_shape=[32, 16, 64],
        cga_layout=cga_layout_c,
    )
    DOT_LAYOUT_X = gl.DotOperandLayout(
        operand_index=0,
        parent=WMMA_LAYOUT_PACKED,
        k_width=16,
    )
    DOT_LAYOUT_W = gl.DotOperandLayout(
        operand_index=1,
        parent=WMMA_LAYOUT_PACKED,
        k_width=16,
    )

    CGA_A = DOT_LAYOUT_X.cga_layout
    CGA_B = DOT_LAYOUT_W.cga_layout
    CGA_B_NMAJOR = [[basis[1], basis[0]] for basis in CGA_B]
    CGA_A_T = [[basis[1], basis[0]] for basis in CGA_A]

    # wmma layouts for scales
    WMMA_X_SCALES = gl.amd.AMDWMMALayout(
        version=3,
        transposed=True,
        warp_bases=warp_bases,
        reg_bases=[],
        instr_shape=WMMA_LAYOUT_PACKED.instr_shape,
        cga_layout=CGA_A,
    )
    WMMA_W_SCALES = gl.amd.AMDWMMALayout(
        version=3,
        transposed=True,
        warp_bases=warp_bases,
        reg_bases=[],
        instr_shape=WMMA_LAYOUT_PACKED.instr_shape,
        cga_layout=CGA_B_NMAJOR,
    )
    DOT_LAYOUT_X_SCALES = gl.amd.gfx1250.get_wmma_scale_layout(
        gl.DotOperandLayout(operand_index=0, parent=WMMA_X_SCALES, k_width=16),
        [PACKED_BLOCK_M_X, MX_SCALE_BLOCK_K],
    )
    DOT_LAYOUT_W_SCALES = gl.amd.gfx1250.get_wmma_scale_layout(
        gl.DotOperandLayout(operand_index=1, parent=WMMA_W_SCALES, k_width=16),
        [PACKED_BLOCK_N_W, MX_SCALE_BLOCK_K],
    )

    GATHER_IDX_LAYOUT = None
    if GatherIndx is not None:
        assert GatherIndx.dtype == torch.uint16 or GatherIndx.dtype == torch.int32
        gather_idx_bitwidth = 16 if GatherIndx.dtype == torch.uint16 else 32
        GATHER_IDX_LAYOUT = gl.SliceLayout(
            0,
            gl.BlockedLayout(
                size_per_thread=[1, 256 // gather_idx_bitwidth],
                threads_per_warp=[32, 1],
                warps_per_cta=[1, num_warps],
                order=[0, 1],
                cga_layout=CGA_A_T,
            ),
        )

    BLOCKED_LAYOUT_X_SCALES = gl.BlockedLayout(
        size_per_thread=[1, MX_SCALE_BLOCK_K],
        threads_per_warp=[32, 1],
        warps_per_cta=[num_warps, 1],
        order=[1, 0],
        cga_layout=CGA_A,
    )

    # shared layouts
    SHARED_LAYOUT_X = gl.PaddedSharedLayout.with_identity_for(
        interval_padding_pairs=[[PACKED_BLOCK_K_X, 16]],
        shape=[PACKED_BLOCK_M_X, PACKED_BLOCK_K_X],
        order=[1, 0],
        cga_layout=CGA_A,
    )
    if PRESHUFFLE_WEIGHTS:
        SHARED_LAYOUT_W = gl.SwizzledSharedLayout(
            vec=1,
            per_phase=1,
            max_phase=1,
            order=[1, 0],
            cga_layout=CGA_B_NMAJOR,
        )
    elif BLOCK_K <= 256:
        SHARED_LAYOUT_W = gl.PaddedSharedLayout.with_identity_for(
            interval_padding_pairs=[[256, 16]],
            shape=[SHUFFLED_BLOCK_N_W, SHUFFLED_BLOCK_K_W],
            order=[1, 0],
            cga_layout=CGA_B_NMAJOR,
        )
    else:
        SHARED_LAYOUT_W = gl.PaddedSharedLayout.with_identity_for(
            interval_padding_pairs=[[SHUFFLED_BLOCK_K_W, 16]],
            shape=[SHUFFLED_BLOCK_N_W, SHUFFLED_BLOCK_K_W],
            order=[1, 0],
            cga_layout=CGA_B_NMAJOR,
        )
    if X_SCALES_TDM:
        SHARED_LAYOUT_X_SCALES = gl.PaddedSharedLayout.with_identity_for(
            interval_padding_pairs=[[MX_SCALE_BLOCK_K, 16]],
            shape=[PACKED_BLOCK_M_X, MX_SCALE_BLOCK_K],
            order=[1, 0],
            cga_layout=CGA_A,
        )
    else:
        SHARED_LAYOUT_X_SCALES = gl.PaddedSharedLayout.with_identity_for(
            interval_padding_pairs=[[256, 16]],
            shape=[PACKED_BLOCK_M_X, MX_SCALE_BLOCK_K],
            order=[1, 0],
            cga_layout=CGA_A,
        )
    if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
        SHARED_LAYOUT_W_SCALES = gl.SwizzledSharedLayout(
            vec=1,
            per_phase=1,
            max_phase=1,
            order=[1, 0],
            cga_layout=CGA_B_NMAJOR,
        )
    elif MX_SCALE_BLOCK_K <= 256:
        SHARED_LAYOUT_W_SCALES = gl.PaddedSharedLayout.with_identity_for(
            interval_padding_pairs=[[256, 16]],
            shape=[SHUFFLED_BLOCK_N_WS, SHUFFLED_BLOCK_K_WS],
            order=[1, 0],
            cga_layout=CGA_B_NMAJOR,
        )
    else:
        SHARED_LAYOUT_W_SCALES = gl.PaddedSharedLayout.with_identity_for(
            interval_padding_pairs=[[SHUFFLED_BLOCK_K_WS, 16]],
            shape=[SHUFFLED_BLOCK_N_WS, SHUFFLED_BLOCK_K_WS],
            order=[1, 0],
            cga_layout=CGA_B_NMAJOR,
        )
    if ctas_per_cga[1] > 1:
        SHARED_LAYOUT_Y = gl.SwizzledSharedLayout(
            vec=1,
            per_phase=1,
            max_phase=1,
            order=[1, 0],
            cga_layout=cga_layout_c,
        )
    else:
        SHARED_LAYOUT_Y = gl.PaddedSharedLayout.with_identity_for(
            interval_padding_pairs=[[OUT_BLOCK_N, 8]],
            shape=[BLOCK_M, OUT_BLOCK_N],
            order=[1, 0],
            cga_layout=cga_layout_c,
        )

    layouts = {
        "WMMA_LAYOUT": WMMA_LAYOUT,
        "DOT_LAYOUT_X": DOT_LAYOUT_X,
        "DOT_LAYOUT_W": DOT_LAYOUT_W,
        "DOT_LAYOUT_X_SCALES": DOT_LAYOUT_X_SCALES,
        "DOT_LAYOUT_W_SCALES": DOT_LAYOUT_W_SCALES,
        "GATHER_IDX_LAYOUT": GATHER_IDX_LAYOUT,
        "BLOCKED_LAYOUT_X_SCALES": BLOCKED_LAYOUT_X_SCALES,
        "SHARED_LAYOUT_X": SHARED_LAYOUT_X,
        "SHARED_LAYOUT_W": SHARED_LAYOUT_W,
        "SHARED_LAYOUT_X_SCALES": SHARED_LAYOUT_X_SCALES,
        "SHARED_LAYOUT_W_SCALES": SHARED_LAYOUT_W_SCALES,
        "SHARED_LAYOUT_Y": SHARED_LAYOUT_Y,
    }

    return layouts


def get_moe_a4w4_layouts_decode(
    BLOCK_M,
    BLOCK_N,
    BLOCK_K,
    num_warps,
    ACTIVATION_REDUCTION_N,
    PRESHUFFLE_WEIGHTS,
    SWIZZLE_MX_SCALE,
    GatherIndx,
    X_SCALES_TDM=False,
):
    OUT_BLOCK_N = BLOCK_N // ACTIVATION_REDUCTION_N
    PACKED_BLOCK_M_X = BLOCK_M
    PACKED_BLOCK_K_X = BLOCK_K // 2
    PACKED_BLOCK_K_W = BLOCK_K // 2
    PACKED_BLOCK_N_W = BLOCK_N

    # weight preshuffling
    if PRESHUFFLE_WEIGHTS:
        PRESHUFFLE_FACTOR_W = 16
        SHUFFLED_BLOCK_K_W = PACKED_BLOCK_K_W * PRESHUFFLE_FACTOR_W
        SHUFFLED_BLOCK_N_W = PACKED_BLOCK_N_W // PRESHUFFLE_FACTOR_W
    else:
        PRESHUFFLE_FACTOR_W = 1
        SHUFFLED_BLOCK_K_W = PACKED_BLOCK_K_W
        SHUFFLED_BLOCK_N_W = PACKED_BLOCK_N_W

    # scale preshuffling
    MX_SCALE_BLOCK_K = BLOCK_K // 32
    if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
        PRESHUFFLE_FACTOR_WS = 32
        SHUFFLED_BLOCK_K_WS = MX_SCALE_BLOCK_K * PRESHUFFLE_FACTOR_WS
        SHUFFLED_BLOCK_N_WS = PACKED_BLOCK_N_W // PRESHUFFLE_FACTOR_WS
    else:
        PRESHUFFLE_FACTOR_WS = 1
        SHUFFLED_BLOCK_K_WS = MX_SCALE_BLOCK_K
        SHUFFLED_BLOCK_N_WS = PACKED_BLOCK_N_W

    # wmma layouts
    if num_warps == 4:
        warp_bases = [[0, 1], [0, 2]]
    else:
        warp_bases = [[0, 1], [0, 2], [0, 4]]
    WMMA_LAYOUT = gl.amd.AMDWMMALayout(
        version=3,
        transposed=True,
        warp_bases=warp_bases,
        reg_bases=[],
        instr_shape=[32, 16, 128],
    )
    WMMA_LAYOUT_PACKED = gl.amd.AMDWMMALayout(
        version=3,
        transposed=True,
        warp_bases=warp_bases,
        reg_bases=[],
        instr_shape=[32, 16, 64],
    )
    DOT_LAYOUT_X = gl.DotOperandLayout(
        operand_index=0,
        parent=WMMA_LAYOUT_PACKED,
        k_width=16,
    )
    DOT_LAYOUT_W = gl.DotOperandLayout(
        operand_index=1,
        parent=WMMA_LAYOUT_PACKED,
        k_width=16,
    )

    # wmma layouts for scales
    DOT_LAYOUT_X_SCALES = gl.amd.gfx1250.get_wmma_scale_layout(
        DOT_LAYOUT_X, [PACKED_BLOCK_M_X, MX_SCALE_BLOCK_K]
    )
    DOT_LAYOUT_W_SCALES = gl.amd.gfx1250.get_wmma_scale_layout(
        DOT_LAYOUT_W, [PACKED_BLOCK_N_W, MX_SCALE_BLOCK_K]
    )

    GATHER_IDX_LAYOUT = None
    if GatherIndx is not None:
        assert GatherIndx.dtype == torch.uint16 or GatherIndx.dtype == torch.int32
        gather_idx_bitwidth = 16 if GatherIndx.dtype == torch.uint16 else 32
        GATHER_IDX_LAYOUT = gl.SliceLayout(
            0,
            gl.BlockedLayout(
                size_per_thread=[1, 256 // gather_idx_bitwidth],
                threads_per_warp=[32, 1],
                warps_per_cta=[1, num_warps],
                order=[0, 1],
            ),
        )

    BLOCKED_LAYOUT_X_SCALES = gl.BlockedLayout(
        size_per_thread=[1, MX_SCALE_BLOCK_K],
        threads_per_warp=[32, 1],
        warps_per_cta=[num_warps, 1],
        order=[1, 0],
    )

    # shared layouts
    SHARED_LAYOUT_X = gl.PaddedSharedLayout.with_identity_for(
        interval_padding_pairs=[[PACKED_BLOCK_K_X, 16]],
        shape=[PACKED_BLOCK_M_X, PACKED_BLOCK_K_X],
        order=[1, 0],
    )
    if PRESHUFFLE_WEIGHTS:
        SHARED_LAYOUT_W = gl.SwizzledSharedLayout(
            vec=1,
            per_phase=1,
            max_phase=1,
            order=[1, 0],
        )
    elif SHUFFLED_BLOCK_K_W <= 256:
        SHARED_LAYOUT_W = gl.PaddedSharedLayout.with_identity_for(
            interval_padding_pairs=[[256, 16]],
            shape=[SHUFFLED_BLOCK_N_W, SHUFFLED_BLOCK_K_W],
            order=[1, 0],
        )
    else:
        SHARED_LAYOUT_W = gl.PaddedSharedLayout.with_identity_for(
            interval_padding_pairs=[[SHUFFLED_BLOCK_K_W, 16]],
            shape=[SHUFFLED_BLOCK_N_W, SHUFFLED_BLOCK_K_W],
            order=[1, 0],
        )
    SHARED_LAYOUT_X_SCALES = gl.SwizzledSharedLayout(
        vec=1,
        per_phase=1,
        max_phase=1,
        order=[1, 0],
    )
    if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
        SHARED_LAYOUT_W_SCALES = gl.SwizzledSharedLayout(
            vec=1,
            per_phase=1,
            max_phase=1,
            order=[1, 0],
        )
    elif SHUFFLED_BLOCK_K_WS <= 256:
        SHARED_LAYOUT_W_SCALES = gl.PaddedSharedLayout.with_identity_for(
            interval_padding_pairs=[[256, 16]],
            shape=[SHUFFLED_BLOCK_N_WS, SHUFFLED_BLOCK_K_WS],
            order=[1, 0],
        )
    else:
        SHARED_LAYOUT_W_SCALES = gl.PaddedSharedLayout.with_identity_for(
            interval_padding_pairs=[[SHUFFLED_BLOCK_K_WS, 16]],
            shape=[SHUFFLED_BLOCK_N_WS, SHUFFLED_BLOCK_K_WS],
            order=[1, 0],
        )
    SHARED_LAYOUT_Y = gl.PaddedSharedLayout.with_identity_for(
        interval_padding_pairs=[[OUT_BLOCK_N, 8]],
        shape=[BLOCK_M, OUT_BLOCK_N],
        order=[1, 0],
    )

    layouts = {
        "WMMA_LAYOUT": WMMA_LAYOUT,
        "DOT_LAYOUT_X": DOT_LAYOUT_X,
        "DOT_LAYOUT_W": DOT_LAYOUT_W,
        "DOT_LAYOUT_X_SCALES": DOT_LAYOUT_X_SCALES,
        "DOT_LAYOUT_W_SCALES": DOT_LAYOUT_W_SCALES,
        "GATHER_IDX_LAYOUT": GATHER_IDX_LAYOUT,
        "BLOCKED_LAYOUT_X_SCALES": BLOCKED_LAYOUT_X_SCALES,
        "SHARED_LAYOUT_X": SHARED_LAYOUT_X,
        "SHARED_LAYOUT_W": SHARED_LAYOUT_W,
        "SHARED_LAYOUT_X_SCALES": SHARED_LAYOUT_X_SCALES,
        "SHARED_LAYOUT_W_SCALES": SHARED_LAYOUT_W_SCALES,
        "SHARED_LAYOUT_Y": SHARED_LAYOUT_Y,
    }

    return layouts


@gluon.jit
def unswizzle_scales_gfx1250(
    scale_buffer_slice, BLOCK_N, MX_SCALE_BLOCK_K, PRESHUFFLE_FACTOR, SCALE_KWIDTH
):
    scale_buffer_slice = (
        scale_buffer_slice.reshape(
            (
                BLOCK_N // PRESHUFFLE_FACTOR,
                MX_SCALE_BLOCK_K // SCALE_KWIDTH,
                PRESHUFFLE_FACTOR,
                SCALE_KWIDTH,
            )
        )
        .permute((0, 2, 1, 3))
        .reshape((BLOCK_N, MX_SCALE_BLOCK_K))
    )

    return scale_buffer_slice


@gluon.jit
def unshuffle_weights_gfx1250(
    weights_slice,
    PACKED_BLOCK_N_W: gl.constexpr,
    PACKED_BLOCK_K_W: gl.constexpr,
):
    return (
        weights_slice.reshape(
            (
                PACKED_BLOCK_N_W // 16,
                PACKED_BLOCK_K_W // 16,
                16,
                16,
            )
        )
        .permute((0, 2, 1, 3))
        .reshape((PACKED_BLOCK_N_W, PACKED_BLOCK_K_W))
    )


@gluon.jit(launch_metadata=matmul_launch_metadata, repr=_moe_gemm_a4w4_prefill_repr)
def _moe_gemm_a4w4_prefill(
    Y,
    stride_y_m,
    stride_y_n,
    X,
    stride_x_m,
    stride_x_k,
    XMxScale,
    stride_x_mx_m,
    stride_x_mx_k,
    W,
    stride_w_e,
    stride_w_k,
    stride_w_n,
    WMxScale,
    stride_w_mx_e,
    stride_w_mx_k,
    stride_w_mx_n,
    # bias
    B,
    stride_b_e,
    Gammas,
    # shapes
    num_tokens,
    N: gl.constexpr,
    K: gl.constexpr,
    # expt data
    GatherIndx,
    ExptHist,
    ExptOffs,
    ExptOffsSum,
    ExptData,
    # true grid size
    grid_m,
    grid_n,
    # fused activation function
    APPLY_SWIGLU: gl.constexpr,
    alpha,
    limit,
    ACTIVATION_REDUCTION_N: gl.constexpr,
    ADD_RESIDUAL: gl.constexpr,
    # MoE config
    N_EXPTS_ACT: gl.constexpr,
    # optimization config
    BLOCK_M: gl.constexpr,
    BLOCK_N: gl.constexpr,
    BLOCK_K: gl.constexpr,
    XCD_SWIZZLE: gl.constexpr,
    SWIZZLE_MX_SCALE: gl.constexpr,  # "GFX1250_SCALE" | None
    PRESHUFFLE_WEIGHTS: gl.constexpr,
    NUM_BUFFERS: gl.constexpr,
    UPCAST_INDICES: gl.constexpr,
    X_SCALES_TDM: gl.constexpr,
    CLAMP_BOUNDS: gl.constexpr,
    # layouts
    WMMA_LAYOUT: gl.constexpr,
    DOT_LAYOUT_X: gl.constexpr,
    DOT_LAYOUT_W: gl.constexpr,
    DOT_LAYOUT_X_SCALES: gl.constexpr,
    DOT_LAYOUT_W_SCALES: gl.constexpr,
    GATHER_IDX_LAYOUT: gl.constexpr,
    BLOCKED_LAYOUT_X_SCALES: gl.constexpr,
    SHARED_LAYOUT_X: gl.constexpr,
    SHARED_LAYOUT_W: gl.constexpr,
    SHARED_LAYOUT_X_SCALES: gl.constexpr,
    SHARED_LAYOUT_W_SCALES: gl.constexpr,
    SHARED_LAYOUT_Y: gl.constexpr,
    # metaparameters
    num_warps: gl.constexpr,
    num_ctas: gl.constexpr,
    # MXFP4 output quant (GEMM1-style): emit e2m1 nibbles + e8m0 scales straight
    # from the epilogue so GEMM2 consumes them with no separate quant launch.
    YMxScale=None,
    stride_y_mx_m=0,
    stride_y_mx_n=0,
    HAS_MX_OUT: gl.constexpr = False,
    # Expert-parallel combine (GEMM2-style): per-row destination row in a peer
    # combine-staging window, negative where the row must not be delivered.
    DstRow=None,
    EP_SCATTER: gl.constexpr = False,
    # Row extent of the combine window, so an out-of-range index is droppable.
    Y_ROWS=0,
    PRELOAD_X_SCALES: gl.constexpr = False,
    XS_SLAB_COLS: gl.constexpr = 0,
    # Warm L2 with the first this-many K-tiles of w during the prologue.
    # 0 disables. Costs no LDS, unlike raising NUM_BUFFERS, which would
    # cost a whole workgroup per CU on both prefill GEMMs.
    L2_PREFETCH_DISTANCE: gl.constexpr = 0,
):
    MX_PACK_DIVISOR: gl.constexpr = 32
    gl.static_assert(
        BLOCK_K % MX_PACK_DIVISOR == 0, "BLOCK_K must be a multiple of MX_PACK_DIVISOR"
    )

    # Preloading takes x scales out of the loop entirely
    if PRELOAD_X_SCALES:
        NUM_TDM_OPS: gl.constexpr = 3
    elif X_SCALES_TDM:
        # via TDM: w, w scales, x, x scales
        NUM_TDM_OPS: gl.constexpr = 4
    else:
        # via TDM: w, w scales, x
        # via async_copy: x scales
        NUM_TDM_OPS: gl.constexpr = 3

    w_type: gl.constexpr = W.dtype.element_ty
    gl.static_assert(w_type == gl.uint8, "Weights must be uint8")
    gl.static_assert(
        WMxScale.dtype.element_ty == gl.uint8, "Weights scales must be uint8"
    )
    x_type: gl.constexpr = X.dtype.element_ty
    gl.static_assert(x_type == gl.uint8, "Activations must be uint8")
    gl.static_assert(
        XMxScale.dtype.element_ty == gl.uint8, "Activations scales must be uint8"
    )

    OUT_BLOCK_N: gl.constexpr = BLOCK_N // ACTIVATION_REDUCTION_N
    yN = N // ACTIVATION_REDUCTION_N

    # get program id
    pid = gl.program_id(0)
    index_type: gl.constexpr = gl.int64 if UPCAST_INDICES else gl.int32
    if XCD_SWIZZLE != 1:
        padding_m = grid_m - gl.load(ExptOffsSum)
        unpadded_m = grid_m - padding_m
        total_actual_tiles = unpadded_m * grid_n
        if padding_m > 0 and pid >= total_actual_tiles:
            return
        pid = remap_xcd(pid, total_actual_tiles, XCD_SWIZZLE)
    else:
        unpadded_m = grid_m
    pid_m, pid_n = pid_grid(pid, unpadded_m, grid_n, 1)

    # unpack expert data
    expt_data = gl.load(ExptData + pid_m)
    if XCD_SWIZZLE == 1 and expt_data == -1:
        return
    expt_id = expt_data & 0x0000FFFF
    block_id = expt_data >> 16
    M = gl.load(ExptHist + expt_id)
    start_m = gl.load(ExptOffs + expt_id)

    # get the packed block sizes
    # both A and B tensors are mxfp4
    #   2 MXFP4 elements are packed into 1 int8
    #   in the K dimension
    X_M_DIVISOR: gl.constexpr = 1
    X_K_DIVISOR: gl.constexpr = 2  # 2 MXFP4 elements packed into 1 byte
    W_K_DIVISOR: gl.constexpr = 2  # 2 MXFP4 elements packed into 1 byte
    W_N_DIVISOR: gl.constexpr = 1
    PACKED_BLOCK_M_X: gl.constexpr = BLOCK_M // X_M_DIVISOR
    PACKED_BLOCK_K_X: gl.constexpr = BLOCK_K // X_K_DIVISOR
    PACKED_BLOCK_K_W: gl.constexpr = BLOCK_K // W_K_DIVISOR
    PACKED_BLOCK_N_W: gl.constexpr = BLOCK_N // W_N_DIVISOR
    MX_SCALE_BLOCK_K: gl.constexpr = (
        BLOCK_K // MX_PACK_DIVISOR
    )  # 32 elements share 1 scale element

    # A pointers
    offs_x_m = PACKED_BLOCK_M_X * block_id
    if GatherIndx is None:
        X += start_m.to(index_type) * stride_x_m
    else:
        if GatherIndx.dtype.element_ty == gl.uint16:
            oob_idx = num_tokens.to(gl.uint16)
        else:
            oob_idx = num_tokens
        offs_x_m = PACKED_BLOCK_M_X * block_id + gl.arange(
            0, PACKED_BLOCK_M_X, layout=GATHER_IDX_LAYOUT
        )
        mask_idx = offs_x_m < M
        offs_x_m = offs_x_m % M
        GatherIndx += start_m
        offs_x_m = gl.load(GatherIndx + offs_x_m) // N_EXPTS_ACT
        offs_x_m = gl.where(mask_idx, offs_x_m, oob_idx)

    # B pointers
    W += expt_id.to(index_type) * stride_w_e
    if PRESHUFFLE_WEIGHTS:
        PRESHUFFLE_FACTOR_W: gl.constexpr = 16
        SHUFFLED_BLOCK_K_W: gl.constexpr = PACKED_BLOCK_K_W * PRESHUFFLE_FACTOR_W
        SHUFFLED_BLOCK_N_W: gl.constexpr = PACKED_BLOCK_N_W // PRESHUFFLE_FACTOR_W
    else:
        PRESHUFFLE_FACTOR_W: gl.constexpr = 1
        SHUFFLED_BLOCK_K_W: gl.constexpr = PACKED_BLOCK_K_W
        SHUFFLED_BLOCK_N_W: gl.constexpr = PACKED_BLOCK_N_W
    offs_w_n = pid_n * SHUFFLED_BLOCK_N_W

    # A scale pointers
    if GatherIndx is None:
        XMxScale += start_m.to(index_type) * stride_x_mx_m
    if not X_SCALES_TDM:
        offs_x_m_scales = PACKED_BLOCK_M_X * block_id + gl.arange(
            0,
            PACKED_BLOCK_M_X,
            layout=gl.SliceLayout(1, BLOCKED_LAYOUT_X_SCALES),
        )
        offs_x_m_scales = offs_x_m_scales % M
        if GatherIndx is not None:
            offs_x_m_scales = gl.load(GatherIndx + offs_x_m_scales) // N_EXPTS_ACT
        offs_x_k_scales = gl.arange(
            0, MX_SCALE_BLOCK_K, layout=gl.SliceLayout(0, BLOCKED_LAYOUT_X_SCALES)
        )
        x_scales_ptrs = (
            XMxScale
            + offs_x_m_scales.to(index_type)[:, None] * stride_x_mx_m
            + offs_x_k_scales.to(index_type)[None, :] * stride_x_mx_k
        )

    # B scale pointers
    WMxScale += expt_id.to(index_type) * stride_w_mx_e
    if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
        PRESHUFFLE_FACTOR_WS: gl.constexpr = 32
        SHUFFLED_BLOCK_K_WS: gl.constexpr = MX_SCALE_BLOCK_K * PRESHUFFLE_FACTOR_WS
        SHUFFLED_BLOCK_N_WS: gl.constexpr = BLOCK_N // PRESHUFFLE_FACTOR_WS
        SCALE_KWIDTH: gl.constexpr = 4
    else:
        PRESHUFFLE_FACTOR_WS: gl.constexpr = 1
        SHUFFLED_BLOCK_K_WS: gl.constexpr = MX_SCALE_BLOCK_K
        SHUFFLED_BLOCK_N_WS: gl.constexpr = BLOCK_N
    offs_w_n_scale = pid_n * SHUFFLED_BLOCK_N_WS

    if GatherIndx is None:
        x_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=X,
            shape=(M, K // X_K_DIVISOR),
            strides=(stride_x_m, stride_x_k),
            block_shape=(PACKED_BLOCK_M_X, PACKED_BLOCK_K_X),
            layout=SHARED_LAYOUT_X,
        )
    else:
        x_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=X,
            shape=(num_tokens, K // X_K_DIVISOR),
            strides=(stride_x_m, stride_x_k),
            block_shape=(PACKED_BLOCK_M_X, PACKED_BLOCK_K_X),
            layout=SHARED_LAYOUT_X,
        )
    w_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
        base=W,
        shape=(N // PRESHUFFLE_FACTOR_W, K // W_K_DIVISOR * PRESHUFFLE_FACTOR_W),
        strides=(stride_w_n, stride_w_k),
        block_shape=(SHUFFLED_BLOCK_N_W, SHUFFLED_BLOCK_K_W),
        layout=SHARED_LAYOUT_W,
    )
    if GatherIndx is None:
        x_scales_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=XMxScale,
            shape=(M, gl.cdiv(K, MX_PACK_DIVISOR)),
            strides=(stride_x_mx_m, stride_x_mx_k),
            block_shape=(PACKED_BLOCK_M_X, MX_SCALE_BLOCK_K),
            layout=SHARED_LAYOUT_X_SCALES,
        )
    else:
        x_scales_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=XMxScale,
            shape=(num_tokens, gl.cdiv(K, MX_PACK_DIVISOR)),
            strides=(stride_x_mx_m, stride_x_mx_k),
            block_shape=(PACKED_BLOCK_M_X, MX_SCALE_BLOCK_K),
            layout=SHARED_LAYOUT_X_SCALES,
        )
    w_scales_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
        base=WMxScale,
        shape=(
            N // PRESHUFFLE_FACTOR_WS,
            gl.cdiv(K, MX_PACK_DIVISOR) * PRESHUFFLE_FACTOR_WS,
        ),
        strides=(stride_w_mx_n, stride_w_mx_k),
        block_shape=(SHUFFLED_BLOCK_N_WS, SHUFFLED_BLOCK_K_WS),
        layout=SHARED_LAYOUT_W_SCALES,
    )

    x_buffer = gl.allocate_shared_memory(
        x_desc.dtype, shape=[NUM_BUFFERS] + x_desc.block_shape, layout=x_desc.layout
    )
    w_buffer = gl.allocate_shared_memory(
        w_desc.dtype, shape=[NUM_BUFFERS] + w_desc.block_shape, layout=w_desc.layout
    )
    if PRELOAD_X_SCALES:
        XS_SLAB_LAYOUT: gl.constexpr = gl.SwizzledSharedLayout(
            vec=1, per_phase=1, max_phase=1, order=[1, 0]
        )
        XS_SLOTS: gl.constexpr = XS_SLAB_COLS // MX_SCALE_BLOCK_K
        xs_offs_kg = gl.arange(
            0, MX_SCALE_BLOCK_K, layout=gl.SliceLayout(0, DOT_LAYOUT_X_SCALES)
        )
        xs_zeros_row = gl.zeros(
            (PACKED_BLOCK_M_X,),
            dtype=gl.int32,
            layout=gl.SliceLayout(1, DOT_LAYOUT_X_SCALES),
        )
        gl.static_assert(
            XS_SLAB_COLS % MX_SCALE_BLOCK_K == 0,
            "XS_SLAB_COLS must be a whole number of MX_SCALE_BLOCK_K tiles",
        )
        gl.static_assert(XS_SLOTS >= 1, "x-scale slab needs at least one slot")
        x_scales_slab = gl.allocate_shared_memory(
            x_scales_desc.dtype,
            shape=[PACKED_BLOCK_M_X, XS_SLAB_COLS],
            layout=XS_SLAB_LAYOUT,
        )
        if GatherIndx is None:
            xs_slab_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
                base=XMxScale,
                shape=(M, gl.cdiv(K, MX_PACK_DIVISOR)),
                strides=(stride_x_mx_m, stride_x_mx_k),
                block_shape=(PACKED_BLOCK_M_X, XS_SLAB_COLS),
                layout=XS_SLAB_LAYOUT,
            )
        else:
            xs_slab_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
                base=XMxScale,
                shape=(num_tokens, gl.cdiv(K, MX_PACK_DIVISOR)),
                strides=(stride_x_mx_m, stride_x_mx_k),
                block_shape=(PACKED_BLOCK_M_X, XS_SLAB_COLS),
                layout=XS_SLAB_LAYOUT,
            )
    else:
        x_scales_buffer = gl.allocate_shared_memory(
            x_scales_desc.dtype,
            shape=[NUM_BUFFERS] + x_scales_desc.block_shape,
            layout=x_scales_desc.layout,
        )
    w_scales_buffer = gl.allocate_shared_memory(
        w_scales_desc.dtype,
        shape=[NUM_BUFFERS] + w_scales_desc.block_shape,
        layout=w_scales_desc.layout,
    )

    load_idx = 0
    wmma_idx = 0

    num_k_iter = gl.cdiv(K, BLOCK_K)

    if PRELOAD_X_SCALES:
        if GatherIndx is None:
            gl.amd.gfx1250.tdm.async_load(xs_slab_desc, [offs_x_m, 0], x_scales_slab)
        else:
            gl.amd.gfx1250.tdm.async_gather(xs_slab_desc, offs_x_m, x_scales_slab)

    # prologue: fill NUM_BUFFERS LDS slots via TDM
    for _ in gl.static_range(NUM_BUFFERS):
        if GatherIndx is None:
            gl.amd.gfx1250.tdm.async_load(
                x_desc,
                [offs_x_m, 0],
                x_buffer.index(load_idx % NUM_BUFFERS),
            )
            if X_SCALES_TDM and not PRELOAD_X_SCALES:
                gl.amd.gfx1250.tdm.async_load(
                    x_scales_desc,
                    [offs_x_m, 0],
                    x_scales_buffer.index(load_idx % NUM_BUFFERS),
                )
        else:
            gl.amd.gfx1250.tdm.async_gather(
                x_desc,
                offs_x_m,
                x_buffer.index(load_idx % NUM_BUFFERS),
            )
            if X_SCALES_TDM and not PRELOAD_X_SCALES:
                gl.amd.gfx1250.tdm.async_gather(
                    x_scales_desc,
                    offs_x_m,
                    x_scales_buffer.index(load_idx % NUM_BUFFERS),
                )
        gl.amd.gfx1250.tdm.async_load(
            w_desc,
            [offs_w_n, 0],
            w_buffer.index(load_idx % NUM_BUFFERS),
        )
        gl.amd.gfx1250.tdm.async_load(
            w_scales_desc,
            [offs_w_n_scale, 0],
            w_scales_buffer.index(load_idx % NUM_BUFFERS),
        )
        if not X_SCALES_TDM and not PRELOAD_X_SCALES:
            gl.amd.gfx1250.async_copy.global_to_shared(
                x_scales_buffer.index(load_idx % NUM_BUFFERS),
                x_scales_ptrs,
            )
            gl.amd.gfx1250.async_copy.commit_group()
            x_scales_ptrs += MX_SCALE_BLOCK_K * stride_x_mx_k

        # update descriptors
        x_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            x_desc, add_offsets=[0, PACKED_BLOCK_K_X], clamp_bounds=CLAMP_BOUNDS
        )
        if X_SCALES_TDM and not PRELOAD_X_SCALES:
            x_scales_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
                x_scales_desc,
                add_offsets=[0, MX_SCALE_BLOCK_K],
                clamp_bounds=CLAMP_BOUNDS,
            )
        w_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            w_desc, add_offsets=[0, SHUFFLED_BLOCK_K_W], clamp_bounds=CLAMP_BOUNDS
        )
        w_scales_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            w_scales_desc,
            add_offsets=[0, SHUFFLED_BLOCK_K_WS],
            clamp_bounds=CLAMP_BOUNDS,
        )

        load_idx += 1

    if L2_PREFETCH_DISTANCE > 0:
        for pf_j in gl.static_range(L2_PREFETCH_DISTANCE):
            gl.amd.gfx1250.tdm.prefetch(w_desc, [offs_w_n, pf_j * SHUFFLED_BLOCK_K_W])

    # preload tile 0 from LDS into registers
    gl.amd.gfx1250.tdm.async_wait((NUM_BUFFERS - 1) * NUM_TDM_OPS)
    if not X_SCALES_TDM and not PRELOAD_X_SCALES:
        gl.amd.gfx1250.async_copy.wait_group(NUM_BUFFERS - 1)
    cur_x = x_buffer.index(wmma_idx % NUM_BUFFERS).load(layout=DOT_LAYOUT_X)
    if PRESHUFFLE_WEIGHTS:
        cur_w = (
            (
                unshuffle_weights_gfx1250(
                    w_buffer.index(wmma_idx % NUM_BUFFERS),
                    PACKED_BLOCK_N_W,
                    PACKED_BLOCK_K_W,
                )
            )
            .permute((1, 0))
            .load(layout=DOT_LAYOUT_W)
        )
    else:
        cur_w = (
            w_buffer.index(wmma_idx % NUM_BUFFERS)
            .permute((1, 0))
            .load(layout=DOT_LAYOUT_W)
        )
    if PRELOAD_X_SCALES:
        cur_x_scales = x_scales_slab.gather(
            ((wmma_idx % XS_SLOTS) * MX_SCALE_BLOCK_K + xs_offs_kg)[None, :]
            + xs_zeros_row[:, None],
            1,
        )
    else:
        cur_x_scales = x_scales_buffer.index(wmma_idx % NUM_BUFFERS).load(
            layout=DOT_LAYOUT_X_SCALES
        )
    if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
        cur_w_scales = (
            unswizzle_scales_gfx1250(
                w_scales_buffer.index(wmma_idx % NUM_BUFFERS),
                BLOCK_N,
                MX_SCALE_BLOCK_K,
                PRESHUFFLE_FACTOR_WS,
                SCALE_KWIDTH,
            )
        ).load(layout=DOT_LAYOUT_W_SCALES)
    else:
        cur_w_scales = w_scales_buffer.index(wmma_idx % NUM_BUFFERS).load(
            layout=DOT_LAYOUT_W_SCALES
        )
    wmma_idx += 1

    # main loop: perform wmma and fill LDS with next tile
    acc = gl.zeros((BLOCK_M, BLOCK_N), dtype=gl.float32, layout=WMMA_LAYOUT)
    for _ in range(num_k_iter - NUM_BUFFERS):
        if num_ctas > 1:
            gl.amd.gfx1250.cluster.arrive()
        acc = gl.amd.gfx1250.wmma_scaled(
            cur_x, cur_x_scales, "e2m1", cur_w, cur_w_scales, "e2m1", acc
        )
        if num_ctas > 1:
            gl.amd.gfx1250.cluster.wait()

        # fill next tile to LDS
        if GatherIndx is None:
            gl.amd.gfx1250.tdm.async_load(
                x_desc,
                [offs_x_m, 0],
                x_buffer.index(load_idx % NUM_BUFFERS),
            )
            if X_SCALES_TDM and not PRELOAD_X_SCALES:
                gl.amd.gfx1250.tdm.async_load(
                    x_scales_desc,
                    [offs_x_m, 0],
                    x_scales_buffer.index(load_idx % NUM_BUFFERS),
                )
        else:
            gl.amd.gfx1250.tdm.async_gather(
                x_desc,
                offs_x_m,
                x_buffer.index(load_idx % NUM_BUFFERS),
            )
            if X_SCALES_TDM and not PRELOAD_X_SCALES:
                gl.amd.gfx1250.tdm.async_gather(
                    x_scales_desc,
                    offs_x_m,
                    x_scales_buffer.index(load_idx % NUM_BUFFERS),
                )
        gl.amd.gfx1250.tdm.async_load(
            w_desc,
            [offs_w_n, 0],
            w_buffer.index(load_idx % NUM_BUFFERS),
        )
        gl.amd.gfx1250.tdm.async_load(
            w_scales_desc,
            [offs_w_n_scale, 0],
            w_scales_buffer.index(load_idx % NUM_BUFFERS),
        )
        if not X_SCALES_TDM and not PRELOAD_X_SCALES:
            gl.amd.gfx1250.async_copy.global_to_shared(
                x_scales_buffer.index(load_idx % NUM_BUFFERS),
                x_scales_ptrs,
            )
            gl.amd.gfx1250.async_copy.commit_group()
            x_scales_ptrs += MX_SCALE_BLOCK_K * stride_x_mx_k

        # update descriptors
        x_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            x_desc, add_offsets=[0, PACKED_BLOCK_K_X], clamp_bounds=CLAMP_BOUNDS
        )
        if X_SCALES_TDM and not PRELOAD_X_SCALES:
            x_scales_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
                x_scales_desc,
                add_offsets=[0, MX_SCALE_BLOCK_K],
                clamp_bounds=CLAMP_BOUNDS,
            )
        w_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            w_desc, add_offsets=[0, SHUFFLED_BLOCK_K_W], clamp_bounds=CLAMP_BOUNDS
        )
        w_scales_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            w_scales_desc,
            add_offsets=[0, SHUFFLED_BLOCK_K_WS],
            clamp_bounds=CLAMP_BOUNDS,
        )
        load_idx += 1

        # wait for next tile to be filled
        gl.amd.gfx1250.tdm.async_wait((NUM_BUFFERS - 1) * NUM_TDM_OPS)
        if not X_SCALES_TDM and not PRELOAD_X_SCALES:
            gl.amd.gfx1250.async_copy.wait_group(NUM_BUFFERS - 1)

        # load next tile from LDS into registers
        next_x = x_buffer.index(wmma_idx % NUM_BUFFERS).load(layout=DOT_LAYOUT_X)
        if PRESHUFFLE_WEIGHTS:
            next_w = (
                (
                    unshuffle_weights_gfx1250(
                        w_buffer.index(wmma_idx % NUM_BUFFERS),
                        PACKED_BLOCK_N_W,
                        PACKED_BLOCK_K_W,
                    )
                )
                .permute((1, 0))
                .load(layout=DOT_LAYOUT_W)
            )
        else:
            next_w = (
                w_buffer.index(wmma_idx % NUM_BUFFERS)
                .permute((1, 0))
                .load(layout=DOT_LAYOUT_W)
            )
        if PRELOAD_X_SCALES:
            next_x_scales = x_scales_slab.gather(
                ((wmma_idx % XS_SLOTS) * MX_SCALE_BLOCK_K + xs_offs_kg)[None, :]
                + xs_zeros_row[:, None],
                1,
            )
        else:
            next_x_scales = x_scales_buffer.index(wmma_idx % NUM_BUFFERS).load(
                layout=DOT_LAYOUT_X_SCALES
            )
        if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
            next_w_scales = (
                unswizzle_scales_gfx1250(
                    w_scales_buffer.index(wmma_idx % NUM_BUFFERS),
                    BLOCK_N,
                    MX_SCALE_BLOCK_K,
                    PRESHUFFLE_FACTOR_WS,
                    SCALE_KWIDTH,
                )
            ).load(layout=DOT_LAYOUT_W_SCALES)
        else:
            next_w_scales = w_scales_buffer.index(wmma_idx % NUM_BUFFERS).load(
                layout=DOT_LAYOUT_W_SCALES
            )
        wmma_idx += 1

        # prepare next iteration
        cur_x = next_x
        cur_w = next_w
        cur_x_scales = next_x_scales
        cur_w_scales = next_w_scales

    # load bias into LDS while the pipeline drains
    if B is not None:
        B += expt_id * stride_b_e
        SHARED_LAYOUT_BIAS: gl.constexpr = gl.SwizzledSharedLayout(
            vec=1, per_phase=1, max_phase=1, order=[1, 0]
        )
        bias_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=B,
            shape=(1, N),
            strides=(stride_b_e, 1),
            block_shape=(1, BLOCK_N),
            layout=SHARED_LAYOUT_BIAS,
        )
        bias_buffer = gl.allocate_shared_memory(
            bias_desc.dtype, shape=[1, BLOCK_N], layout=bias_desc.layout
        )
        gl.amd.gfx1250.tdm.async_load(
            bias_desc,
            [0, pid_n * BLOCK_N],
            bias_buffer,
        )
        TDM_BIAS_WAIT: gl.constexpr = 1
    else:
        TDM_BIAS_WAIT: gl.constexpr = 0

    # epilogue: drain remaining tiles
    for k_ep in gl.static_range(NUM_BUFFERS - 1):
        if num_ctas > 1:
            gl.amd.gfx1250.cluster.arrive()
        acc = gl.amd.gfx1250.wmma_scaled(
            cur_x, cur_x_scales, "e2m1", cur_w, cur_w_scales, "e2m1", acc
        )
        if num_ctas > 1:
            gl.amd.gfx1250.cluster.wait()

        # wait for next tile to be filled
        gl.amd.gfx1250.tdm.async_wait(
            (NUM_BUFFERS - 2 - k_ep) * NUM_TDM_OPS + TDM_BIAS_WAIT
        )
        if not X_SCALES_TDM and not PRELOAD_X_SCALES:
            gl.amd.gfx1250.async_copy.wait_group(NUM_BUFFERS - 2 - k_ep)

        # load next tile from LDS into registers
        next_x = x_buffer.index(wmma_idx % NUM_BUFFERS).load(layout=DOT_LAYOUT_X)
        if PRESHUFFLE_WEIGHTS:
            next_w = (
                (
                    unshuffle_weights_gfx1250(
                        w_buffer.index(wmma_idx % NUM_BUFFERS),
                        PACKED_BLOCK_N_W,
                        PACKED_BLOCK_K_W,
                    )
                )
                .permute((1, 0))
                .load(layout=DOT_LAYOUT_W)
            )
        else:
            next_w = (
                w_buffer.index(wmma_idx % NUM_BUFFERS)
                .permute((1, 0))
                .load(layout=DOT_LAYOUT_W)
            )
        if PRELOAD_X_SCALES:
            next_x_scales = x_scales_slab.gather(
                ((wmma_idx % XS_SLOTS) * MX_SCALE_BLOCK_K + xs_offs_kg)[None, :]
                + xs_zeros_row[:, None],
                1,
            )
        else:
            next_x_scales = x_scales_buffer.index(wmma_idx % NUM_BUFFERS).load(
                layout=DOT_LAYOUT_X_SCALES
            )
        if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
            next_w_scales = (
                unswizzle_scales_gfx1250(
                    w_scales_buffer.index(wmma_idx % NUM_BUFFERS),
                    BLOCK_N,
                    MX_SCALE_BLOCK_K,
                    PRESHUFFLE_FACTOR_WS,
                    SCALE_KWIDTH,
                )
            ).load(layout=DOT_LAYOUT_W_SCALES)
        else:
            next_w_scales = w_scales_buffer.index(wmma_idx % NUM_BUFFERS).load(
                layout=DOT_LAYOUT_W_SCALES
            )
        wmma_idx += 1

        # prepare next iteration
        cur_x = next_x
        cur_w = next_w
        cur_x_scales = next_x_scales
        cur_w_scales = next_w_scales

    # issue last wmma
    acc = gl.amd.gfx1250.wmma_scaled(
        cur_x, cur_x_scales, "e2m1", cur_w, cur_w_scales, "e2m1", acc
    )

    # bias
    if B is not None:
        gl.amd.gfx1250.tdm.async_wait(0)
        bias = bias_buffer.reshape((BLOCK_N,)).load(
            layout=gl.SliceLayout(0, WMMA_LAYOUT)
        )
        acc = acc + bias[None, :]

    # apply activation function
    if APPLY_SWIGLU:
        out = _swiglu(acc, alpha, limit, ADD_RESIDUAL)
        out = gl.convert_layout(out, WMMA_LAYOUT)
        gl.static_assert(
            out.shape[1] == OUT_BLOCK_N,
            f"Activation fn out.shape[1] ({out.shape[1]}) doesn't match computed OUT_BLOCK_N ({OUT_BLOCK_N})",
        )
    else:
        gl.static_assert(
            ACTIVATION_REDUCTION_N == 1,
            "Activation reduction must be 1 if no activation fn is provided",
        )
        out = acc

    # apply gammas
    if Gammas is not None:
        offs_m = BLOCK_M * block_id + gl.arange(0, BLOCK_M)
        mask_m = offs_m < M
        gammas = gl.amd.gfx1250.buffer_load(
            Gammas + start_m, offs_m, mask=mask_m, other=0.0
        )
        out *= gammas[:, None]

    if HAS_MX_OUT:
        # MXFP4 emit. The consuming GEMM reads ACTIVATION scales unswizzled in
        # every branch -- SWIZZLE_MX_SCALE gates only w_scales -- so plain
        # row-major [M, yN/32] e8m0 is exactly the layout it wants. And
        # _mxfp4_quant_op is the same device function `mxfp4_quant` calls, so
        # the nibble packing is byte-identical to the standalone launch this
        # replaces.
        gl.static_assert(
            OUT_BLOCK_N % 32 == 0, "HAS_MX_OUT requires OUT_BLOCK_N % 32 == 0"
        )
        NUM_QB: gl.constexpr = OUT_BLOCK_N // 32
        # Quant groups are 32 wide along N and OUT_BLOCK_N % 32 == 0, so every
        # group lies inside this tile: no cross-program reduction, and the
        # amax of a padding row can only ever affect that same padding row.
        packed, bs_e8m0 = _mxfp4_quant_op(
            out.to(gl.bfloat16).to(gl.float32), OUT_BLOCK_N, BLOCK_M, 32
        )
        # The two stores get their own row offsets rather than sharing one. The
        # values and the scales come off different tails of the reshape/split
        # chain and so carry different layouts; a shared offset tensor would have
        # to resolve to both at once, which fails auto-encoding resolution with
        # "'tt.addptr' op found conflicting encodings for value".
        #
        # packed is [BLOCK_M, OUT_BLOCK_N // 2] -- two nibbles per byte along N,
        # so both the column offset and the row-length bound halve.
        offs_m_p = BLOCK_M * block_id + gl.arange(0, BLOCK_M)
        offs_n_p = pid_n * (OUT_BLOCK_N // 2) + gl.arange(0, OUT_BLOCK_N // 2)
        gl.store(
            Y
            + (start_m + offs_m_p).to(index_type)[:, None] * stride_y_m
            + offs_n_p[None, :] * stride_y_n,
            packed,
            mask=(offs_m_p[:, None] < M) & (offs_n_p[None, :] < yN // 2),
        )
        offs_m_s = BLOCK_M * block_id + gl.arange(0, BLOCK_M)
        offs_n_s = pid_n * NUM_QB + gl.arange(0, NUM_QB)
        gl.store(
            YMxScale
            + (start_m + offs_m_s).to(index_type)[:, None] * stride_y_mx_m
            + offs_n_s[None, :] * stride_y_mx_n,
            bs_e8m0,
            mask=(offs_m_s[:, None] < M) & (offs_n_s[None, :] < gl.cdiv(yN, 32)),
        )
    elif EP_SCATTER:
        # Expert-parallel combine: these rows leave for arbitrary rows of a peer
        # combine-staging window rather than for their slot in a contiguous Y
        # tile, so there is no block move left to hand TDM -- address each row
        # from its own destination. The rows are already in registers here, so
        # the separate `scatter_grouped` pass over (M x hidden) disappears.
        #
        # Gammas was applied above, exactly as on the reduce path, so rows land
        # already route-weighted and the peer's combine sum stays unweighted.
        out = out.to(gl.bfloat16)
        # Build the row offsets DIRECTLY in the layout async_scatter wants, so
        # there is one layout end to end. Letting the arange auto-resolve and
        # converting `dst` afterwards makes it feed two conflicting consumers
        # (buffer_load and the scatter), and auto-encoding cannot pick:
        # "'tt.make_range' op Failed to infer return type".
        THREADS_PER_WARP: gl.constexpr = 32
        NUM_WARPS: gl.constexpr = gl.num_warps()
        M_PER_WARP: gl.constexpr = BLOCK_M // NUM_WARPS if BLOCK_M >= NUM_WARPS else 1
        idx_base: gl.constexpr = gl.BlockedLayout(
            [M_PER_WARP, 1], [1, THREADS_PER_WARP], [NUM_WARPS, 1], [1, 0]
        )
        idx_layout: gl.constexpr = gl.SliceLayout(1, idx_base)
        offs_m_d = BLOCK_M * block_id + gl.arange(0, BLOCK_M, layout=idx_layout)
        dst = gl.amd.gfx1250.buffer_load(
            DstRow + start_m, offs_m_d, mask=offs_m_d < M, other=-1
        )
        # Delivered by TDM scatter through LDS, not by per-thread global stores.
        #
        # This matters ONLY because the destination is remote. ~3/4 of these rows
        # land in a peer's HBM over xGMI, where the transaction shape dominates:
        # per-thread stores emit OUT_BLOCK_N*2 bytes per row per tile (256 B at
        # BLOCK_N=128) as many small independent writes, while TDM moves whole
        # rows, 8 per instruction with int32 indices. flydsl's a8w4 GEMM2 does
        # exactly this and delivers the same rows for ~13us on top of its GEMM,
        # against ~177us for the per-thread version measured here.
        #
        # Rows this rank must not deliver, and the tile's padding rows, are aimed
        # at Y_ROWS -- the first row past the window -- so the bounds check drops
        # them instead of a mask doing it. Same trick flydsl uses.
        dst = gl.where(dst >= 0, dst, Y_ROWS)
        y_buffer = gl.allocate_shared_memory(
            Y.type.element_ty,
            shape=[BLOCK_M, OUT_BLOCK_N],
            layout=SHARED_LAYOUT_Y,
        )
        y_buffer.store(out)
        # Rows are addressed by index, so the descriptor carries only the column
        # position; no start_m bias applies, dst is already absolute.
        y_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=Y,
            shape=(Y_ROWS, yN),
            strides=(stride_y_m, stride_y_n),
            block_shape=(BLOCK_M, OUT_BLOCK_N),
            layout=SHARED_LAYOUT_Y,
        )
        y_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            y_desc, add_offsets=[0, pid_n * OUT_BLOCK_N], clamp_bounds=True
        )
        gl.amd.gfx1250.tdm.async_scatter(y_desc, dst, y_buffer)
        gl.amd.gfx1250.tdm.async_wait(0)
    else:
        # write-back via TDM store: registers -> shared memory -> global memory
        out = out.to(gl.bfloat16)
        Y += start_m.to(index_type) * stride_y_m
        y_buffer = gl.allocate_shared_memory(
            Y.type.element_ty,
            shape=[BLOCK_M, OUT_BLOCK_N],
            layout=SHARED_LAYOUT_Y,
        )
        y_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=Y,
            shape=(M, yN),
            strides=(stride_y_m, stride_y_n),
            block_shape=(BLOCK_M, OUT_BLOCK_N),
            layout=SHARED_LAYOUT_Y,
        )
        y_buffer.store(out)
        gl.amd.gfx1250.tdm.async_store(
            y_desc, [block_id * BLOCK_M, pid_n * OUT_BLOCK_N], y_buffer
        )
        gl.amd.gfx1250.tdm.async_wait(0)


@gluon.jit(
    launch_metadata=matmul_launch_metadata,
    do_not_specialize=["num_tokens"],
    repr=_moe_gemm_a4w4_decode_repr,
)
def _moe_gemm_a4w4_decode(
    Y,
    stride_y_m,
    stride_y_n,
    X,
    stride_x_m,
    stride_x_k,
    XMxScale,
    stride_x_mx_m,
    stride_x_mx_k,
    W,
    stride_w_e,
    stride_w_k,
    stride_w_n,
    WMxScale,
    stride_w_mx_e,
    stride_w_mx_k,
    stride_w_mx_n,
    # bias
    B,
    stride_b_e,
    Gammas,
    # shapes
    num_tokens,
    N: gl.constexpr,
    K: gl.constexpr,
    # expt data
    GatherIndx,
    ExptHist,
    ExptOffs,
    ExptOffsSum,
    ExptData,
    # true grid size
    grid_m,
    grid_n,
    # fused activation function
    APPLY_SWIGLU: gl.constexpr,
    alpha,
    limit,
    ACTIVATION_REDUCTION_N: gl.constexpr,
    ADD_RESIDUAL: gl.constexpr,
    # MoE config
    N_EXPTS_ACT: gl.constexpr,
    # optimization config
    BLOCK_M: gl.constexpr,
    BLOCK_N: gl.constexpr,
    BLOCK_K: gl.constexpr,
    XCD_SWIZZLE: gl.constexpr,
    SWIZZLE_MX_SCALE: gl.constexpr,  # "GFX1250_SCALE" | None
    PRESHUFFLE_WEIGHTS: gl.constexpr,
    NUM_BUFFERS: gl.constexpr,
    UPCAST_INDICES: gl.constexpr,
    X_SCALES_TDM: gl.constexpr,
    CLAMP_BOUNDS: gl.constexpr,
    # layouts
    WMMA_LAYOUT: gl.constexpr,
    DOT_LAYOUT_X: gl.constexpr,
    DOT_LAYOUT_W: gl.constexpr,
    DOT_LAYOUT_X_SCALES: gl.constexpr,
    DOT_LAYOUT_W_SCALES: gl.constexpr,
    GATHER_IDX_LAYOUT: gl.constexpr,
    BLOCKED_LAYOUT_X_SCALES: gl.constexpr,
    SHARED_LAYOUT_X: gl.constexpr,
    SHARED_LAYOUT_W: gl.constexpr,
    SHARED_LAYOUT_X_SCALES: gl.constexpr,
    SHARED_LAYOUT_W_SCALES: gl.constexpr,
    SHARED_LAYOUT_Y: gl.constexpr,
    # metaparameters
    num_warps: gl.constexpr,
    # MXFP4 output quant (GEMM1-style): emit e2m1 nibbles + e8m0 scales straight
    # from the epilogue so GEMM2 consumes them with no separate quant launch.
    YMxScale=None,
    stride_y_mx_m=0,
    stride_y_mx_n=0,
    HAS_MX_OUT: gl.constexpr = False,
    # Expert-parallel combine (GEMM2-style): per-row destination row in a peer
    # combine-staging window, negative where the row must not be delivered.
    DstRow=None,
    EP_SCATTER: gl.constexpr = False,
    # Row extent of the combine window, so an out-of-range index is droppable.
    Y_ROWS=0,
):
    MX_PACK_DIVISOR: gl.constexpr = 32
    gl.static_assert(
        BLOCK_K % MX_PACK_DIVISOR == 0, "BLOCK_K must be a multiple of MX_PACK_DIVISOR"
    )

    if X_SCALES_TDM:
        # via TDM: w, x, w scales, x scales
        NUM_TDM_OPS: gl.constexpr = 4
    else:
        # via TDM: w, x, w scales
        # via async_copy: x scales
        NUM_TDM_OPS: gl.constexpr = 3

    w_type: gl.constexpr = W.dtype.element_ty
    gl.static_assert(w_type == gl.uint8, "Weights must be uint8")
    gl.static_assert(
        WMxScale.dtype.element_ty == gl.uint8, "Weights scales must be uint8"
    )
    x_type: gl.constexpr = X.dtype.element_ty
    gl.static_assert(x_type == gl.uint8, "Activations must be uint8")
    gl.static_assert(
        XMxScale.dtype.element_ty == gl.uint8, "Activations scales must be uint8"
    )

    OUT_BLOCK_N: gl.constexpr = BLOCK_N // ACTIVATION_REDUCTION_N
    yN = N // ACTIVATION_REDUCTION_N

    # get program id
    pid = gl.program_id(0)
    index_type: gl.constexpr = gl.int64 if UPCAST_INDICES else gl.int32
    if XCD_SWIZZLE != 1:
        padding_m = grid_m - gl.load(ExptOffsSum)
        unpadded_m = grid_m - padding_m
        total_actual_tiles = unpadded_m * grid_n
        if padding_m > 0 and pid >= total_actual_tiles:
            return
        pid = remap_xcd(pid, total_actual_tiles, XCD_SWIZZLE)
    else:
        unpadded_m = grid_m
    pid_m, pid_n = pid_grid(pid, unpadded_m, grid_n, 1)

    # unpack expert data
    expt_data = gl.load(ExptData + pid_m)
    if XCD_SWIZZLE == 1 and expt_data == -1:
        return
    expt_id = expt_data & 0x0000FFFF
    block_id = expt_data >> 16
    M = gl.load(ExptHist + expt_id)
    start_m = gl.load(ExptOffs + expt_id)

    # get the packed block sizes
    # both A and B tensors are mxfp4
    #   2 MXFP4 elements are packed into 1 int8
    #   in the K dimension
    X_M_DIVISOR: gl.constexpr = 1
    X_K_DIVISOR: gl.constexpr = 2  # 2 MXFP4 elements packed into 1 byte
    W_K_DIVISOR: gl.constexpr = 2  # 2 MXFP4 elements packed into 1 byte
    W_N_DIVISOR: gl.constexpr = 1
    PACKED_BLOCK_M_X: gl.constexpr = BLOCK_M // X_M_DIVISOR
    PACKED_BLOCK_K_X: gl.constexpr = BLOCK_K // X_K_DIVISOR
    PACKED_BLOCK_K_W: gl.constexpr = BLOCK_K // W_K_DIVISOR
    PACKED_BLOCK_N_W: gl.constexpr = BLOCK_N // W_N_DIVISOR
    MX_SCALE_BLOCK_K: gl.constexpr = (
        BLOCK_K // MX_PACK_DIVISOR
    )  # 32 elements share 1 scale element

    # A pointers
    offs_x_m = PACKED_BLOCK_M_X * block_id
    if GatherIndx is None:
        X += start_m.to(index_type) * stride_x_m
        XMxScale += start_m.to(index_type) * stride_x_mx_m
    else:
        if GatherIndx.dtype.element_ty == gl.uint16:
            oob_idx = num_tokens.to(gl.uint16)
        else:
            oob_idx = num_tokens
        offs_x_m = PACKED_BLOCK_M_X * block_id + gl.arange(
            0, PACKED_BLOCK_M_X, layout=GATHER_IDX_LAYOUT
        )
        mask_idx = offs_x_m < M
        offs_x_m = offs_x_m % M
        GatherIndx += start_m
        offs_x_m = gl.load(GatherIndx + offs_x_m) // N_EXPTS_ACT
        offs_x_m = gl.where(mask_idx, offs_x_m, oob_idx)

    # A scale pointers
    if not X_SCALES_TDM:
        if NUM_BUFFERS > 1:
            X_SCALES_OFFS_LAYOUT: gl.constexpr = BLOCKED_LAYOUT_X_SCALES
        else:
            X_SCALES_OFFS_LAYOUT: gl.constexpr = DOT_LAYOUT_X_SCALES
        offs_x_m_scales = PACKED_BLOCK_M_X * block_id + gl.arange(
            0,
            PACKED_BLOCK_M_X,
            layout=gl.SliceLayout(1, X_SCALES_OFFS_LAYOUT),
        )
        offs_x_m_scales = offs_x_m_scales % M
        if GatherIndx is not None:
            offs_x_m_scales = gl.load(GatherIndx + offs_x_m_scales) // N_EXPTS_ACT
        offs_x_k_scales = gl.arange(
            0, MX_SCALE_BLOCK_K, layout=gl.SliceLayout(0, X_SCALES_OFFS_LAYOUT)
        )
        if NUM_BUFFERS > 1:
            x_scales_ptrs = (
                XMxScale
                + offs_x_m_scales.to(index_type)[:, None] * stride_x_mx_m
                + offs_x_k_scales.to(index_type)[None, :] * stride_x_mx_k
            )
        else:
            x_scales_offs = (
                offs_x_m_scales[:, None] * stride_x_mx_m
                + offs_x_k_scales[None, :] * stride_x_mx_k
            ).to(gl.int32)

    # B pointers
    W += expt_id.to(index_type) * stride_w_e
    if PRESHUFFLE_WEIGHTS:
        PRESHUFFLE_FACTOR_W: gl.constexpr = 16
        SHUFFLED_BLOCK_K_W: gl.constexpr = PACKED_BLOCK_K_W * PRESHUFFLE_FACTOR_W
        SHUFFLED_BLOCK_N_W: gl.constexpr = PACKED_BLOCK_N_W // PRESHUFFLE_FACTOR_W
    else:
        PRESHUFFLE_FACTOR_W: gl.constexpr = 1
        SHUFFLED_BLOCK_K_W: gl.constexpr = PACKED_BLOCK_K_W
        SHUFFLED_BLOCK_N_W: gl.constexpr = PACKED_BLOCK_N_W
    offs_w_n = pid_n * SHUFFLED_BLOCK_N_W

    # B scale pointers
    WMxScale += expt_id.to(index_type) * stride_w_mx_e
    if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
        PRESHUFFLE_FACTOR_WS: gl.constexpr = 32
        SHUFFLED_BLOCK_K_WS: gl.constexpr = MX_SCALE_BLOCK_K * PRESHUFFLE_FACTOR_WS
        SHUFFLED_BLOCK_N_WS: gl.constexpr = BLOCK_N // PRESHUFFLE_FACTOR_WS
        SCALE_KWIDTH: gl.constexpr = 4
    else:
        PRESHUFFLE_FACTOR_WS: gl.constexpr = 1
        SHUFFLED_BLOCK_K_WS: gl.constexpr = MX_SCALE_BLOCK_K
        SHUFFLED_BLOCK_N_WS: gl.constexpr = BLOCK_N
    offs_w_n_scale = pid_n * SHUFFLED_BLOCK_N_WS

    if GatherIndx is None:
        x_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=X,
            shape=(M, K // X_K_DIVISOR),
            strides=(stride_x_m, stride_x_k),
            block_shape=(PACKED_BLOCK_M_X, PACKED_BLOCK_K_X),
            layout=SHARED_LAYOUT_X,
        )
        x_scales_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=XMxScale,
            shape=(M, gl.cdiv(K, MX_PACK_DIVISOR)),
            strides=(stride_x_mx_m, stride_x_mx_k),
            block_shape=(PACKED_BLOCK_M_X, MX_SCALE_BLOCK_K),
            layout=SHARED_LAYOUT_X_SCALES,
        )
    else:
        x_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=X,
            shape=(num_tokens, K // X_K_DIVISOR),
            strides=(stride_x_m, stride_x_k),
            block_shape=(PACKED_BLOCK_M_X, PACKED_BLOCK_K_X),
            layout=SHARED_LAYOUT_X,
        )
        x_scales_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=XMxScale,
            shape=(num_tokens, gl.cdiv(K, MX_PACK_DIVISOR)),
            strides=(stride_x_mx_m, stride_x_mx_k),
            block_shape=(PACKED_BLOCK_M_X, MX_SCALE_BLOCK_K),
            layout=SHARED_LAYOUT_X_SCALES,
        )
    w_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
        base=W,
        shape=(N // PRESHUFFLE_FACTOR_W, K // W_K_DIVISOR * PRESHUFFLE_FACTOR_W),
        strides=(stride_w_n, stride_w_k),
        block_shape=(SHUFFLED_BLOCK_N_W, SHUFFLED_BLOCK_K_W),
        layout=SHARED_LAYOUT_W,
    )
    w_scales_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
        base=WMxScale,
        shape=(
            N // PRESHUFFLE_FACTOR_WS,
            gl.cdiv(K, MX_PACK_DIVISOR) * PRESHUFFLE_FACTOR_WS,
        ),
        strides=(stride_w_mx_n, stride_w_mx_k),
        block_shape=(SHUFFLED_BLOCK_N_WS, SHUFFLED_BLOCK_K_WS),
        layout=SHARED_LAYOUT_W_SCALES,
    )

    x_buffer = gl.allocate_shared_memory(
        x_desc.dtype, shape=[NUM_BUFFERS] + x_desc.block_shape, layout=x_desc.layout
    )
    w_buffer = gl.allocate_shared_memory(
        w_desc.dtype, shape=[NUM_BUFFERS] + w_desc.block_shape, layout=w_desc.layout
    )
    if X_SCALES_TDM or NUM_BUFFERS > 1:
        x_scales_buffer = gl.allocate_shared_memory(
            x_scales_desc.dtype,
            shape=[NUM_BUFFERS] + x_scales_desc.block_shape,
            layout=x_scales_desc.layout,
        )
    w_scales_buffer = gl.allocate_shared_memory(
        w_scales_desc.dtype,
        shape=[NUM_BUFFERS] + w_scales_desc.block_shape,
        layout=w_scales_desc.layout,
    )

    load_idx = 0
    wmma_idx = 0

    num_k_iter = gl.cdiv(K, BLOCK_K)

    # prologue: fill NUM_BUFFERS - 1 LDS slots via TDM, leaving one slot for the
    # main loop's own issue. w goes first so the split wait below can pick it up
    # before the rest of the tile has landed.
    for _ in gl.static_range(NUM_BUFFERS - 1):
        gl.amd.gfx1250.tdm.async_load(
            w_desc,
            [offs_w_n, 0],
            w_buffer.index(load_idx % NUM_BUFFERS),
        )
        if GatherIndx is None:
            gl.amd.gfx1250.tdm.async_load(
                x_desc,
                [offs_x_m, 0],
                x_buffer.index(load_idx % NUM_BUFFERS),
            )
        else:
            gl.amd.gfx1250.tdm.async_gather(
                x_desc,
                offs_x_m,
                x_buffer.index(load_idx % NUM_BUFFERS),
            )
        gl.amd.gfx1250.tdm.async_load(
            w_scales_desc,
            [offs_w_n_scale, 0],
            w_scales_buffer.index(load_idx % NUM_BUFFERS),
        )
        if X_SCALES_TDM:
            if GatherIndx is None:
                gl.amd.gfx1250.tdm.async_load(
                    x_scales_desc,
                    [offs_x_m, 0],
                    x_scales_buffer.index(load_idx % NUM_BUFFERS),
                )
            else:
                gl.amd.gfx1250.tdm.async_gather(
                    x_scales_desc,
                    offs_x_m,
                    x_scales_buffer.index(load_idx % NUM_BUFFERS),
                )
        else:
            if NUM_BUFFERS > 1:
                gl.amd.gfx1250.async_copy.global_to_shared(
                    x_scales_buffer.index(load_idx % NUM_BUFFERS),
                    x_scales_ptrs,
                )
                gl.amd.gfx1250.async_copy.commit_group()
                x_scales_ptrs += MX_SCALE_BLOCK_K * stride_x_mx_k
            else:
                cur_x_scales = gl.amd.gfx1250.buffer_load(XMxScale, x_scales_offs)
                x_scales_offs += MX_SCALE_BLOCK_K * stride_x_mx_k

        # update descriptors
        w_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            w_desc, add_offsets=[0, SHUFFLED_BLOCK_K_W], clamp_bounds=CLAMP_BOUNDS
        )
        x_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            x_desc, add_offsets=[0, PACKED_BLOCK_K_X], clamp_bounds=CLAMP_BOUNDS
        )
        w_scales_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            w_scales_desc,
            add_offsets=[0, SHUFFLED_BLOCK_K_WS],
            clamp_bounds=CLAMP_BOUNDS,
        )
        if X_SCALES_TDM:
            x_scales_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
                x_scales_desc,
                add_offsets=[0, MX_SCALE_BLOCK_K],
                clamp_bounds=CLAMP_BOUNDS,
            )

        load_idx += 1

    acc = gl.zeros((BLOCK_M, BLOCK_N), dtype=gl.float32, layout=WMMA_LAYOUT)

    if NUM_BUFFERS == 1:
        num_k_iter -= 1
        gl.amd.gfx1250.tdm.async_load(
            w_desc,
            [offs_w_n, 0],
            w_buffer.index(load_idx % NUM_BUFFERS),
        )
        if GatherIndx is None:
            gl.amd.gfx1250.tdm.async_load(
                x_desc,
                [offs_x_m, 0],
                x_buffer.index(load_idx % NUM_BUFFERS),
            )
        else:
            gl.amd.gfx1250.tdm.async_gather(
                x_desc,
                offs_x_m,
                x_buffer.index(load_idx % NUM_BUFFERS),
            )
        gl.amd.gfx1250.tdm.async_load(
            w_scales_desc,
            [offs_w_n_scale, 0],
            w_scales_buffer.index(load_idx % NUM_BUFFERS),
        )
        if X_SCALES_TDM:
            if GatherIndx is None:
                gl.amd.gfx1250.tdm.async_load(
                    x_scales_desc,
                    [offs_x_m, 0],
                    x_scales_buffer.index(load_idx % NUM_BUFFERS),
                )
            else:
                gl.amd.gfx1250.tdm.async_gather(
                    x_scales_desc,
                    offs_x_m,
                    x_scales_buffer.index(load_idx % NUM_BUFFERS),
                )
        else:
            cur_x_scales = gl.amd.gfx1250.buffer_load(XMxScale, x_scales_offs)
            x_scales_offs += MX_SCALE_BLOCK_K * stride_x_mx_k

        # update descriptors
        w_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            w_desc, add_offsets=[0, SHUFFLED_BLOCK_K_W], clamp_bounds=CLAMP_BOUNDS
        )
        x_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            x_desc, add_offsets=[0, PACKED_BLOCK_K_X], clamp_bounds=CLAMP_BOUNDS
        )
        w_scales_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            w_scales_desc,
            add_offsets=[0, SHUFFLED_BLOCK_K_WS],
            clamp_bounds=CLAMP_BOUNDS,
        )
        if X_SCALES_TDM:
            x_scales_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
                x_scales_desc,
                add_offsets=[0, MX_SCALE_BLOCK_K],
                clamp_bounds=CLAMP_BOUNDS,
            )

        gl.amd.gfx1250.tdm.async_wait(NUM_BUFFERS * NUM_TDM_OPS - 1)
        if PRESHUFFLE_WEIGHTS:
            cur_w = (
                (
                    unshuffle_weights_gfx1250(
                        w_buffer.index(wmma_idx % NUM_BUFFERS),
                        PACKED_BLOCK_N_W,
                        PACKED_BLOCK_K_W,
                    )
                )
                .permute((1, 0))
                .load(layout=DOT_LAYOUT_W)
            )
        else:
            cur_w = (
                w_buffer.index(wmma_idx % NUM_BUFFERS)
                .permute((1, 0))
                .load(layout=DOT_LAYOUT_W)
            )

        gl.amd.gfx1250.tdm.async_wait((NUM_BUFFERS - 1) * NUM_TDM_OPS)
        if not X_SCALES_TDM and NUM_BUFFERS > 1:
            gl.amd.gfx1250.async_copy.wait_group(NUM_BUFFERS - 1)
        cur_x = x_buffer.index(wmma_idx % NUM_BUFFERS).load(layout=DOT_LAYOUT_X)
        if X_SCALES_TDM or NUM_BUFFERS > 1:
            cur_x_scales = x_scales_buffer.index(wmma_idx % NUM_BUFFERS).load(
                layout=DOT_LAYOUT_X_SCALES
            )
        if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
            cur_w_scales = (
                unswizzle_scales_gfx1250(
                    w_scales_buffer.index(wmma_idx % NUM_BUFFERS),
                    BLOCK_N,
                    MX_SCALE_BLOCK_K,
                    PRESHUFFLE_FACTOR_WS,
                    SCALE_KWIDTH,
                )
            ).load(layout=DOT_LAYOUT_W_SCALES)
        else:
            cur_w_scales = w_scales_buffer.index(wmma_idx % NUM_BUFFERS).load(
                layout=DOT_LAYOUT_W_SCALES
            )

        acc = gl.amd.gfx1250.wmma_scaled(
            cur_x, cur_x_scales, "e2m1", cur_w, cur_w_scales, "e2m1", acc
        )

    # main loop: fill LDS with the next tile, then consume the oldest one
    for _ in range(num_k_iter - (NUM_BUFFERS - 1)):
        gl.amd.gfx1250.tdm.async_load(
            w_desc,
            [offs_w_n, 0],
            w_buffer.index(load_idx % NUM_BUFFERS),
        )
        if GatherIndx is None:
            gl.amd.gfx1250.tdm.async_load(
                x_desc,
                [offs_x_m, 0],
                x_buffer.index(load_idx % NUM_BUFFERS),
            )
        else:
            gl.amd.gfx1250.tdm.async_gather(
                x_desc,
                offs_x_m,
                x_buffer.index(load_idx % NUM_BUFFERS),
            )
        gl.amd.gfx1250.tdm.async_load(
            w_scales_desc,
            [offs_w_n_scale, 0],
            w_scales_buffer.index(load_idx % NUM_BUFFERS),
        )
        if X_SCALES_TDM:
            if GatherIndx is None:
                gl.amd.gfx1250.tdm.async_load(
                    x_scales_desc,
                    [offs_x_m, 0],
                    x_scales_buffer.index(load_idx % NUM_BUFFERS),
                )
            else:
                gl.amd.gfx1250.tdm.async_gather(
                    x_scales_desc,
                    offs_x_m,
                    x_scales_buffer.index(load_idx % NUM_BUFFERS),
                )
        else:
            if NUM_BUFFERS > 1:
                gl.amd.gfx1250.async_copy.global_to_shared(
                    x_scales_buffer.index(load_idx % NUM_BUFFERS),
                    x_scales_ptrs,
                )
                gl.amd.gfx1250.async_copy.commit_group()
                x_scales_ptrs += MX_SCALE_BLOCK_K * stride_x_mx_k
            else:
                cur_x_scales = gl.amd.gfx1250.buffer_load(XMxScale, x_scales_offs)
                x_scales_offs += MX_SCALE_BLOCK_K * stride_x_mx_k

        # update descriptors
        w_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            w_desc, add_offsets=[0, SHUFFLED_BLOCK_K_W], clamp_bounds=CLAMP_BOUNDS
        )
        x_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            x_desc, add_offsets=[0, PACKED_BLOCK_K_X], clamp_bounds=CLAMP_BOUNDS
        )
        w_scales_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            w_scales_desc,
            add_offsets=[0, SHUFFLED_BLOCK_K_WS],
            clamp_bounds=CLAMP_BOUNDS,
        )
        if X_SCALES_TDM:
            x_scales_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
                x_scales_desc,
                add_offsets=[0, MX_SCALE_BLOCK_K],
                clamp_bounds=CLAMP_BOUNDS,
            )

        load_idx += 1

        # w is the first op issued per tile, so it completes first: wait for it
        # alone and start reading it while the rest of the tile is in flight
        gl.amd.gfx1250.tdm.async_wait(NUM_BUFFERS * NUM_TDM_OPS - 1)
        if PRESHUFFLE_WEIGHTS:
            cur_w = (
                (
                    unshuffle_weights_gfx1250(
                        w_buffer.index(wmma_idx % NUM_BUFFERS),
                        PACKED_BLOCK_N_W,
                        PACKED_BLOCK_K_W,
                    )
                )
                .permute((1, 0))
                .load(layout=DOT_LAYOUT_W)
            )
        else:
            cur_w = (
                w_buffer.index(wmma_idx % NUM_BUFFERS)
                .permute((1, 0))
                .load(layout=DOT_LAYOUT_W)
            )

        # wait for the remainder of the tile
        gl.amd.gfx1250.tdm.async_wait((NUM_BUFFERS - 1) * NUM_TDM_OPS)
        if not X_SCALES_TDM and NUM_BUFFERS > 1:
            gl.amd.gfx1250.async_copy.wait_group(NUM_BUFFERS - 1)
        cur_x = x_buffer.index(wmma_idx % NUM_BUFFERS).load(layout=DOT_LAYOUT_X)
        if X_SCALES_TDM or NUM_BUFFERS > 1:
            cur_x_scales = x_scales_buffer.index(wmma_idx % NUM_BUFFERS).load(
                layout=DOT_LAYOUT_X_SCALES
            )
        if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
            cur_w_scales = (
                unswizzle_scales_gfx1250(
                    w_scales_buffer.index(wmma_idx % NUM_BUFFERS),
                    BLOCK_N,
                    MX_SCALE_BLOCK_K,
                    PRESHUFFLE_FACTOR_WS,
                    SCALE_KWIDTH,
                )
            ).load(layout=DOT_LAYOUT_W_SCALES)
        else:
            cur_w_scales = w_scales_buffer.index(wmma_idx % NUM_BUFFERS).load(
                layout=DOT_LAYOUT_W_SCALES
            )
        wmma_idx += 1

        acc = gl.amd.gfx1250.wmma_scaled(
            cur_x, cur_x_scales, "e2m1", cur_w, cur_w_scales, "e2m1", acc
        )

    # load bias into LDS while the pipeline drains
    if B is not None:
        B += expt_id * stride_b_e
        SHARED_LAYOUT_BIAS: gl.constexpr = gl.SwizzledSharedLayout(
            vec=1, per_phase=1, max_phase=1, order=[1, 0]
        )
        bias_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=B,
            shape=(1, N),
            strides=(stride_b_e, 1),
            block_shape=(1, BLOCK_N),
            layout=SHARED_LAYOUT_BIAS,
        )
        bias_buffer = gl.allocate_shared_memory(
            bias_desc.dtype, shape=[1, BLOCK_N], layout=bias_desc.layout
        )
        gl.amd.gfx1250.tdm.async_load(
            bias_desc,
            [0, pid_n * BLOCK_N],
            bias_buffer,
        )
        TDM_BIAS_WAIT: gl.constexpr = 1
    else:
        TDM_BIAS_WAIT: gl.constexpr = 0

    # epilogue: drain remaining tiles (no new TDM loads)
    for k_ep in gl.static_range(NUM_BUFFERS - 1):
        gl.amd.gfx1250.tdm.async_wait(
            (NUM_BUFFERS - 1 - k_ep) * NUM_TDM_OPS - 1 + TDM_BIAS_WAIT
        )
        if PRESHUFFLE_WEIGHTS:
            cur_w = (
                (
                    unshuffle_weights_gfx1250(
                        w_buffer.index(wmma_idx % NUM_BUFFERS),
                        PACKED_BLOCK_N_W,
                        PACKED_BLOCK_K_W,
                    )
                )
                .permute((1, 0))
                .load(layout=DOT_LAYOUT_W)
            )
        else:
            cur_w = (
                w_buffer.index(wmma_idx % NUM_BUFFERS)
                .permute((1, 0))
                .load(layout=DOT_LAYOUT_W)
            )

        gl.amd.gfx1250.tdm.async_wait(
            (NUM_BUFFERS - 2 - k_ep) * NUM_TDM_OPS + TDM_BIAS_WAIT
        )
        if not X_SCALES_TDM:
            gl.amd.gfx1250.async_copy.wait_group(NUM_BUFFERS - 2 - k_ep)
        cur_x = x_buffer.index(wmma_idx % NUM_BUFFERS).load(layout=DOT_LAYOUT_X)
        cur_x_scales = x_scales_buffer.index(wmma_idx % NUM_BUFFERS).load(
            layout=DOT_LAYOUT_X_SCALES
        )
        if SWIZZLE_MX_SCALE == "GFX1250_SCALE":
            cur_w_scales = (
                unswizzle_scales_gfx1250(
                    w_scales_buffer.index(wmma_idx % NUM_BUFFERS),
                    BLOCK_N,
                    MX_SCALE_BLOCK_K,
                    PRESHUFFLE_FACTOR_WS,
                    SCALE_KWIDTH,
                )
            ).load(layout=DOT_LAYOUT_W_SCALES)
        else:
            cur_w_scales = w_scales_buffer.index(wmma_idx % NUM_BUFFERS).load(
                layout=DOT_LAYOUT_W_SCALES
            )
        wmma_idx += 1

        acc = gl.amd.gfx1250.wmma_scaled(
            cur_x, cur_x_scales, "e2m1", cur_w, cur_w_scales, "e2m1", acc
        )

    # bias
    if B is not None:
        gl.amd.gfx1250.tdm.async_wait(0)
        bias = bias_buffer.reshape((BLOCK_N,)).load(
            layout=gl.SliceLayout(0, WMMA_LAYOUT)
        )
        acc = acc + bias[None, :]

    # apply activation function
    if APPLY_SWIGLU:
        out = _swiglu(acc, alpha, limit, ADD_RESIDUAL)
        out = gl.convert_layout(out, WMMA_LAYOUT)
        gl.static_assert(
            out.shape[1] == OUT_BLOCK_N,
            f"Activation fn out.shape[1] ({out.shape[1]}) doesn't match computed OUT_BLOCK_N ({OUT_BLOCK_N})",
        )
    else:
        gl.static_assert(
            ACTIVATION_REDUCTION_N == 1,
            "Activation reduction must be 1 if no activation fn is provided",
        )
        out = acc

    # apply gammas
    if Gammas is not None:
        offs_m = BLOCK_M * block_id + gl.arange(0, BLOCK_M)
        mask_m = offs_m < M
        gammas = gl.amd.gfx1250.buffer_load(
            Gammas + start_m, offs_m, mask=mask_m, other=0.0
        )
        out *= gammas[:, None]

    if HAS_MX_OUT:
        # MXFP4 emit. The consuming GEMM reads ACTIVATION scales unswizzled in
        # every branch -- SWIZZLE_MX_SCALE gates only w_scales -- so plain
        # row-major [M, yN/32] e8m0 is exactly the layout it wants. And
        # _mxfp4_quant_op is the same device function `mxfp4_quant` calls, so
        # the nibble packing is byte-identical to the standalone launch this
        # replaces.
        gl.static_assert(
            OUT_BLOCK_N % 32 == 0, "HAS_MX_OUT requires OUT_BLOCK_N % 32 == 0"
        )
        NUM_QB: gl.constexpr = OUT_BLOCK_N // 32
        # Quant groups are 32 wide along N and OUT_BLOCK_N % 32 == 0, so every
        # group lies inside this tile: no cross-program reduction, and the
        # amax of a padding row can only ever affect that same padding row.
        packed, bs_e8m0 = _mxfp4_quant_op(
            out.to(gl.bfloat16).to(gl.float32), OUT_BLOCK_N, BLOCK_M, 32
        )
        # The two stores get their own row offsets rather than sharing one. The
        # values and the scales come off different tails of the reshape/split
        # chain and so carry different layouts; a shared offset tensor would have
        # to resolve to both at once, which fails auto-encoding resolution with
        # "'tt.addptr' op found conflicting encodings for value".
        #
        # packed is [BLOCK_M, OUT_BLOCK_N // 2] -- two nibbles per byte along N,
        # so both the column offset and the row-length bound halve.
        offs_m_p = BLOCK_M * block_id + gl.arange(0, BLOCK_M)
        offs_n_p = pid_n * (OUT_BLOCK_N // 2) + gl.arange(0, OUT_BLOCK_N // 2)
        gl.store(
            Y
            + (start_m + offs_m_p).to(index_type)[:, None] * stride_y_m
            + offs_n_p[None, :] * stride_y_n,
            packed,
            mask=(offs_m_p[:, None] < M) & (offs_n_p[None, :] < yN // 2),
        )
        offs_m_s = BLOCK_M * block_id + gl.arange(0, BLOCK_M)
        offs_n_s = pid_n * NUM_QB + gl.arange(0, NUM_QB)
        gl.store(
            YMxScale
            + (start_m + offs_m_s).to(index_type)[:, None] * stride_y_mx_m
            + offs_n_s[None, :] * stride_y_mx_n,
            bs_e8m0,
            mask=(offs_m_s[:, None] < M) & (offs_n_s[None, :] < gl.cdiv(yN, 32)),
        )
    elif EP_SCATTER:
        # Expert-parallel combine: these rows leave for arbitrary rows of a peer
        # combine-staging window rather than for their slot in a contiguous Y
        # tile, so there is no block move left to hand TDM -- address each row
        # from its own destination. The rows are already in registers here, so
        # the separate `scatter_grouped` pass over (M x hidden) disappears.
        #
        # Gammas was applied above, exactly as on the reduce path, so rows land
        # already route-weighted and the peer's combine sum stays unweighted.
        out = out.to(gl.bfloat16)
        # Build the row offsets DIRECTLY in the layout async_scatter wants, so
        # there is one layout end to end. Letting the arange auto-resolve and
        # converting `dst` afterwards makes it feed two conflicting consumers
        # (buffer_load and the scatter), and auto-encoding cannot pick:
        # "'tt.make_range' op Failed to infer return type".
        THREADS_PER_WARP: gl.constexpr = 32
        NUM_WARPS: gl.constexpr = gl.num_warps()
        M_PER_WARP: gl.constexpr = BLOCK_M // NUM_WARPS if BLOCK_M >= NUM_WARPS else 1
        idx_base: gl.constexpr = gl.BlockedLayout(
            [M_PER_WARP, 1], [1, THREADS_PER_WARP], [NUM_WARPS, 1], [1, 0]
        )
        idx_layout: gl.constexpr = gl.SliceLayout(1, idx_base)
        offs_m_d = BLOCK_M * block_id + gl.arange(0, BLOCK_M, layout=idx_layout)
        dst = gl.amd.gfx1250.buffer_load(
            DstRow + start_m, offs_m_d, mask=offs_m_d < M, other=-1
        )
        # Delivered by TDM scatter through LDS, not by per-thread global stores.
        #
        # This matters ONLY because the destination is remote. ~3/4 of these rows
        # land in a peer's HBM over xGMI, where the transaction shape dominates:
        # per-thread stores emit OUT_BLOCK_N*2 bytes per row per tile (256 B at
        # BLOCK_N=128) as many small independent writes, while TDM moves whole
        # rows, 8 per instruction with int32 indices. flydsl's a8w4 GEMM2 does
        # exactly this and delivers the same rows for ~13us on top of its GEMM,
        # against ~177us for the per-thread version measured here.
        #
        # Rows this rank must not deliver, and the tile's padding rows, are aimed
        # at Y_ROWS -- the first row past the window -- so the bounds check drops
        # them instead of a mask doing it. Same trick flydsl uses.
        dst = gl.where(dst >= 0, dst, Y_ROWS)
        y_buffer = gl.allocate_shared_memory(
            Y.type.element_ty,
            shape=[BLOCK_M, OUT_BLOCK_N],
            layout=SHARED_LAYOUT_Y,
        )
        y_buffer.store(out)
        # Rows are addressed by index, so the descriptor carries only the column
        # position; no start_m bias applies, dst is already absolute.
        y_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=Y,
            shape=(Y_ROWS, yN),
            strides=(stride_y_m, stride_y_n),
            block_shape=(BLOCK_M, OUT_BLOCK_N),
            layout=SHARED_LAYOUT_Y,
        )
        y_desc = gl.amd.gfx1250.tdm.update_tensor_descriptor(
            y_desc, add_offsets=[0, pid_n * OUT_BLOCK_N], clamp_bounds=True
        )
        gl.amd.gfx1250.tdm.async_scatter(y_desc, dst, y_buffer)
        gl.amd.gfx1250.tdm.async_wait(0)
    else:
        # write-back via TDM store: registers -> shared memory -> global memory
        out = out.to(gl.bfloat16)
        Y += start_m.to(index_type) * stride_y_m
        y_buffer = gl.allocate_shared_memory(
            Y.type.element_ty,
            shape=[BLOCK_M, OUT_BLOCK_N],
            layout=SHARED_LAYOUT_Y,
        )
        y_desc = gl.amd.gfx1250.tdm.make_tensor_descriptor(
            base=Y,
            shape=(M, yN),
            strides=(stride_y_m, stride_y_n),
            block_shape=(BLOCK_M, OUT_BLOCK_N),
            layout=SHARED_LAYOUT_Y,
        )
        y_buffer.store(out)
        gl.amd.gfx1250.tdm.async_store(
            y_desc, [block_id * BLOCK_M, pid_n * OUT_BLOCK_N], y_buffer
        )
        gl.amd.gfx1250.tdm.async_wait(0)
