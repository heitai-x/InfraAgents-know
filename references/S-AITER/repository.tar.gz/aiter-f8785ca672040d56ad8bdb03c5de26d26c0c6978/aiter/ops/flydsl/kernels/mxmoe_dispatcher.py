# SPDX-License-Identifier: Apache-2.0
# Copyright (C) 2025-2026 FlyDSL Project Contributors
"""Compile + launch dispatch for the layout-API MXFP4 MoE gemm (BM32, opus-sort); a4w4/a8w4 entry point."""

import os

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import const_expr, gpu, range_constexpr, rocdl
from flydsl.expr.typing import Int8, T

from aiter.jit.utils.chip_info import get_cu_num

from .mxfp4_gemm_common import _udiv
from .mxmoe_gemm_v2 import (
    gemm2_body_v2,
    global_typed_ptr,
    issue_a_load_lds_dt,
    kStages,
)
from .tensor_shim import _run_compiled as run_compiled

__all__ = [
    "compile_gemm2_a4w4_port",
    "mxfp4_moe_gemm2",
]


def _norm_sbm(SBM, BM):
    """Resolve SBM (sort_block_m): None -> SBM==BM."""
    return BM if SBM is None else SBM


def _active_m_blocks_upper_bound(M_logical, topk, NE, BM, SBM):
    """Host-side upper bound for non-persistent GEMM2 M tiles."""
    routes = M_logical * topk
    active_experts = min(routes, NE)
    sort_blocks = (routes + active_experts * (SBM - 1) + SBM - 1) // SBM
    return sort_blocks * (SBM // BM)


def _validate_v2_gemm2_dtypes(a_dtype: str, b_dtype: str) -> None:
    if (a_dtype, b_dtype) not in {
        ("fp4", "fp4"),
        ("fp8", "fp4"),
        ("fp8", "fp8"),
    }:
        raise AssertionError(f"unsupported v2 GEMM2 dtype pair {(a_dtype, b_dtype)!r}")


# ---- gemm2 (down-proj) compile ----
def _spart_output_tile_index(block_1d_id, M0, N0, group_num, m01, nmajor=False):
    """ck_tile GemmSpatiallyLocalTilePartitioner::GetOutputTileIndex: 1D block id -> spatially-local (m_block_idx, n_block_idx). block_1d_id/M0 runtime; N0/group_num/m01 compile-time."""
    gn = fx.Int32(group_num)
    n0 = fx.Int32(N0)
    m01c = fx.Int32(m01)

    # group_size = ceil(M0*N0 / GroupNum); big_group_num = GroupNum - (group_size*GroupNum - M0*N0)
    mn = M0 * n0
    group_size = _udiv(mn + gn - fx.Int32(1), gn)
    big_group_num = gn - (group_size * gn - mn)

    group_id_y = _udiv(block_1d_id, gn)
    group_id_x = block_1d_id - group_id_y * gn

    # remap = group_id_x <= big_group_num ? gx*gs + gy : gx*gs + big - gx + gy
    remap_a = group_id_x * group_size + group_id_y
    remap_b = group_id_x * group_size + big_group_num - group_id_x + group_id_y
    remap = (group_id_x <= big_group_num).select(remap_a, remap_b)

    if nmajor:
        if m01 != 1:
            raise AssertionError("nmajor requires m01==1")
        idx_N0 = _udiv(remap, M0)
        return remap - idx_N0 * M0, idx_N0

    idx_M0 = _udiv(remap, n0)
    idx_N0 = remap - idx_M0 * n0

    # M0_tmp = M0 / M01 ; M0_mod_M01 = M0 - M0_tmp*M01 ; M01_adapt = (idx_M0 < M0 - M0_mod) ? M01 : M0_mod
    M0_tmp = _udiv(M0, m01c)
    M0_mod = M0 - M0_tmp * m01c
    M01_adapt = (idx_M0 < (M0 - M0_mod)).select(m01c, M0_mod)

    idx_M00 = _udiv(idx_M0, m01c)
    idx_M01 = idx_M0 - idx_M00 * m01c
    idx_local = idx_N0 + idx_M01 * n0

    N_out = _udiv(idx_local, M01_adapt)
    loc_mod = idx_local - N_out * M01_adapt

    m_block_idx = loc_mod + idx_M00 * m01c
    n_block_idx = N_out
    return m_block_idx, n_block_idx


def _pick_epi_lanes(BM, BN, route_out_fp8, g2_scale_blk, nthreads=256):
    if not route_out_fp8:
        return None
    order = (32, 16, 8) if BN >= 512 else (16, 8, 32)
    for lanes in order:
        epi_rows = nthreads // lanes
        route_vec = BN // lanes
        if BM % epi_rows or BN % lanes or route_vec % 4:
            continue
        if g2_scale_blk in (route_vec, 2 * route_vec, 4 * route_vec):
            return lanes
    return None


def compile_gemm2_a4w4_port(
    BM=32,
    BN=256,
    BK=256,
    use_nt=False,
    HIDDEN_MAX=8192,
    epilog="atomic",
    INTER_MAX=8192,
    a_dtype="fp4",
    b_dtype="fp4",
    topk=1,
    SBM=None,
    persist=False,
    cu_num=0,
    g2_bhoist=None,
    g2_ascale_pf=None,
    g2_spart=None,
    g2_bf16_lds=None,
    g2_kstatic=False,
    out_dtype="bf16",
    enable_bias=False,
    _composition=None,
    _reduce_store_cache_modifier=None,
    _input_row_resolver=None,
    _output_n_range=None,
):
    """Compile gemm2 a4w4 down-proj; epilog 'atomic' (weighted atomic-fadd) or 'reduce' (store into out[token_id*topk+slot]). inter_dim runtime; SBM None -> SBM==BM byte-identical."""
    SBM = _norm_sbm(SBM, BM)
    if BM not in (16, 32, 64, 128) or epilog not in ("atomic", "reduce"):
        raise AssertionError(
            f"mxfp4_moe_gemm2 supports only (BM in {{16,32,64,128}}, epilog in {{'atomic','reduce'}}); "
            f"got (BM={BM}, epilog={epilog})"
        )
    if BN not in (128, 256, 512) or BK not in (128, 256):
        raise AssertionError(
            "mxfp4_moe_gemm2 supports only "
            f"(BN in {{128,256,512}}, BK in {{128,256}}); got (BN={BN}, BK={BK})"
        )
    if SBM % BM != 0:
        raise AssertionError(f"SBM ({SBM}) must be a multiple of BM ({BM})")
    if _composition is None and _input_row_resolver is not None:
        raise ValueError("an input row resolver requires a composition")
    if _reduce_store_cache_modifier is not None and _composition is None:
        raise ValueError("a custom reduce-store cache policy requires a composition")
    use_reduce = epilog == "reduce"
    out_dtype = str(out_dtype).strip().lower()
    if out_dtype not in ("bf16", "fp8"):
        raise AssertionError(f"out_dtype must be 'bf16' or 'fp8', got {out_dtype!r}")
    route_out_fp8 = out_dtype == "fp8"
    if route_out_fp8 and not use_reduce:
        raise AssertionError("out_dtype='fp8' is supported only with epilog='reduce'")
    g2_kstatic = bool(g2_kstatic)
    compact_route = _output_n_range is not None
    if compact_route:
        if not route_out_fp8:
            raise ValueError("weighted compact routes require FP8 reduce output")
        g2_defer_weight = False
        g2_out_pitch_align = 0
        g2_scale_blk = 8
    elif g2_kstatic and route_out_fp8:
        from .mxfp4_gemm_common import FP8OUT_PITCH_ALIGN, FP8OUT_SCALE_BLK

        g2_defer_weight = True
        g2_out_pitch_align = FP8OUT_PITCH_ALIGN
        g2_scale_blk = FP8OUT_SCALE_BLK
    else:
        g2_defer_weight = False
        g2_out_pitch_align = 0
        g2_scale_blk = 8
    if g2_bhoist is None:
        g2_bhoist = os.environ.get("MXFP4_G2_BHOIST", "1") == "1"
    g2_bhoist = bool(g2_bhoist)
    if g2_ascale_pf is None:
        g2_ascale_pf = os.environ.get("MXFP4_G2_ASCALE_PF", "1") == "1"
    g2_ascale_pf = bool(g2_ascale_pf)
    if g2_spart is None:
        g2_spart = int(os.environ.get("MXFP4_G2_SPART", "402"))
    g2_spart = int(g2_spart)
    g2_group_num = g2_spart // 100 if g2_spart > 0 else 0
    g2_m01 = g2_spart % 100 if g2_spart > 0 else 0
    if g2_spart > 0 and (g2_group_num < 1 or g2_m01 < 1):
        raise AssertionError(
            f"g2_spart={g2_spart} must encode GroupNum>=1,M01>=1 as GroupNum*100+M01 (e.g. 402)"
        )
    _validate_v2_gemm2_dtypes(a_dtype, b_dtype)
    assert INTER_MAX % BK == 0, f"INTER_MAX must be a multiple of {BK}, got {INTER_MAX}"
    is_f8 = a_dtype == "fp8"
    if g2_bf16_lds is None:
        default_bf16_lds = "1" if g2_kstatic else "0"
        g2_bf16_lds = os.environ.get("MXFP4_G2_BF16_LDS", default_bf16_lds) == "1"
    g2_bf16_lds = bool(g2_bf16_lds)
    KH_TILE_A = BK // (1 if is_f8 else 2)  # A LDS K-tile bytes (fp8 256, fp4 128)
    slot_bytes = BM * KH_TILE_A
    c_lds_bytes = BM * BN * (2 if g2_bf16_lds else 4)
    # aStages must exceed kStages: the K-loop ds_reads slot kt%aStages then
    # prefetches kt+kStages into (kt+kStages)%aStages, so equal counts make that
    # DMA rewrite the slot being read (cross-wave: waves DMA their own rows but
    # ds_read all BM rows). Only bump to 3 when the C region already covers it,
    # so lds_bytes and occupancy are unchanged; otherwise keep 2 and let
    # a_slot_alias fence the prefetch instead.
    aStages = 3 if (not g2_bf16_lds or 3 * slot_bytes <= c_lds_bytes) else 2
    a_slot_alias = aStages <= kStages
    lds_bytes = max(c_lds_bytes, aStages * slot_bytes)
    K_TILES_RT_MAX = INTER_MAX // BK
    g2_apre = g2_kstatic and aStages >= K_TILES_RT_MAX
    a_preload = min(aStages, K_TILES_RT_MAX) if g2_apre else kStages
    # N_OUT = model_dim/hidden is runtime; HIDDEN_MAX is a compile/cache bucket
    # so different runtime hidden sizes can reuse one compiled launcher.
    assert (
        HIDDEN_MAX % BN == 0
    ), f"HIDDEN_MAX must be a multiple of {BN}, got {HIDDEN_MAX}"
    if _output_n_range is None:
        output_n_base = 0
        output_width = None
        output_range_tag = ""
    else:
        output_n_base, output_n_end = _output_n_range
        if (
            output_n_base < 0
            or output_n_end > HIDDEN_MAX
            or output_n_base >= output_n_end
            or output_n_base % BN
            or output_n_end % BN
        ):
            raise ValueError(
                f"invalid output N range {_output_n_range} for "
                f"HIDDEN_MAX={HIDDEN_MAX}, BN={BN}"
            )
        if _composition is None:
            raise ValueError("output N range requires a composition")
        output_width = output_n_end - output_n_base
        output_range_tag = f"_nr{output_n_base}x{output_n_end}"

    # Kernel-name tags empty on the default so its name/IR stays byte-identical (each variant distinct).
    atag = "_a8" if is_f8 else ""
    btag = "_w8" if b_dtype == "fp8" else ""
    etag = "atomic" if not use_reduce else f"reduce_tk{topk}"
    sbm_tag = "" if SBM == BM else f"_sbm{SBM}"
    shared_scale_tag = "_shared_scale" if BM < 32 and SBM != BM else ""
    if persist and cu_num <= 0:
        raise AssertionError(f"persist=True requires cu_num>0, got {cu_num}")
    if persist and is_f8:
        # fp8-A gemm2 persist is a known-broken F2 combo (cos=0 at large M); fail fast.
        raise AssertionError(
            "a8w4/fp8-A gemm2 persist is not supported (known-broken F2 path: cos=0 at large M). "
            "Use persist only with a_dtype='fp4', or run a8w4 with persist=False."
        )
    persist_tag = "" if not persist else f"_persist_cu{cu_num}"
    bh_tag = "_bhoist" if g2_bhoist else ""
    apf_tag = "_apf" if g2_ascale_pf else ""
    spart_tag = f"_spart{g2_group_num}x{g2_m01}" if g2_spart > 0 else ""
    bf16lds_tag = "_bf16lds" if g2_bf16_lds else ""
    noil_tag = "_noil" if g2_kstatic and g2_bf16_lds and compact_route else ""
    dw_tag = "_dw" if g2_defer_weight else ""
    kst_tag = "_kst" if g2_kstatic else ""
    pitch_tag = (
        f"_pa{g2_out_pitch_align}" if (route_out_fp8 and g2_out_pitch_align) else ""
    )
    sblk_tag = f"_sblk{g2_scale_blk}" if (route_out_fp8 and g2_scale_blk != 8) else ""
    out_tag = "_fp8out" if route_out_fp8 else ""
    compact_tag = "_weighted_compact_s8" if compact_route else ""
    route_guard_tag = "_routeguard" if use_reduce else ""
    tile_tag = "" if (BN, BK) == (256, 256) else f"_bn{BN}_bk{BK}"
    bias_tag = "_bias" if enable_bias else ""
    g2_epi_lanes = _pick_epi_lanes(BM, BN, route_out_fp8, g2_scale_blk)
    tag = f"hmax{HIDDEN_MAX}_imax{INTER_MAX}_bm{BM}{tile_tag}{'_nt' if use_nt else ''}_{etag}{atag}{btag}{sbm_tag}{shared_scale_tag}{persist_tag}{bh_tag}{apf_tag}{spart_tag}{bf16lds_tag}{noil_tag}{dw_tag}{kst_tag}{pitch_tag}{sblk_tag}{out_tag}{compact_tag}{bias_tag}{output_range_tag}_v2_biasabi7{route_guard_tag}"
    name = f"gemm2_a4w4_port_{tag}"

    @fx.struct
    class SharedStorage:
        buf: fx.Array[Int8, lds_bytes, 16]

    def resolve_input_rows(arg_stids, i32_M, m_row, wave, lane):
        lanes_per_row = KH_TILE_A // 16
        rows_per_call = 64 // lanes_per_row
        rows_per_wave = BM // 4
        if rows_per_wave < rows_per_call:
            gather_base_row = (wave % fx.Int32(BM // rows_per_call)) * rows_per_call
            n_row_groups = 1
        else:
            gather_base_row = wave * rows_per_wave
            n_row_groups = rows_per_wave // rows_per_call
        lane_row = lane // lanes_per_row
        rows = []
        for g in range_constexpr(n_row_groups):
            local_row = gather_base_row + g * rows_per_call + lane_row
            packed = global_typed_ptr(arg_stids, T.i32)[m_row + local_row]
            rows.append(_input_row_resolver(packed, i32_M))
        return rows

    @flyc.jit
    def _gemm2_kernel_body(
        arg_aq,
        arg_ascale,
        arg_bq,
        arg_bscale,
        arg_eids,
        arg_cumsum,
        arg_stids,
        arg_sweights,
        arg_bias,
        arg_out,
        bx_i32,
        lane,
        wave,
        i32_M,
        i32_max_m_blocks,
        i32_inter,
        i32_hidden,
        i32_grid_blocks,
        lds,
        mn_idx=None,
        resolved_input_rows=(),
    ):
        num_n_blocks = _udiv(i32_hidden, BN)
        k_bytes = _udiv(i32_inter, 1 if is_f8 else 2)
        aq_rows = (
            fx.Int64(i32_M) * fx.Int64(topk)
            if len(resolved_input_rows) > 0
            else fx.Int64(i32_max_m_blocks) * fx.Int64(BM)
        )
        aq_num = aq_rows * fx.Int64(k_bytes)
        lds_base_i32 = fx.Int32(fx.ptrtoint(lds.buf.ptr))

        def issue_all_a_loads(m_row0):
            for slot in range_constexpr(a_preload):
                issue_a_load_lds_dt(
                    arg_aq,
                    aq_num,
                    lds_base_i32,
                    slot,
                    slot,
                    m_row0,
                    wave,
                    lane,
                    is_f8,
                    KH_TILE_A,
                    k_bytes,
                    BM=BM,
                    resolved_rows=resolved_input_rows,
                )

        def run_unit(unit_bx, mn_idx=None):
            gemm2_body_v2(
                lds_base_i32,
                arg_ascale,
                arg_bq,
                arg_bscale,
                arg_eids,
                arg_stids,
                arg_sweights,
                arg_bias,
                i32_M,
                i32_max_m_blocks,
                arg_out,
                unit_bx,
                lane,
                wave,
                arg_aq,
                i32_inter,
                i32_hidden,
                BM=BM,
                BN=BN,
                BK=BK,
                use_nt=use_nt,
                INTER_MAX=INTER_MAX,
                g2_kstatic=g2_kstatic,
                aStages=aStages,
                a_slot_alias=a_slot_alias,
                a_dtype=a_dtype,
                b_dtype=b_dtype,
                use_reduce=use_reduce,
                topk=topk,
                SBM=SBM,
                g2_bhoist=g2_bhoist,
                g2_ascale_pf=g2_ascale_pf,
                g2_bf16_lds=g2_bf16_lds,
                g2_defer_weight=g2_defer_weight,
                g2_out_pitch_align=g2_out_pitch_align,
                g2_scale_blk=g2_scale_blk,
                route_out_fp8=route_out_fp8,
                g2_epi_lanes=g2_epi_lanes,
                g2_apre=g2_apre,
                enable_bias=enable_bias,
                mn_idx=mn_idx,
                reduce_store_cache_modifier=_reduce_store_cache_modifier,
                resolved_input_rows=resolved_input_rows,
                output_n_base=output_n_base,
                output_width=output_width,
            )

        if const_expr(mn_idx is not None):
            issue_all_a_loads(mn_idx[0] * fx.Int32(BM))
            rocdl.sched_barrier(0)
            run_unit(fx.Int32(0), mn_idx=mn_idx)
        elif const_expr(not persist and g2_spart <= 0):
            # One-shot naive linear block->(m,n): issue A->LDS before the cumsum load (latency overlap).
            issue_all_a_loads(_udiv(bx_i32, num_n_blocks) * fx.Int32(BM))
            rocdl.sched_barrier(0)

            cumsum0 = global_typed_ptr(arg_cumsum, T.i32)[0]
            total_m_blocks = _udiv(cumsum0, BM)
            bound = total_m_blocks * fx.Int32(num_n_blocks)

            if fx.Int32(bx_i32) < bound:
                run_unit(bx_i32)
        elif const_expr(not persist):
            # One-shot with spatial-partitioner remap (g2_spart>0): needs M0=total_m_blocks so cumsum is read FIRST.
            cumsum0 = global_typed_ptr(arg_cumsum, T.i32)[0]
            total_m_blocks = _udiv(cumsum0, BM)
            bound = total_m_blocks * fx.Int32(num_n_blocks)

            if fx.Int32(bx_i32) < bound:
                m_block_idx, n_block_idx = _spart_output_tile_index(
                    bx_i32,
                    total_m_blocks,
                    num_n_blocks,
                    g2_group_num,
                    g2_m01,
                )
                unit_bx = m_block_idx * fx.Int32(num_n_blocks) + n_block_idx
                issue_all_a_loads(m_block_idx * fx.Int32(BM))
                rocdl.sched_barrier(0)
                run_unit(unit_bx, mn_idx=(m_block_idx, n_block_idx))
        else:
            # Persistent-m: fixed cu_num*num_n_blocks grid; each block grid-strides m-tiles by cu_num (aiter `_persist`).
            m_tile0 = _udiv(bx_i32, num_n_blocks)
            n_block = bx_i32 - m_tile0 * fx.Int32(num_n_blocks)
            c_stride = fx.Int32(cu_num)

            cumsum0 = global_typed_ptr(arg_cumsum, T.i32)[0]
            total_m_blocks = _udiv(cumsum0, BM)
            # ceil((total_m_blocks - m_tile0) / cu_num), clamped to 0 when m_tile0 >= total_m_blocks.
            diff = total_m_blocks - m_tile0
            rem = (diff > fx.Int32(0)).select(diff, fx.Int32(0))
            n_iters = _udiv(rem + c_stride - fx.Int32(1), c_stride)
            for _it in range(
                fx.Int32(0),
                n_iters,
                fx.Int32(1),
            ):
                m_block = m_tile0 + fx.Int32(_it) * c_stride
                unit_bx = m_block * fx.Int32(num_n_blocks) + n_block
                gpu.barrier()  # persist: separate prev-iter epilog C-slab LDS reads from this iter's A-load into the shared LDS union
                issue_all_a_loads(m_block * fx.Int32(BM))
                rocdl.sched_barrier(0)
                if fx.Int32(m_block) < total_m_blocks:
                    run_unit(unit_bx)

    @flyc.jit
    def _gemm2_tile(
        arg_aq,
        arg_ascale,
        arg_bq,
        arg_bscale,
        arg_eids,
        arg_stids,
        arg_sweights,
        arg_bias,
        arg_out,
        m_block_idx,
        n_block_idx,
        lane,
        wave,
        i32_M,
        i32_max_m_blocks,
        i32_inter,
        i32_hidden,
        lds,
    ):
        m_row = m_block_idx * fx.Int32(BM)
        resolved_rows = (
            ()
            if _input_row_resolver is None
            else resolve_input_rows(arg_stids, i32_M, m_row, wave, lane)
        )
        _gemm2_kernel_body(
            arg_aq,
            arg_ascale,
            arg_bq,
            arg_bscale,
            arg_eids,
            arg_stids,
            arg_stids,
            arg_sweights,
            arg_bias,
            arg_out,
            fx.Int32(0),
            lane,
            wave,
            i32_M,
            i32_max_m_blocks,
            i32_inter,
            i32_hidden,
            fx.Int32(0),
            lds,
            mn_idx=(m_block_idx, n_block_idx),
            resolved_input_rows=resolved_rows,
        )

    if _composition is not None:
        launch_gemm2 = _composition(
            module_name=name,
            emit_gemm2_tile=_gemm2_tile,
            shared_storage=SharedStorage,
        )
        if BM == 16:
            launch_gemm2.compile_hints["llvm_options"] = {"enable-post-misched": False}
        return launch_gemm2

    @flyc.kernel(name=name, known_block_size=[256, 1, 1])
    def gemm2_kernel(
        arg_aq: fx.Int64,
        arg_ascale: fx.Int64,
        arg_bq: fx.Int64,
        arg_bscale: fx.Int64,
        arg_eids: fx.Int64,
        arg_cumsum: fx.Int64,
        arg_stids: fx.Int64,
        arg_sweights: fx.Int64,
        arg_bias: fx.Int64,
        i32_M: fx.Int32,
        i32_max_m_blocks: fx.Int32,
        i32_inter: fx.Int32,
        i32_hidden: fx.Int32,
        arg_out: fx.Int64,
        arg_out_scale: fx.Int64,  # unused (atomic epilog); kept for signature parity
        i32_grid_blocks: fx.Int32,
    ):
        tx = gpu.thread_id("x")
        bx = gpu.block_id("x")
        tx_i32 = fx.Int32(tx)
        bx_i32 = fx.Int32(bx)
        lane = tx_i32 % fx.Int32(64)
        wave = rocdl.readfirstlane(T.i32, tx_i32 // fx.Int32(64))
        lds = fx.SharedAllocator().allocate(SharedStorage).peek()
        _gemm2_kernel_body(
            arg_aq,
            arg_ascale,
            arg_bq,
            arg_bscale,
            arg_eids,
            arg_cumsum,
            arg_stids,
            arg_sweights,
            arg_bias,
            arg_out,
            bx_i32,
            lane,
            wave,
            i32_M,
            i32_max_m_blocks,
            i32_inter,
            i32_hidden,
            i32_grid_blocks,
            lds,
        )

    @flyc.jit
    def launch_gemm2(
        arg_aq: fx.Int64,
        arg_ascale: fx.Int64,
        arg_bq: fx.Int64,
        arg_bscale: fx.Int64,
        arg_eids: fx.Int64,
        arg_cumsum: fx.Int64,
        arg_stids: fx.Int64,
        arg_sweights: fx.Int64,
        arg_bias: fx.Int64,
        i32_M: fx.Int32,
        i32_max_m_blocks: fx.Int32,
        i32_grid_blocks: fx.Int32,
        i32_inter: fx.Int32,
        i32_hidden: fx.Int32,
        arg_out: fx.Int64,
        arg_out_scale: fx.Int64,
        stream: fx.Stream,
    ):
        # i32_max_m_blocks sizes buffer resources; i32_grid_blocks bounds the launch to real m-blocks.
        num_n_blocks = fx.Int32(fx.Uint32(i32_hidden) // fx.Uint32(BN))
        grid_x = i32_grid_blocks * num_n_blocks
        gemm2_kernel(
            arg_aq,
            arg_ascale,
            arg_bq,
            arg_bscale,
            arg_eids,
            arg_cumsum,
            arg_stids,
            arg_sweights,
            arg_bias,
            i32_M,
            i32_max_m_blocks,
            i32_inter,
            i32_hidden,
            arg_out,
            arg_out_scale,
            i32_grid_blocks,
        ).launch(grid=(grid_x, 1, 1), block=(256, 1, 1), stream=stream)

    return launch_gemm2


# ---- launcher cache + dispatch (compile once per config, fast-dispatch after) ----
G2_CACHE = {}


def get_g2(
    BM,
    BN,
    BK,
    use_nt,
    HIDDEN_MAX,
    epilog,
    INTER_MAX,
    a_dtype,
    b_dtype="fp4",
    topk=1,
    SBM=None,
    persist=False,
    cu_num=0,
    out_dtype="bf16",
    g2_bf16_lds=None,
    g2_spart=None,
    g2_kstatic=False,
    enable_bias=False,
):
    # Cache key uses compile-time buckets; runtime inter_dim/model_dim share a
    # launcher while remaining within their respective caps.
    SBM = _norm_sbm(SBM, BM)
    out_dtype = str(out_dtype).strip().lower()
    topk_key = topk if epilog == "reduce" else 1
    cu_key = cu_num if persist else 0
    # gemm2 perf knobs enter the key; defaults ON (env override), matching compile_gemm2_a4w4_port.
    g2_bhoist = os.environ.get("MXFP4_G2_BHOIST", "1") == "1"
    g2_ascale_pf = os.environ.get("MXFP4_G2_ASCALE_PF", "1") == "1"
    if g2_spart is None:
        g2_spart = int(os.environ.get("MXFP4_G2_SPART", "402"))
    g2_spart = int(g2_spart)
    g2_kstatic = bool(g2_kstatic)
    if g2_bf16_lds is None:
        default_bf16_lds = "1" if g2_kstatic else "0"
        g2_bf16_lds = os.environ.get("MXFP4_G2_BF16_LDS", default_bf16_lds) == "1"
    g2_bf16_lds = bool(g2_bf16_lds)
    key = (
        BM,
        BN,
        BK,
        use_nt,
        HIDDEN_MAX,
        epilog,
        INTER_MAX,
        a_dtype,
        b_dtype,
        topk_key,
        SBM,
        persist,
        cu_key,
        g2_bhoist,
        g2_ascale_pf,
        g2_spart,
        g2_bf16_lds,
        g2_kstatic,
        out_dtype,
        enable_bias,
    )
    launch = G2_CACHE.get(key)
    if launch is None:
        launch = compile_gemm2_a4w4_port(
            BM=BM,
            BN=BN,
            BK=BK,
            use_nt=use_nt,
            HIDDEN_MAX=HIDDEN_MAX,
            epilog=epilog,
            INTER_MAX=INTER_MAX,
            a_dtype=a_dtype,
            b_dtype=b_dtype,
            topk=topk_key,
            SBM=SBM,
            persist=persist,
            cu_num=cu_key,
            g2_bhoist=g2_bhoist,
            g2_ascale_pf=g2_ascale_pf,
            g2_spart=g2_spart,
            g2_bf16_lds=g2_bf16_lds,
            g2_kstatic=g2_kstatic,
            out_dtype=out_dtype,
            enable_bias=enable_bias,
        )
        G2_CACHE[key] = launch
    return launch


def mxfp4_moe_gemm2(
    *,
    inter_sorted_quant,
    inter_sorted_shuffled_scale,
    w2_u8,
    w2_scale_u8,
    sorted_expert_ids,
    cumsum_tensor,
    sorted_token_ids,
    sorted_weights,
    out,
    M_logical,
    max_sorted,
    NE,
    D_HIDDEN,
    D_INTER,
    topk,
    BM=32,
    BN=256,
    BK=256,
    use_nt=False,
    a_dtype="fp4",
    b_dtype="fp4",
    epilog="atomic",
    SBM=None,
    persist=False,
    cu_num=0,
    n_sorted_padded=None,
    out_dtype="bf16",
    HIDDEN_MAX=8192,
    INTER_MAX=8192,
    g2_bf16_lds=None,
    g2_spart=None,
    stream=None,
    bias=None,
):
    """Stage-2 down-proj gemm for unpadded dimensions."""
    import torch

    _validate_v2_gemm2_dtypes(a_dtype, b_dtype)
    if persist and cu_num <= 0:
        cu_num = get_cu_num()
    SBM = _norm_sbm(SBM, BM)
    if BN not in (128, 256, 512):
        raise AssertionError(f"BN must be one of (128, 256, 512), got {BN}")
    if BK not in (128, 256):
        raise AssertionError(f"BK must be one of (128, 256), got {BK}")
    # model_dim/hidden (gemm2 N-output) is a runtime arg; validate host-side (not compile-time).
    if D_HIDDEN % BN != 0:
        raise AssertionError(
            f"D_HIDDEN (N_OUT) must be a multiple of BN ({BN}), got {D_HIDDEN}"
        )
    if D_INTER % BK != 0:
        raise AssertionError(
            f"D_INTER (K) must be a multiple of BK ({BK}), got {D_INTER}"
        )
    if D_HIDDEN > HIDDEN_MAX:
        raise AssertionError(
            f"D_HIDDEN ({D_HIDDEN}) exceeds compile cap HIDDEN_MAX ({HIDDEN_MAX})"
        )
    if D_INTER > INTER_MAX:
        raise AssertionError(
            f"D_INTER ({D_INTER}) exceeds compile cap INTER_MAX ({INTER_MAX})"
        )
    if (
        str(out_dtype).strip().lower() == "bf16"
        and getattr(out, "dtype", None) != torch.bfloat16
    ):
        raise TypeError(
            "FlyDSL v2 GEMM2 supports only torch.bfloat16 output, "
            f"got {getattr(out, 'dtype', None)}"
        )
    if sorted_weights is None:
        raise NotImplementedError(
            "FlyDSL v2 GEMM2 requires sorted_weights; "
            "doweight_stage1=True is not supported"
        )
    _kstatic = os.environ.get("MXFP4_G2_KSTATIC", "1") == "1"
    if _kstatic:
        INTER_MAX = D_INTER
    if bias is not None:
        if bias.dtype != torch.float32:
            bias = bias.to(torch.float32)
        if not bias.is_contiguous():
            bias = bias.contiguous()
    launch = get_g2(
        BM,
        BN,
        BK,
        use_nt,
        HIDDEN_MAX,
        epilog,
        INTER_MAX,
        a_dtype,
        g2_kstatic=_kstatic,
        b_dtype=b_dtype,
        topk=topk,
        SBM=SBM,
        persist=persist,
        cu_num=cu_num,
        out_dtype=out_dtype,
        g2_bf16_lds=g2_bf16_lds,
        g2_spart=g2_spart,
        enable_bias=bias is not None,
    )
    max_m_blocks = (max_sorted + BM - 1) // BM
    if persist:
        # Fixed grid: cu_num m-slots; each block loops over its m-tiles.
        grid_blocks = cu_num
    elif n_sorted_padded is not None:
        grid_blocks = n_sorted_padded // BM
    else:
        grid_blocks = min(
            max_m_blocks,
            _active_m_blocks_upper_bound(M_logical, topk, NE, BM, SBM),
        )
    out_scale = out  # unused by the atomic epilog; any valid device ptr is fine
    run_compiled(
        launch,
        inter_sorted_quant.data_ptr(),
        inter_sorted_shuffled_scale.data_ptr(),
        w2_u8.data_ptr(),
        w2_scale_u8.data_ptr(),
        sorted_expert_ids.data_ptr(),
        cumsum_tensor.data_ptr(),
        sorted_token_ids.data_ptr(),
        sorted_weights.data_ptr(),
        (bias if bias is not None else out).data_ptr(),
        M_logical,
        max_m_blocks,
        grid_blocks,
        D_INTER,
        D_HIDDEN,
        out.data_ptr(),
        out_scale.data_ptr(),
        torch.cuda.current_stream() if stream is None else stream,
    )
    return out
