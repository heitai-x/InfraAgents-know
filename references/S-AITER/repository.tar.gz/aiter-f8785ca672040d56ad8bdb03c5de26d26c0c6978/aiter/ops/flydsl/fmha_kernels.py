# SPDX-License-Identifier: MIT
# Copyright (C) 2024-2026, Advanced Micro Devices, Inc. All rights reserved.

"""High-level FlyDSL Flash Attention APIs.

``flydsl_flash_attn_batch_func`` / ``flydsl_flash_attn_varlen_func`` dispatch by
arch and dtype: gfx950 fp8 to ``kernels/fmha_gfx950``, gfx1250 bf16/f16 to the
m32x8 prefill kernel, anything else ``None`` so the caller falls through to
CK/Triton.

``flydsl_flash_attn_func`` (gfx1201 / RDNA4) wraps the
`flash_attn_func_gfx1201` kernel with:
  - Build cache keyed by (num_heads, head_dim, causal, dtype, waves_per_eu, daz).
  - Automatic seq_len padding to the kernel's tile size (multiple of 128).
  - BSHD ([B, S, H, D]) input/output convention to match upstream
    flash-attention layout.
  - Non-causal padding-ratio safety guard: padded K/V tokens contribute to
    the softmax denominator and would scale outputs. Calls with
    ``n_pad / seq_len_pad > 0.005`` (0.5%) and ``causal=False`` are rejected
    with a ``ValueError``. The 0.5% threshold is the bf16 mantissa precision
    floor plus 1 bit of margin; production Wan2.1 (S_real=32760, S_pad=32768,
    ratio=0.024%) clears it by 20x. See option (d) in
    ``2969_padded_softmax_rca.md``.

The kernel implements self-attention only (Lq == Lk). Cross-attention
(Lq != Lk) is rejected; callers should fall back to PyTorch SDPA.
"""

from __future__ import annotations

from functools import lru_cache

import torch
import torch.nn.functional as F

from .fmha_bwd_gfx942 import flash_attn_varlen_bwd_d192_gfx942
from .kernels.flash_attn_func_gfx1201 import build_flash_attn_func_module
from .kernels.fmha_gfx1250.fmha_fwd_prefill_a16w16_m32x8 import (
    flash_attn_batch_m32x8,
    flash_attn_varlen_m32x8,
)

__all__ = [
    "flydsl_flash_attn_batch_func",
    "flydsl_flash_attn_func",
    "flydsl_flash_attn_varlen_bwd",
    "flydsl_flash_attn_varlen_func",
]


# Tile size baked into the gfx1201 kernel. Seq_len must be a multiple of this.
# Picked to match BLOCK_M=128 in the kernel; padding is invisible to callers.
_KERNEL_BLOCK_M = 128

# Maximum tolerated ratio of padded tokens for non-causal attention.
# Padded K/V keys produce QK^T = 0, but exp(0) = 1 leaks into the softmax
# denominator and silently scales the output. 0.5% is the bf16 mantissa
# precision floor (~0.4%) plus 1 bit of margin. Above this the relative
# error grows quickly (50% pad -> 37% rel_err per RCA in
# 2969_padded_softmax_rca.md). Causal mode masks future tokens including
# the padded ones, so it is unaffected.
_MAX_NONCAUSAL_PAD_RATIO = 0.005


def _torch_dtype_to_str(dtype: torch.dtype) -> str:
    if dtype == torch.bfloat16:
        return "bf16"
    if dtype == torch.float16:
        return "f16"
    raise ValueError(f"flydsl_flash_attn_func only supports bf16/f16, got {dtype!r}")


@lru_cache(maxsize=32)
def _get_kernel(
    num_heads: int,
    head_dim: int,
    causal: bool,
    dtype_str: str,
    waves_per_eu: int,
    daz: bool,
):
    return build_flash_attn_func_module(
        num_heads=num_heads,
        head_dim=head_dim,
        causal=causal,
        dtype_str=dtype_str,
        waves_per_eu=waves_per_eu,
        daz=daz,
    )


def flydsl_flash_attn_func(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    causal: bool = False,
    waves_per_eu: int = 2,
    daz: bool = True,
    stream: torch.cuda.Stream | None = None,
) -> torch.Tensor:
    """Run FlyDSL Flash Attention on RDNA4 (gfx1201).

    Args:
        q, k, v: tensors with shape ``[batch, seq_len, num_heads, head_dim]``
            (BSHD). All three must share dtype, batch, num_heads, head_dim,
            and seq_len. Must reside on a CUDA/HIP device.
        causal: apply causal masking when ``True``.
        waves_per_eu: kernel occupancy hint passed to the FlyDSL builder.
        daz: enable denormals-are-zero on the kernel.
        stream: optional CUDA/HIP stream to launch on. Defaults to the current
            stream for ``q.device``.

    Returns:
        Output tensor with the same shape and dtype as ``q``.

    Raises:
        ValueError: if shapes/dtypes/devices are incompatible, the kernel's
            ``head_dim`` constraints are not met, or the non-causal padding
            ratio ``n_pad / seq_len_pad`` exceeds 0.5% (see module docstring
            for rationale).
    """
    if not (q.is_cuda and k.is_cuda and v.is_cuda):
        raise ValueError("flydsl_flash_attn_func requires CUDA/HIP tensors")
    if not (q.device == k.device == v.device):
        raise ValueError(
            "q/k/v must reside on the same device, got "
            f"q={q.device} k={k.device} v={v.device}"
        )
    try:
        arch = torch.cuda.get_device_properties(q.device.index).gcnArchName
    except Exception:  # noqa: BLE001
        arch = ""
    arch_base = arch.lower().split(":")[0] if arch else ""
    if not arch_base.startswith("gfx1201"):
        raise ValueError(f"flydsl_flash_attn_func requires gfx1201, got {arch!r}")
    if not (q.shape == k.shape == v.shape):
        raise ValueError(
            "flydsl_flash_attn_func is self-attention; q/k/v must share "
            f"shape, got q={tuple(q.shape)} k={tuple(k.shape)} v={tuple(v.shape)}"
        )
    if not (q.dtype == k.dtype == v.dtype):
        raise ValueError(f"q/k/v dtype must match: {q.dtype}/{k.dtype}/{v.dtype}")
    if q.dim() != 4:
        raise ValueError(
            f"expected 4D BSHD tensor, got rank {q.dim()} ({tuple(q.shape)})"
        )

    batch, seq_len_real, num_heads, head_dim = q.shape
    if head_dim < 64 or head_dim % 32 != 0:
        raise ValueError(
            f"kernel requires head_dim >= 64 and head_dim % 32 == 0, got {head_dim}"
        )

    dtype_str = _torch_dtype_to_str(q.dtype)

    # Pad seq_len up to the kernel's tile size. Tight padding (<= 0.5% of
    # S_pad) is empirically below the bf16 noise floor on production shapes
    # (Wan2.1 cos_sim >= 0.999992). Higher ratios are rejected upstream:
    # padded K/V tokens produce QK^T = 0 but exp(0) = 1 still contributes
    # to the softmax denominator and would scale the output. Padded queries
    # produce garbage rows that we slice off before returning.
    seq_len_pad = (
        (seq_len_real + _KERNEL_BLOCK_M - 1) // _KERNEL_BLOCK_M
    ) * _KERNEL_BLOCK_M
    n_pad = seq_len_pad - seq_len_real
    if not causal and n_pad > 0 and n_pad / seq_len_pad > _MAX_NONCAUSAL_PAD_RATIO:
        raise ValueError(
            "flydsl_flash_attn_func: non-causal path with padding ratio "
            f"{n_pad}/{seq_len_pad}={n_pad / seq_len_pad:.4f} exceeds 0.5% "
            "safety threshold; padded K/V tokens contribute to softmax "
            "denominator and would scale outputs. Either set causal=True, "
            "pad seq_len to a multiple of 128 before calling, or use a "
            "self-attn kernel with explicit attention masking."
        )
    if seq_len_pad != seq_len_real:
        pad = n_pad
        # F.pad pads from the last dim; for BSHD (last=head_dim) the seq dim
        # is dim 1, so we pad (D_left, D_right, H_left, H_right, S_left, S_right).
        q_p = F.pad(q.contiguous(), (0, 0, 0, 0, 0, pad))
        k_p = F.pad(k.contiguous(), (0, 0, 0, 0, 0, pad))
        v_p = F.pad(v.contiguous(), (0, 0, 0, 0, 0, pad))
    else:
        q_p = q.contiguous()
        k_p = k.contiguous()
        v_p = v.contiguous()

    o_p = torch.empty_like(q_p)

    # Wrap kernel build + launch in q.device context so multi-GPU callers
    # whose current device differs from q.device get the kernel compiled
    # and launched on the right device/stream.
    with torch.cuda.device(q.device.index):
        launch_stream = (
            torch.cuda.current_stream(q.device) if stream is None else stream
        )
        if launch_stream.device != q.device:
            raise ValueError(
                f"`stream` must be on {q.device}, got {launch_stream.device}"
            )
        exe = _get_kernel(
            num_heads=num_heads,
            head_dim=head_dim,
            causal=causal,
            dtype_str=dtype_str,
            waves_per_eu=waves_per_eu,
            daz=daz,
        )
        exe(
            q_p.reshape(-1),
            k_p.reshape(-1),
            v_p.reshape(-1),
            o_p.reshape(-1),
            batch,
            seq_len_pad,
            stream=launch_stream,
        )

    if seq_len_pad != seq_len_real:
        return o_p[:, :seq_len_real, :, :].contiguous()
    return o_p


@lru_cache(maxsize=64)
def _fp8_gfx950_buildable(head_dim: int, head_dim_v: int) -> bool:
    from .kernels.fmha_gfx950.pipeline import _make_dualwave_swp_fp8_traits

    for block_m in (128, 256):
        try:
            _make_dualwave_swp_fp8_traits(
                1, 1, head_dim, 6.0, head_dim_v=head_dim_v, block_m=block_m
            )
        except RuntimeError:
            return False
    return True


def _fp8_gfx950_supported(
    q,
    k,
    v,
    *,
    softmax_scale,
    dropout_p,
    window_size,
    bias,
    alibi_slopes,
    sink,
    return_attn_probs,
    block_table,
    q_descale,
    k_descale,
    v_descale,
    out,
) -> bool:
    """Gate for the gfx950 fp8 kernel.

    It needs e4m3fn Q/K/V with per-tensor descales and a positive, finite
    softmax scale, and writes bf16. Reject anything else so it falls through rather than
    silently dropping the feature.
    """
    if q.dtype is not torch.float8_e4m3fn or q_descale is None:
        return False

    from ...jit.utils.chip_info import get_gfx
    from .kernels.flash_attn_func_fp8_gfx950 import _is_valid_softmax_scale

    if get_gfx() != "gfx950":
        return False
    if not (k.dtype == v.dtype == torch.float8_e4m3fn):
        return False
    if out is not None and (out.dtype != torch.bfloat16 or not out.is_contiguous()):
        return False
    if not (q.is_cuda and k.device == q.device and v.device == q.device):
        return False
    if any(
        s is None
        or not torch.is_tensor(s)
        or s.dtype != torch.float32
        or s.numel() != 1
        or s.device != q.device
        for s in (q_descale, k_descale, v_descale)
    ):
        return False
    qk_hdim = q.shape[-1]
    if not _is_valid_softmax_scale(softmax_scale):
        return False
    if not _fp8_gfx950_buildable(qk_hdim, v.shape[-1]):
        return False
    nq, nkv = q.shape[-2], k.shape[-2]
    return (
        k.shape[-1] == qk_hdim
        and nkv > 0
        and nq % nkv == 0
        and dropout_p == 0.0
        and all(w < 0 for w in window_size[:2])
        and (len(window_size) < 3 or window_size[2] == 0)
        and bias is None
        and alibi_slopes is None
        and sink is None
        and block_table is None
        and not return_attn_probs
    )


def flydsl_flash_attn_varlen_func(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    cu_seqlens_q: torch.Tensor,
    cu_seqlens_k: torch.Tensor,
    max_seqlen_q: int,
    max_seqlen_k: int,
    softmax_scale: float | None = None,
    causal: bool = False,
    return_lse: bool = False,
    dropout_p: float = 0.0,
    window_size=(-1, -1),
    bias=None,
    alibi_slopes=None,
    deterministic=False,
    return_attn_probs=False,
    block_table=None,
    out=None,
    sink=None,
    q_descale=None,
    k_descale=None,
    v_descale=None,
):
    """FlyDSL MHA forward, varlen THD layout.

    Returns the result if FlyDSL can handle this configuration,
    otherwise returns None so the caller falls through to Triton/CK.
    """
    from ...jit.core import is_experimental_enabled
    from ...jit.utils.chip_info import get_gfx

    if (
        q.dtype is torch.float8_e4m3fn
        and q.dim() == 3
        and _fp8_gfx950_supported(
            q,
            k,
            v,
            softmax_scale=softmax_scale,
            dropout_p=dropout_p,
            window_size=window_size,
            bias=bias,
            alibi_slopes=alibi_slopes,
            sink=sink,
            return_attn_probs=return_attn_probs,
            block_table=block_table,
            q_descale=q_descale,
            k_descale=k_descale,
            v_descale=v_descale,
            out=out,
        )
    ):
        from .kernels.flash_attn_func_fp8_gfx950 import flydsl_flash_attn_fp8_func

        return flydsl_flash_attn_fp8_func(
            q,
            k,
            v,
            softmax_scale=softmax_scale,
            causal=causal,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_kv=cu_seqlens_k,
            max_seqlen_q=max_seqlen_q,
            max_seqlen_kv=max_seqlen_k,
            cross_seqlen=max_seqlen_q != max_seqlen_k,
            q_descale=q_descale,
            k_descale=k_descale,
            v_descale=v_descale,
            out=out,
            return_lse=return_lse,
        )

    # FlyDSL m32x8 serves plain MHA plus attention-sink and sliding-window; other
    # features (bias, alibi, dropout, paging, return_attn_probs) fall through to
    # CK/Triton instead of being silently dropped.
    #
    # Routing (D_v=128, bf16, gfx1250): our m32x8 kernel is the DEFAULT for qk_hdim 128 and 192.
    # qk_hdim==256 routes to us only under AITER_ENABLE_EXPERIMENTAL=1 (else CK).
    qk_hdim = q.shape[-1]
    exp = is_experimental_enabled()
    _use_fdsl_wave8_fmha = qk_hdim in (128, 192) or (qk_hdim == 256 and exp)
    # sink must be a valid [nheads_q] fp32 tensor; heads must divide;
    # window_size[2] (sink_size) is unsupported (reject so it is never silently dropped).
    _nq, _nkv = q.shape[-2], k.shape[-2]
    _sink_ok = sink is None or (
        torch.is_tensor(sink) and sink.dtype == torch.float32 and sink.shape == (_nq,)
    )
    supported = (
        get_gfx() == "gfx1250"
        and _use_fdsl_wave8_fmha
        and v.shape[-1] == 128
        and k.shape[-1] == qk_hdim
        and q.dtype in (torch.bfloat16, torch.float16)
        and k.dtype == q.dtype
        and v.dtype == q.dtype
        and _nkv > 0
        and _nq % _nkv == 0
        and dropout_p == 0.0
        and (len(window_size) < 3 or window_size[2] == 0)
        and block_table is None
        and bias is None
        and alibi_slopes is None
        and _sink_ok
        and not return_attn_probs
    )
    if not supported:
        return None

    # gfx1250 — varlen THD, D_v=128, bf16
    if out is None:
        out = torch.empty_like(q[:, :, : v.shape[-1]])

    # Clean-DSL 8-wave prefill kernel (m32x8), D_qk in {128,192,256}, D_v=128.
    return flash_attn_varlen_m32x8(
        q,
        k,
        v,
        cu_seqlens_q,
        cu_seqlens_k,
        max_seqlen_q,
        max_seqlen_k,
        softmax_scale=softmax_scale,
        causal=causal,
        window_size=window_size,
        out=out,
        return_lse=return_lse,
        sink=sink,
    )


def flydsl_flash_attn_batch_func(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    softmax_scale: float | None = None,
    causal: bool = False,
    return_lse: bool = False,
    dropout_p: float = 0.0,
    window_size=(-1, -1),
    bias=None,
    alibi_slopes=None,
    deterministic=False,
    return_attn_probs=False,
    sink=None,
    out=None,
    q_descale=None,
    k_descale=None,
    v_descale=None,
):
    """FlyDSL MHA forward, batched BSHD ``[B, S, H, D]`` layout.

    Routes gfx950 fp8 to the dual-wave kernel and gfx1250 bf16/f16 to the
    dedicated BSHD m32x8 kernel (uniform ``seq_len``, no ``cu_seqlens`` —
    CUDA-graph safe). Returns the result if FlyDSL can handle this
    configuration, otherwise returns ``None`` so the caller falls through
    to Triton/CK.
    """
    from ...jit.core import is_experimental_enabled
    from ...jit.utils.chip_info import get_gfx

    if (
        q.dtype is torch.float8_e4m3fn
        and q.dim() == 4
        and _fp8_gfx950_supported(
            q,
            k,
            v,
            softmax_scale=softmax_scale,
            dropout_p=dropout_p,
            window_size=window_size,
            bias=bias,
            alibi_slopes=alibi_slopes,
            sink=sink,
            return_attn_probs=return_attn_probs,
            block_table=None,
            q_descale=q_descale,
            k_descale=k_descale,
            v_descale=v_descale,
            out=out,
        )
    ):
        from .kernels.flash_attn_func_fp8_gfx950 import flydsl_flash_attn_fp8_func

        return flydsl_flash_attn_fp8_func(
            q,
            k,
            v,
            softmax_scale=softmax_scale,
            causal=causal,
            q_descale=q_descale,
            k_descale=k_descale,
            v_descale=v_descale,
            out=out,
            return_lse=return_lse,
        )

    # BSHD routes to the m32x8 kernel. D_v=128. D_qk 128/192 are
    # the DEFAULT; D_qk==256 needs AITER_ENABLE_EXPERIMENTAL=1 (else CK).
    qk_hdim = q.shape[-1]
    # Head count (BSHD [B,S,H,D]) and sink must satisfy the kernel's asserts, else validate
    # up front so an unsupported request returns None instead of tripping a kernel assert.
    _nq, _nkv = q.shape[-2], k.shape[-2]
    _sink_ok = sink is None or (
        torch.is_tensor(sink) and sink.dtype == torch.float32 and sink.shape == (_nq,)
    )
    supported = (
        get_gfx() == "gfx1250"
        and q.dim() == 4
        and (qk_hdim in (128, 192) or (qk_hdim == 256 and is_experimental_enabled()))
        and v.shape[-1] == 128
        and k.shape[-1] == qk_hdim
        and q.dtype in (torch.bfloat16, torch.float16)
        and k.dtype == q.dtype
        and v.dtype == q.dtype
        and _nkv > 0
        and _nq % _nkv == 0
        and _sink_ok
        and dropout_p == 0.0
        and bias is None
        and alibi_slopes is None
        and (len(window_size) < 3 or window_size[2] == 0)
        and not return_attn_probs
    )
    # No `not deterministic` gate: it is a backward-only flag (this forward is atomic-free
    # / deterministic), and flash_attn_func defaults it True — gating would reject all.
    if not supported:
        return None

    return flash_attn_batch_m32x8(
        q,
        k,
        v,
        softmax_scale=softmax_scale,
        causal=causal,
        window_size=window_size,
        out=out,
        return_lse=return_lse,
        sink=sink,
    )


def flydsl_flash_attn_varlen_bwd(
    dout: torch.Tensor,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    out: torch.Tensor,
    softmax_lse: torch.Tensor,
    dq: torch.Tensor,
    dk: torch.Tensor,
    dv: torch.Tensor,
    cu_seqlens: torch.Tensor,
    max_seqlen_q: int,
    max_seqlen_k: int,
    softmax_scale: float,
):
    """FlyDSL MHA backward, varlen THD layout.

    Returns ``(dq, dk, dv, softmax_d)`` to match ``mha_varlen_bwd`` and
    ``fmha_v3_varlen_bwd``.  The gradients are the same tensors that were passed
    in -- the kernel fills them in place -- and ``softmax_d`` is the ``[H, T]``
    fp32 ``rowsum(dO*O)`` those two also return.

    PRECONDITION: the caller has established this configuration is supported --
    causal varlen THD self-attention, d_qk=192 / d_v=128, bf16, no GQA,
    contiguous, ``[H, T]`` fp32 LSE, no dropout / sliding window / alibi / sink /
    padded cu_seqlens, on gfx942.  The authoritative gate is
    ``can_impl_fmha_bwd_flydsl`` inside ``_flash_attn_varlen_backward`` in
    ``aiter/ops/mha.py``; the screened feature arguments are absent from this
    signature precisely because that gate has already established they are unset,
    leaving no configuration for this function to branch on.
    """
    dq, dk, dv, softmax_d = flash_attn_varlen_bwd_d192_gfx942(
        dout,
        q,
        k,
        v,
        out,
        softmax_lse,
        cu_seqlens,
        max_seqlen_q,
        max_seqlen_k,
        softmax_scale,
        dq=dq,
        dk=dk,
        dv=dv,
    )
    return dq, dk, dv, softmax_d
