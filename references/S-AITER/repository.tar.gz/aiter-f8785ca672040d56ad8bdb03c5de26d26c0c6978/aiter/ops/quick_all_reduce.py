# SPDX-License-Identifier: MIT
# Copyright (C) 2024-2025, Advanced Micro Devices, Inc. All rights reserved.

import torch

from ..jit.core import (
    compile_ops,
)

MD_NAME = "module_quick_all_reduce"


@compile_ops("module_quick_all_reduce", develop=True)
def init_custom_qr(
    rank: int, world_size: int, qr_max_size: int | None = None
) -> int: ...


@compile_ops("module_quick_all_reduce", develop=True)
def qr_destroy(fa: int) -> None: ...


@compile_ops("module_quick_all_reduce", develop=True)
def qr_all_reduce(
    fa: int,
    inp: torch.Tensor,
    out: torch.Tensor,
    quant_level: int,
    cast_bf2half: bool = False,
) -> None: ...


@compile_ops("module_quick_all_reduce", develop=True)
def qr_all_reduce_rmsnorm(
    fa: int,
    inp: torch.Tensor,
    residual_inp: torch.Tensor,
    residual_out: torch.Tensor,
    out: torch.Tensor,
    weight: torch.Tensor,
    eps: float,
    hidden_dim: int,
    quant_level: int,
    cast_bf2half: bool = False,
) -> None: ...


@compile_ops("module_quick_all_reduce", develop=True)
def qr_get_handle(fa: int, out_ptr: int) -> None: ...


@compile_ops("module_quick_all_reduce", develop=True)
def qr_open_handles(fa: int, handle_ptrs: list[int]) -> None: ...


@compile_ops("module_quick_all_reduce", develop=True)
def qr_max_size() -> int: ...
