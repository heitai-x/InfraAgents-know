---
applyTo: "aiter/ops/triton/**,op_tests/triton_tests/**,op_tests/op_benchmarks/triton/**"
---

# AITER Triton ops — PR review rules

When a change violates one of these rules, flag it and point the author to the
relevant rule — reviewers may not know these conventions yet.

## PR scope — one concern per PR

- **A new kernel goes in its own PR.** Flag any PR that adds a new kernel
  together with unrelated work — a refactor, a cleanup, config retuning, or a
  fix to a different kernel — and ask for the new kernel to be split into a
  dedicated PR. A new kernel's own PR still carries its wrapper, unit test and
  benchmark (see *Tests and benchmarks*); those belong to the kernel and are
  not separate concerns.
- Keep PRs small and easy to review: one concern each, as granular as the
  change allows. Flag a PR that solves two or three independent problems at
  once — a bug fix plus a refactor, a new op plus a cleanup, retuning plus an
  API change — even when every individual change is correct.
- When flagging scope, name the specific part that should move out and say it
  belongs in a follow-up PR, so the author knows what to split rather than
  only that the PR is too large.

## Reuse before adding

Always prefer reusing existing code over adding new code. Before a PR adds a
helper, kernel, or utility, the existing ones should have been checked:
`utils/` (`config_utils` and the per-family `*_config_utils` loaders,
shuffling, arch info, logging, `kernel_repr`), `_triton_kernels/common/`
(shared split-K reduce), and existing kernels and test helpers. Flag new code
that duplicates functionality already in the tree, even partially — the fix is
to extend or import the existing implementation, not to add a parallel copy.

`utils/` is layered on purpose: `config_utils.py` holds the shared core
(`resolve_config_dir`, `load_config_json`, the path constants) and each family
keeps its own loader module (`gemm_config_utils`, `conv_config_utils`,
`mhc_config_utils`, `moe_config_utils`, `tuned_config_utils`) on top of it.
Flag a function given a second home — a re-export, a wrapper that only
forwards to another module, or a copy of a core helper inside a family module.

## Folder structure and imports

The layout is: public wrapper modules in category folders
(`gemm/{basic,batched,feed_forward,fused}/`, `attention/`, `moe/`,
`normalization/`, `quant/`, `rope/`, `fusions/`, `comms/`, `conv/`,
`gated_delta_net/`, `kimi_delta_attn/`, `gluon/`), kernel bodies under
`_triton_kernels/` at the same relative category path, or under
`_gluon_kernels/<arch>/` at the same relative category path when the Gluon
implementation is architecture-specific. Shared machinery lives in `utils/`
and tuned JSON in `configs/`. Flag:

- New modules added flat at the top of `aiter/ops/triton/` — every new
  wrapper goes in the correct category folder.
- New launchable `@triton.jit` or `@gluon.jit` kernel bodies defined inside
  public wrapper modules — Triton bodies belong under `_triton_kernels/` and
  Gluon bodies under `_gluon_kernels/<arch>/`, mirroring the wrapper's
  category path. JIT-decorated device helpers that are called only from
  another kernel may remain with the entry kernel they support.
- Generic helpers (config loading, shuffling, arch detection, logging)
  re-implemented inside a kernel file instead of imported from `utils/`.
- New code importing via the legacy flat paths
  (`from aiter.ops.triton.gemm_a16w16 import ...`) — the categorized path is
  required; `_BACKWARD_COMPAT_MAP` exists only for old external callers.
- Relative imports (`from .foo import ...`, `from ..utils import ...`) —
  only absolute imports (`from aiter.ops.triton.<...> import ...`) are
  allowed.

## Framework portability — torch stays out of `utils/_triton/`

`utils/_triton/` and the config loaders are torch-free so the kernels and
their tuned configs can be imported by a framework that is not PyTorch
(JAX-Triton is the live case). Flag:

- `import torch`, `from torch import ...` or any `torch.` use added to a
  module under `utils/_triton/`. The torch-using half belongs in `utils/` —
  split the helper rather than duplicating it (`moe_common.py` already lives
  on both sides). `utils/_triton/tunning/` is exempt: standalone tuning
  harnesses, not importable library code.
- torch newly introduced into config resolution (`utils/config_utils.py` or a
  `*_config_utils.py` family module) — loading a tuned config must not
  require torch.
- A new kernel module under `_triton_kernels/` or `_gluon_kernels/` that
  imports torch, or a first torch import added to one that is currently
  torch-free. A jit body cannot call torch; what drags it in is host-side
  glue — `torch.Tensor` annotations, dtype constants, `torch.empty`
  allocations — and that belongs in the public wrapper. Kernel modules that
  already import torch are grandfathered.

## Tuned configs: JSON placement and naming

Every tuned config lives in one nested layout:
`configs/<arch>/<backend>/<op>/<d_type>/`, e.g.
`configs/gfx950/triton/gemm/gemm_afp4wfp4/DEFAULT.json`. `<op>` is `gemm`,
`moe`, `conv`, `mhc`, `attention`, `gmm` or `fusions`; `<d_type>` is
`config_name.lower().replace("-", "_")`. The flat arch-prefixed directories
and every fallback that reached them are gone. Flag:

- A config JSON added outside `configs/<arch>/<backend>/<op>/<d_type>/` — a
  re-created `configs/gemm/`, `configs/moe/` or `configs/conv/` directory, or
  a loose file at the top of `configs/`. Nothing resolves there any more.
- An arch prefix on a filename inside `configs/<arch>/...` (wrong:
  `configs/gfx950/triton/gemm/x/gfx950-GEMM-X.json`), or a default file named
  anything other than exactly `DEFAULT.json`.
- A specialized file added to a `<d_type>/` directory that contains no
  `DEFAULT.json`, for a family whose loader requires the default — the load
  raises for every shape, not just the unspecialized ones.
- A family's files split across two `<d_type>/` directories that differ only
  by the `_dtype_dir()` fold (`GEMM-FOO-BAR` and `GEMM-FOO_BAR` collide; two
  spellings of one family must not both exist).
- A config file that is both moved and content-edited in the same commit —
  moves must be pure `git mv` renames, content changes in a follow-up.
- A new `.gitkeep` under `configs/`. A `<d_type>/` directory is created
  populated; the few `.gitkeep` files left from the migration are inert
  leftovers, not placeholders to maintain.
- A new arch directory seeded from another arch without the copy being
  byte-identical and called out in the commit message. The one seeding rule in
  force is gfx950 → gfx1250, triton only — never into a gluon directory, never
  backwards into gfx950.
- `kpack` newly added to a gfx950 config. Triton's AMD backend deprecates
  `kpack` on CDNA4 — it warns and force-overrides `kpack = 1` there, and the
  parameter is slated for removal. The gfx950 tree is clean of it; gfx942 may
  still carry it, and existing RDNA (gfx1151/gfx1201/gfx1250) entries predate
  the rule, so flag additions rather than the entries already there.
- Checked-in files under `configs/gemm/aot/` or `configs/paged_mqa_logits/aot/`
  — these are runtime AOT caches, never committed.

## Tuned configs: JSON contents

Flag, inside GEMM-family config JSON:

- Top-level `"small"` / `"large"` keys — the required scheme is `M_LEQ_<x>` /
  `M_GEQ_<x>` / `"any"`.
- A new config file with no `"any"` entry (lookup raises `KeyError` for
  uncovered M unless every reachable M hits an explicit bound).
- Entries missing required params: `BLOCK_SIZE_M`, `BLOCK_SIZE_N`,
  `BLOCK_SIZE_K`, `GROUP_SIZE_M`, `num_warps`, `num_stages`, `waves_per_eu`,
  `matrix_instr_nonkdim`, `cache_modifier`, `NUM_KSPLIT`. (Loader backfill of
  `NUM_KSPLIT`/`cache_modifier` is a last resort, not a license to omit.)
- MOE dispatch keys (`bm<block_m>_n<N>_k<K>`) in a GEMM config or GEMM
  `M_LEQ_x`/`M_GEQ_y` keys in a MOE dispatch table — the schemes must not mix.
- For `*AFP4WFP4*` specialized filenames: `K` must be the logical K
  (`2 * K_bytes`) — the wrapper doubles K before lookup, so a file named by
  the packed byte width will never resolve.

And inside MOE dispatch tables:

- A newly tuned gluon dispatch shape that does not carry all six `m2bucket`
  suffixes (`tiny`, `small`, `medium`, `medium2`, `large`, `xlarge`) — a
  missing bucket falls through to `bm<block_m>_any` and silently loses that
  shape's tuning for that M range. (Existing entries are unevenly covered;
  flag new gaps, not the ones already shipped.)
- A gluon dispatch file with no `bm<block_m>_any` tier for a `block_m` it
  otherwise covers: that tier is the last resort for an unmeasured shape.
- A `BLOCK_SIZE_M` / `block_m` key inside a dispatch entry — `block_m` is the
  dispatch key (routing decides it), not a tunable.
- Triton-shaped entry keys (`BLOCK_SIZE_N`, `num_stages`, ...) in a gluon
  dispatch file or gluon-shaped keys (`block_n`, `num_buffers`,
  `persistent_iters`) in a triton one — the two paths read disjoint params.

## Python-side config hygiene

These rules apply equally to Triton and Gluon wrappers and kernels. Tuning
values for either backend live in JSON, never in Python. Flag:

- Hardcoded tuning values in `.py` files: `config.setdefault(...)` blocks,
  inline dict literals with `BLOCK_SIZE_*`/`num_warps`/`waves_per_eu` keys,
  arch-conditional tuning constants, or hardcoded fallback configs. The fix is
  always in the JSON file, not the Python.
- A kernel-level `_get_config()` whose `backend` parameter defaults to `None`
  (or any value outside `("triton", "gluon")`) — `None` is not a backend and
  `resolve_config_dir()` asserts on it, so the kernel raises the moment a
  caller omits the argument. Kernel-level helpers default to `"triton"`;
  public wrappers that expose `backend: str | None = None` must normalize it
  before calling down.
- A new or modified Triton or Gluon GEMM `_get_config()` that does anything
  beyond calling `get_gemm_config(...)` with the appropriate backend selection
  (plus `compute_splitk_params()` for split-K kernels), and that does not
  preserve the standardized `(config, is_tuned)` result:

  ```python
  # Correct — thin wrapper
  def _get_config(M: int, N: int, K: int):
      return get_gemm_config("GEMM-A16W16", M, N, K)
  ```

- A `_get_config()` that swallows the `is_tuned` flag: the standardized
  signature returns `(config, is_tuned)` straight from `get_gemm_config()`,
  so flag new or modified `_get_config()` implementations that return a bare
  config dict. Call sites may legitimately ignore the flag
  (`config, _ = _get_config(...)` is fine) — it exists so callers and tuning
  tooling can detect a shape resolving to the untuned default and log or
  re-tune.
- Raw config-file reads — `json.load(open(...))` or function-attribute caches
  like `_get_config._config_dict` — instead of
  `aiter.ops.triton.utils.config_utils.load_config_json` (which caches per
  path, including negative results) or a family loader. All hand-rolled
  loaders were deliberately removed; do not add them back.
- Mutating the dict returned by `load_config_json()` — it is the shared cached
  object. Copy first (`dict(...)` for flat entries, `copy.deepcopy` for nested
  ones); the family loaders already copy on the caller's behalf.
- New hand-built config paths (`f"{AITER_TRITON_CONFIGS_PATH}/..."`) where a
  family loader or `resolve_config_dir()` would work — a hand-built path is a
  second place the layout is encoded, and it skips the argument validation
  that makes a wrong value fail closed.
- A second MOE config reader. `utils/moe_config_utils.py::get_moe_dispatch` is
  the only MOE fetcher; flag any new MOE path built by hand, any direct
  `load_config_json` on a `moe/` file, and any reintroduced per-wrapper MOE
  loader.
- A new arch- or backend-fallback chain inside a loader (try this arch, then
  that one; try triton, then gluon). Resolution is deterministic. MHC's gfx942
  fallback is the one documented exception and it goes through the `arch=`
  override, not through a probe.
- A raw config list handed to `@triton.autotune`. Route it through
  `autotune_configs` from `aiter.ops.triton.utils.tuned_config_utils`:

  ```python
  @triton.autotune(
      configs=autotune_configs("MY_FAMILY", _get_autotune_configs()),
      key=[...],
  )
  ```

  That returns every candidate only while `<FAMILY>_TRITON_AUTOTUNE=1`, and a
  single config otherwise, so nothing benchmarks at launch. A raw list searches
  on every new key: it costs compile time, breaks CUDA-graph capture, and leaves
  a unit test's numerics dependent on whichever config the timing happened to
  pick that run. Pass `default_config=` when the list's first entry is not the
  one to pin.

  A family that already published its own variable name keeps it by passing
  `env=` (and `default=` for what unset means), as `flash_attn_triton_amd/` does
  with `FLASH_ATTENTION_TRITON_AMD_AUTOTUNE` — it still goes through this helper.

  There are no exemptions. A candidate list read from the config JSON is a
  search space for a tuning build, not a launch-time list — handed to
  `@triton.autotune` it still benchmarks every entry on every new key. Pass it
  as `configs` and pin the launch with `default_config=`, as
  `chunk_delta_attn/flash_kda.py` does with its published K2 candidates.

## Weight & scale shuffling — must come from `utils/shuffle.py`

All weight/scale pre-shuffle helpers are unified in
`aiter/ops/triton/utils/shuffle.py`: `shuffle_weight`,
`moe_weight_decode_view`, `shuffle_scale_gemm`, `unshuffle_scale_gemm`,
`shuffle_scale_moe`, `shuffle_scale_batched`. Flag:

- Any new local re-implementation of a weight or scale shuffle in a kernel
  wrapper, kernel body, test, or benchmark — the telltale is a small helper
  doing `view(...) → permute(...) → contiguous()` on weights or scales.
  Per-kernel copies were deliberately deleted; new layouts belong in
  `utils/shuffle.py`.
- Use of the removed name `moe_weight_gfx1250_decode_view` — it was renamed
  to `moe_weight_decode_view`.
- Hardcoded `SWIZZLE_MX_SCALE` labels (`"CDNA4_SCALE"`, `"GFX1250_SCALE"`)
  next to a `shuffle_scale_moe` call — use
  `shuffle_scale_moe(..., return_layout=True)` so the caller stays
  arch-agnostic.

## Kernel conventions

- Every new launchable Triton or Gluon kernel must set a config-aware `repr`
  using `make_kernel_repr` from `aiter.ops.triton.utils._triton.kernel_repr`:

  ```python
  _kernel_repr = make_kernel_repr(
      "_kernel_name",
      ["BLOCK_SIZE_M", "BLOCK_SIZE_N", "num_warps"],
  )

  @triton.jit(repr=_kernel_repr)  # Triton entry kernel
  # or
  @gluon.jit(repr=_kernel_repr)   # Gluon entry kernel
  ```

  Flag every new launchable `@triton.jit` or `@gluon.jit` kernel without
  `repr=`. Include all meaningful compile-time/tuned config keys so trace
  names identify the specialization. JIT-decorated device helpers that cannot
  be launched independently do not require their own `repr`.
- Split-K GEMM implementations must use the shared second-stage reduce,
  regardless of whether the first-stage kernel uses Triton or Gluon —
  `_gemm_splitk_reduce_kernel` / `_batched_gemm_splitk_reduce_kernel` from
  `aiter/ops/triton/_triton_kernels/common/splitk_reduce.py`. Flag any new
  Triton or Gluon per-operation reduce kernel that duplicates it.
- Triton and Gluon kernel bodies are internal: they must be launched only
  from their public wrapper under `aiter/ops/triton/`. Flag any direct
  import or launch of a kernel from `_triton_kernels/` or `_gluon_kernels/`
  in tests, benchmarks, or code outside the wrapper layer — and flag new
  kernels that ship without a public wrapper.
- Arch handling: flag product names (`MI300`, `MI350`, `MI355`, ...) in
  identifiers, filenames, comments-as-logic, or any parsing of product
  strings. Compare architecture identifiers instead:

  ```python
  # Correct
  if DEVICE_ARCH in ("gfx950", "gfx1250"): ...
  # Wrong
  if int(DEVICE_ARCH.split("MI")[1]) >= 350: ...
  ```

- Device handling: allocate on the input's device, never a hardcoded
  `"cuda"`. `device="cuda"` resolves to the process's current default device,
  so a wrapper whose inputs live on `cuda:3` allocates its output or
  workspace on `cuda:0` — a cross-device error at best, the wrong GPU at
  worst. Flag new `device="cuda"`, `torch.device("cuda")` and `.cuda()` in
  wrappers and kernel launch code:

  ```python
  # Correct
  y = torch.empty(shape, dtype=x.dtype, device=x.device)
  # Wrong
  y = torch.empty(shape, dtype=x.dtype, device="cuda")
  ```

  Docstring examples and tests that build their own inputs may keep
  `device="cuda"`; the rule is about library code deriving the device from
  the tensors it was handed.
- Flag new public wrapper functions without a docstring covering: what the
  kernel computes, the arguments (including which config parameters apply),
  the return value, and special considerations (layout expectations,
  unsupported options).
- Keep comments and docstrings concise. Flag padded or hard-to-follow prose:
  multi-paragraph docstrings that restate the code, tutorial-style
  explanations of Triton basics, narration of what the next line does, or
  commented-out code left behind. A comment earns its place by explaining
  *why* — a non-obvious constraint, a layout requirement, an arch quirk.

## Tests and benchmarks

- Every new Triton or Gluon kernel must ship a unit test under
  `op_tests/triton_tests/<category>/`, mirroring the kernel's category (a new
  `gemm/basic/` kernel gets `op_tests/triton_tests/gemm/basic/test_<op>.py`).
  Flag PRs that add a kernel wrapper without adding or extending a matching
  test. Likewise flag a new kernel with no benchmark script — a kernel ships
  as kernel + wrapper + unit test + benchmark.
- Tests must follow the existing pattern: pytest-style `test_<op>.py` files
  inside the category folder, shared helpers in the existing
  `*_test_utils.py` / `utils/` modules. Flag tests added flat at the
  `op_tests/triton_tests/` root or as one-off scripts.
- No kernel tuning configs in test files: flag test code that hardcodes
  config dicts (`BLOCK_SIZE_*`, `num_warps`, `waves_per_eu`, ...) or passes
  literal `config=` overrides to a wrapper. Tests exercise the wrapper's own
  config resolution — tuning values live only in `configs/` JSON.
- Unit tests assert, they do not dump. Flag `print(...)` of tensors, shapes,
  or timings and any ad-hoc `if __name__ == "__main__"` reporting block in a
  test file: correctness is checked with asserts
  (`torch.testing.assert_close` and friends) so a regression fails the test
  instead of needing a human to read the log. Diagnostic output worth keeping
  goes through the logger, per the next two rules — not through `print`. A few
  older tests still print (`gemm/basic/test_gemm_a8wfp4.py`,
  `quant/test_quant.py`, `conv/_helpers.py`) — flag new dumps, not those.
- Log messages use lazy `%` placeholders, never f-strings. Flag
  `logger.info(f"...")` and `logger.info("..." + x)`: an f-string is built
  before the level check, so the message is formatted and thrown away on every
  call below the configured level. Pass the values instead —
  `logger.info("shape=%s", x.shape)` — and match the specifier to the value:
  `%d` for counts and dimensions, `%f` for thresholds and real scalars, `%s`
  for tensors, `torch.Size` shapes, tuples and strings. `%d` or `%f` on `None`
  or on a tuple raises *at log time*, and logging reports that as
  `--- Logging error ---` on stderr rather than failing the test, so flag a
  numeric specifier on a value that can be either.
- Failure diagnostics go at WARNING or ERROR, never INFO. Under pytest
  `op_tests/triton_tests/__init__.py` pins `AITER_LOG_LEVEL=WARNING`, so an
  INFO message is invisible in CI. Flag `logger.info(...)` that reports a
  mismatch, a NaN, a "FAILED", or the detail behind an assertion that is
  about to fire — converting a `print` of that kind to INFO deletes the only
  evidence a failing run leaves behind. Detail a reader needs in order to act
  belongs in the assertion message itself, where pytest always shows it.
- A test that logs its verdict instead of asserting it is broken, and the
  level change makes that visible. Flag any `if ok: log("pass") else:
  log("fail")` with no assert on the same condition: the test cannot fail.
- Debug output is gated by level, not by an `if` around the call, and not by
  a module constant. Flag `if DEBUG_MODE: logger.info(...)` and any new
  `DEBUG_MODE`-style flag: write `logger.debug(...)` and run with
  `AITER_LOG_LEVEL=DEBUG`, which `aiter/__init__.py` applies to the logger
  *and* its console handler. Flag code that lowers the level by hand after
  import (`logger.setLevel(...)`) — it leaves the handler where it was, so
  the records never come out — and flag `logging.basicConfig(...)` in a test,
  which reconfigures the root logger for the whole process at import time.
- No autotuning in unit tests: flag `@triton.autotune`, an autotune config
  sweep, or a loop over tile sizes inside a test. Tests exercise the config
  the wrapper resolves for the shape; tuning belongs in the tuning scripts
  and benchmarks.
- Benchmarks live in `op_tests/op_benchmarks/triton/` as `bench_<op>.py`,
  structured like the existing files. The config and shuffle rules above
  apply to them too: no hardcoded tuning dicts, shuffles imported from
  `aiter.ops.triton.utils.shuffle`.

## Keeping this file and the README current

Any cleanup or refactor that changes a convention under `aiter/ops/triton/` —
renaming or moving a shared helper, changing the config layout or loader
behavior, reorganizing folders, unifying duplicated code — must update
`aiter/ops/triton/README.md` **and** this instructions file in the same PR.
Flag convention-changing PRs that leave either document stale.
